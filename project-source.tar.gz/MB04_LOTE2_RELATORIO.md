# Nexo Cirúrgico — Relatório MB04, Lote 2

**Release:** 1.5.1-mb04-lote2  
**Data de referência:** 16/10/2026  
**Base preservada:** MB04 Lote 1, versão 1.5.0 (backup independente).  
**Propósito:** ensino de técnicas e segurança por simulação, para estudantes de Medicina e médicos em formação. Sem barreira editorial para leitura.

## Resultado curricular

- **21 fichas novas**, com 14 campos, sequência de preparação/simulação (mínimo cinco etapas), 5 itens de verificação, sinais de risco, referências institucionais e vínculos ao Atlas.
- **M08 Anestesia e analgesia — 10/10 tópicos com ficha:** tópica, infiltrativa, bloqueio periférico, sedação procedimental, raquianestesia, peridural, anestesia geral, estação/circuitos, toxicidade sistêmica dos anestésicos locais, recuperação pós-anestésica.
- **M09 Preparo cirúrgico — 11/11 tópicos com ficha:** avaliação, jejum, exames, consentimento/lateralidade, antimicrobianos, profilaxia tromboembólica, banho/pelos, antissepsia, marcação, posicionamento, checklist cirúrgico.
- O M16 (8/8) continua disponível; assim, **29 tópicos M08+M09+M16** têm roteiros dentro do MB04.
- **75 fichas práticas no total** (54 anteriores +21), de 227 tópicos curriculares; **52 materiais no Atlas** (41+11) e **180 variantes** (158+22). Fonte Atlas dos novos materiais: requisitos de instruções do fabricante; não converter ilustração genérica em identificação morfológica individual.
- As **33 trilhas, 115 aulas, 210 questões, 30 casos e 137 flashcards** foram preservadas; nenhum PDF comercial foi incluído no bundle.

## Material didático e limitações

As fichas são guias de preparação de materiais, reconhecimento de riscos, execução em manequim/modelo e conferência de resultados, **não protocolos para atuação autônoma**. As técnicas anestésicas invasivas exigem domínio anatômico, seleção de pacientes, resgate e supervisão; deliberadamente não se apresentam doses universais de anestésicos nem passos para execução independente de raqui/peridural. O ensino de LAST deve consultar o algoritmo ASRA atualizado; não se reproduz seu gráfico protegido. Treinamento e atualização contínua estão previstos, mas não existe bloqueio por falta de assinatura de revisor externo.

Em espanhol, **títulos e descrições iniciais** dos 21 procedimentos foram traduzidos na interface; os campos técnicos extensos **continuam em português**. A tradução integral é pendência do MB08; não exibir alegação de bilinguismo integral.

## Referências técnicas usadas para curadoria das fichas

- OMS, Surgical Safety Checklist: https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources
- NICE NG125 — prevenção de infecção cirúrgica, antissepsia e preparo de pelos: https://www.nice.org.uk/guidance/ng125/chapter/recommendations
- NICE NG180 — avaliação, preparação, tromboprofilaxia e recuperação perioperatória: https://www.nice.org.uk/guidance/ng180/chapter/recommendations
- NICE NG45 — exames pré-operatórios eletivos selecionados: https://www.nice.org.uk/guidance/ng45/chapter/recommendations
- ASA — diretrizes de jejum pré-operatório (2023), inclusive líquidos claros para *adultos saudáveis eletivos*: https://doi.org/10.1097/ALN.0000000000004381
- ASRA — LAST checklist (2020): https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity
- Bibliografia recebida para estruturação: *Manual de procedimientos médico-quirúrgicos* (Tapia Jurado, 2005), *Manual básico de procedimentos médicos hospitalares* (FMUSP, 2017), *Medicina de Emergência — Abordagem Prática* (19ª edição, 2025). Não foram copiadas imagens nem páginas.

## QA e critérios de aceite

1. `npm run qa:all`: valida conteúdo histórico, módulos, fichas, dados, idiomas, tipografia e build estático.
2. `node qa_mb04_l2.js`: 208 verificações sobre M08/M09, vínculos, 14 campos, URLs, rotas, escopo, preservação e segurança.
3. `node qa_mb03.js`: 479 verificações na matriz/rotas (incluindo 75 fichas).
4. `node qa_mb04.js`: 88 verificações de continuidade do M16.
5. O bundle estático contém somente 16 arquivos públicos; nenhuma imagem dos livros, planilha interna ou arquivo de QA é publicado.
6. **Limite de QA:** inspeção visual em Chromium não concluída neste ambiente; validação clínica da exatidão detalhada por procedimento tampouco é alegada a partir de teste de software.

## Pendências e próximo passo

O núcleo do MB04 agora cobre 29 tópicos curriculares e pode ser utilizado para estudo. Itens para futuras revisões: identificação visual individual de aparelhos, simulados de emergência anestésica e procedimentos por faixa etária, conferência de licenças de vídeos (MB06), exercícios OSCE (MB07), tradução dos campos técnicos (MB08). Não extrapolar listas genéricas de materiais para uma montagem de sala clínica real.

**Próximo passo programado:** **MB05 — Lote 1: via aérea, oxigenoterapia e procedimentos de urgência**, a partir dos tópicos M10–M12, preservando a matriz curricular e sem duplicar procedimentos canônicos.
