# Nexo Cirúrgico — MB02 Atlas de Materiais

**Versão:** 1.0  
**Data:** 14 de outubro de 2026  
**Estado:** núcleo inicial implementado; revisão clínica pendente  
**Macroblocos:** 2 de 8 entregues

## 1. Objetivo

Construir uma relação extensível entre **material → variante/calibre → procedimento → fonte**, sem misturar escalas nem converter fichas editoriais em recomendações clínicas universais. O Atlas mantém a marca provisória Nexo Cirúrgico e o foco em estudantes de Medicina e médicos em treinamento supervisionado.

## 2. Ressalvas da auditoria MB01

| Achado | Correção incorporada |
|---|---|
| MB01-01 — busca sem normalização | Função única remove acentos e pontuação; aliases clínicos e siglas; busca global retorna o tópico exato |
| MB01-02 — prioridade combinada | `priorityLevels` por módulo e tópico; P0 inclui P0–P1 e P0–P2 |
| MB01-03 — vínculos amplos | 254 relações migradas e tipadas: 97 diretas, 149 fundamentos e 8 pré-requisitos |
| MB01-04 — status apenas por módulo | Cada um dos 227 tópicos possui status, prioridade e revisão independentes |
| MB01-05 — duplicidades semânticas | 224 procedimentos canônicos; cardioversão, irrigação vesical e punção capilar compartilham ficha principal entre contextos |
| MB01-06 — metadados antigos | Descrição HTML ampliada para procedimentos técnicos, materiais e assistência perioperatória |
| MB01-07 — validação limitada | QA estrutural ampliado, `qa_atlas.js` com testes negativos e `qa_ui.js` com smoke tests funcionais |
| MB01-08 — ficha de 14 campos | Mantida como contrato para o MB03; não foi tratada indevidamente como 227 fichas concluídas |

Todos os tópicos permanecem inicialmente no estado **Catalogado**. A existência de aula relacionada não altera o estado editorial.

## 3. Entrega do MB02

- **30 materiais** com IDs estáveis; 
- **133 variantes**; 
- **7 categorias** em quatro camadas; 
- **7 sistemas de escala ou classificação**; 
- **9 fontes e requisitos de proveniência**; 
- 100% dos visuais do lote são esquemas vetoriais originais do projeto;
- nenhuma miniatura ou fotografia de terceiros foi copiada;
- rota `#/atlas` e páginas `#/atlas/MAT-...`;
- filtros por categoria, escala e aplicação;
- busca tolerante a acentos, siglas, nomes comuns e dimensões;
- links bidirecionais com a matriz técnica;
- compatibilidades condicionais e incompatibilidades explícitas;
- estado de revisão separado de publicação clínica.

## 4. Catálogo inicial

| ID | Material | Categoria | Escala | Variantes | Procedimentos |
|---|---|---|---|---:|---:|
| MAT-VAS-001 | Cateter intravenoso periférico | Dispositivos vasculares | G | 8 | 2 |
| MAT-VAS-002 | Dispositivo alado para acesso vascular | Dispositivos vasculares | G | 4 | 2 |
| MAT-VAS-003 | Cateter central de inserção periférica | Dispositivos vasculares | Fr | 5 | 1 |
| MAT-VAS-004 | Cateter venoso central não tunelizado | Dispositivos vasculares | Fr | 5 | 1 |
| MAT-VAS-005 | Cateter arterial | Dispositivos vasculares | G | 4 | 2 |
| MAT-INF-001 | Conector sem agulha | Infusão e conexões | Sem escala | 3 | 2 |
| MAT-INF-002 | Extensor de infusão | Infusão e conexões | Sem escala | 2 | 2 |
| MAT-INF-003 | Equipo de infusão | Infusão e conexões | Sem escala | 3 | 2 |
| MAT-MED-001 | Seringa descartável | Seringas e acesso medicamentoso | mL | 7 | 2 |
| MAT-MED-002 | Agulha hipodérmica descartável | Seringas e acesso medicamentoso | G | 9 | 4 |
| MAT-MED-003 | Bomba de infusão | Seringas e acesso medicamentoso | Sem escala | 2 | 1 |
| MAT-INF-004 | Torneira de três vias | Infusão e conexões | Sem escala | 2 | 2 |
| MAT-SON-001 | Cateter urinário de demora tipo Foley | Sondas e drenagem | Fr | 7 | 2 |
| MAT-SON-002 | Cateter urinário intermitente tipo Nelaton | Sondas e drenagem | Fr | 7 | 2 |
| MAT-SON-003 | Sonda gástrica ou enteral | Sondas e drenagem | Fr | 7 | 3 |
| MAT-SON-004 | Conector enteral ENFit | Sondas e drenagem | Sem escala | 2 | 2 |
| MAT-AIR-001 | Tubo endotraqueal | Via aérea e oxigenação | mm-ID | 14 | 1 |
| MAT-AIR-002 | Bolsa-válvula-máscara | Via aérea e oxigenação | Sem escala | 3 | 2 |
| MAT-AIR-003 | Cânula nasal de oxigênio | Via aérea e oxigenação | Sem escala | 3 | 1 |
| MAT-SUT-001 | Fio de sutura de nylon | Fechamento e suturas | USP | 5 | 3 |
| MAT-SUT-002 | Fio de sutura de poliglactina | Fechamento e suturas | USP | 5 | 2 |
| MAT-SUT-003 | Agulha cirúrgica | Fechamento e suturas | Sem escala | 3 | 1 |
| MAT-INS-001 | Cabo de bisturi | Instrumentais cirúrgicos | blade | 2 | 2 |
| MAT-INS-002 | Lâmina de bisturi | Instrumentais cirúrgicos | blade | 9 | 2 |
| MAT-INS-003 | Porta-agulhas Mayo-Hegar | Instrumentais cirúrgicos | pattern | 2 | 1 |
| MAT-INS-004 | Pinça Adson | Instrumentais cirúrgicos | pattern | 2 | 1 |
| MAT-INS-005 | Pinça hemostática Kelly | Instrumentais cirúrgicos | pattern | 2 | 1 |
| MAT-INS-006 | Tesoura Metzenbaum | Instrumentais cirúrgicos | pattern | 2 | 1 |
| MAT-INS-007 | Tesoura Mayo | Instrumentais cirúrgicos | pattern | 2 | 1 |
| MAT-INS-008 | Afastador Farabeuf | Instrumentais cirúrgicos | pattern | 2 | 1 |

## 5. Sistemas de escala

| Código | Sistema | Regra | Precaução |
|---|---|---|---|
| G | Gauge | Número legado associado ao diâmetro externo; números menores representam diâmetros maiores dentro da mesma família. | Agulhas hipodérmicas e cateteres intravenosos usam códigos de cor distintos. Verifique família, marcação e IFU; não use somente a cor. |
| Fr | French / Charrière | Escala de diâmetro externo: 1 Fr corresponde a aproximadamente 0,33 mm; diâmetro externo em mm = Fr ÷ 3. | O diâmetro interno e o fluxo variam com material, parede, lúmens e fabricante. |
| USP | Numeração USP de suturas | Classificação nominal de diâmetro e desempenho; mais zeros indicam fios mais finos, enquanto números inteiros crescentes indicam fios mais grossos. | Faixas de diâmetro podem variar por classe/material. Não converter para milímetros sem monografia e produto específicos. |
| mm-ID | Milímetros — diâmetro interno | Dimensão interna nominal usada, entre outros exemplos, em tubos endotraqueais. | Diâmetro interno, diâmetro externo, comprimento e conectores são dimensões diferentes. |
| mL | Mililitros | Capacidade nominal de seringas e reservatórios; não representa calibre. | Precisão, graduação, espaço morto e conector dependem do produto. |
| blade | Número de lâmina | Identificador de formato de lâmina e compatibilidade de cabo, não uma escala linear de tamanho. | Confirmar encaixe com o cabo e instruções do fabricante. |
| pattern | Padrão ou modelo | Nome de desenho, forma ou função do instrumental; não equivale a tamanho universal. | Comprimento, ponta, serrilha, cremalheira e fabricante devem constar na especificação. |

### Regras editoriais

- Gauge é interpretado dentro da família do dispositivo; cores de agulhas hipodérmicas e cateteres IV não são tratadas como uma única sequência.
- French descreve diâmetro externo aproximado; lúmen interno e fluxo dependem do produto.
- USP de suturas não é convertido para uma tabela universal em milímetros.
- Diâmetro interno de tubo endotraqueal não equivale ao diâmetro externo.
- Número de lâmina identifica formato/encaixe, não uma escala linear.
- Cor nunca substitui leitura da embalagem, modelo, lote ou instrução de uso.

## 6. Modelo de dados

Cada material registra:

1. `id`, nome preferencial e aliases;
2. categoria e descrição;
3. aplicações gerais, riscos, precauções e alternativas;
4. sistema de escala, quando aplicável;
5. variantes com dimensões, conectores e contexto de cor;
6. vínculo muitos-para-muitos com tópicos `PT-Mxx-yy`;
7. compatibilidades condicionais;
8. proveniência por fonte ou requisito de fabricante;
9. visual com autor, licença e texto alternativo;
10. versão e estado de revisão.

## 7. Fontes e requisitos

| ID | Organização | Documento | Estado |
|---|---|---|---|
| SRC-MAT-WHO-PIV-2024 | World Health Organization | [Guidelines for the prevention of bloodstream infections associated with peripheral catheters](https://www.who.int/publications/i/item/9789240093829) | verificada |
| SRC-MAT-WHO-CVC-2026 | World Health Organization | [Guidelines for the prevention of bloodstream infections associated with central venous catheters](https://www.who.int/publications/i/item/9789240121805) | verificada |
| SRC-MAT-ISO-10555-5 | ISO | [ISO 10555-5:2013 — Over-needle peripheral catheters](https://www.iso.org/standard/54885.html) | vigente-em-revisao |
| SRC-MAT-ISO-6009 | ISO | [ISO 6009:2016 — Hypodermic needles colour coding](https://www.iso.org/standard/63277.html) | vigente |
| SRC-MAT-FDA-FOLEY | U.S. Food and Drug Administration | [Conventional Foley Catheters — Safety and Performance Based Pathway](https://www.fda.gov/media/130865/download) | verificada |
| SRC-MAT-FDA-SUTURE | U.S. Food and Drug Administration | [Surgical Sutures — Safety and Performance Based Pathway](https://www.fda.gov/media/157490/download) | verificada |
| SRC-MAT-ISO-80369-3 | ISO | [ISO 80369-3:2016 — Connectors for enteral applications](https://www.iso.org/standard/50731.html) | vigente |
| SRC-MAT-CDC-INJECTION | Centers for Disease Control and Prevention | [Preventing Unsafe Injection Practices](https://www.cdc.gov/injection-safety/hcp/clinical-safety/) | verificada |
| SRC-MAT-IFU | Fabricante e registro sanitário aplicáveis | Instruções de uso do fabricante do item selecionado | obrigatoria-antes-validacao |

Normas ISO integrais podem exigir licença. O Atlas referencia título, edição e página oficial, sem reproduzir tabelas protegidas além de fatos necessários à identificação e síntese editorial própria.

## 8. Política visual

Todos os cartões usam SVG original embutido, com:

- autor: Nexo Cirúrgico;
- licença: original do projeto;
- ID do ativo;
- texto alternativo.

Futuras fotografias ou ilustrações só poderão ser adicionadas com URL original, autor, licença, crédito e data de verificação.

## 9. Testes de aceite

### Buscas demonstradas

- `jelco`;
- `cateter intravenoso`;
- `IV`;
- `24G`;
- `sonda Foley`;
- `14 Fr`;
- `nylon 4-0`;
- `lâmina 15`;
- `ECG`;
- `puncao`.

### Validadores

- `node qa_content.js`;
- `node qa_assessment.js`;
- `node qa_atlas.js`;
- `npm run qa:ui` após `npm install`.

`qa_atlas.js` executa testes negativos para ID duplicado, tópico inexistente, escala inválida, proveniência ausente, variante sem confirmação de fabricante, compatibilidade quebrada, status editorial inválido e prioridade inconsistente.

## 10. Regressão e preservação

Uma comparação profunda com o ZIP aprovado do MB01 confirmou identidade integral dos objetos anteriores: módulos, aulas, flashcards, questões, checklists, vídeos, referências, competências, blueprint, casos, planos de estudo e remediação. O MB02 acrescenta `materialAtlas` e corrige somente a arquitetura de expansão e o roadmap.

## 11. Limites

- As 30 fichas estão em **revisão editorial**, não validadas clinicamente.
- Não há recomendação universal de calibre, cor, tamanho, conector ou material.
- Seleção depende de paciente, procedimento, terapêutica, ambiente, protocolo e produto.
- Informações condicionais exigem verificação da instrução de uso vigente.
- O Atlas não autoriza execução autônoma de procedimento invasivo.
- O banco anterior permanece com 33 trilhas, 115 aulas, 210 questões e 30 casos.

## 12. Próximo macrobloco

O **MB03 — Procedimentos fundamentais** deverá preencher fichas canônicas prioritárias usando os materiais do Atlas, começando por acesso venoso periférico, coleta, administração, feridas, curativos, suturas e imobilizações. Nenhum tópico deve avançar a “Validado” sem revisor clínico documentado.
