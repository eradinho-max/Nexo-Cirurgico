/* MB03: internacionalizacao parcial e HONESTA. Nao traduza clinica por substituicao cega. */
(() => {
  const translations = {
    'Início':'Inicio','Matriz Técnica':'Matriz técnica','Procedimentos':'Procedimientos',
    'Atlas de Materiais':'Atlas de materiales','Casos':'Casos clínicos','Checklists':'Listas de verificación',
    'Avaliações':'Evaluaciones','Biblioteca de aulas':'Biblioteca de clases',
    'Planos de estudo':'Planes de estudio','Flashcards':'Tarjetas de estudio',
    'Desafio rápido':'Desafío rápido','Meu progresso':'Mi progreso',
    'Plano de reforço':'Plan de refuerzo','Videoteca':'Videoteca',
    'Fontes e créditos':'Fuentes y créditos','Roadmap':'Hoja de ruta',
    'ESTUDAR':'ESTUDIAR','RECURSOS':'RECURSOS','PLATAFORMA':'PLATAFORMA',
    'BUSCA GLOBAL':'BÚSQUEDA GLOBAL','Voltar':'Volver',
    'Buscar procedimentos, aulas, temas ou materiais...':'Buscar procedimientos, clases, temas o materiales...',
    'Instrumentação cirúrgica':'Instrumentación quirúrgica',
    'Cirurgia geral':'Cirugía general','Cirurgia geral e digestiva':'Cirugía general y digestiva',
    'Anestesia e analgesia':'Anestesia y analgesia','Feridas e lesões':'Heridas y lesiones',
    'Suturas e fechamento':'Suturas y cierre','Preparo cirúrgico':'Preparación quirúrgica',
    'Via aérea e oxigenoterapia':'Vía aérea y oxigenoterapia',
    'Ortopedia e imobilização':'Ortopedia e inmovilización',
    'Cuidados pós-operatórios':'Cuidados posoperatorios',
    'Acessos vasculares':'Accesos vasculares',
    'Pediatria e neonatologia':'Pediatría y neonatología',
    'Ginecologia e obstetrícia':'Ginecología y obstetricia',
    'Diagnóstico à beira-leito':'Diagnóstico a pie de cama',
    'Documentação e comunicação':'Documentación y comunicación',
    'Procedimentos ambulatoriais':'Procedimientos ambulatorios',
    'Otorrinolaringologia':'Otorrinolaringología',
    'Segurança cirúrgica':'Seguridad quirúrgica'
  };
  const langSelect=document.getElementById('languageSelector');
  const minus=document.getElementById('readerSmaller');
  const plus=document.getElementById('readerLarger');
  const notice=document.getElementById('localePending');
  const get=(key,fallback)=>{try {return localStorage.getItem(key)||fallback;}catch{return fallback;}};
  const set=(key,val)=>{try{localStorage.setItem(key,val);}catch{}};
  let lang=get('nexo-ui-language','pt');
  if(!['pt','es'].includes(lang))lang='pt';
  let font=Number(get('nexo-reader-font','18'));
  if(![16,18,20,22].includes(font))font=18;
  const navOriginal=new Map();
  document.querySelectorAll('.side-nav a > span:last-child,.side-nav .nav-label').forEach(el=>navOriginal.set(el,el.textContent.trim()));
  const originalPlaceholder=document.getElementById('globalSearch').placeholder;
  function refreshText(){
    document.documentElement.lang=lang==='es'?'es':'pt-BR';
    for(const [el,orig] of navOriginal)el.textContent=lang==='es'?(translations[orig]||orig):orig;
    const search=document.getElementById('globalSearch');
    search.placeholder=lang==='es'?translations[originalPlaceholder]:originalPlaceholder;
    search.setAttribute('aria-label',lang==='es'?'Búsqueda global':'Busca global');
    const title=document.getElementById('pageTitle');
    if(title){let val=title.textContent.trim();if(lang==='es'&&translations[val])title.textContent=translations[val];}
    notice.hidden=lang!=='es';
    if(lang==='es')notice.textContent='Interfaz en español (versión preliminar). Las 115 clases y las 46 fichas clínicas siguen en portugués hasta su traducción y revisión especializada.';
    langSelect.value=lang;
  }
  function refreshFont(){document.documentElement.style.setProperty('--nexo-reader-size',`${font}px`);minus.disabled=font<=16;plus.disabled=font>=22;set('nexo-reader-font',String(font));}
  langSelect.addEventListener('change',()=>{lang=langSelect.value;set('nexo-ui-language',lang);refreshText();window.dispatchEvent(new Event('hashchange'));});
  minus.addEventListener('click',()=>{font=Math.max(16,font-2);refreshFont();});
  plus.addEventListener('click',()=>{font=Math.min(22,font+2);refreshFont();});
  const title=document.getElementById('pageTitle');
  if(title)new MutationObserver(()=>{if(lang==='es'){const val=title.textContent.trim();if(translations[val])title.textContent=translations[val];}}).observe(title,{childList:true,characterData:true,subtree:true});
  refreshFont();refreshText();
})();
