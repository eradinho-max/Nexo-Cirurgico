/* MB04 Lote 2: verificação de contrato curricular, segurança, navegação e regressão. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const dir=__dirname, errors=[];let checks=0;
function ok(name,yes){checks++;if(!yes)errors.push(name)}
function el(){return{innerHTML:'',textContent:'',value:'',style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelectorAll:()=>[],querySelector:()=>null,focus(){},parentElement:{addEventListener(){},contains(){return false},classList:{add(){},remove(){}}}}}
function load(){const events={},els={},location={hash:'#/dashboard'},window={};const ctx={window,console,location,localStorage:{getItem:()=>null,setItem(){}},setTimeout:()=>0,clearTimeout(){},requestAnimationFrame:()=>{}};const document={title:'',querySelectorAll:()=>[],addEventListener(){},getElementById(id){return els[id]||(els[id]=el())}};Object.assign(ctx,{document});Object.assign(window,{window,document,location,localStorage:ctx.localStorage,scrollTo(){},addEventListener:(n,fn)=>events[n]=fn});vm.createContext(ctx);for(const file of ['data.js','procedimentos_mb03.js','procedimentos_mb04_l2.js','app.js'])vm.runInContext(fs.readFileSync(path.join(dir,file),'utf8'),ctx,{filename:file});return{window,events,els,location};}
const t=load();const d=t.window.NEXO_DATA,p=t.window.NEXO_PROCEDURES.procedures;const atlas=d.materialAtlas.materials,topics=d.technicalCurriculum.modules.flatMap(x=>x.topics),ids=d.technicalCurriculum.lessonSchema.map(f=>f.id);
const target=p.filter(x=>/^PT-M0[89]-/.test(x.id));
ok('75 fichas com IDs únicos',p.length===75&&new Set(p.map(x=>x.id)).size===75);
ok('21 fichas MB04 L2 sem duplicação',target.length===21&&new Set(target.map(x=>x.id)).size===21);
ok('10/10 anestesia e 11/11 preparo',p.filter(x=>x.id.startsWith('PT-M08-')).length===10&&p.filter(x=>x.id.startsWith('PT-M09-')).length===11);
ok('M08 e M09 sem tópicos pendentes de ficha',d.technicalCurriculum.modules.filter(m=>['M08','M09'].includes(m.id)).every(m=>m.topics.every(x=>target.some(p=>p.id===x.id))));
ok('52 materiais identificados',atlas.length===52);
ok('22 variantes novas sem repetição',atlas.filter(x=>x.id.startsWith('MAT-ANE-')).reduce((s,x)=>s+x.variants.length,0)===22&&new Set(atlas.flatMap(x=>x.variants.map(v=>v.id))).size===atlas.flatMap(x=>x.variants).length);
ok('Acervo anterior preservado',d.modules.length===33&&d.modules.flatMap(m=>m.lessons).length===115&&d.quiz.length===210&&d.cases.length===30&&d.flashcards.length===137);
ok('227 tópicos curriculares estáveis',topics.length===227);
for(const x of target){
 ok(x.id+' 14 campos preenchidos',ids.length===14&&ids.every(id=>Array.isArray(x.fields[id])&&x.fields[id].length));
 ok(x.id+' técnica de simulação + checklist',x.fields.sequence.length>=5&&x.fields['skills-checklist'].length>=5);
 ok(x.id+' riscos e contraindicações',x.criticalErrors.length>=3&&x.fields.contraindications[0].length>35);
 ok(x.id+' material rastreável',x.materialLinks.length>=1&&x.materialLinks.every(mid=>atlas.some(m=>m.id===mid&&m.procedureLinks.some(z=>z.topicId===x.id))));
 ok(x.id+' fontes e URLs',x.references.length>=2&&x.references.every(ref=>ref.url.startsWith('https://')));
 ok(x.id+' supervisão e preparo individualizados',x.supervision.includes('supervisão')&&x.population&&x.fields.patient.length);
 ok(x.id+' estado não bloqueante',x.editorial.status==='em-desenvolvimento'&&x.editorial.clinicalReviewer===null);
 const topic=topics.find(z=>z.id===x.id);ok(x.id+' vínculo curricular',topic&&topic.status==='em-desenvolvimento'&&topic.revision.version==='0.2-MB04-L2');
}
function render(path){t.location.hash='#/'+path;t.events.hashchange();return t.els.app.innerHTML;}
for(const x of target){const html=render('procedimento/'+x.id);ok('rota '+x.id,html.includes('class="procedure-header"')&&html.includes('mb04-quick')&&(html.match(/class="panel procedure-field"/g)||[]).length===14);}
ok('75 cartões na biblioteca', (render('procedimentos').match(/class="procedure-card"/g)||[]).length===75);
for(const mod of ['M08','M09']){const html=render('matriz-tecnica/'+mod);ok('links funcionais M08/M09 '+mod,(html.match(/Abrir ficha técnica/g)||[]).length=== (mod==='M08'?10:11));}
ok('roadmap contagem 29',render('roadmap').includes('29 procedimentos operacionais no MB04'));
const index=fs.readFileSync(path.join(dir,'index.html'),'utf8');ok('script MB04 vinculado antes do app',index.indexOf('procedimentos_mb04_l2.js')>index.indexOf('procedimentos_mb03.js')&&index.indexOf('procedimentos_mb04_l2.js')<index.indexOf('app.js'));
const es=fs.readFileSync(path.join(dir,'idiomas.js'),'utf8');for(const term of ['Anestesia por infiltración','Evaluación preoperatoria','Lista de verificación de cirugía segura']) ok('tradução ES '+term,es.includes(term));
for(const bad of ['mg/kg universal','dose padronizada sem avaliação','copiar figura do livro']) ok('sem instrução inadequada: '+bad,!target.some(x=>JSON.stringify(x.fields).includes(bad)));
console.log(JSON.stringify({status:errors.length?'FALHOU':'APROVADO',checks,passed:checks-errors.length,procedures:p.length,l2:target.length,materials:atlas.length,errors},null,2));if(errors.length)process.exit(1);
