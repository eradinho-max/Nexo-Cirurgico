from pathlib import Path
import json,subprocess
r=Path(__file__).parent
p=json.loads(subprocess.check_output(['node','-e',"let fs=require('fs'),vm=require('vm'),x={window:{}};vm.runInNewContext(fs.readFileSync('data.js','utf8'),x);vm.runInNewContext(fs.readFileSync('procedimentos_mb03.js','utf8'),x);console.log(JSON.stringify(x.window.NEXO_PROCEDURES.procedures.map(p=>p.fields.definition[0])))"],cwd=r).decode())
spanish='''Práctica fundamental para interrumpir la transmisión cruzada de microorganismos y proteger al paciente y al equipo.
Administración de un fármaco en el tejido muscular, respetando la indicación de la vía y la formulación autorizada.
Introducción de un catéter corto en una vena periférica para tratamiento intravenoso y otras indicaciones clínicas.
Obtención de una muestra venosa para análisis de laboratorio con trazabilidad preanalítica.
Exploración estructurada de la lesión para decidir la urgencia, la limpieza, los estudios de imagen, el cierre y el seguimiento.
Limpieza mecánica mediante un flujo de líquido para disminuir contaminantes antes de decidir el cierre.
Selección, colocación y cambio de cobertura para proteger el lecho de la herida y controlar el exudado.
Abordaje de lesiones con posible inoculación de microorganismos por saliva, incluido el riesgo de rabia en determinadas exposiciones.
Técnica de aproximación cutánea con puntos separados, adecuada para algunas heridas después de la evaluación.
Inmovilización no circunferencial de la muñeca y el antebrazo como soporte temporal o terapéutico en determinadas indicaciones.
Examen seriado de perfusión, sensibilidad y función motora distal en traumatismos y después de colocar férulas o yesos.
Determinación de glucosa en el punto de atención con un dispositivo apropiado y control de calidad.
Evaluación organizada de heridas traumáticas, quirúrgicas o crónicas sin confundir los distintos sistemas de clasificación.
Retirada controlada de dispositivos de cierre después de valorar la reparación tisular y el riesgo de dehiscencia.
Registro no invasivo de la actividad eléctrica del corazón mediante la colocación normalizada de electrodos y la correcta identificación.
Administración superficial en la dermis para indicaciones autorizadas; no confundir con las vías intramuscular y subcutánea.
Administración en el tejido adiposo subcutáneo cuando la formulación y la prescripción lo permiten.
Administración intravenosa del medicamento prescrito a través de un acceso permeable y compatible.
Administración controlada de soluciones o fármacos intravenosos por gravedad o mediante un dispositivo apropiado.
Preparación aséptica de la forma farmacéutica y de la concentración prescrita.
Control programable de velocidad, volumen y duración en sistemas de infusión compatibles.
Conjunto de medidas de seguridad para medicamentos cuyo uso erróneo puede producir un daño importante.
Extracción aséptica de muestras de sangre para detectar microorganismos ante una sospecha de infección del torrente sanguíneo.
Control inmediato del sangrado externo e identificación de una posible hemorragia grave.
Eliminación de suciedad y partículas accesibles después de evaluar las estructuras comprometidas y los riesgos.
Evaluación clínica de una posible infección local o diseminada, o de una complicación de la cicatrización.
Seguimiento de la cicatrización, indicaciones para el paciente y vigilancia de las complicaciones de las heridas.
Cierre secuencial mediante un hilo continuo, seleccionado de acuerdo con el tejido y la tensión.
Técnica de eversión de los bordes mediante pasadas a diferentes profundidades.
Punto de aproximación y distribución de la tensión entre segmentos de los bordes.
Aproximación cutánea mediante un trayecto dérmico, generalmente para heridas limpias de baja tensión.
Aproximación de planos profundos para disminuir la tensión superficial y el espacio muerto.
Cierre externo sin sutura para determinadas heridas superficiales de baja tensión.
Cierre mecánico superficial de incisiones o de ciertas heridas.
Férula no circular que limita la pronación y la supinación del antebrazo y estabiliza lesiones seleccionadas.
Inmovilización no circunferencial de la pierna y el tobillo, útil durante el edema inicial.
Inmovilización rígida circunferencial, generalmente cuando la situación del edema y la estabilidad lo permiten.
Reconocimiento del aumento de presión en un compartimento musculofascial con riesgo de isquemia.
Identificar hilos absorbibles y no absorbibles, monofilamentos y multifilamentos, con diferencias de memoria, resistencia y respuesta tisular.
Diferenciar agujas cilíndricas, cortantes y de corte reverso, con la curvatura y la colocación adecuadas al tejido.
Soporte provisional del miembro superior para comodidad y limitación del movimiento en determinadas lesiones.
Inmovilización temporal del brazo en determinadas situaciones, protegiendo las prominencias óseas.
Férula para inmovilizar selectivamente pulgar y muñeca ante lesiones o sospechas que requieren protección.
Estabilización de determinadas lesiones de los dedos, con protección cutánea y alineación anatómica.
Dispositivo para restringir el movimiento cervical en determinados pacientes, integrado en la evaluación traumatológica.
Evaluación del tejido desvitalizado y de las modalidades de retirada de tejido, en el entorno adecuado y por personal competente.'''.splitlines()
assert len(p)==len(spanish),(len(p),len(spanish))
d=json.loads((r/'i18n-catalog.es.json').read_text())
for a,b in zip(p,spanish):d[a]=b
(r/'i18n-catalog.es.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('translated 46 procedure summaries; dict entries',len(d))
