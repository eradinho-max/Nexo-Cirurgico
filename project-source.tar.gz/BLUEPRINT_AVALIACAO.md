# Nexo Cirúrgico — blueprint de competências e avaliação

**Versão:** 1.2  
**Data:** 13 de outubro de 2026  
**Estado:** núcleo e expansão P2 estruturados; auditoria clínica e piloto adiados até a conclusão editorial

---

## 1. Objetivo

O blueprint liga conteúdo, competência, dificuldade, questão, caso situacional e fonte. Ele evita que o simulado seja apenas uma coleção de perguntas fáceis ou concentradas nos temas mais simples de escrever.

O banco atual possui:

- **28 competências**;
- **210 questões**;
- **30 casos situacionais sintéticos**;
- **72 fontes catalogadas**, incluindo referências P2 e de acessos verificadas em 13/10/2026;
- justificativa, dificuldade, competência e fontes vinculadas em cada item.

Os números atendem à meta estrutural. Isso **não significa que os itens estejam clinicamente validados**. O próximo gate exige revisão independente, piloto e análise de desempenho.

---

## 2. Domínio cognitivo

| Nível | Itens | Percentual | Objetivo |
|---|---:|---:|---|
| Básico | 53 | 25,2% | Reconhecer conceitos, riscos e elementos essenciais |
| Aplicação | 115 | 54,8% | Escolher a conduta segura em contexto típico |
| Análise | 42 | 20,0% | Priorizar, reconciliar e escalonar em situação ambígua |
| **Total** | **210** | **100%** | — |

A distribuição aproxima a meta de 25% básico, 55% aplicação e 20% análise.

### Distribuição das posições de gabarito

| Tipo | A | B | C | D |
|---|---:|---:|---:|---:|
| Questões | 53 | 53 | 52 | 52 |
| Casos | 8 | 8 | 7 | 7 |

A distribuição foi corrigida após a auditoria detectar concentração excessiva na alternativa B. A ordem das alternativas foi alterada sem mudar o conteúdo das respostas corretas.

---

## 3. Matriz de competências

| ID | Competência | Questões | Casos | Fonte central |
|---|---|---:|---:|---|
| C01 | Instrumentais cirúrgicos | 9 | 0 | SOBECC; AORN |
| C02 | Fios e suturas | 8 | 0 | revisão clínica de materiais de sutura |
| C03 | Posicionamento | 8 | 2 | revisão sistemática; AORN/SOBECC |
| C04 | Técnica asséptica | 10 | 2 | Anvisa ISC 2025; SOBECC |
| C05 | Anatomia aplicada | 6 | 0 | OpenStax 1e como apoio; revisão específica futura |
| C06 | Fluxo do procedimento | 7 | 0 | cirurgia segura; espécimes; RDC 15 |
| C07 | Ambiente e equipe | 7 | 0 | SOBECC; NR-32; Cofen |
| C08 | Cirurgia segura | 10 | 3 | Ministério da Saúde; OMS |
| C09 | Prevenção de ISC | 9 | 1 | Anvisa 2025; CDC/SHEA |
| C10 | Contagens | 9 | 2 | OMS; SOBECC |
| C11 | Espécimes e implantes | 8 | 2 | AORN; RDC 36 |
| C12 | CME e processamento | 11 | 2 | RDC 15; OMS |
| C13 | Energia, fogo e fumaça | 9 | 2 | AORN; Anvisa; NIOSH |
| C14 | Medicamentos | 9 | 2 | MS/Anvisa; OMS; Coren-SP |
| C15 | Anestesia e SRPA | 8 | 1 | CFM; SOBECC |
| C16 | Segurança ocupacional | 8 | 0 | NR-32; NIOSH |
| C17 | Documentação e privacidade | 8 | 0 | Cofen; LGPD |
| C18 | Eventos críticos | 6 | 1 | RDC 36; Stanford; MHAUS |
| C19 | Cirurgia geral e digestiva | 6 | 1 | ERAS 2025; ESPEN 2025; Anvisa |
| C20 | Ortopedia e trauma | 6 | 1 | AAOS; FDA 2026 |
| C21 | Ginecologia e obstetrícia | 6 | 1 | ERAS 2025–2026; Anvisa |
| C22 | Urologia | 6 | 1 | AUA 2026; EAU corrente |
| C23 | Cirurgia vascular | 6 | 1 | ESVS 2025–2026; ACC/AHA 2026 |
| C24 | Neurocirurgia e coluna | 6 | 1 | CNS; Anvisa |
| C25 | Cabeça e pescoço | 6 | 1 | ERAS; revisão 2024; ASA 2026 |
| C26 | Torácica e cardíaca | 6 | 1 | ERAS/STS; ERAS/ESTS; ACC/AHA |
| C27 | Pediátrica e neonatal | 6 | 1 | ERAS 2024–2025; APSA |
| C28 | Minimamente invasiva e robótica | 6 | 1 | AORN 2026; FDA 2026 — rascunho |
| **Total** | — | **210** | **30** | — |

### Interpretação da coluna “casos”

Os 30 casos priorizam decisões de maior risco e integração. As competências C19–C28 possuem um caso inicial cada; competências centrais sem caso dedicado continuam avaliadas por questões de aplicação.

---

## 4. Distribuição dos 30 casos

- **3** de cirurgia segura e comunicação;
- **3** de técnica asséptica e prevenção de ISC;
- **2** de posicionamento;
- **2** de contagem;
- **2** de espécimes e implantes;
- **2** de CME;
- **2** de medicamentos;
- **2** de energia, incêndio e fumaça;
- **2** de eventos críticos, anestesia e transferência;
- **10** casos P2, um para cada especialidade incorporada.

Cada caso contém:

1. contexto sintético;
2. decisão principal;
3. quatro alternativas;
4. uma melhor resposta;
5. justificativa;
6. consequência e aprendizado;
7. competência;
8. dificuldade;
9. fontes.

Nenhum caso representa paciente real. Os casos não prescrevem dose ou tratamento individual e não substituem protocolos de emergência.

---

## 5. Regras de escrita dos itens

1. Deve existir **uma única melhor resposta**.
2. O enunciado precisa apresentar as informações necessárias, sem pistas ocultas.
3. Distratores devem ser plausíveis, mas inadequados diante da fonte e do risco.
4. Evitar “sempre” e “nunca” quando houver exceções clínicas ou institucionais.
5. Não usar cor, marca ou preferência local como regra universal.
6. A justificativa deve explicar por que a alternativa correta reduz risco.
7. Questões clínicas não devem produzir prescrição individual.
8. Doses, diluições e velocidades não devem ser avaliadas sem protocolo e fonte farmacológica específica.
9. Cada item deve ter competência, dificuldade e referências.
10. Alterações precisam manter histórico de versão.
11. Itens P2 avaliam processo e decisão segura, não técnica operatória autônoma.
12. Parâmetros de equipamentos dependem de instrução de uso, protocolo e profissional habilitado.

---

## 6. Critérios da revisão técnica

Para cada questão e caso, o revisor deve responder:

- A competência está corretamente vinculada?
- O enunciado é clinicamente e legalmente adequado?
- Existe apenas uma melhor resposta?
- Algum distrator também poderia estar correto em outro protocolo?
- A justificativa corresponde às fontes?
- A linguagem respeita o escopo profissional?
- O item testa conhecimento relevante ou apenas detalhe trivial?
- Há pista gramatical, de comprimento ou repetição?
- O conteúdo está atualizado?
- O item deve ser aprovado, corrigido ou arquivado?

Revisão de conteúdo e revisão de qualidade do item devem ser registradas separadamente.

---

## 7. Plano de piloto

### Rodada 1 — revisão cognitiva

Aplicar itens a pequeno grupo de estudantes e profissionais para identificar:

- termos ambíguos;
- informação ausente;
- interpretação diferente da pretendida;
- distrator claramente absurdo;
- tempo excessivo;
- confiança incompatível com o acerto.

### Rodada 2 — piloto fechado

Coletar, quando houver amostra suficiente:

- percentual de acerto;
- distribuição por alternativa;
- tempo de resposta;
- dificuldade observada;
- relação entre desempenho no item e desempenho total;
- comentários dos participantes;
- desempenho por competência.

### Rodada 3 — decisão editorial

- manter;
- revisar enunciado;
- revisar distrator;
- alterar dificuldade;
- atualizar fonte;
- retirar do banco.

Não definir nota de certificação antes de concluir o piloto e a validação do curso.

---

## 8. Próximas expansões

Antes da revisão clínica consolidada:

1. progressão entre aulas e competências organizada em três planos — entregue;
2. remediação automática por plano e competência — entregue;
3. revisar acessibilidade e responsividade do novo conteúdo.

Depois da revisão e do piloto:

4. acrescentar casos para competências centrais ainda sem caso dedicado;
5. criar versões paralelas dos casos para reduzir memorização;
6. separar avaliação diagnóstica, formativa e somativa;
7. formar blocos equivalentes de simulado;
8. criar análise de qualidade dos itens no painel editorial.

---

## 9. Gate de aprovação do banco

O banco só pode ser denominado **revisado** quando:

- 100% dos itens tiverem revisor identificado;
- fontes e versões estiverem registradas;
- itens problemáticos tiverem sido corrigidos ou removidos;
- o piloto tiver relatório;
- a matriz permanecer equilibrada após exclusões;
- acessibilidade e linguagem tiverem sido verificadas;
- não houver conteúdo que extrapole habilitação ou protocolo.
