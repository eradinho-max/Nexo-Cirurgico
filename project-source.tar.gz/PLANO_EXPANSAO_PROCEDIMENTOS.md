# Nexo Cirúrgico — plano de expansão para procedimentos médicos

**Versão:** 1.1  
**Data:** 14 de outubro de 2026  
**Público principal:** estudantes de Medicina e médicos em treinamento supervisionado  
**Marca nesta fase:** Nexo Cirúrgico

## 1. Decisão de produto

A expansão será executada por fases. O acervo perioperatório existente não será descartado: as 33 trilhas e 115 aulas permanecem ativas e passam a ser mapeadas a uma arquitetura técnica mais ampla.

O Nexo continuará sendo uma plataforma educacional. Conteúdo digital, simulação e checklist não conferem habilitação para executar procedimentos invasivos. Aplicam-se supervisão, autorização institucional, protocolo local, equipe habilitada, limites profissionais e instruções do fabricante.

## 2. Situação do programa de expansão

| Macrobloco | Estado | Resultado |
|---|---|---|
| MB01 — Arquitetura curricular | **Entregue e corrigido** | Status por tópico, prioridade inclusiva, relações tipadas, aliases e procedimentos canônicos |
| MB02 — Atlas de materiais | **Entregue** | 30 materiais, 133 variantes, escalas, compatibilidades, fontes e visuais originais |
| MB03 — Procedimentos fundamentais | Próximo | Acessos, coletas, administração, feridas, curativos, suturas e imobilizações |
| MB04 — Cirurgia e anestesia | Planejado | Fluxos completos do pré-operatório à recuperação |
| MB05 — Urgência e especialidades | Planejado | Via aérea, emergências, sondagens, drenagens e especialidades |
| MB06 — Videoteca vinculada | Planejado | Vídeos associados às fichas, autoria, revisão e conformidade |
| MB07 — Avaliação prática | Planejado | Checklists de habilidade e erros críticos para simulação supervisionada |
| MB08 — Revisão e publicação | Planejado | Revisão clínica, acessibilidade, teste, versionamento e aprovação

**Progresso dos macroblocos: 2 de 8.**

## 3. Entrega do MB01

- rota `#/matriz-tecnica`;
- filtros por macroárea, prioridade e cobertura;
- busca por módulo, tópico ou identificador;
- 28 módulos numerados de M01 a M28;
- 227 tópicos técnicos com IDs únicos `PT-Mxx-yy`;
- seis macroáreas curriculares;
- vínculo entre a nova matriz e o acervo atual;
- estado editorial transparente: base existente, cobertura parcial ou lacuna prioritária;
- ficha técnica padronizada de 14 campos;
- metadados obrigatórios de população, pré-requisitos, supervisão, escopo, ambiente e revisão;
- integração dos tópicos à busca global.

Os 227 tópicos representam o **catálogo editorial de expansão**. Eles não são 227 aulas prontas.

## 4. Matriz dos 28 módulos

| ID | Módulo | Prioridade | Macroárea | Estado | Tópicos | Aulas atuais relacionadas |
|---|---|---|---|---|---:|---:|
| M01 | Biossegurança | P0 | Fundamentos, segurança e materiais | Base existente | 8 | 11 |
| M02 | Instrumentação cirúrgica | P0 | Fundamentos, segurança e materiais | Base existente | 10 | 6 |
| M03 | Agulhas, seringas e dispositivos | P0 | Fundamentos, segurança e materiais | Cobertura parcial | 10 | 15 |
| M04 | Administração de medicamentos | P0 | Terapêutica, acessos e dispositivos | Lacuna prioritária | 10 | 9 |
| M05 | Acessos vasculares | P0–P2 | Terapêutica, acessos e dispositivos | Cobertura parcial | 8 | 6 |
| M06 | Feridas e lesões | P0 | Procedimentos fundamentais | Lacuna prioritária | 10 | 7 |
| M07 | Suturas e fechamento | P0 | Procedimentos fundamentais | Cobertura parcial | 11 | 5 |
| M08 | Anestesia e analgesia | P0–P2 | Terapêutica, acessos e dispositivos | Cobertura parcial | 10 | 9 |
| M09 | Preparo cirúrgico | P0 | Fundamentos, segurança e materiais | Base existente | 11 | 17 |
| M10 | Via aérea e oxigenoterapia | P0–P2 | Terapêutica, acessos e dispositivos | Cobertura parcial | 9 | 13 |
| M11 | Procedimentos respiratórios | P1–P2 | Terapêutica, acessos e dispositivos | Cobertura parcial | 6 | 10 |
| M12 | Emergências | P0–P2 | Urgência e cuidados críticos | Cobertura parcial | 9 | 15 |
| M13 | Ortopedia e imobilização | P0–P2 | Procedimentos fundamentais | Lacuna prioritária | 11 | 4 |
| M14 | Sondas e cateteres | P0–P1 | Terapêutica, acessos e dispositivos | Cobertura parcial | 7 | 10 |
| M15 | Procedimentos ambulatoriais | P1 | Procedimentos fundamentais | Lacuna prioritária | 5 | 5 |
| M16 | Cirurgia geral | P1–P2 | Cirurgia e fluxo operatório | Base existente | 8 | 15 |
| M17 | Ginecologia e obstetrícia | P1–P2 | Especialidades clínicas e cirúrgicas | Cobertura parcial | 8 | 4 |
| M18 | Pediatria e neonatologia | P1–P2 | Especialidades clínicas e cirúrgicas | Cobertura parcial | 7 | 10 |
| M19 | Neurologia | P1–P2 | Especialidades clínicas e cirúrgicas | Cobertura parcial | 5 | 10 |
| M20 | Cardiologia | P0–P2 | Urgência e cuidados críticos | Cobertura parcial | 7 | 7 |
| M21 | Gastroenterologia | P1–P2 | Especialidades clínicas e cirúrgicas | Cobertura parcial | 7 | 15 |
| M22 | Urologia | P1–P2 | Especialidades clínicas e cirúrgicas | Cobertura parcial | 6 | 10 |
| M23 | Oftalmologia | P1 | Especialidades clínicas e cirúrgicas | Lacuna prioritária | 7 | 0 |
| M24 | Otorrinolaringologia | P1 | Especialidades clínicas e cirúrgicas | Lacuna prioritária | 6 | 4 |
| M25 | Dermatologia | P1 | Especialidades clínicas e cirúrgicas | Lacuna prioritária | 7 | 5 |
| M26 | Cuidados pós-operatórios | P0 | Procedimentos fundamentais | Base existente | 10 | 14 |
| M27 | Diagnóstico à beira-leito | P0–P1 | Procedimentos fundamentais | Lacuna prioritária | 6 | 11 |
| M28 | Documentação e comunicação | P0 | Fundamentos, segurança e materiais | Base existente | 8 | 7 |

### Resumo de cobertura

- **Base existente:** 6 módulos.
- **Cobertura parcial:** 14 módulos.
- **Lacuna prioritária:** 8 módulos.

Há 94 aulas atuais associadas a pelo menos um módulo da matriz. A associação pode ser transversal; uma mesma aula pode apoiar mais de um módulo.

## 5. Identificadores editoriais

Cada tópico recebeu um código estável:

```text
PT-M05-01 — Acesso venoso periférico
PT-M07-03 — Sutura simples interrompida
PT-M13-03 — Tala tipo sugar-tong
```

Esses códigos permitem vincular posteriormente aulas, materiais, vídeos, checklists, questões, revisões e versões sem depender apenas do título.

## 6. Ficha técnica obrigatória

| Ordem | Campo | Função |
|---:|---|---|
| 01 | Definição e finalidade | Delimitar o procedimento, seu objetivo e os resultados esperados. |
| 02 | Indicações clínicas | Explicar quando considerar a técnica e quais decisões antecedem sua indicação. |
| 03 | Contraindicações e alternativas | Registrar contraindicações absolutas e relativas, alternativas e critérios de escalonamento. |
| 04 | Anatomia e referências | Apresentar referências anatômicas e variações relevantes sem substituir treinamento prático. |
| 05 | Materiais e calibres | Identificar materiais, escalas, compatibilidades, tamanhos e instruções do fabricante. |
| 06 | Preparação do ambiente | Organizar equipe, equipamentos, barreiras, monitorização e plano de contingência. |
| 07 | Preparação do paciente | Cobrir identificação, consentimento, avaliação, posicionamento e comunicação. |
| 08 | Anestesia e analgesia | Explicar opções e monitorização conforme população, procedimento e protocolo validado. |
| 09 | Sequência técnica ilustrada | Organizar etapas verificáveis para simulação e execução exclusivamente supervisionada. |
| 10 | Confirmação do resultado | Definir como confirmar funcionamento, posicionamento ou objetivo alcançado. |
| 11 | Complicações e manejo inicial | Reconhecer falhas, sinais de alarme, interrupção segura e escalonamento. |
| 12 | Cuidados posteriores | Descrever vigilância, manutenção, retirada, documentação e orientações. |
| 13 | Checklist de habilidades | Avaliar preparação, sequência, comunicação, segurança e erros críticos em simulação. |
| 14 | Vídeo, referências e revisão | Vincular fontes, vídeo externo creditado, data de revisão e conformidade editorial. |

Metadados adicionais obrigatórios: população, pré-requisitos, nível de supervisão, escopo profissional, ambiente assistencial e versão/revisão clínica.

## 7. Regra para conteúdo procedimental

Uma ficha somente poderá mudar de “catalogada” para “conteúdo desenvolvido” quando:

1. os 14 campos estiverem preenchidos;
2. materiais, calibres e compatibilidades tiverem fonte e versão;
3. população e ambiente estiverem delimitados;
4. pontos críticos e critérios de interrupção estiverem explícitos;
5. técnica invasiva estiver enquadrada como treinamento supervisionado;
6. referências e mídia tiverem autoria, licença e data de verificação;
7. revisão clínica independente estiver registrada antes da publicação profissional.

## 8. Próxima fase — MB03

O MB02 foi implementado e está documentado em `ATLAS_MATERIAIS_MB02.md`. O MB03 deve começar pelas fichas canônicas de maior frequência:

- acesso venoso periférico e coleta;
- administração segura de medicamentos;
- avaliação, limpeza e curativos de feridas;
- sutura simples e fechamento;
- imobilizações iniciais;
- diagnóstico à beira-leito.

Cada ficha deverá reutilizar materiais do Atlas, preencher os campos aplicáveis do modelo de 14 campos e permanecer fora do estado “Validado” até revisão clínica independente.

## 9. Limites da entrega atual

- O total do acervo permanece em 115 aulas, 210 questões e 30 casos.
- Os tópicos da matriz ainda não possuem todos conteúdo, mídia ou avaliação próprios.
- Não foi realizada validação clínica das novas lacunas.
- Nenhum status estrutural equivale a certificação prática.
- Os 92 alertas lexicais do banco de avaliação permanecem para revisão editorial posterior; não são 92 erros clínicos confirmados.
