from pathlib import Path
import runpy,json
r=Path(__file__).resolve().parents[1]
b=runpy.run_path(str(r/'scripts/gerar_mb04_lote2.py'))
P=b['P'];ES_TITLES=b['ES_TITLES']
# index JS ordering
p=r/'index.html';s=p.read_text();needle='  <script src="procedimentos_mb03.js"></script>'
assert needle in s
s=s.replace(needle,needle+'\n  <script src="procedimentos_mb04_l2.js"></script>')
s=s.replace('MB03 em desenvolvimento • 2 macroblocos entregues.','MB04: cirurgia, anestesia e preparo em expansão.')
p.write_text(s)
# build deploy
p=r/'scripts/build-static.mjs';s=p.read_text();s=s.replace("'procedimentos_mb03.js','app.js'","'procedimentos_mb03.js','procedimentos_mb04_l2.js','app.js'");s=s.replace("'procedimentos_mb03.js','app.js'","'procedimentos_mb03.js','procedimentos_mb04_l2.js','app.js'");p.write_text(s)
# dynamic interface quick procedures
p=r/'app.js';s=p.read_text();s=s.replace('proc.id.startsWith("PT-M16-") ? "MB04" : "MB03"','proc.id.startsWith("PT-M16-") || proc.id.startsWith("PT-M08-") || proc.id.startsWith("PT-M09-") ? "MB04" : "MB03"')
s=s.replace('proc.id.startsWith(\'PT-M16-\') ? `<section class="panel mb04-quick"','(proc.id.startsWith(\'PT-M16-\') || proc.id.startsWith(\'PT-M08-\') || proc.id.startsWith(\'PT-M09-\')) ? `<section class="panel mb04-quick"')
s=s.replace('<span class="eyebrow">M16 — CIRURGIA GERAL</span><h2>8 procedimentos operacionais no MB04 Lote 1</h2><p>Os oito tópicos possuem fichas educacionais e checklists. O bloco de anestesia continua planejado para a próxima entrega.</p><a href="#/matriz-tecnica/M16" class="button secondary">Abrir a matriz M16', '<span class="eyebrow">M08 + M09 + M16 — CIRURGIA E ANESTESIA</span><h2>29 procedimentos operacionais no MB04 — Lotes 1 e 2</h2><p>Oito fichas de cirurgia geral, dez de anestesia e onze de preparo perioperatório; todas com checklists de simulação e materiais relacionados. A expansão continua sem bloquear o estudo.</p><a href="#/matriz-tecnica/M08" class="button secondary">Abrir matriz de anestesia')
p.write_text(s)
# translations titles and initial definitions; update i18n dictionary before reverse indexing
p=r/'idiomas.js';s=p.read_text();mark='  const reverse = new Map(Object.entries(translations).map'
assert mark in s
ES_DEF={
'M08-01':'Aplicación de un anestésico sobre piel o mucosa según la formulación autorizada, sin punción.',
'M08-02':'Bloqueo de la sensibilidad por infiltración local, con evaluación de anatomía, dosis total y seguridad.',
'M08-03':'Anestesia regional de nervios periféricos, con vigilancia y entrenamiento específico.',
'M08-04':'Sedación para procedimientos con evaluación de vía aérea, monitorización y capacidad de rescate.',
'M08-05':'Técnica neuroaxial en el espacio subaracnoideo por personal especializado.',
'M08-06':'Técnica neuroaxial epidural, con vigilancia del catéter cuando corresponda.',
'M08-07':'Estado anestésico controlado que requiere monitorización y soporte respiratorio individualizados.',
'M08-08':'Comprobación de máquina de anestesia, circuitos, alarmas y suministro de gases.',
'M08-09':'Reconocimiento y respuesta a la toxicidad sistémica por anestésicos locales.',
'M08-10':'Vigilancia durante la recuperación anestésica y transición segura de cuidados.',
'M09-01':'Evaluación dirigida de los riesgos clínicos y anestésicos antes de la cirugía.',
'M09-02':'Planificación del ayuno preoperatorio según el paciente, el riesgo de aspiración y el procedimiento.',
'M09-03':'Elección de pruebas preoperatorias pertinentes, evitando solicitudes innecesarias.',
'M09-04':'Consentimiento informado y comprobación de identidad, procedimiento y lateralidad.',
'M09-05':'Uso apropiado de profilaxis antibiótica según el procedimiento y las pautas locales.',
'M09-06':'Prevención de tromboembolismo según los riesgos de trombosis y hemorragia.',
'M09-07':'Higiene preoperatoria y retirada selectiva del vello cuando sea necesaria.',
'M09-08':'Preparación antiséptica segura de la piel antes de la incisión.',
'M09-09':'Identificación y señalización del sitio correcto de la cirugía.',
'M09-10':'Colocación segura del paciente con protección de nervios, piel y dispositivos.',
'M09-11':'Verificación en equipo de la seguridad antes de la anestesia, la incisión y la salida de quirófano.'
}
assert len(ES_DEF)==21
# Get PT definitions and title via runpy
from collections import OrderedDict
translations={'Anestesia e analgesia':'Anestesia y analgesia','Preparo cirúrgico':'Preparación quirúrgica',
  '29 procedimentos operacionais no MB04 — Lotes 1 e 2':'29 procedimientos operativos en MB04 — entregas 1 y 2',
  'Roteiro rápido — ':'Guía rápida — ',
  'Abrir matriz de anestesia':'Abrir matriz de anestesia'}
for key,d in P.items():
    orig=' '.join([line for line in [d['info']]])
    translations[orig]=ES_DEF[key]
# must access exact PT titles from data.js using a simple regex block for topic ids
base=(r/'data.js').read_text()
for key,es in ES_TITLES.items():
    match=__import__('re').search(r'"id": "PT-'+key+r'",\s*"title": "([^"]+)"',base)
    assert match,key
    translations[match.group(1)]=es
s=s.replace(mark,'  Object.assign(translations, '+json.dumps(translations,ensure_ascii=False)+');\n'+mark)
p.write_text(s)
# adjust legacy QA to load new data, stop requiring old 54 exact count
for filename in ['qa_mb03.js','qa_mb04.js']:
 p=r/filename;s=p.read_text()
 s=s.replace("'procedimentos_mb03.js','app.js'","'procedimentos_mb03.js','procedimentos_mb04_l2.js','app.js'")
 s=s.replace('pack.procedures.length===54','pack.procedures.length===75')
 s=s.replace('p.length===54','p.length===75')
 s=s.replace('===54&&new Set','===75&&new Set')
 s=s.replace("===54&&t.els.app", "===75&&t.els.app")
 s=s.replace('length===54','length===75')
 s=s.replace('54 fichas MB03+MB04','75 fichas MB03+MB04')
 s=s.replace('54 cards no índice','75 cards no índice')
 s=s.replace('54 rotas diretas','75 rotas diretas')
 s=s.replace('54 fichas totais','75 fichas totais')
 s=s.replace('54 cartões e filtro','75 cartões e filtro')
 p.write_text(s)
# QA specific separate
p=r/'package.json';pkg=json.loads(p.read_text());pkg['version']='1.5.1-mb04-lote2';pkg['scripts']['qa:mb04:lote2']='node qa_mb04_l2.js';pkg['scripts']['qa:all']=pkg['scripts']['qa:all'].replace('npm run qa:mb04 &&','npm run qa:mb04 && npm run qa:mb04:lote2 &&');p.write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n')
print('Integrados scripts, interface, traduções e ajustes de QA. 21 definições espanholas.')
