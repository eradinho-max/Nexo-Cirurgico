import http from 'node:http';import fs from 'node:fs';import path from 'node:path';
const root=process.argv.includes('--dist')?path.join(process.cwd(),'dist'):process.cwd();
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.txt':'text/plain'};
const port=Number(process.env.PORT||4173);
http.createServer((req,res)=>{let name;try{name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);return res.end();}
if(name==='/'||name==='')name='/index.html';
const target=path.resolve(root,'.'+name);if(!target.startsWith(root+path.sep)){res.writeHead(403);return res.end();}
fs.stat(target,(err,st)=>{if(err||!st.isFile()){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':types[path.extname(target)]||'application/octet-stream'});fs.createReadStream(target).pipe(res)});
}).listen(port,'127.0.0.1',()=>console.log(`Nexo local: http://127.0.0.1:${port} (${root})`));
