from pathlib import Path
import re,json
root=Path(__file__).resolve().parent.parent
p=root/'qa_content.js';s=p.read_text()
s=s.replace('atlas.materials.length !== 30','atlas.materials.length !== 41').replace('esperado 30 IDs únicos','esperado 41 IDs únicos')
s=s.replace('atlas.categories.length !== 7','atlas.categories.length !== 8').replace('sete categorias únicas','oito categorias únicas')
s=s.replace('atlas.sources.length !== 9','atlas.sources.length !== 10').replace('nove fontes/requisitos únicos','dez fontes/requisitos únicos')
s=s.replace('variantIds.length !== 133','variantIds.length !== 158').replace('esperado 133 IDs únicos','esperado 158 IDs únicos')
p.write_text(s)
p=root/'qa_ui.js';s=p.read_text().replace("length===30,'Atlas não exibiu 30 materiais'","length===41,'Atlas não exibiu 41 materiais'").replace("materials:30,searches","materials:41,searches");p.write_text(s)
p=root/'qa_mb03.js';s=p.read_text();s=s.replace("check('46 cards no índice'", "check('46 cards no índice'")
# reverse links: new clinical procedure pages include Atlas material references
p=root/'procedimentos_mb03.js';text=p.read_text();key='window.NEXO_PROCEDURES = ';a=text.index(key)+len(key);obj,off=json.JSONDecoder().raw_decode(text[a:]);b=a+off
extra={
 'PT-M07-01':['MAT-SUT-001','MAT-SUT-002','MAT-SUT-004','MAT-SUT-005','MAT-SUT-006'],
 'PT-M07-02':['MAT-SUT-003'],
 'PT-M07-09':['MAT-CLO-001'],
 'PT-M07-10':['MAT-CLO-002'],
 'PT-M07-11':['MAT-CLO-003'],
 'PT-M13-01':['MAT-ORT-005'],
 'PT-M13-03':['MAT-ORT-001','MAT-ORT-002','MAT-ORT-003','MAT-ORT-005'],
 'PT-M13-04':['MAT-ORT-001','MAT-ORT-002','MAT-ORT-005'],
 'PT-M13-05':['MAT-ORT-001','MAT-ORT-002','MAT-ORT-003','MAT-ORT-005'],
 'PT-M13-06':['MAT-ORT-001','MAT-ORT-002','MAT-ORT-003','MAT-ORT-004'],
 'PT-M13-07':['MAT-ORT-002','MAT-ORT-005'],
 'PT-M13-08':['MAT-ORT-005']
}
for it in obj['procedures']:
 ids=extra.get(it['id'])
 if ids:
  it['materialLinks']=list(dict.fromkeys((it.get('materialLinks') or [])+ids))
  it['fields']['materials']=(it['fields'].get('materials') or [])+[f'Consulte {len(ids)} ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica.']
text=text[:a]+json.dumps(obj,ensure_ascii=False,indent=2)+text[b:];p.write_text(text)
# update docs: clear no clinical review and version
p=root/'README.md';s=p.read_text();s+='\n## Consolidação MB03 / Legibilidade (v1.4.3)\n\nInterface revista: texto principal 16 px, legendas e textos secundários 14 px como mínimo no CSS; 46 fichas estruturadas, Atlas com 41 materiais e 158 variantes. Revisão médica independente pendente. Ver `MB03_CONSOLIDACAO.md`.\n';p.write_text(s)
(root/'MB03_CONSOLIDACAO.md').write_text('''# Consolidação MB03 — 14/10/2026\n\n- Correção auditada: ZIP da entrega anunciada como Lote 3 continha **38**, não 46 fichas. Foram aplicadas as 8 fichas do script, agora **46 de fato**.\n- Tipografia: `html` e corpo 16 px (aprox. 12 pt), declarações CSS abaixo de 14 px elevadas a 14 px (aprox. 10,5 pt), linha de leitura 1,55–1,7.\n- Atlas: 30 → 41 materiais; 133 → 158 variantes; nova categoria de imobilização. Fichas novas de fios, fitas, grampeador, removedor de grampos, malha, acolchoamento, gesso, fibra de vidro e atadura.\n- Desenhos esquemáticos próprios (não anatômicos, sem escala) diferenciados por família de material, com aviso de desenho didático.\n- Novos materiais relacionados bidirecionalmente a procedimentos; status permanecem em `revisao-editorial` e `revisao-tecnica`.\n- Validações e testes integrados revisados para nova contagem.\n- A aplicação é **educacional** e não substitui prática supervisionada, IFU, protocolos institucionais ou revisão clínica especializada.\n- Fontes gerais: FDA (surgical sutures), AAOS OrthoInfo (care of casts and splints) e IFU do fabricante. Sem validação independente de modelo, lote, dispositivo ou conduta clínica.\n- A publicação na Vercel não prova acessibilidade, correção clínica ou direitos de todos os ativos presentes na fonte interna; apenas `dist` deve ser publicado.\n\n## Próximo passo\n\nAuditoria clínica independente por módulos, avaliação de contraste e acessibilidade (WCAG), normalização definitiva do código GitHub em arquivos versionáveis e depois MB04 — Cirurgia e Anestesia.\n''')
print('Patched validators, relations, README')
