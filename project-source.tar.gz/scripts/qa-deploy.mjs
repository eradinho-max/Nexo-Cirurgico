import { readdir,readFile,stat } from 'node:fs/promises';
import path from 'node:path';
const d=path.join(process.cwd(),'dist');
const files=[];
async function walk(dir){for(const item of await readdir(dir,{withFileTypes:true})){const loc=path.join(dir,item.name);if(item.isDirectory())await walk(loc);else files.push(path.relative(d,loc).replaceAll('\\','/'));}}
await walk(d);
const required=['index.html','styles.css','interface.css','procedimentos.css','leitura.css','idiomas.js','app.js','data.js','procedimentos_mb03.js','assets/nexo-cirurgico-logo.svg','robots.txt'];
for(const file of required)if(!files.includes(file))throw Error('Falta no build: '+file);
const allowed=new Set([...required,'assets/mini-sutura.svg','assets/mini-vascular.svg','assets/mini-instrumentais.svg','assets/mini-curativos.svg']);
for(const file of files)if(!allowed.has(file))throw Error('Artefato indevido no site público: '+file);
const html=await readFile(path.join(d,'index.html'),'utf8');
if(!html.includes('noindex,nofollow'))throw Error('Gate de indexação ausente no estágio pré-validação');
for(const forbidden of ['.md','.xlsx','.py','package.json','qa_content','jpg'])if(files.some(f=>f.endsWith(forbidden)))throw Error('Documento ou ativo não auditado publicado: '+forbidden);
const app=await readFile(path.join(d,'app.js'),'utf8');
for(const name of ['mini-sutura.svg','mini-vascular.svg','mini-instrumentais.svg','mini-curativos.svg'])if(!app.includes(name))throw Error('Imagem de domínio não substituída: '+name);
console.log(JSON.stringify({status:'APROVADO',files:files.length,publicFiles:files},null,2));
