import {readFile} from 'node:fs/promises';
const cssFiles=['styles.css','interface.css','procedimentos.css'];let total=0;
for(const file of cssFiles){const text=await readFile(file,'utf8');const matches=[...text.matchAll(/font-size\s*:\s*(\d+(?:\.\d+)?)px/g)];const low=matches.filter(m=>Number(m[1])<14);if(low.length)throw Error(`${file}: ${low.length} font-sizes abaixo de 14px`); total+=matches.length;}
const interfaceCss=await readFile('interface.css','utf8');if(!/html\s*\{font-size\s*:\s*16px/.test(interfaceCss))throw Error('Texto-base 16px não configurado');
console.log(JSON.stringify({status:'APROVADO',cssFiles,checkedFontSizes:total,minSizePx:14,bodySizePx:16}));
