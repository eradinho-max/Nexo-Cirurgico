#!/usr/bin/env python3
"""Gera oito fichas originais para o M16, mantendo o contrato curricular dos 14 campos."""
import json,re,pathlib
p=pathlib.Path(__file__).resolve().parents[1]
file=p/'procedimentos_mb03.js'
s=file.read_text()
start=s.index('window.NEXO_PROCEDURES = ')+len('window.NEXO_PROCEDURES = ')
end=s.index('\n};',start)+2
obj=json.loads(s[start:end])
assert len(obj['procedures'])==46
REFS={
'who': {'id':'WHO-SAFE-2009','title':'OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)','url':'https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources','checkedOn':'2026-10-15'},
'nice':{'id':'NICE-NG125','title':'NICE NG125 — Surgical site infections: prevention and treatment','url':'https://www.nice.org.uk/guidance/ng125/chapter/Recommendations','checkedOn':'2026-10-15'},
'whoSSI':{'id':'WHO-SSI-2018','title':'OMS — Global guidelines for prevention of surgical site infection (2018)','url':'https://www.who.int/publications/i/item/9789241550475','checkedOn':'2026-10-15'},
'sage':{'id':'ACS-SURGICAL-PRINCIPLES','title':'American College of Surgeons — Surgical Education and Training','url':'https://www.facs.org/education/','checkedOn':'2026-10-15'},
}
# Dados autorais condensados em linguagem de treino; parâmetros específicos dependem da cirurgia, da equipe e do serviço.
DATA=[
 dict(id='01',title='Incisões e vias de acesso',level='Fundamental / intermediário',materialIds=['MAT-INS-001','MAT-INS-002','MAT-INS-004','MAT-INS-006','MAT-INS-008'],supplies=['Campos, compressas estéreis, solução antisséptica apropriada, marcador cirúrgico quando indicado','Modelo de pele/tecidos para simulação; sistema de descarte de perfurocortantes'],critical=['Incisão sem identificação do paciente, lateralidade, local e procedimento','Plano anatômico errado ou exposição insuficiente de estruturas em risco','Uso de antisséptico alcoólico ainda úmido quando houver energia cirúrgica'],
 definition=['Escolha e preparo de uma via de acesso cirúrgica, com planejamento anatômico, proteção de estruturas e abertura tecidual controlada; treinamento inicial em modelos de simulação.'],
 indications=['Acesso para exploração, tratamento ou drenagem quando indicação cirúrgica estabelecida; a via depende do órgão-alvo, exposição necessária e características do paciente.'],
 contraindications=['Não há uma incisão universal: avaliar cicatrizes, infecção local, vascularização, cirurgias prévias e possibilidade de via menos invasiva. Escolha final cabe à equipe cirúrgica.'],
 anatomy=['Reconhecer pele, tecido subcutâneo, fáscia, aponeurose e musculatura; localizar projeções vasculonervosas e cicatrizes antes de marcar o trajeto.'],
 materials=['Cabo e lâmina de bisturi compatíveis (número conforme alvo e fabricante), pinça de preensão, tesoura de dissecção, afastador, compressas e recursos de hemostasia.'],
 environment=['Conferir mesa, iluminação, equipamento de aspiração/hemostasia, campo estéril e descarte de lâminas. Confirmar checklist cirúrgico.'],
 patient=['Identificação dupla, consentimento, procedimento/local/lado, alergias, preparo cutâneo, posicionamento com proteção de pontos de pressão e comunicação com anestesia.'],
 analgesia=['Plano anestésico proporcional à extensão e localização; infiltração, bloqueio ou anestesia geral conforme avaliação da anestesiologia/equipe habilitada.'],
 sequence=['No simulador, marcar limites anatômicos e estruturas a proteger.','Selecionar lâmina e instrumental de preensão com conferência de compatibilidade.','Demonstrar incisão controlada por camadas e proteção do tecido adjacente, sem avançar em planos não identificados.','Expor a área de forma progressiva, mantendo hemostasia e comunicação da mudança de plano.','Realizar pausa de segurança diante de sangramento inesperado ou anatomia incerta.'],
 confirmation=['Campo adequadamente exposto, limites anatômicos reconhecidos, hemostasia controlada e integridade dos tecidos adjacentes.'],
 complications=['Sangramento, lesão nervosa/vascular, queimadura por energia, infecção, cicatriz desfavorável ou deiscência; interromper, identificar e comunicar intercorrências.'],
 aftercare=['Registrar acesso e achados, integridade do campo, material utilizado e plano de fechamento/curativo; vigiar perfusão, dor e sinais de infecção.'],
 checklist=['Confere paciente, procedimento e lado antes de iniciar','Marca referências e estruturas vulneráveis no modelo','Escolhe lâmina e protege perfurocortantes','Demonstra acesso por planos e reconhece necessidade de hemostasia','Confere material e comunica intercorrências'],refs=['who','nice','sage']),
 dict(id='02',title='Dissecção por planos',level='Intermediário',materialIds=['MAT-INS-004','MAT-INS-006','MAT-INS-007','MAT-INS-008','MAT-INS-005'],supplies=['Modelo anatômico multicamadas, gazes e afastadores apropriados ao acesso','Instrumentos de dissecção romba e delicada conforme estrutura alvo'],critical=['Tracionar tecido não identificado','Dissecção cega junto a vasos, nervos ou vísceras','Usar eletrocirurgia sem reconhecer a estrutura adjacente'],
 definition=['Separação progressiva dos tecidos em planos anatômicos com técnica romba, cortante ou combinação conforme necessidade de exposição.'],
 indications=['Acesso a estruturas-alvo em procedimentos abertos, controle de tecido cicatricial e identificação segura de planos cirúrgicos.'],
 contraindications=['Aderências complexas, anatomia distorcida e campo hemorrágico exigem maior exposição e decisão por especialista; não avançar quando o plano é incerto.'],
 anatomy=['Distinguir pele, subcutâneo, fáscias, fibras musculares, planos avasculares e planos com estruturas neurovasculares.'],
 materials=['Pinças atraumáticas e de dissecção, tesoura Metzenbaum, afastadores, hemostáticas e material para proteção do campo.'],
 environment=['Exposição e iluminação adequadas, instrumental funcional, orientação espacial da equipe e recursos de hemostasia disponíveis.'],
 patient=['Posicionar para preservar ergonomia, proteção cutânea e acesso; identificar cirurgias prévias e fatores que podem alterar os planos.'],
 analgesia=['Conforme operação principal; controlar analgesia e estabilidade antes de manipular planos mais profundos.'],
 sequence=['Identificar no modelo a camada atual e a seguinte.','Fazer tração e contratração delicadas com auxílio de afastadores.','Demonstrar dissecção romba no plano apropriado e técnica cortante apenas onde a estrutura foi identificada.','Inspecionar frequentemente pontos de sangramento e reconhecer plano avascular quando presente.','Suspender avanço quando não for possível identificar estruturas com confiança.'],
 confirmation=['Camadas distinguíveis, estruturas preservadas, campo sem tração excessiva e manutenção da hemostasia.'],
 complications=['Laceração vascular, lesão nervosa, perfuração visceral, seroma, queimaduras e sangramento oculto; reconhecer e pedir apoio.'],
 aftercare=['Reavaliar viabilidade e hemostasia antes de continuar; documentar alterações anatômicas e danos identificados.'],
 checklist=['Aponta as camadas no modelo','Demonstra tração/contratração controladas','Seleciona técnica romba ou cortante justificadamente','Identifica estruturas vulneráveis','Interrompe a técnica diante de incerteza anatômica'],refs=['sage','who']),
 dict(id='03',title='Hemostasia e ligaduras',level='Intermediário',materialIds=['MAT-INS-005','MAT-INS-003','MAT-SUT-002','MAT-SUT-004','MAT-INS-004'],supplies=['Compressas estéreis contáveis; recurso de aspiração e energia cirúrgica quando disponíveis e indicados','Pinças hemostáticas adicionais conforme calibre e localização do vaso'],critical=['Aplicar energia junto a estruturas não visualizadas','Ligadura sem conferência do vaso e de estruturas adjacentes','Encerrar a operação sem verificar hemostasia de planos profundos'],
 definition=['Conjunto de estratégias para localizar, conter e tratar sangramento operatório por compressão, pinçamento, ligadura ou tecnologia apropriada.'],
 indications=['Sangramento tecidual ou vascular durante dissecção/fechamento e prevenção de perda sanguínea no campo operatório.'],
 contraindications=['A técnica varia com vaso, calibre, perfusão e órgão: não usar eletrocoagulação ou pinçamento às cegas, sobretudo perto de nervos e vísceras.'],
 anatomy=['Identificar trajeto vascular, perfusão distal, relação com estruturas nervosas e planos de acesso; distinguir sangramento capilar, venoso e arterial.'],
 materials=['Pinças hemostáticas, porta-agulhas, fios adequados ao vaso/tecido, compressas e instrumento de energia quando indicado.'],
 environment=['Aspirador pronto, compressas contadas e plano de resposta a sangramento de maior porte, com comunicação anestésica.'],
 patient=['Antecedentes de anticoagulantes/coagulopatia e avaliação do risco hemorrágico; acesso a hemoderivados quando plano cirúrgico demandar.'],
 analgesia=['Gerenciamento anestésico e hemodinâmico durante controle de sangramento; procedimento invasivo por equipe habilitada.'],
 sequence=['Em modelo de simulação, localizar a origem do sangramento.','Demonstrar compressão adequada e exposição do campo.','Selecionar entre compressão, ligadura ou outro método de forma justificada e confirmar identificação das estruturas.','Treinar ligadura/controle em modelo vascular sem tensionar excessivamente o tecido.','Reinspecionar o campo depois do controle, inclusive após mudanças de pressão ou posição.'],
 confirmation=['Ausência de sangramento ativo relevante, perfusão preservada dos tecidos de interesse, estabilidade hemodinâmica e contagem das compressas.'],
 complications=['Hemorragia persistente, lesão vascular, isquemia por ligadura inadequada, queimadura por energia e hematoma pós-operatório; solicitar apoio e tratar causa.'],
 aftercare=['Registrar método hemostático, estimativa de perdas conforme rotina, necessidade de observação e sinais de ressangramento.'],
 checklist=['Reconhece tipo provável de sangramento','Aplica compressão no modelo antes de avançar','Identifica vasos/estruturas antes de ligar','Justifica seleção de hemostasia','Confere campo e hemostasia ao final'],refs=['sage','who','whoSSI']),
 dict(id='04',title='Laparotomia: preparo e princípios de abertura',level='Avançado / observação supervisionada',materialIds=['MAT-INS-001','MAT-INS-002','MAT-INS-006','MAT-INS-008','MAT-INS-005','MAT-SUT-005'],supplies=['Afastadores abdominais conforme cirurgia, sistema de aspiração, compressas radiopacas contáveis, fios para fáscia','Simulador de parede abdominal com peritônio e camadas reconhecíveis'],critical=['Abertura abdominal sem reconhecer anatomia, aderências ou cicatrizes','Não identificar risco de lesão visceral na entrada','Falha de contagem de compressas/instrumentos'],
 definition=['Acesso aberto à cavidade abdominal realizado por equipe cirúrgica, com escolha da incisão, identificação das camadas e proteção das vísceras.'],
 indications=['Exploração ou tratamento de patologia abdominal quando a abordagem aberta está indicada, inclusive conversão de abordagem minimamente invasiva.'],
 contraindications=['Não existe indicação universal para acesso aberto; discutir alternativas, aderências, condição hemodinâmica, infecção e riscos anestésicos.'],
 anatomy=['Parede abdominal: pele, subcutâneo, aponeurose, músculos/linha alba, fáscia transversalis, peritônio; vísceras e vasos próximos à entrada.'],
 materials=['Instrumental de corte/dissecção, afastadores, hemostasia, aspiração, compressas contáveis, sutura de fechamento fascial; escolher conforme técnica.'],
 environment=['Sala de cirurgia equipada, equipamentos e iluminação revisados, contagens iniciais, plano anestésico, protocolo de antibiótico quando indicado.'],
 patient=['Jejum e avaliação anestésica individualizados, identificação/local/consentimento, antissepsia, posicionamento, monitorização e checklist OMS.'],
 analgesia=['Anestesia e analgesia definidas pela anestesiologia; considerar analgesia multimodal e prevenção de náuseas conforme risco.'],
 sequence=['No simulador, identificar e marcar referências da parede abdominal e a possível via de acesso.','Conferir equipe, instrumentais, contagens e campo.','Demonstrar abertura progressiva de planos em modelo, com proteção de estruturas profundas.','Explicar por que toda entrada no peritônio requer visualização segura e reavaliação de aderências.','Antes de encerrar, simular hemostasia, contagens, fechamento da fáscia e registro.'],
 confirmation=['Exposição alcançada sem lesão simulada, estruturas reconhecidas, contagens reconciliadas e plano de fechamento adequado.'],
 complications=['Hemorragia, lesão visceral, infecção, deiscência, hérnia incisional, dor e complicações anestésicas; reconhecimento precoce é obrigatório.'],
 aftercare=['Handoff estruturado para recuperação com acesso realizado, intercorrências, risco hemorrágico e plano de analgesia/cuidado da ferida.'],
 checklist=['Localiza camadas da parede abdominal','Identifica riscos de vísceras aderidas','Confere checklist e contagens','Descreve acesso apenas no simulador','Explica fechamento fascial e handoff'],refs=['who','nice','whoSSI']),
 dict(id='05',title='Laparoscopia: equipamentos, acesso e segurança',level='Avançado / observação supervisionada',materialIds=['MAT-INS-001','MAT-INS-002','MAT-INS-005','MAT-INS-008'],supplies=['Coluna de vídeo, óptica e câmera, insuflador de CO₂, fonte de luz, trocartes e cânulas compatíveis','Instrumentais laparoscópicos, sistema de energia e dispositivos de aspiração/irrigação compatíveis','Simulador de caixa laparoscópica para treino bimanual e ergonomia'],critical=['Iniciar sem verificar insuflador, imagem, cabos e pressão definida pela equipe','Utilizar energia fora do campo visual','Não identificar falha de acesso, lesão ou condição que requer conversão'],
 definition=['Abordagem minimamente invasiva com óptica, pneumoperitônio e instrumentos especializados; este módulo ensina preparação, ergonomia e reconhecimento de segurança em simulador.'],
 indications=['Cirurgias elegíveis para abordagem minimamente invasiva conforme indicação, condições clínicas, anatomia e experiência da equipe.'],
 contraindications=['Acesso inviável, instabilidade ou condição clínica/operatória que torne a abordagem inadequada; decisões caso a caso por cirurgião e anestesiologista.'],
 anatomy=['Parede abdominal, grandes vasos retroperitoneais, vísceras sob pontos de entrada e orientação do campo por vídeo; reconhecer limites de visão e profundidade.'],
 materials=['Câmera e torre, insuflação de CO₂, trocartes, óptica, pinças laparoscópicas, sistema de energia e recursos de conversão a cirurgia aberta.'],
 environment=['Testar imagem/foco, fonte de luz, insuflador, conexões, integridade de trocartes, ergonomia do monitor, aspiração e disponibilidade para conversão.'],
 patient=['Checklist de identificação/procedimento, posicionamento e proteção de pontos de pressão, preparo cutâneo e avaliação cardiopulmonar/anestésica.'],
 analgesia=['Geralmente requer anestesia geral e controle ventilatório durante pneumoperitônio; regime e contraindicações individualizados.'],
 sequence=['Montar no simulador torre, ótica, monitor, insuflador e cabos, identificando suas funções.','Simular posicionamento ergonômico da equipe e disposição dos portais sem inserção no paciente.','Treinar coordenação mão–olho e manuseio atraumático com câmera em simulador de caixa.','Demonstrar regras de segurança de energia e resposta a perda de imagem, sangramento ou falha de insuflação.','Descrever indicação de interromper/converter com comunicação entre cirurgia e anestesia.'],
 confirmation=['Imagem, luz e insuflação testadas; exercício bimanual sem colisões ou tração excessiva; resposta ao problema técnico descrita.'],
 complications=['Lesão vascular/visceral na entrada, hipercapnia, embolia gasosa rara, queimaduras e lesões por posição; reconhecer sinais e acionar equipe.'],
 aftercare=['Registrar dispositivos e portais utilizados, contagens, complicações, sítios de acesso e plano de vigilância pós-operatória.'],
 checklist=['Reconhece câmera, insuflador, óptica e trocartes','Executa checklist de equipamento antes da simulação','Manuseia dois instrumentos com controle em caixa de treinamento','Interrompe exercício diante de falha de imagem','Conhece recursos e comunicação de conversão'],refs=['who','sage','nice']),
 dict(id='06',title='Fechamento por planos',level='Intermediário / avançado',materialIds=['MAT-INS-003','MAT-INS-004','MAT-INS-007','MAT-SUT-002','MAT-SUT-005','MAT-SUT-006'],supplies=['Modelo de parede abdominal com camadas; compressas e cobertura para ferida operatória','Fios e agulhas específicos conforme plano, tensão, contaminação e fabricante'],critical=['Fechar cavidade antes de conferir hemostasia, estruturas e contagens','Incluir estruturas ou comprimir tecido com tensão excessiva','Escolher fio ou agulha sem considerar o plano e o suporte mecânico necessário'],
 definition=['Reconstrução progressiva dos planos operados, respeitando função anatômica, viabilidade tecidual e resistência exigida em cada camada.'],
 indications=['Encerramento cirúrgico após tratamento, hemostasia e verificação do campo; a técnica depende do tipo de incisão e risco de infecção.'],
 contraindications=['Contaminação e infecção podem requerer estratégias de fechamento diferido; tecido isquêmico ou sob tensão excessiva exige reavaliação.'],
 anatomy=['Reconhecer fáscia/aponeurose como camada de sustentação, subcutâneo, derme e epiderme; evitar incorporar vasos, nervos ou alças.'],
 materials=['Porta-agulhas, pinça, tesoura e suturas absorvíveis ou não conforme função do plano, curva e ponta da agulha, tensão e técnica.'],
 environment=['Campo iluminado, contagem reconciliada, fios e agulhas identificados, apoio para hemostasia e curativo disponível.'],
 patient=['Rever risco de infecção, obesidade, diabetes, cicatrização, perda tecidual e pressão intra-abdominal conforme caso.'],
 analgesia=['Controle anestésico intraoperatório e analgesia pós-operatória individualizados; técnica de fechamento dentro da cirurgia programada.'],
 sequence=['No modelo multicamadas, classificar os planos que precisam ser aproximados e os que não precisam de sutura adicional.','Selecionar fio e agulha justificando suporte mecânico e reação tecidual.','Demonstrar aproximação sem estrangular bordas, com nós seguros e tensão distribuída.','Conferir fechamento do plano estrutural, hemostasia e espaços mortos conforme contexto.','Simular cobertura, contagem final e documentação dos fios usados.'],
 confirmation=['Boa coaptação sem isquemia aparente, suporte da camada estrutural, ausência de espaço morto inadequado e contagem final reconciliada.'],
 complications=['Seroma, hematoma, infecção de sítio cirúrgico, deiscência, hérnia incisional e necrose por tensão; identificar sinais precoces.'],
 aftercare=['Curativo apropriado, plano de analgesia e mobilização, orientação de sinais de alarme e revisão da ferida conforme risco.'],
 checklist=['Reconhece aponeurose e demais camadas','Seleciona fio conforme função do plano','Executa aproximação em modelo sem estrangulamento','Confere hemostasia e contagens','Documenta fio, plano e cuidados posteriores'],refs=['nice','whoSSI','sage']),
 dict(id='07',title='Drenos cirúrgicos: seleção, instalação e vigilância',level='Intermediário / avançado',materialIds=['MAT-INS-005','MAT-INS-003','MAT-SUT-001','MAT-INF-002'],supplies=['Dispositivo de drenagem adequado ao procedimento (Penrose, dreno fechado com reservatório ou outro)','Sistema coletor identificado, curativo estéril e material de fixação; confirmar IFU e integridade'],critical=['Usar dreno sem indicação documentada','Conexão inadequada, quebra do sistema fechado ou tração sobre o dreno','Retirada ou manipulação sem verificar indicação, tipo, débito e protocolo'],
 definition=['Dispositivos para evacuação controlada de líquidos/ar ou monitorização de saída em contextos operatórios selecionados.'],
 indications=['Coleção ou espaço cirúrgico com necessidade de drenagem conforme decisão técnica; não são indicados rotineiramente em todas as cirurgias.'],
 contraindications=['Evitar uso sem benefício esperado; risco de infecção ascendente, erosão ou permanência desnecessária; dispositivos específicos têm contraindicações próprias.'],
 anatomy=['Percurso do dreno em relação à cavidade tratada, estruturas vasculares, vísceras e ponto de exteriorização; evitar compressão/angulação.'],
 materials=['Dreno especificado por tipo/diâmetro e fabricante, reservatório ou coletor quando indicado, fio de fixação, gaze e cobertura.'],
 environment=['Dispor sistema fechado e identificado, organizar armazenamento com estabilidade do reservatório e circuito, materiais para documentação do débito.'],
 patient=['Informar finalidade e mobilização segura; avaliar posição, conforto, alergias e risco de retirada acidental.'],
 analgesia=['A inserção acompanha plano anestésico do procedimento; cuidados e retirada conforme analgesia e decisão da equipe.'],
 sequence=['Identificar em bandeja simulada drenagens abertas e fechadas e seus objetivos.','Conferir integridade, reservatório, conectores e material de fixação do modelo.','Simular posicionamento e fixação no manequim sem pinçamento do circuito e sem tração de pele.','Demonstrar mensuração do débito, aspecto e documentação sem abrir desnecessariamente o sistema.','Reconhecer situações para comunicar perda de sucção, alteração súbita de débito, dor ou febre.'],
 confirmation=['Fixação e permeabilidade mantidas, integridade do sistema, mensuração clara de débito e ausência de tração no modelo.'],
 complications=['Obstrução, infecção, sangramento, deslocamento, lesão de estruturas e retenção do dreno; reconhecer e documentar.'],
 aftercare=['Registrar tipo, local, características de débito e curativo; reavaliar diariamente indicação e necessidade de manutenção.'],
 checklist=['Diferencia dreno aberto e fechado','Seleciona o sistema adequado no cenário simulado','Checa circuito, reservatório e fixação','Registra débito e aspecto','Identifica critérios de alerta e reavaliação'],refs=['nice','whoSSI','sage']),
 dict(id='08',title='Conversão e encerramento cirúrgico seguro',level='Avançado / trabalho em equipe',materialIds=['MAT-INS-001','MAT-INS-003','MAT-INS-005','MAT-SUT-005'],supplies=['Formulário de checklist OMS, mapa de contagem de agulhas, gazes, compressas e instrumentos','Instrumental alternativo e campo para acesso aberto quando previsto','Identificação e acondicionamento seguro de amostras e materiais implantados'],critical=['Persistir numa via insegura diante de complicação ou visualização insuficiente','Fechar sem contagem final reconciliada ou deixar divergência sem investigação','Transferir paciente sem relato das intercorrências, dispositivos e plano de vigilância'],
 definition=['Reconhecimento da necessidade de mudar a via cirúrgica e execução dos passos de segurança para concluir o procedimento, contabilizar materiais e transferir cuidados.'],
 indications=['Mudança de abordagem por acesso insuficiente, complicação ou necessidade cirúrgica; encerramento seguro obrigatório em todos os procedimentos.'],
 contraindications=['Não existem condições aceitáveis para omitir as verificações de segurança; decisões de conversão competem à equipe habilitada.'],
 anatomy=['Reavaliar a anatomia e eventuais lesões identificadas; localizar a nova via de acesso caso a equipe indique conversão.'],
 materials=['Checklist, materiais de contagem, instrumentos de hemostasia e fechamento, identificação de espécimes e meios seguros de handoff.'],
 environment=['Pausar para comunicação estruturada, definir novos papéis e recursos, confirmar disponibilidade de instrumentais, anestesia e suporte.'],
 patient=['Reconfirmar lateridade/procedimento quando houver mudança de plano, alergias, estado hemodinâmico, riscos e comunicação de eventos adversos.'],
 analgesia=['Reavaliação contínua pela anestesiologia conforme duração, sangramento e ampliação do procedimento; plano pós-operatório atualizado.'],
 sequence=['No cenário simulado, identificar sinal que justifica solicitar ajuda ou converter a técnica.','Comunicar imediatamente equipe/anestesia, riscos e recursos necessários para o novo plano.','Reconciliar instrumentos, compressas, agulhas, espécimes e implantes com registro da divergência, se houver.','Simular o Sign Out: procedimento realizado, contagens, equipamentos, amostras e plano de recuperação.','Transmitir handoff estruturado com intercorrências, analgesia, acesso, drenos e sinais de alerta.'],
 confirmation=['Equipe ciente da abordagem final, contagens e amostras reconciliadas, documentação completa e plano pós-operatório compreendido.'],
 complications=['Objeto retido, perda de informação, falha de contagem, agravamento não comunicado, sangramento ou reação adversa; acionar rastreio de segurança institucional.'],
 aftercare=['Registro cirúrgico e anestésico, identificação de dispositivos e espécimes, instrução de recuperação e critérios para escalonamento.'],
 checklist=['Reconhece situação de conversão e pede ajuda','Realiza comunicação fechada com equipe','Reconciliou contagens e espécimes no cenário','Executa Sign Out OMS','Faz handoff estruturado com riscos e plano'],refs=['who','nice','sage'])
]
assert len(DATA)==8
fields=['definition','indications','contraindications','anatomy','materials','environment','patient','analgesia','sequence','confirmation','complications','aftercare','checklist']
for item in DATA:
 ref=item['refs']; idx=item['id']; tag='PT-M16-'+idx
 proc={
  'id':tag,'topicIds':[tag],'title':item['title'],'priority':'P1' if idx in ('01','02','03','06','07') else 'P2','level':item['level'],'scope':'Cirurgia geral',
  'population':'Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação','environment':'Centro cirúrgico equipado; treino inicial em laboratório de simulação',
  'supervision':'Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada','professionalScope':'Conforme habilitação legal, treinamento específico e protocolo institucional',
  'prerequisites':['Assepsia, antissepsia e segurança cirúrgica','Anatomia por planos e reconhecimento de instrumentos','Comunicação cirúrgica e preparo para intercorrências'],
  'editorial':{'status':'em-desenvolvimento','version':'0.1-MB04-L1','clinicalReviewer':None,'reviewedOn':None,'publishedOn':None},
  'materialLinks':item['materialIds'],'additionalSupplies':item['supplies'],'criticalErrors':item['critical'],
  'fields':{f: item['checklist' if f=='skills-checklist' else f] for f in fields if f!='checklist'},
  'references':[REFS[key] for key in ref],'media':[],
  'illustration':{'type':'original-schematic','caption':'Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida','author':'Nexo Cirúrgico','license':'Original do projeto'}
 }
 proc['fields']['skills-checklist']=item['checklist']
 proc['fields']['media-references']=['Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.','Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.','Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06.']
 assert set(proc['fields'])=={'definition','indications','contraindications','anatomy','materials','environment','patient','analgesia','sequence','confirmation','complications','aftercare','skills-checklist','media-references'}
 obj['procedures'].append(proc)
assert len(obj['procedures'])==54
obj['version']='0.3-MB04-L1'; obj['generatedOn']='2026-10-15'; obj['sourcePolicy']='Fontes identificadas; fichas educacionais para simulação, com atualização contínua e sem bloqueio de acesso ao estudo.'
s=s[:start]+json.dumps(obj,ensure_ascii=False,indent=2)+s[end:]
s=s.replace('/* Fichas de estudo prático. Fontes e versões registradas; não constituem autorização profissional. */','/* MB03 + MB04 Lote 1: fichas de estudo prático para simulação com fontes e versões registradas. */')
# remover afirmação desatualizada e utilizar números de dados reais sem alterar o contrato de sincronização
s=s.replace("macro.description='MB03: lotes 1 e 2 — 38 fichas técnicas em revisão clínica; procedimentos adicionais e validação pendentes.'", "macro.description='MB03: 46 fichas fundamentais cadastradas; treino supervisionado e aprofundamentos seguem em expansão.'")
s += '''\n/* MB04 — cirurgias: estágio de criação separado da liberação para execução clínica. */\n(function(){\n const curriculum=window.NEXO_DATA.technicalCurriculum;\n const macro=curriculum.macroblocks.find(m=>m.id==='MB04');\n if(macro){macro.status='Em desenvolvimento';macro.description='MB04 Lote 1: oito roteiros de Cirurgia Geral (M16); anestesia e demais procedimentos ficam para o lote seguinte.'}\n const module=curriculum.modules.find(m=>m.id==='M16');\n for(const topic of module.topics){\n  if(window.NEXO_PROCEDURES.procedures.some(p=>p.id===topic.id)){\n    topic.status='em-desenvolvimento';topic.revision={...topic.revision,version:'0.1-MB04-L1',state:'em-desenvolvimento'};\n  }\n }\n})();\n'''
file.write_text(s)
print('Fichas totais',len(obj['procedures']),'novas',len(DATA),'bytes',file.stat().st_size)
