"""Consolida legibilidade e Atlas MB03. Conteúdo permanece em revisão técnica."""
import pathlib,json,re
root=pathlib.Path(__file__).resolve().parent.parent
path=root/'data.js'; s=path.read_text(); marker='window.NEXO_DATA = '; start=s.index(marker)+len(marker); data,offset=json.JSONDecoder().raw_decode(s[start:]); end=start+offset
atlas=data['materialAtlas']; mat=atlas['materials']; existing={x['id'] for x in mat}
newcat={'id':'imobilizacao','title':'Imobilização, talas e gessos','layer':'E'}
if not any(x['id']==newcat['id'] for x in atlas['categories']):atlas['categories'].append(newcat)
if not any(x['id']=='SRC-MAT-AAOS-SPLINTS' for x in atlas['sources']):atlas['sources'].append({'id':'SRC-MAT-AAOS-SPLINTS','title':'Care of Casts and Splints','organization':'American Academy of Orthopaedic Surgeons (AAOS)','edition':'OrthoInfo — cuidados, proteção e sinais de alerta','year':'consulta corrente','url':'https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/','verifiedOn':None,'status':'referencia-de-apoio-a-rever'})

def make(id,name,aliases,category,desc,indications,risks,precautions,variants,topics,source,schematic,scale=None,alternatives=None):
 if id in existing:return
 links=[{'topicId':topic,'role':'dependente-indicacao','note':'Material ilustrativo; seleção condicionada a avaliação, dispositivo e protocolo institucional.'} for topic in topics]
 item={'id':id,'preferredName':name,'aliases':aliases,'categoryId':category,'description':desc,'generalIndications':indications,'risks':risks,'alternatives':alternatives or [],'precautions':precautions,'scaleSystem':scale,'variants':[{'id':vid,'label':lab,'scaleType':scale,'scaleValue':sv,'manufacturerVerificationRequired':True} for vid,lab,sv in variants],'procedureLinks':links,'compatibility':[],'provenance':[{'sourceId':source,'claimScope':'Descrição geral e finalidade; nenhuma indicação específica validada individualmente','reviewedOn':None,'status':'revisao-editorial'},{'sourceId':'SRC-MAT-IFU','claimScope':'Verificar compatibilidade, apresentações, esterilidade, tamanho e indicação','reviewedOn':None,'status':'pendente-fabricante'}],'visual':{'kind':'original-schematic','assetId':'atlas-inline-svg-'+schematic,'schematicType':schematic,'author':'Nexo Cirúrgico — desenho original','license':'Original do projeto','sourceUrl':None,'alt':'Esquema vetorial original de '+name.lower()+'. Não representa geometria nem escala reais.'},'review':{'status':'revisao-editorial','version':'0.2','clinicalReviewer':None,'reviewedOn':None}}
 mat.append(item);existing.add(id)
SUT='SRC-MAT-FDA-SUTURE'; ORT='SRC-MAT-AAOS-SPLINTS'
make('MAT-SUT-004','Fio de sutura de polipropileno',['prolene','polipropileno','sutura não absorvível monofilamentar'],'fechamento','Fio sintético não absorvível usualmente monofilamentar; características e apresentações específicas por produto.',['Fechamento de tecidos quando selecionado por profissional habilitado'],['Deiscência, corpo estranho e lesão por tensão inadequada'],['Número USP não equivale isoladamente a diâmetro em milímetros; confirmar agulha, embalagem e IFU.'],[('PP-3-0','USP 3-0','3-0'),('PP-4-0','USP 4-0','4-0'),('PP-5-0','USP 5-0','5-0')],['PT-M07-01','PT-M07-03','PT-M07-08'],SUT,'fio-monofilamento','USP',['Nylon e outros fios conforme indicação'])
make('MAT-SUT-005','Fio de sutura de polidioxanona',['PDS','polidioxanona','PDO','monofilamento absorvível'],'fechamento','Fio sintético absorvível geralmente monofilamentar, frequentemente utilizado quando se necessita manutenção de suporte tecidual por maior período.',['Fechamentos profundos selecionados segundo técnica e tecido'],['Perda de resistência, deiscência, reação tecidual e escolha inadequada'],['Perfil de suporte e absorção é do produto; confirmar indicação, dimensões e IFU.'],[('PDS-2-0','USP 2-0','2-0'),('PDS-3-0','USP 3-0','3-0'),('PDS-4-0','USP 4-0','4-0')],['PT-M07-01','PT-M07-08'],SUT,'fio-absorvivel','USP')
make('MAT-SUT-006','Fio de sutura de poliglecaprone',['poliglecaprone 25','monocryl','monofilamento absorvível'],'fechamento','Fio absorvível monofilamentar; retenção de força e absorção dependem do produto.',['Fechamento dérmico ou outros planos conforme indicação'],['Deiscência, reação local e absorção incompatível com cicatrização'],['Conferir perfil de absorção e aplicação em tecido sob tensão antes de selecionar.'],[('MONO-3-0','USP 3-0','3-0'),('MONO-4-0','USP 4-0','4-0'),('MONO-5-0','USP 5-0','5-0')],['PT-M07-01','PT-M07-07','PT-M07-08'],SUT,'fio-absorvivel','USP')
make('MAT-CLO-001','Fitas de aproximação cutânea',['steri strip','fitas adesivas de fechamento','fitas de aproximação'],'fechamento','Fitas adesivas para aproximação de bordas em condições selecionadas.',['Fechamento superficial quando indicado e bordas apropriadas'],['Falha da adesão, maceração e deiscência'],['Não aplicáveis universalmente a feridas sob tensão, com infecção ou inadequadas para fechamento imediato.'],[('CLO-TAPE-NAR','Fita estreita',None),('CLO-TAPE-LAR','Fita larga',None)],['PT-M07-09','PT-M06-07'],SUT,'fitas')
make('MAT-CLO-002','Grampeador cutâneo descartável',['grampeador de pele','skin stapler','grampos cutâneos'],'fechamento','Dispositivo de aplicação de grampos para aproximação cutânea em indicações selecionadas.',['Fechamento cutâneo por equipe treinada quando apropriado'],['Lesão de bordas, cicatriz, retenção de grampo e infecção'],['Confirmar modelo, assepsia, contagem, indicação e modo de remoção conforme IFU.'],[('STAP-STD','Modelo cutâneo padronizado',None),('STAP-ALT','Modelo com geometria específica',None)],['PT-M07-10'],SUT,'grampeador')
make('MAT-CLO-003','Removedor de grampos cutâneos',['extrator de grampos','staple remover'],'instrumentais','Instrumento destinado à remoção de grampos compatíveis após avaliação da cicatrização.',['Retirada de grampos quando indicada'],['Abertura de ferida, dor, trauma local e remoção precoce'],['Verificar compatibilidade com grampo e indicação clínica; não confundir com extrator de grampos de escritório.'],[('REM-DISP','Removedor descartável',None),('REM-REUS','Removedor reutilizável',None)],['PT-M07-11'],SUT,'removedor')
make('MAT-ORT-001','Malha tubular para imobilização',['stockinette','malha tubular de gesso','meia tubular ortopédica'],'imobilizacao','Camada de base para determinadas talas ou imobilizações, escolhida para tamanho e pele.',['Proteção de pele em imobilização conforme método'],['Dobras, pontos de pressão e irritação'],['Dimensionar conforme membro, integridade cutânea e edema; não substituir acolchoamento indicado.'],[('MALHA-PED','Dimensão pediátrica — sob medida',None),('MALHA-ADT','Dimensão adulta — sob medida',None)],['PT-M13-02','PT-M13-04','PT-M13-06'],ORT,'malha')
make('MAT-ORT-002','Acolchoamento ortopédico',['padding ortopédico','algodão ortopédico','proteção de proeminências ósseas'],'imobilizacao','Material de proteção e preenchimento para imobilizações com técnica e distribuição adequadas.',['Proteção de áreas sob talas e gessos'],['Lesões de pressão se excessivo, insuficiente ou mal distribuído'],['Seguir técnica institucional e avaliar pele, edema e perfusão antes e após aplicação.'],[('PAD-STD','Rolo de acolchoamento',None),('PAD-SPEC','Proteção localizada de proeminência',None)],['PT-M13-02','PT-M13-03','PT-M13-05','PT-M13-06'],ORT,'acolchoamento')
make('MAT-ORT-003','Atadura gessada',['gesso de Paris','plaster of Paris bandage','atadura de gesso'],'imobilizacao','Material de imobilização que endurece com água, sujeito a tempo de presa e aquecimento conforme fabricante.',['Imobilizações selecionadas com treinamento supervisionado'],['Queimadura térmica, lesão por pressão, edema, compressão e perda de alinhamento'],['Conferir tempo de presa, água, espessura, pele, acolchoamento e avaliação neurovascular seriada; nunca apertar sobre edema progressivo.'],[('CAST-PLASTER-ROLL','Rolo de gesso — largura por fabricante',None),('CAST-PLASTER-SPLINT','Lâmina de gesso para tala',None)],['PT-M13-03','PT-M13-05','PT-M13-06'],ORT,'gesso')
make('MAT-ORT-004','Atadura sintética de fibra de vidro',['fiberglass cast','gesso sintético','atadura de fibra de vidro'],'imobilizacao','Material sintético de imobilização rígida com propriedades dependentes da formulação.',['Imobilizações selecionadas e com indicação documentada'],['Compressão, irritação, queimadura e dificuldade de remoção'],['Respeitar tempo de endurecimento e preparo do produto, proteção cutânea, monitoramento distal e critérios de retirada.'],[('CAST-FIB-ROLL','Rolo de fibra de vidro — largura por fabricante',None),('CAST-FIB-SPLINT','Lâmina sintética para tala',None)],['PT-M13-03','PT-M13-06'],ORT,'gesso')
make('MAT-ORT-005','Bandagem elástica para fixação de talas',['atadura elástica','faixa elástica para tala','elastic bandage'],'imobilizacao','Material auxiliar de retenção de tala, sem substituir avaliação de perfusão e edema.',['Fixação de imobilizações não circunferenciais selecionadas'],['Compressão excessiva, parestesia, dor e comprometimento vascular'],['Não aplicar tensão excessiva; monitorar pele e exame neurovascular antes e depois.'],[('BAND-ROLL-S','Rolo estreito por fabricante',None),('BAND-ROLL-L','Rolo largo por fabricante',None)],['PT-M13-03','PT-M13-04','PT-M13-05','PT-M13-07'],ORT,'atadura')
# do not mistake merely cataloguing these items for independent clinical verification
raw=s[:start]+json.dumps(data,ensure_ascii=False,indent=2)+s[end:];path.write_text(raw)
# UI drawings: morphologically distinct new schematic families
app=root/'app.js';txt=app.read_text();old="      instrumentais:'<circle cx=\"24\" cy=\"24\" r=\"12\"/><circle cx=\"24\" cy=\"76\" r=\"12\"/><path d=\"m34 32 51 51M34 68 85 17M51 51l13 13M51 49l13-13\"/>'";
assert old in txt
new=old+''',
      imobilizacao:'<path d="M21 25h58v50H21z"/><path d="M21 35h58M21 46h58M21 57h58M21 68h58M35 25v50M49 25v50M63 25v50"/>' ,
      'fio-absorvivel':'<circle cx="40" cy="48" r="21"/><path d="M40 27c22 4 22 38 0 42M55 54c15-16 26-13 31-6s-5 16-15 22"/>',
      'fio-monofilamento':'<path d="M13 69c23-37 25-39 43-29s24-4 26-16"/><path d="M77 17l9 6-8 7"/>',
      fitas:'<path d="M13 35h74v32H13Z"/><path d="M23 35v32M34 35v32M45 35v32M56 35v32M67 35v32M78 35v32"/>',
      grampeador:'<path d="M20 22h43l20 17-8 11H50L39 75H24l10-32H20Z"/><path d="M50 50h26M57 57h13"/>',
      removedor:'<path d="M18 27c21 7 41 14 65 46M21 75l61-45M30 32v11M70 66v-9"/>',
      malha:'<path d="M26 18h48v64H26Z"/><path d="M26 34h48M26 50h48M26 66h48M42 18v64M58 18v64"/>',
      acolchoamento:'<rect x="20" y="28" width="60" height="45" rx="18"/><path d="M32 30c20 10 20 31 0 40M44 28c20 12 20 32 0 44M57 29c15 13 15 30 0 43"/>',
      gesso:'<path d="M24 17h52v67H24Z"/><path d="M24 34h52M24 51h52M24 68h52M40 17v67M58 17v67"/>',
      atadura:'<circle cx="50" cy="50" r="31"/><circle cx="50" cy="50" r="11"/><path d="M29 23c36 3 41 49 0 54M23 34c31 5 33 35 0 37"/>'
'''
txt=txt.replace(old,new)
txt=txt.replace('drawings[material.categoryId] || drawings.instrumentais','drawings[material.visual.schematicType] || drawings[material.categoryId] || drawings.instrumentais');app.write_text(txt)
# readable CSS: increase all explicit CSS values under 14px to 14px; preserve headings as-is
changes={}
for file in ('styles.css','interface.css','procedimentos.css'):
 p=root/file; css=p.read_text();count=[0]
 def fix(m):
  v=float(m.group(2))
  if v>=14:return m.group(0)
  count[0]+=1
  return f'{m.group(1)}14px'
 css=re.sub(r'(font-size\s*:\s*)(\d+(?:\.\d+)?)px',fix,css,flags=re.I)
 css=re.sub(r'(font-size\s*:\s*)(0\.\d+)rem',lambda m:f'{m.group(1)}0.875rem' if float(m.group(2))<.875 else m.group(0),css,flags=re.I)
 p.write_text(css);changes[file]=count[0]
# standard base font and line height with no global icon overrides
p=root/'interface.css';p.write_text(p.read_text()+'''
/* Consolidacao MB03: leitura confortável por padrão (12 pt ~= 16 px). */
html {font-size:16px;}
body {font-size:16px;line-height:1.55;}
#app :is(p,li,dd,dt), .site-footer, .side-nav a {line-height:1.6;}
:where(button,select,input,textarea){font-size:inherit;}
:where(button,a,input,select,textarea):focus-visible {outline:3px solid #D90429;outline-offset:2px;}
.atlas-detail-hero p,.procedure-header p,.procedure-field li{line-height:1.7;}
/* Permitir que os textos maiores se ajustem sem corte horizontal em telas pequenas. */
.atlas-card,.procedure-card,.dashboard-stat,.recommended-item,.study-area-card {min-width:0;overflow-wrap:break-word;}
@media(max-width:750px) {.atlas-variant-grid,.atlas-clinical-grid{grid-template-columns:1fr;} .procedure-header{overflow-wrap:anywhere;} }
''')
# bump package
pkg=root/'package.json';pk=json.loads(pkg.read_text());pk['version']='1.4.3-mb03-consolidacao';pk['scripts']['qa:typography']='node scripts/qa-typography.mjs';pkg.write_text(json.dumps(pk,ensure_ascii=False,indent=2)+'\n')
print('Atlas:',len(mat),'categories',len(atlas['categories']),'fontsize raised',changes)
