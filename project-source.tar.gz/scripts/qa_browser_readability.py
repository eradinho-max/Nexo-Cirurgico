import json,threading,http.server,socketserver,pathlib,sys
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent.parent
class Quiet(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*args,**kw): super().__init__(*args,directory=str(ROOT/'dist'),**kw)
 def log_message(self,*a): pass
class Server(socketserver.ThreadingMixIn,http.server.HTTPServer):daemon_threads=True
s=Server(('127.0.0.1',0),Quiet);threading.Thread(target=s.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{s.server_port}/'; results=[]; errors=[];samples=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 routes=['#/dashboard','#/atlas','#/atlas/MAT-ORT-003','#/atlas/MAT-SUT-004','#/procedimentos','#/procedimento/PT-M13-06','#/procedimento/PT-M07-01','#/matriz-tecnica','#/biblioteca']
 for label,width,height in [('desktop',1440,900),('tablet',768,900),('mobile',390,844)]:
  ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  for route in routes:
   page.goto(url+route,wait_until='load');page.wait_for_timeout(115)
   metrics=page.evaluate('''() => {const all=[...document.querySelectorAll('body, body *')].filter(e=>e.children.length===0 && e.textContent?.trim() && !['SCRIPT','STYLE','SVG','PATH'].includes(e.tagName)); const candidates=all.filter(e=>{const b=e.getBoundingClientRect();let s=getComputedStyle(e);return b.width>2 && b.height>2 && s.visibility==='visible'&&s.display!=='none'&&Number(s.opacity)!==0});return {w:document.documentElement.scrollWidth, viewport:innerWidth, candidates:candidates.length,min:candidates.length?Math.min(...candidates.map(e=>parseFloat(getComputedStyle(e).fontSize))):null, small:candidates.filter(e=>parseFloat(getComputedStyle(e).fontSize)<13.9).slice(0,5).map(e=>[e.tagName,e.className,e.textContent.slice(0,30),getComputedStyle(e).fontSize])}}''')
   results.append([label,route,metrics]);
   if metrics['w']>width+3:errors.append(f'{label} horizontal overflow {route}: {metrics["w"]}>{width}')
   if metrics['small']:errors.append(f'{label} small text {route}: {metrics["small"][:2]}')
   if label in ('desktop','mobile') and route in ('#/dashboard','#/procedimento/PT-M13-06','#/atlas/MAT-ORT-003'):
    tag=route.split('/')[-1] if route!='#/dashboard' else 'dashboard';page.screenshot(path=str(ROOT/f'qa_{label}_{tag}.png'),full_page=False)
  ctx.close()
 browser.close()
s.shutdown()
print(json.dumps({'status':'APROVADO' if not errors else 'REVISAR','routesChecked':len(results),'textSamples':sum(i[2]['candidates'] for i in results),'errors':errors[:25],'summary':[{ 'viewport':v,'route':r,'minFont':m['min'],'scrollWidth':m['w']} for v,r,m in results]},ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
