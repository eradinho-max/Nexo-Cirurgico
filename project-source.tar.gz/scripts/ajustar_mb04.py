from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
p=root/'procedimentos_mb03.js';s=p.read_text();s=s.replace('"MAT-INS-005",\n        "MAT-INS-003",\n        "MAT-SUT-001",\n        "MAT-INF-002"','"MAT-INS-005",\n        "MAT-INS-003",\n        "MAT-SUT-001"')
s+='''
/* Liga Atlas → ficha cirúrgica, mantendo navegação bidirecional sem inventar compatibilidade. */
(function(){
 const materials=new Map(window.NEXO_DATA.materialAtlas.materials.map(item=>[item.id,item]));
 for(const procedure of window.NEXO_PROCEDURES.procedures.filter(p=>p.id.startsWith('PT-M16-'))){
  for(const materialId of procedure.materialLinks){
   const material=materials.get(materialId);
   if(!material)throw new Error('MB04: material não cadastrado '+materialId);
   if(!material.procedureLinks.some(link=>link.topicId===procedure.id)){
    material.procedureLinks.push({topicId:procedure.id,role:'dependente-indicacao',note:'Instrumental de simulação; selecionar conforme técnica, tecido e fabricante.'});
   }
  }
 }
})();
'''
p.write_text(s)
# corrigir título da biblioteca de fichas para múltiplos macroblocos e roadmap com contagens verificáveis
p=root/'app.js';s=p.read_text();s=s.replace('setPage("Procedimentos fundamentais", "MB03 • FICHAS TÉCNICAS");','setPage("Procedimentos técnicos", "MB03 + MB04 • FICHAS TÉCNICAS");')
s=s.replace('MACROBLOCO 03 • ENTREGA EDITORIAL','MB03 + MB04 • BIBLIOTECA OPERACIONAL')
s=s.replace('<h1>Procedimentos fundamentais</h1>','<h1>Procedimentos técnicos</h1>')
s=s.replace('Nenhuma ficha possui validação clínica ou certifica execução prática.','Material disponível para estudo e simulação; não certifica execução prática.')
s=s.replace('setPage(proc.title, "FICHA TÉCNICA • MB03");','setPage(proc.title, `FICHA TÉCNICA • ${proc.id.startsWith("PT-M16-") ? "MB04" : "MB03"}`);')
s=s.replace('Ficha técnica MB03 • ${proc.id} • estudo disponível','Ficha técnica ${proc.id.startsWith("PT-M16-") ? "MB04" : "MB03"} • ${proc.id} • estudo disponível')
# mapa de 8 M16 práticas na própria tela principal, preserva rotas das 33 trilhas
s=s.replace('      <section class="roadmap-summary">','''      <section class="roadmap-summary">''')
s=s.replace('        <article><strong>${DATA.technicalCurriculum?.lessonSchema.length || 0}</strong><span>campos por ficha técnica</span></article>','''        <article><strong>${procedures.length}</strong><span>fichas de estudo com 14 campos</span></article>''')
s=s.replace('      ${macroblocks.length ? `<section class="roadmap-macroblocks">','''      <section class="panel" style="margin:18px 0;padding:19px"><span class="eyebrow">M16 — CIRURGIA GERAL</span><h2>8 procedimentos operacionais no MB04 Lote 1</h2><p>Os oito tópicos possuem fichas educacionais e checklists. O bloco de anestesia continua planejado para a próxima entrega.</p><a href="#/matriz-tecnica/M16" class="button secondary">Abrir a matriz M16 ${icon("arrow")}</a></section>
      ${macroblocks.length ? `<section class="roadmap-macroblocks">''')
# UX abre guia rápido para formação prática apenas 8 fichas novas
anchor='''      <section class="procedure-meta"><div><strong>População</strong>'''
quick='''      ${proc.id.startsWith('PT-M16-') ? `<section class="panel mb04-quick"><div class="mb04-quick-head"><span class="eyebrow">GUIA OPERACIONAL · SIMULAÇÃO</span><h2>Roteiro rápido — ${esc(proc.title)}</h2><p>Estude a sequência antes da simulação; a ficha completa contém materiais, contraindicações e cuidados.</p></div><ol>${proc.fields.sequence.map(line=>`<li>${esc(line)}</li>`).join('')}</ol><a class="button secondary" href="#field-materials" data-scroll-field="materials">Conferir instrumentos e materiais ${icon('arrow')}</a></section>` : ''}
'''
s=s.replace(anchor,quick+anchor)
p.write_text(s)
# estilo legível para etapa MB04
p=root/'procedimentos.css';s=p.read_text()+'''
/* MB04 — resumo operacional prático com leitura confortável em desktop/mobile */
.mb04-quick{margin:16px 0;padding:24px!important;border-top:4px solid #D90429}
.mb04-quick h2{font-size:clamp(20px,2vw,25px);margin:5px 0 9px;color:#1E293B}
.mb04-quick p{font-size:var(--nexo-reader-size,18px);line-height:1.6;color:#475569;margin:0}
.mb04-quick ol{margin:14px 0 16px;padding-left:28px;display:grid;gap:11px}
.mb04-quick li{font-size:var(--nexo-reader-size,18px);line-height:1.65;color:#263343;padding-left:5px}
.mb04-quick li::marker{font-weight:800;color:#A0001C}
@media(max-width:650px){.mb04-quick{padding:17px!important}.mb04-quick ol{padding-left:23px}}
''';p.write_text(s)
# atualizar mapeamento PT/ES sem alegar tradução integral de 14 campos
p=root/'idiomas.js';s=p.read_text();translations={
 'Incisões e vias de acesso':'Incisiones y vías de abordaje',
 'Dissecção por planos':'Disección por planos',
 'Hemostasia e ligaduras':'Hemostasia y ligaduras',
 'Laparotomia: preparo e princípios de abertura':'Laparotomía: preparación y principios de apertura',
 'Laparoscopia: equipamentos, acesso e segurança':'Laparoscopia: equipos, acceso y seguridad',
 'Fechamento por planos':'Cierre por planos',
 'Drenos cirúrgicos: seleção, instalação e vigilância':'Drenajes quirúrgicos: selección, colocación y vigilancia',
 'Conversão e encerramento cirúrgico seguro':'Conversión y cierre quirúrgico seguro',
 'Procedimentos técnicos':'Procedimientos técnicos',
 '8 procedimentos operacionais no MB04 Lote 1':'8 procedimientos operativos en MB04 Lote 1',
 'Roteiro rápido —':'Guía rápida —',
 'GUIA OPERACIONAL · SIMULAÇÃO':'GUÍA OPERATIVA · SIMULACIÓN',
 'Conferir instrumentos e materiais':'Revisar instrumentos y materiales',
 'Cirurgia geral':'Cirugía general',
 'Incisão':'Incisión',
 'Laparotomia':'Laparotomía',
 'Laparoscopia':'Laparoscopia',
 'Guia operacional':'Guía operativa',
}
import json
needle="  const selector = document.getElementById('languageSelector');"
s=s.replace(needle,'  Object.assign(translations, '+json.dumps(translations,ensure_ascii=False)+' );\n'+needle)
p.write_text(s)
print('MB04 interface/Atlas/i18n patched')
