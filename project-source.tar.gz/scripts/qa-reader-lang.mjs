import {readFile} from 'node:fs/promises';
const root=process.cwd();
const [css,index,i18n,build]=await Promise.all(['leitura.css','index.html','idiomas.js','scripts/build-static.mjs'].map(f=>readFile(`${root}/${f}`,'utf8')));
const expects=[
 ['controles idioma PT',index.includes('value="pt"')],
 ['idioma ES selecionável',index.includes('value="es"')],
 ['controle A+',index.includes('id="readerLarger"')],
 ['controle A−',index.includes('id="readerSmaller"')],
 ['estilos finais leitura',index.includes('href="leitura.css"')],
 ['script de idioma',index.includes('src="idiomas.js"')],
 ['persistencia idioma',i18n.includes('nexo-ui-language')],
 ['persistencia fonte',i18n.includes('nexo-reader-font')],
 ['sem aviso de bloqueio',!index.includes('localePending')&&!i18n.includes('siguen en portugués')],
 ['índice bilíngue real',i18n.includes('Sutura simple interrumpida')&&i18n.includes('Cómo clasificar un hilo')],
 ['troca e persistência',i18n.includes('change:setLanguage')&&i18n.includes('nexo-ui-language')],
 ['leitura na aula antiga',css.includes('#app .lesson-article .lesson-content')],
 ['leitura na ficha',css.includes('#app .procedure-field')],
 ['fonte principal 18px',css.includes('--nexo-reader-size:18px')],
 ['escala minima 16px',i18n.includes('Math.max(16,font-2)')],
 ['build inclui CSS',build.includes("'leitura.css'")],
 ['build inclui i18n',build.includes("'idiomas.js'")],
];
const bad=expects.filter(([,success])=>!success);
console.log(JSON.stringify({passed:expects.length-bad.length,total:expects.length,failed:bad.map(x=>x[0]),scope:'estrutura; navegador real nao verificado'},null,2));
if(bad.length)process.exit(1);
