import { cp, mkdir, rm, writeFile, readFile, stat } from 'node:fs/promises';
import path from 'node:path';
const root = process.cwd();
const dist = path.join(root, 'dist');
const files = ['index.html','styles.css','interface.css','procedimentos.css','data.js','procedimentos_mb03.js','app.js','robots.txt'];
const assets = ['nexo-cirurgico-logo.svg','mini-sutura.svg','mini-vascular.svg','mini-instrumentais.svg','mini-curativos.svg'];
await rm(dist,{recursive:true,force:true});
await mkdir(path.join(dist,'assets'),{recursive:true});
for(const filename of files) await cp(path.join(root,filename),path.join(dist,filename));
for(const filename of assets) await cp(path.join(root,'assets',filename),path.join(dist,'assets',filename));
const index = await readFile(path.join(dist,'index.html'),'utf8');
for (const src of ['styles.css','interface.css','procedimentos.css','data.js','procedimentos_mb03.js','app.js']){
 if(!index.includes(`"${src}"`)) throw new Error('Arquivo de aplicativo não registrado no HTML: '+src);
}
console.log('Build estático concluído:',dist, '- arquivos públicos:',files.length+assets.length);
