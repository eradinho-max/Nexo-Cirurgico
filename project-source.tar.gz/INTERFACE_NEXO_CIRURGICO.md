# Especificação de interface — Nexo Cirúrgico

**Versão:** 1.3  
**Data:** 14/10/2026  
**Escopo:** identidade provisória, shell da aplicação, dashboard e adaptação responsiva.

## 1. Direção de design

A interface adota uma linguagem médica editorial de alto contraste: navegação azul-marinho, superfícies claras, vermelho como cor de marca e turquesa apenas para indicadores de progresso. A composição foi inspirada na organização da referência fornecida, mas foi reconstruída com componentes e ativos próprios.

O objetivo é permitir que o usuário reconheça rapidamente quatro ações: continuar uma aula, consultar a matriz técnica, encontrar um procedimento/material e acompanhar o próprio percurso local.

## 2. Logomarca provisória

O arquivo vetorial original está em [`assets/nexo-cirurgico-logo.svg`](assets/nexo-cirurgico-logo.svg).

### Construção

- **Símbolo:** cruz médica geométrica combinada a um capelo.
- **Cruz:** representa segurança e contexto de saúde.
- **Capelo:** representa educação, formação contínua e supervisão.
- **Vermelho:** cria reconhecimento sem usar símbolos ou arquivos recortados da referência.
- **Assinatura:** “Nexo Cirúrgico” em duas linhas e descritor “Educação médica • protótipo”.

### Regras de uso

- Preferir fundo azul-marinho ou outra superfície escura de alto contraste.
- Não distorcer, rotacionar, recortar ou separar o símbolo do nome na assinatura principal.
- Manter área livre mínima equivalente à largura do braço vertical da cruz.
- O ativo é provisório e deve passar por revisão de marca antes de uso comercial.

## 3. Tokens visuais

| Token | Valor | Uso |
|---|---:|---|
| Azul-marinho principal | `#0B1628` | Sidebar, textos fortes e superfícies institucionais |
| Azul-marinho elevado | `#13233A` | Hover e painéis escuros |
| Vermelho de marca | `#D71936` | CTA, navegação ativa e destaque da marca |
| Vermelho escuro | `#AF0E28` | Hover e contraste |
| Turquesa | `#12A594` | Progresso e estados informativos positivos |
| Fundo | `#F5F7FA` | Canvas da aplicação |
| Papel | `#FFFFFF` | Cartões e painéis |
| Texto | `#111827` | Títulos e conteúdo principal |
| Texto secundário | `#667085` | Metadados e descrições |
| Linha | `#E5E9F0` | Bordas e separadores |

A tipografia usa a pilha nativa `Inter, Segoe UI, Arial, sans-serif`, sem dependência externa. Títulos usam pesos 750–850; corpo usa 400–600.

## 4. Arquitetura da navegação

### Grupo “Estudar”

1. Início
2. Matriz Técnica
3. Procedimentos
4. Atlas de Materiais
5. Casos
6. Checklists
7. Avaliações

### Grupo “Recursos”

Planos de estudo, Flashcards, Desafio rápido, Meu progresso, Plano de reforço, Videoteca, Roadmap e Fontes e créditos.

A barra lateral permanece fixa no desktop e se torna um painel deslizante em telas abaixo de 920 px. Todas as rotas anteriores continuam disponíveis.

## 5. Topbar

- busca global ampla com atalho `Ctrl/⌘ + K`;
- resultados de procedimentos, Atlas, trilhas, aulas, casos, competências, vídeos, fontes e roadmap;
- sino demonstrativo sem alegar eventos ou alertas clínicos reais;
- perfil local, armazenado somente no navegador;
- botão de menu em tablet e celular.

## 6. Dashboard

### Cabeçalho editorial

Apresenta saudação, propósito e citação curta. Não inclui agenda institucional nem alegação de certificação.

### Indicadores derivados do protótipo

- 33 trilhas;
- 115 aulas;
- progresso calculado pelas aulas concluídas no perfil local;
- 2 de 8 macroblocos editoriais entregues.

### Continuar aprendendo

Usa a próxima aula ainda não concluída no percurso recomendado. O percentual, número de aulas e duração são calculados a partir da trilha correspondente.

### Próximos passos

É uma **sequência recomendada**, não uma agenda. Mostra as três próximas aulas não concluídas e evita datas, horários ou compromissos inexistentes.

### Áreas de estudo

Atalhos para Procedimentos, Matriz Técnica, Casos, Atlas e Checklists.

### Procedimentos em destaque

Quatro cartões editoriais usam imagens ilustrativas próprias do protótipo:

- `assets/procedimento-sutura.jpg`;
- `assets/procedimento-acesso-vascular.jpg`;
- `assets/instrumentais-cirurgicos.jpg`;
- `assets/curativos-cirurgicos.jpg`.

As imagens representam ambientes de simulação/educação, não execução autônoma nem recomendação clínica. Títulos, contagens e progresso vêm dos módulos reais.

### Resumo da matriz

Mostra 28 módulos, 227 tópicos e 224 procedimentos canônicos. O anel representa a entrega editorial de macroblocos (2/8), não domínio de competência.

### Meta mensal

A meta é uma ação de estudo no perfil local (“concluir 3 aulas”), e não um número de procedimentos executados.

## 7. Integridade e limites clínicos

- Não são exibidos certificados conquistados.
- Não se afirma aquisição de competência clínica.
- O progresso é formativo e local.
- A agenda foi substituída por sequência recomendada.
- Procedimentos invasivos são abordados com foco educacional/perioperatório.
- Treinamento supervisionado, autorização institucional e limites profissionais permanecem explícitos.
- O estudo digital não substitui habilitação nem validação prática.

## 8. Responsividade

### Desktop — acima de 1180 px

Sidebar fixa de 268 px, topbar horizontal, painel principal com coluna de conteúdo e coluna lateral de 320 px.

### Tablet — 721 a 1179 px

Sidebar deslizante, indicadores em duas colunas, conteúdo principal em uma coluna e cartões de destaque em duas colunas.

### Celular — até 720 px

Busca compacta expansível, cartões empilhados, atalhos em duas colunas, CTAs em largura total e rodapé vertical.

## 9. Acessibilidade

- landmarks semânticos (`aside`, `nav`, `header`, `main`, `footer`);
- rótulos para busca, menu, notificações e perfil;
- foco preservado após troca de rota;
- contraste elevado entre navegação e texto;
- conteúdo essencial não depende de cor;
- animações discretas e compatibilidade com `prefers-reduced-motion`.

## 10. Implementação

Arquivos principais:

- `index.html` — shell, navegação, topbar, rodapé e inclusão do ativo vetorial;
- `interface.css` — sistema visual e responsividade desta versão;
- `app.js` — dashboard orientado a dados e rotas existentes;
- `data.js` — fonte única dos números e conteúdos;
- `qa_ui.js` — regressão funcional e verificações da nova interface.

A implementação não adiciona dependências de execução. O projeto continua sendo uma SPA estática servida por HTTP.
