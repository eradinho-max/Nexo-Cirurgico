# Nexo Cirúrgico — MB04 Lote 1: auditoria e entrega

**Release:** 1.5.0-mb04-lote1 · **Data:** 16/10/2026 · **Base preservada:** v1.4.5.

## Escopo entregue

- Oito fichas para os oito tópicos do M16 — Cirurgia Geral (PT-M16-01 a PT-M16-08).
- Cada ficha usa os 14 campos do contrato curricular, sequência de simulação, 5 itens de checklist, erros críticos, bibliografia institucional com URL e kits associados ao Atlas.
- Materiais relacionados possuem vínculos bidirecionais Atlas ↔ M16 (papel dependente da indicação). Materiais não cadastrados permanecem identificados como insumo adicional, **sem invenção de variantes ou compatibilidades**.
- Interface com guia rápido, filtro Cirurgia Geral e estado MB04 em desenvolvimento no roadmap; conteúdo antigo mantido.
- Seletor ES: títulos e resumos M16 traduzidos; textos técnicos de 14 campos ainda em português, não alegar tradução integral.

## Uso das fontes

Levantamento de técnica e habilidades orientado pelos índices dos manuais enviados: Tapia Jurado, *Manual de procedimientos médico-quirúrgicos* (2005), principalmente feridas, anestesia local, suturas, pós-operatório; *Manual Básico de Procedimentos Médicos Hospitalares* (FMUSP, 2017), com anatomia, técnicas e checklists; atualização de segurança a partir da OMS (Checklist Cirurgia Segura e SSI, 2018) e NICE NG125. Os cinco PDFs e suas imagens não são distribuídos ou republicados.

## Restrições e prioridades

- Laparotomia e laparoscopia: roteiros de preparação, anatomia, equipamentos e simulação, **não** técnicas completas para execução independente em paciente.
- Atlas específico de laparoscopia e de drenos ainda incompleto; listados nas fichas como itens ausentes no Atlas.
- Vídeos vinculados por ficha continuam para MB06.
- Anestesia, pré-operatório e recuperação ficam para MB04 Lote 2.
- Teste visual real no Chromium permanece não demonstrado neste ambiente; não declarar aprovado.
- Tradução completa PT/ES, como já estabelecido no Mapa Mestre, segue incremental.

## Garantias verificáveis

- Suite histórica `npm run qa:all` e nova `node qa_mb04.js` são executadas na entrega.
- IDs canônicos e vínculos com Matriz Técnica preservados, não houve remoção de aulas, provas, casos ou flashcards.
- Somente a pasta `dist` deve ser publicada; testes, documentos e livros permanecem fora da aplicação.

## Próximo passo

**MB04 Lote 2:** preparar conjunto procedural em M08 e M09 (anestesia local, preparo pré-operatório, checklist e recuperação), com treino de equipamento e fármacos contextualizados, sem inventar doses universais.
