from pathlib import Path
import re
R=Path(__file__).parent
p=R/'app.js'; a=p.read_text(encoding='utf-8')
def rep(old,new,label):
 global a
 if old not in a: raise RuntimeError('sem âncora: '+label)
 a=a.replace(old,new,1)
# Conteúdo no catálogo e busca
rep('  const atlasMaterials = DATA.materialAtlas?.materials || [];','  const atlasMaterials = DATA.materialAtlas?.materials || [];\n  const procedures = window.NEXO_PROCEDURES?.procedures || [];\n  const procedureForTopic = topicId => procedures.find(item => item.topicIds.includes(topicId));\n  const materialById = id => atlasMaterials.find(item => item.id === id);', 'procedures init')
rep('    completedLessons: ["instrumentais-logica", "fios-classificacao"],\n    learnedCards: [1, 5],', '    completedLessons: [],\n    learnedCards: [],', 'sem progresso demonstrativo')
rep('    atlasSearch: ""','    atlasSearch: "",\n    procedureSearch: "",\n    procedureCategory: "Todos"','ui filters')
rep('      const matches = [\n        ...technicalTopics','      const matches = [\n        ...procedures.filter(proc => searchIncludes(`${proc.id} ${proc.title} ${proc.scope} ${proc.additionalSupplies.join(" ")} ${proc.materialLinks.map(id => materialById(id)?.preferredName||id).join(" ")}`,term)).map(proc => ({title:proc.title,meta:`Ficha técnica MB03 • ${proc.id} • revisão pendente`,url:`#/procedimento/${proc.id}`})),\n        ...technicalTopics','global search')
# Rota da matriz
rep('${contextual ? `<b>${canonical.contexts.length} contextos • ficha canônica compartilhada</b>` : ""}</div></article>', '${contextual ? `<b>${canonical.contexts.length} contextos • ficha canônica compartilhada</b>` : ""}${procedureForTopic(topic.id) ? `<a class="topic-ficha-link" href="#/procedimento/${esc(topic.id)}">${icon("book")} Abrir ficha técnica em revisão ${icon("arrow")}</a>` : ""}</div></article>', 'topic details')
rep('          <a class="button primary technical-atlas-link" href="#/atlas">Abrir Atlas de materiais ${icon("arrow")}</a>', '          <a class="button primary technical-atlas-link" href="#/procedimentos">Fichas técnicas MB03 ${icon("arrow")}</a>\n          <a class="button secondary technical-atlas-link" href="#/atlas">Abrir Atlas de materiais ${icon("arrow")}</a>', 'matrix sidebar')
# Atlas → ficha técnica contextual
rep('${linkedTopics.map(item => `<a href="#/matriz-tecnica/${item.topic.module.id}/${item.topic.id}"><span><strong>${esc(item.topic.title)}</strong><small>${esc(item.topic.id)} • ${esc(item.role.replaceAll("-"," "))}</small></span>${icon("arrow")}</a>`).join("")}', '${linkedTopics.map(item => {const clinical=procedureForTopic(item.topic.id);return `<a href="${clinical ? `#/procedimento/${clinical.id}` : `#/matriz-tecnica/${item.topic.module.id}/${item.topic.id}`}"><span><strong>${esc(item.topic.title)}</strong><small>${esc(item.topic.id)} • ${esc(item.role.replaceAll("-"," "))}${clinical ? " • ficha disponível" : " • catálogo"}</small></span>${icon("arrow")}</a>`;}).join("")}', 'atlas bidirectional')
# nav active
rep('const active = key === route || (route === "modulo" || route === "aula") && key === "biblioteca"', 'const active = key === route || (route === "procedimento" && key === "procedimentos") || (route === "modulo" || route === "aula") && key === "biblioteca"', 'nav active')
rep('    else if (route === "biblioteca") renderLibrary();','    else if (route === "biblioteca") renderLibrary();\n    else if (route === "procedimentos") renderProcedures();\n    else if (route === "procedimento") renderProcedure(id);', 'route')
rep('{title:"Procedimentos", detail:`${canonicalProcedures} fichas canônicas`, href:"#/biblioteca",', '{title:"Procedimentos", detail:`${procedures.length} fichas técnicas em revisão`, href:"#/procedimentos",', 'dashboard')
rep('<div class="dashboard-block-head"><h2>Procedimentos em destaque</h2><div class="featured-toolbar"', '<div class="dashboard-block-head"><h2>Procedimentos em destaque</h2><div class="featured-toolbar"','not used no-op')
rep('<a href="#/biblioteca">Ver todos ${icon("arrow")}</a></div>\n            <div class="featured-procedure-grid">', '<a href="#/procedimentos">Ver fichas técnicas ${icon("arrow")}</a></div>\n            <div class="featured-procedure-grid">', 'dashboard list link')
rep('<div class="dashboard-block-head"><h2>Principais áreas de estudo</h2><a href="#/biblioteca">Explorar todas', '<div class="dashboard-block-head"><h2>Principais áreas de estudo</h2><a href="#/procedimentos">Explorar todas', 'dashboard areas link')
# insere funções antes de Atlas
insertion=r'''
  function renderProcedures() {
    setPage("Procedimentos fundamentais", "MB03 • FICHAS TÉCNICAS");
    const categories = [...new Set(procedures.map(item => item.scope))].sort();
    const visible = procedures.filter(item => {
      const all = `${item.title} ${item.id} ${item.scope} ${item.fields.definition.join(' ')} ${item.additionalSupplies.join(' ')} ${item.materialLinks.map(id=>materialById(id)?.preferredName||id).join(' ')}`;
      return searchIncludes(all,ui.procedureSearch) && (ui.procedureCategory === "Todos" || ui.procedureCategory === item.scope);
    });
    app.innerHTML = `<div class="view procedures-view">
      <div class="page-heading"><div><span class="eyebrow">MACROBLOCO 03 • ENTREGA EDITORIAL</span><h1>Procedimentos fundamentais</h1><p>${procedures.length} fichas educacionais com 14 campos, materiais rastreáveis, segurança e fontes. Nenhuma ficha possui validação clínica ou certifica execução prática.</p></div><a class="button secondary" href="#/matriz-tecnica">${icon("workflow")} Ver matriz completa</a></div>
      <section class="procedures-warning">${icon("shield")}<div><strong>Conteúdo em revisão técnica — não publicado como protocolo clínico</strong><p>Preparação para simulação e treinamento supervisionado. Aplicação no paciente depende de habilitação e protocolos locais.</p></div></section>
      <div class="procedure-filters"><form id="procedureSearchForm">${icon("search")}<input id="procedureSearchInput" type="search" value="${esc(ui.procedureSearch)}" aria-label="Pesquisar fichas" placeholder="sutura, ferida, cateter, tala, glicemia..."/><button class="button primary" type="submit">Buscar</button></form><select id="procedureCategorySelect" aria-label="Filtrar área"><option value="Todos">Todas as áreas</option>${categories.map(c=>`<option ${c===ui.procedureCategory?'selected':''} value="${esc(c)}">${esc(c)}</option>`).join('')}</select></div>
      <div class="procedure-count"><strong>${visible.length}</strong> fichas encontradas • ${DATA.technicalCurriculum.modules.reduce((n,m)=>n+m.topics.length,0)} tópicos catalogados no programa completo</div>
      ${visible.length ? `<section class="procedure-grid">${visible.map(item=>`<a href="#/procedimento/${esc(item.id)}" class="procedure-card"><span class="proc-area">${esc(item.scope)}</span><span class="proc-code">${esc(item.id)}</span><h2>${esc(item.title)}</h2><p>${esc(item.fields.definition[0])}</p><div class="proc-card-foot"><span>${icon('layers')} ${item.materialLinks.length} materiais do Atlas</span><span>${icon('book')} 14 campos</span>${icon('arrow')}</div><small class="proc-review-pill">${icon('info')} Revisão técnica pendente</small></a>`).join('')}</section>` : `<section class="panel technical-empty"><h2>Nenhuma ficha encontrada</h2><p>Experimente limpar a pesquisa ou utilizar a matriz com todos os tópicos.</p></section>`}
      ${disclaimer()}</div>`;
    document.getElementById('procedureSearchForm').addEventListener('submit',e=>{e.preventDefault();ui.procedureSearch=document.getElementById('procedureSearchInput').value;renderProcedures()});
    document.getElementById('procedureCategorySelect').addEventListener('change',e=>{ui.procedureCategory=e.target.value;renderProcedures()});
  }

  function renderProcedure(id) {
    const proc = procedures.find(item => item.id === id);
    if (!proc) return renderNotFound();
    const fields = DATA.technicalCurriculum.lessonSchema;
    const cards = fields.map(f=>{
      const lines=proc.fields[f.id] || [];
      return `<section class="panel procedure-field" id="field-${esc(f.id)}"><header><span>${String(f.order).padStart(2,'0')}</span><h2>${esc(f.title)}</h2></header>${f.id==='materials' ? `<p class="field-note">Referências vinculadas ao Atlas (conferir fabricante, escala e indicação individual).</p><div class="procedure-materials">${proc.materialLinks.map(mid=>{const m=materialById(mid);return `<a href="#/atlas/${esc(mid)}">${icon('layers')}<span>${esc(m?.preferredName || mid)}<small>${esc(mid)}</small></span>${icon('arrow')}</a>`}).join('')}</div><h3>Outros insumos necessários — cadastro no Atlas pendente</h3><ul>${proc.additionalSupplies.map(item=>`<li>${esc(item)}</li>`).join('')}</ul>`:''}
        ${f.id==='skills-checklist' ? `<div class="procedure-training"><p>Checklist formativo, sem atribuição automática de competência clínica:</p>${lines.map((line,i)=>`<label><input type="checkbox" class="proc-skill-check"/><span>${esc(line)}</span></label>`).join('')}<small id="skillsStatus" aria-live="polite">0 de ${lines.length} itens marcados nesta sessão</small></div>`:`<ul>${lines.map(line=>`<li>${esc(line)}</li>`).join('')}</ul>`}
        ${f.id==='media-references' ? `<div class="procedure-references">${proc.references.map(s=>`<a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${icon('external')}<span>${esc(s.title)}<small>Conferido em ${esc(s.checkedOn)} • vínculo editorial, sem reprodução do conteúdo</small></span></a>`).join('')}</div>`:''}
      </section>`;
    }).join('');
    setPage(proc.title, "FICHA TÉCNICA • MB03");
    app.innerHTML = `<div class="view procedure-detail"><a href="#/procedimentos" class="back-link">${icon('back')} Voltar às fichas</a>
      <section class="procedure-header"><div><span class="eyebrow">${esc(proc.id)} • ${esc(proc.scope)} • ${esc(proc.level)}</span><h1>${esc(proc.title)}</h1><p>${esc(proc.fields.definition[0])}</p><div class="procedure-tags"><span>${icon('shield')} ${esc(proc.editorial.status.replaceAll('-',' '))}</span><span>${icon('book')} 14 campos técnicos</span><span>${icon('layers')} ${proc.materialLinks.length} materiais rastreáveis</span></div></div><div class="procedure-hold">${icon('lock')}<strong>Não validado clinicamente</strong><small>Revisor clínico: não atribuído. Não usar como protocolo assistencial independente.</small></div></section>
      <section class="procedure-meta"><div><strong>População</strong><span>${esc(proc.population)}</span></div><div><strong>Ambiente</strong><span>${esc(proc.environment)}</span></div><div><strong>Supervisão</strong><span>${esc(proc.supervision)}</span></div><div><strong>Escopo profissional</strong><span>${esc(proc.professionalScope)}</span></div></section>
      <section class="procedure-danger"><strong>${icon('info')} Falhas críticas a evitar</strong><ul>${proc.criticalErrors.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></section>
      <div class="procedure-detail-layout"><div class="procedure-sections">${cards}</div><aside class="procedure-aside"><section class="panel"><h2>Índice da ficha</h2>${fields.map(f=>`<a href="#field-${esc(f.id)}" data-scroll-field="${esc(f.id)}"><span>${String(f.order).padStart(2,'0')}</span>${esc(f.title)}</a>`).join('')}</section><section class="panel"><h2>Pré-requisitos</h2><ul>${proc.prerequisites.map(s=>`<li>${esc(s)}</li>`).join('')}</ul><a class="button secondary" href="#/matriz-tecnica/${esc(proc.id.split('-')[1])}/${esc(proc.id)}">Ver tópico na matriz ${icon('arrow')}</a></section></aside></div>
      ${disclaimer()}</div>`;
    app.querySelectorAll('[data-scroll-field]').forEach(link=>link.addEventListener('click',e=>{e.preventDefault();document.getElementById('field-'+link.dataset.scrollField)?.scrollIntoView({behavior:'smooth',block:'start'})}));
    app.querySelectorAll('.proc-skill-check').forEach(x=>x.addEventListener('change',()=>{let all=app.querySelectorAll('.proc-skill-check');document.getElementById('skillsStatus').textContent=`${[...all].filter(z=>z.checked).length} de ${all.length} itens marcados nesta sessão — não é certificação`;}));
  }

'''
rep('  function atlasVisual(material, large = false) {',insertion+'  function atlasVisual(material, large = false) {','insert render')
p.write_text(a,encoding='utf-8')
# head, nav, credit and SVG (minimal markup)
idx=R/'index.html'; h=idx.read_text(encoding='utf-8');h=h.replace('<link rel="stylesheet" href="interface.css" />','<link rel="stylesheet" href="interface.css" />\n  <link rel="stylesheet" href="procedimentos.css" />')
h=h.replace('href="#/biblioteca" data-route="biblioteca"><span data-icon="thread"></span><span>Procedimentos</span>', 'href="#/procedimentos" data-route="procedimentos"><span data-icon="thread"></span><span>Procedimentos</span>')
h=h.replace('        <a href="#/planos" data-route="planos">', '        <a href="#/biblioteca" data-route="biblioteca"><span data-icon="book"></span><span>Biblioteca de aulas</span></a>\n        <a href="#/planos" data-route="planos">')
h=h.replace('2 de 8 macroblocos editoriais entregues.','3 de 8 macroblocos editoriais implementados.')
h=h.replace('<small>Protótipo educacional • O estudo digital não substitui habilitação, avaliação prática nem protocolos institucionais.</small>', '<small>Protótipo educacional • O estudo digital não substitui habilitação, avaliação prática nem protocolos institucionais. <span class="product-by">Product by <b>InMed</b></span></small>')
h=h.replace('<script src="app.js"></script>', '<script src="procedimentos_mb03.js"></script>\n  <script src="app.js"></script>')
idx.write_text(h,encoding='utf-8')
logo='''<svg xmlns="http://www.w3.org/2000/svg" width="248" height="76" viewBox="0 0 248 76" role="img" aria-labelledby="logo-title logo-desc">
<title id="logo-title">Nexo Cirúrgico</title><desc id="logo-desc">Símbolo geométrico vermelho e assinatura tipográfica Nexo Cirúrgico.</desc>
<defs><linearGradient id="nexo-red" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F12A3B"/><stop offset="1" stop-color="#A0001C"/></linearGradient></defs>
<g transform="translate(4 11)"><rect width="53" height="53" rx="13" fill="url(#nexo-red)"/><path d="M20 11h13v9h9v13h-9v9H20v-9h-9V20h9z" fill="white"/><path d="M12 11 26.5 5 41 11 26.5 17z" fill="#0b1628" stroke="#fff" stroke-width="1"/><path d="M39 13v9" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/><circle cx="39" cy="23" r="2" fill="#fff"/></g>
<g font-family="Inter,Montserrat,Segoe UI,Arial,sans-serif" fill="#FFFFFF"><text x="68" y="34" font-size="27" font-weight="800" letter-spacing="-.7">Nexo</text><text x="68" y="57" font-size="25" font-weight="800" letter-spacing="-.7">Cirúrgico</text></g>
</svg>'''
(R/'assets/nexo-cirurgico-logo.svg').write_text(logo,encoding='utf-8')
# Brand color setting appropriate InMed palette, preserve status teal
css=R/'interface.css'; s=css.read_text(encoding='utf-8').replace('--teal:#d71936;--teal-dark:#af0e28;', '--teal:#D90429;--teal-dark:#A0001C;').replace('--red:#d71936;', '--red:#D90429;').replace('--green:#12a594;--status:#12a594;', '--green:#2A9D8F;--status:#2A9D8F;')
s+='\n/* MB03 identidade refinada */\n.product-by{display:inline-block;margin-left:15px;white-space:nowrap;font-size:9px;color:#64748B}.product-by b{font-size:13px;letter-spacing:-.5px;color:#D90429}.sidebar .brand img{width:236px;height:74px;object-fit:contain}.sidebar .brand{height:95px}.topic-ficha-link{display:inline-flex!important;margin-top:8px;align-items:center;gap:5px;color:#A0001C!important;font-size:11px;font-weight:800;text-decoration:underline;text-underline-offset:3px}.topic-ficha-link svg{width:14px;height:14px}\n'
css.write_text(s,encoding='utf-8')
print('patch app/index/styles ok')
