"""Smoke test real Chromium/Playwright: python qa_browser_mb03.py (Playwright opcional)."""
import json, threading, socketserver, http.server, pathlib, sys
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parent
class Quiet(http.server.SimpleHTTPRequestHandler):
    def __init__(self,*args,**kw):super().__init__(*args,directory=str(ROOT),**kw)
    def log_message(self,*a):pass
class Server(socketserver.ThreadingMixIn,http.server.HTTPServer):daemon_threads=True
server=Server(('127.0.0.1',0),Quiet);threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}/'
checks=[];errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for label,width,height in [('desktop',1440,900),('mobile',390,844)]:
        context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url+'#/dashboard');page.wait_for_timeout(650)
        checks.append([label+' dashboard',page.locator('.dashboard-view').count()==1])
        page.goto(url+'#/procedimentos');page.wait_for_timeout(200)
        checks.append([label+' cards',page.locator('.procedure-card').count()==15])
        page.locator('#procedureSearchInput').fill('sutura');page.locator('#procedureSearchForm button').click();page.wait_for_timeout(150)
        checks.append([label+' search',page.locator('.procedure-card').count()>=1])
        page.goto(url+'#/procedimento/PT-M05-01');page.wait_for_timeout(250)
        checks.append([label+' 14 sections',page.locator('.procedure-field').count()==14])
        checks.append([label+' materials links',page.locator('.procedure-materials a').count()==4])
        page.locator('.proc-skill-check').first.check();checks.append([label+' checklist interaction','1 de' in page.locator('#skillsStatus').inner_text()])
        page.locator('.procedure-materials a').first.click();page.wait_for_timeout(180)
        checks.append([label+' link atlas',page.locator('.atlas-detail-hero').count()==1])
        page.goto(url+'#/matriz-tecnica/M05/PT-M05-01');page.wait_for_timeout(180)
        checks.append([label+' link matrix to proc',page.locator('.topic-ficha-link').count()==1])
        page.goto(url+'#/atlas/MAT-VAS-001');page.wait_for_timeout(180)
        checks.append([label+' link atlas to proc',page.locator('a[href="#/procedimento/PT-M05-01"]').count()>0])
        page.goto(url+'#/dashboard');page.wait_for_timeout(150)
        checks.append([label+' responsive width',page.evaluate('document.documentElement.scrollWidth <= innerWidth + 2')])
        if label=='desktop':page.screenshot(path=str(ROOT/'qa_mb03_desktop.png'),full_page=True)
        else:page.goto(url+'#/procedimentos');page.wait_for_timeout(130);page.screenshot(path=str(ROOT/'qa_mb03_mobile.png'),full_page=True)
        context.close()
    browser.close()
server.shutdown()
print(json.dumps({'checks':checks,'errors':errors,'passed':sum(x[1] for x in checks),'total':len(checks)},ensure_ascii=False,indent=2))
sys.exit(1 if errors or any(not x[1] for x in checks) else 0)
