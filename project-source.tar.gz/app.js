(() => {
  const DATA = window.NEXO_DATA;
  const app = document.getElementById("app");
  const pageTitle = document.getElementById("pageTitle");
  const pageEyebrow = document.getElementById("pageEyebrow");
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  const iconPaths = {
    home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10M9 20v-6h6v6"/>',
    book: '<path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22Z"/><path d="M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22Z"/>',
    cards: '<rect x="4" y="5" width="15" height="16" rx="2"/><path d="m8 5 .5-2h11a2 2 0 0 1 2 2v12l-2 .5"/><path d="M8 10h7M8 14h5"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    clipboard: '<rect x="5" y="4" width="14" height="18" rx="2"/><path d="M9 4.5V3h6v1.5M9 10h6M9 14h6M9 18h4"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    checklist: '<path d="m4 6 1.5 1.5L8.5 4M11 6h9M4 12l1.5 1.5 3-3M11 12h9M4 18l1.5 1.5 3-3M11 18h9"/>',
    chevron: '<path d="m9 6 6 6-6 6"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    arrow: '<path d="M5 12h14M14 7l5 5-5 5"/>',
    back: '<path d="M19 12H5M10 17l-5-5 5-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    play: '<circle cx="12" cy="12" r="9"/><path d="m10 8 6 4-6 4Z"/>',
    award: '<circle cx="12" cy="8" r="5"/><path d="m8.5 12-1 9 4.5-2 4.5 2-1-9"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    rotate: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 8A7 7 0 0 1 18 6l2 6M18 16a7 7 0 0 1-11.9 2L4 12"/>',
    brain: '<path d="M9.5 4A3.5 3.5 0 0 0 6 7.5v.3A3 3 0 0 0 4 13a3 3 0 0 0 2.5 4.9A3.5 3.5 0 0 0 10 21V3.5A2.5 2.5 0 0 0 7.5 1M14.5 4A3.5 3.5 0 0 1 18 7.5v.3a3 3 0 0 1 2 5.2 3 3 0 0 1-2.5 4.9A3.5 3.5 0 0 1 14 21V3.5A2.5 2.5 0 0 1 16.5 1M10 8H7M14 8h3M10 13H6M14 13h4"/>',
    scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="m8.2 8.2 11.3 11.3M8.2 15.8 19.5 4.5"/>',
    thread: '<path d="M6 5c7-4 13 0 10 5s-9 2-8 7 8 4 10 1"/><path d="m17 4 3-2-1 4M6 20l-2 2"/>',
    position: '<circle cx="8" cy="5" r="2"/><path d="m5 21 3-7 5 2 4 5M8 8l4 4 6-2M3 14h5"/>',
    shield: '<path d="M12 3 4.5 6v5c0 5 3.2 8.4 7.5 10 4.3-1.6 7.5-5 7.5-10V6Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/>',
    anatomy: '<path d="M12 3c-2 0-3 1.5-3 3v3l-3 3v8M12 3c2 0 3 1.5 3 3v3l3 3v8M9 9h6M8 14h8M12 9v12"/>',
    workflow: '<rect x="3" y="4" width="6" height="5" rx="1"/><rect x="15" y="15" width="6" height="5" rx="1"/><path d="M9 6.5h6a3 3 0 0 1 3 3V15M15 17.5H9a3 3 0 0 1-3-3V9"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    print: '<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v7H6Z"/>',
    reset: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    video: '<rect x="3" y="5" width="15" height="14" rx="2"/><path d="m18 10 4-2v8l-4-2Z"/><path d="m9 9 5 3-5 3Z"/>',
    file: '<path d="M6 2h8l4 4v16H6Z"/><path d="M14 2v5h5M9 12h6M9 16h6"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>'
  };

  function icon(name, cls = "") {
    return `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${iconPaths[name] || iconPaths.info}</svg>`;
  }

  function hydrateIcons(root = document) {
    root.querySelectorAll("[data-icon]").forEach(el => {
      el.innerHTML = icon(el.dataset.icon);
    });
  }

  function esc(value) {
    return String(value ?? "").replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[c]);
  }

  function normalizeSearch(value) {
    return String(value ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
  }

  function searchIncludes(value, term) {
    const haystack = normalizeSearch(value);
    const needle = normalizeSearch(term);
    if (!needle) return true;
    return needle.length <= 2 ? haystack.split(" ").includes(needle) : haystack.includes(needle);
  }

  const defaultState = {
    name: "Visitante",
    completedLessons: [],
    learnedCards: [],
    checklist: {},
    completedCases: [],
    quizBest: 0,
    quizAttempts: [],
    challengeToday: false
  };

  let state;
  try {
    state = {...defaultState, ...JSON.parse(localStorage.getItem("nexo-cirurgico-state") || "{}")};
  } catch {
    state = {...defaultState};
  }

  const ui = {
    libraryFilter: "Todos",
    cardDeck: "Todos",
    cardIndex: 0,
    cardFlipped: false,
    challenge: null,
    simulation: null,
    caseFilter: "Todos",
    caseAnswers: {},
    remediationPlanFilter: "Todos",
    technicalCategory: "Todos",
    technicalPriority: "Todos",
    technicalCoverage: "Todos",
    technicalSearch: "",
    atlasCategory: "Todos",
    atlasScale: "Todos",
    atlasApplication: "Todos",
    atlasSearch: "",
    procedureSearch: "",
    procedureCategory: "Todos"
  };

  const allLessons = DATA.modules.flatMap(module => module.lessons.map(lesson => ({...lesson, module})));
  const technicalTopics = (DATA.technicalCurriculum?.modules || []).flatMap(module => module.topics.map(topic => ({...topic, module})));
  const atlasMaterials = DATA.materialAtlas?.materials || [];
  const procedures = window.NEXO_PROCEDURES?.procedures || [];
  const procedureForTopic = topicId => procedures.find(item => item.topicIds.includes(topicId));
  const materialById = id => atlasMaterials.find(item => item.id === id);
  const curriculumLessons = DATA.studyPlans?.length ? DATA.studyPlans.flatMap(plan => plan.moduleIds.flatMap(moduleId => {
    const module = DATA.modules.find(item => item.id === moduleId);
    return module ? module.lessons.map(lesson => ({...lesson, module})) : [];
  })) : allLessons;
  const totalLessons = curriculumLessons.length;

  function save() {
    localStorage.setItem("nexo-cirurgico-state", JSON.stringify(state));
    updateProfileChrome();
  }

  function lessonDone(id) { return state.completedLessons.includes(id); }
  function completeCountFor(module) { return module.lessons.filter(l => lessonDone(l.id)).length; }
  function modulePercent(module) { return Math.round(completeCountFor(module) / module.lessons.length * 100); }
  function overallPercent() { return Math.round(state.completedLessons.length / totalLessons * 100); }
  function completedMinutes() { return allLessons.filter(l => lessonDone(l.id)).reduce((sum, l) => sum + l.duration, 0); }
  function findLesson(id) { return allLessons.find(l => l.id === id); }
  function findModule(id) { return DATA.modules.find(m => m.id === id); }
  function nextLesson() { return curriculumLessons.find(l => !lessonDone(l.id)) || curriculumLessons[0]; }
  function moduleMinutes(module) { return module.lessons.reduce((sum, lesson) => sum + lesson.duration, 0); }
  function planModules(plan) { return plan.moduleIds.map(findModule).filter(Boolean); }
  function planLessons(plan) { return planModules(plan).flatMap(module => module.lessons.map(lesson => ({...lesson, module}))); }
  function planPercent(plan) { const lessons = planLessons(plan); return Math.round(lessons.filter(lesson => lessonDone(lesson.id)).length / lessons.length * 100); }
  function planNextLesson(plan) { return planLessons(plan).find(lesson => !lessonDone(lesson.id)) || planLessons(plan)[0]; }
  function planForCompetency(competencyId) { return DATA.studyPlans.find(plan => plan.competencyIds.includes(competencyId)); }
  function remediationDefinition(competencyId) { return DATA.remediationMap.find(item => item.competencyId === competencyId); }
  function remediationLessons(competencyId) { return (remediationDefinition(competencyId)?.lessonIds || []).map(findLesson).filter(Boolean); }

  function setPage(title, eyebrow = "PLATAFORMA") {
    pageTitle.textContent = title;
    pageEyebrow.textContent = eyebrow;
    document.title = `${title} — Nexo Cirúrgico`;
  }

  function updateProfileChrome() {
    const name = state.name || "Visitante";
    const initials = name.split(/\s+/).slice(0,2).map(n => n[0]).join("").toUpperCase() || "VC";
    document.querySelectorAll(".avatar").forEach(el => el.textContent = initials);
    document.querySelectorAll(".sidebar-profile strong,.top-profile strong").forEach(el => el.textContent = name);
  }

  function toast(message) {
    const region = document.getElementById("toastRegion");
    const el = document.createElement("div");
    el.className = "toast";
    el.innerHTML = `${icon("check")}<span>${esc(message)}</span>`;
    region.appendChild(el);
    setTimeout(() => el.remove(), 2800);
  }

  function moduleIcon(module) {
    return `<span class="module-icon ${module.color}">${icon(module.icon)}</span>`;
  }

  function bannerArt() {
    return `<div class="banner-art" aria-hidden="true">
      <span class="orb one"></span><span class="orb two"></span>
      <svg class="instrument-lines" viewBox="0 0 260 180">
        <circle cx="55" cy="46" r="16"/><circle cx="55" cy="133" r="16"/><path d="M67 58 201 157M67 121 203 23M81 70l-15 14M81 109 66 94"/>
        <path d="M137 38c30 0 54 13 54 28s-24 28-54 28"/><path d="M137 38v56M191 66h34"/>
      </svg>
      <div class="floating-chip">${totalLessons} aulas • conteúdo em expansão</div>
    </div>`;
  }

  function disclaimer() {
    return `<div class="disclaimer-card">${icon("info")}<span>Conteúdo educacional complementar. Não substitui formação profissional, treinamento supervisionado, avaliação clínica ou protocolos institucionais.</span></div>`;
  }

  function externalMediaNotice() {
    return `<div class="external-media-notice">${icon("info")}<div><strong>Como os vídeos são usados</strong><span>Os botões abrem o conteúdo original no YouTube. A Nexo Cirúrgico não baixa, edita, copia nem hospeda esses vídeos. Título e canal identificam o criador; disponibilidade e políticas podem mudar.</span></div></div>`;
  }

  function videoCard(video, compact = false) {
    return `<article class="video-card ${compact ? "compact" : ""}">
      <a class="video-thumb" href="${esc(video.url)}" target="_blank" rel="noopener noreferrer" aria-label="Abrir ${esc(video.title)} no YouTube">
        <span class="video-thumb-art" aria-hidden="true"><i></i><b>${esc(video.channel)}</b><small>${esc(video.type)}</small></span>
        <span class="video-play">${icon("play")}</span>
        <span class="external-badge">YOUTUBE ${icon("external")}</span>
      </a>
      <div class="video-card-body">
        <div class="video-tags"><span>${esc(video.type)}</span><span>${esc(video.language)}</span></div>
        <h3>${esc(video.title)}</h3>
        <a class="video-channel" href="${esc(video.channelUrl)}" target="_blank" rel="noopener noreferrer">Crédito: ${esc(video.channel)} ${icon("external")}</a>
        ${compact ? "" : `<p>${esc(video.note)}</p><small>Título original: ${esc(video.originalTitle)} • link revisado em ${esc(video.checkedOn)}</small>`}
        <a class="button ${compact ? "secondary" : "primary"}" href="${esc(video.url)}" target="_blank" rel="noopener noreferrer">Assistir no YouTube ${icon("external")}</a>
      </div>
    </article>`;
  }

  function renderDashboard() {
    setPage("Início", "NEXO CIRÚRGICO");
    const next = nextLesson();
    const firstName = esc((state.name || "Visitante").split(" ")[0]);
    const macroblocks = DATA.technicalCurriculum?.macroblocks || [];
    const deliveredMacroblocks = macroblocks.filter(item => item.status === "Entregue").length;
    const technicalModules = DATA.technicalCurriculum?.modules || [];
    const totalTechnicalTopics = technicalModules.reduce((sum, item) => sum + item.topics.length, 0);
    const canonicalProcedures = DATA.technicalCurriculum?.canonicalProcedures?.length || 0;
    const completedLocalLessons = curriculumLessons.filter(lesson => lessonDone(lesson.id)).length;
    const monthlyTarget = 3;
    const monthlyDone = Math.min(completedLocalLessons, monthlyTarget);
    const monthlyPercent = Math.round(monthlyDone / monthlyTarget * 100);
    const recommended = curriculumLessons.filter(lesson => !lessonDone(lesson.id)).slice(0, 3);
    const nextModule = next.module;
    const nextModuleProgress = modulePercent(nextModule);
    const nextImage = nextModule.id === "fios-suturas" ? "assets/mini-sutura.svg" : nextModule.id === "acessos-vasculares-infusao" ? "assets/mini-vascular.svg" : nextModule.id === "instrumentais" ? "assets/mini-instrumentais.svg" : "assets/mini-curativos.svg";
    const featuredDefinitions = [
      {id:"fios-suturas", image:"assets/mini-sutura.svg"},
      {id:"acessos-vasculares-infusao", image:"assets/mini-vascular.svg"},
      {id:"instrumentais", image:"assets/mini-instrumentais.svg"},
      {id:"procedimentos-perioperatorios", image:"assets/mini-curativos.svg"}
    ];
    const featured = featuredDefinitions.map(item => ({...item, module:findModule(item.id)})).filter(item => item.module);
    const studyAreas = [
      {title:"Procedimentos", detail:`${procedures.length} fichas técnicas em revisão`, href:"#/procedimentos", icon:"thread", color:"linear-gradient(135deg,#df1738,#b70525)"},
      {title:"Matriz Técnica", detail:`${technicalModules.length} módulos catalogados`, href:"#/matriz-tecnica", icon:"workflow", color:"linear-gradient(135deg,#861629,#bf1532)"},
      {title:"Casos", detail:`${DATA.cases.length} situações formativas`, href:"#/casos", icon:"file", color:"linear-gradient(135deg,#13233a,#243955)"},
      {title:"Atlas de Materiais", detail:`${atlasMaterials.length} materiais`, href:"#/atlas", icon:"layers", color:"linear-gradient(135deg,#40546d,#74859a)"},
      {title:"Checklists", detail:`${DATA.checklist.reduce((sum, section) => sum + section.items.length, 0)} itens de estudo`, href:"#/checklist", icon:"checklist", color:"linear-gradient(135deg,#0b7e74,#13a897)"}
    ];

    app.innerHTML = `<div class="view dashboard-view" data-dashboard-modules="${DATA.modules.length}" data-dashboard-lessons="${totalLessons}">
      <header class="dashboard-hero">
        <div><h1>Bem-vindo ao <strong>Nexo Cirúrgico</strong>, ${firstName}</h1><p>Conhecimento técnico para uma formação cirúrgica mais segura, precisa e humana.</p></div>
        <div class="dashboard-quote">Técnica, conhecimento e propósito em cada etapa da sua formação.</div>
      </header>

      <section class="dashboard-stats" aria-label="Indicadores formativos">
        <article class="dashboard-stat"><span class="dashboard-stat-icon">${icon("book")}</span><span class="dashboard-stat-copy"><span>Trilhas</span><strong>${DATA.modules.length}</strong><small>no acervo atual</small></span></article>
        <article class="dashboard-stat"><span class="dashboard-stat-icon">${icon("play")}</span><span class="dashboard-stat-copy"><span>Aulas</span><strong>${totalLessons}</strong><small>conteúdos autorais</small></span></article>
        <article class="dashboard-stat progress-stat"><span class="mini-ring" style="--value:${overallPercent()}"><b>${overallPercent()}%</b></span><span class="dashboard-stat-copy"><span>Seu progresso</span><strong>${completedLocalLessons}<small style="display:inline"> de ${totalLessons}</small></strong><a class="dashboard-stat-link" href="#/progresso">Continuar aprendendo ${icon("arrow")}</a></span></article>
        <article class="dashboard-stat"><span class="dashboard-stat-icon">${icon("award")}</span><span class="dashboard-stat-copy"><span>Certificação</span><strong class="status-text">Não emitida</strong><small>protótipo formativo</small></span></article>
      </section>

      <section class="dashboard-layout">
        <div class="dashboard-main">
          <section class="dashboard-block">
            <div class="dashboard-block-head"><h2>Continuar aprendendo</h2><a href="#/planos">Ver percurso ${icon("arrow")}</a></div>
            <div class="continue-learning">
              <a class="continue-media" href="#/aula/${next.id}" aria-label="Continuar aula ${esc(next.title)}"><img src="${nextImage}" alt="Ambiente de simulação médica relacionado à trilha ${esc(nextModule.title)}"><span class="continue-play">${icon("play")}</span></a>
              <div class="continue-copy"><span class="eyebrow">PRÓXIMA AULA RECOMENDADA</span><h3>${esc(next.title)}</h3><p>${esc(next.summary)}</p><div class="continue-progress-row"><span class="progress-track"><i style="width:${nextModuleProgress}%"></i></span><span>${nextModuleProgress}% da trilha</span></div><div class="continue-meta"><span>${icon("book")} ${nextModule.lessons.length} aulas</span><span>${icon("clock")} ${moduleMinutes(nextModule)} min</span><span>${icon("chart")} ${esc(nextModule.level)}</span></div><a class="button primary" href="#/aula/${next.id}">Continuar aula ${icon("arrow")}</a></div>
            </div>
          </section>

          <section class="dashboard-block">
            <div class="dashboard-block-head"><h2>Principais áreas de estudo</h2><a href="#/procedimentos">Explorar todas ${icon("arrow")}</a></div>
            <div class="study-area-grid">${studyAreas.map(area => `<a class="study-area-card" href="${area.href}" style="--area-bg:${area.color}">${icon(area.icon)}<strong>${esc(area.title)}</strong><small>${esc(area.detail)}</small><span class="area-arrow">${icon("arrow")}</span></a>`).join("")}</div>
          </section>

          <section class="dashboard-block">
            <div class="dashboard-block-head"><h2>Procedimentos em destaque</h2><div class="featured-toolbar" aria-label="Categorias ilustrativas"><span>Todos</span><span>Fundamentos</span><span>Perioperatório</span></div><a href="#/procedimentos">Ver fichas técnicas ${icon("arrow")}</a></div>
            <div class="featured-procedure-grid">${featured.map(item => { const module=item.module,pct=modulePercent(module); return `<a class="featured-procedure-card" href="#/modulo/${module.id}"><div class="featured-image"><img src="${item.image}" alt="Ilustração educacional da trilha ${esc(module.title)}"><span class="featured-level">${esc(module.level)}</span><span class="featured-save">${icon("book")}</span></div><div class="featured-card-copy"><h3>${esc(module.title)}</h3><div class="featured-card-meta"><span>${icon("play")} ${module.lessons.length} aulas</span><span>${icon("clock")} ${moduleMinutes(module)} min</span></div><div class="featured-progress"><span class="progress-track"><i style="width:${pct}%"></i></span><b>${pct}%</b></div></div></a>`; }).join("")}</div>
          </section>
        </div>

        <aside class="dashboard-side">
          <section class="dashboard-block">
            <div class="dashboard-block-head"><h2>Próximos passos</h2><a href="#/planos">Ver sequência ${icon("arrow")}</a></div>
            <div class="recommended-list">${recommended.map((lesson,index) => `<a class="recommended-item" href="#/aula/${lesson.id}"><span class="step-number">${String(index+1).padStart(2,"0")}</span><span class="recommended-copy"><strong>${esc(lesson.title)}</strong><small>${esc(lesson.module.title)} • ${lesson.duration} min</small></span>${icon("chevron")}</a>`).join("")}</div>
          </section>

          <section class="dashboard-block">
            <div class="dashboard-block-head"><h2>Minha matriz técnica</h2><a href="#/matriz-tecnica">Ver matriz ${icon("arrow")}</a></div>
            <div class="matrix-summary"><div class="matrix-overview"><div class="matrix-ring" style="--value:${macroblocks.length ? Math.round(deliveredMacroblocks/macroblocks.length*100) : 0}"><span><strong>${deliveredMacroblocks}/${macroblocks.length}</strong><small>macroblocos entregues</small></span></div><div class="matrix-counts"><span><i></i><b>${technicalModules.length}</b> módulos</span><span><i></i><b>${totalTechnicalTopics}</b> tópicos</span><span><i></i><b>${canonicalProcedures}</b> fichas canônicas</span></div></div><p class="matrix-note">Resumo editorial do acervo; não representa competência clínica adquirida.</p></div>
          </section>

          <section class="monthly-goal"><span class="goal-icon">${icon("award")}</span><span><strong>Meta do mês</strong><small>Concluir 3 aulas no perfil local</small><span class="goal-progress"><span class="progress-track"><i style="width:${monthlyPercent}%"></i></span><b>${monthlyDone} de ${monthlyTarget}</b></span></span><a href="#/progresso" aria-label="Ver meta mensal">${icon("chevron")}</a></section>
          <div class="dashboard-caveat">${icon("info")}<span>Estudo complementar. Procedimentos exigem pré-requisitos, autorização institucional, treinamento supervisionado e avaliação prática.</span></div>
        </aside>
      </section>
    </div>`;
  }

  function renderLibrary() {
    setPage("Biblioteca", "CONTEÚDOS");
    const levels = ["Todos", "Essencial", "Intermediário"];
    const visible = ui.libraryFilter === "Todos" ? DATA.modules : DATA.modules.filter(m => m.level === ui.libraryFilter);
    app.innerHTML = `<div class="view">
      <div class="page-heading"><div><span class="eyebrow">BIBLIOTECA ATUAL</span><h1>Trilhas de aprendizagem</h1><p>Conteúdos autorais já desenvolvidos. Consulte a matriz técnica para ver os procedimentos catalogados, a cobertura atual e as lacunas da expansão.</p></div><div class="result-actions"><a class="button secondary" href="#/matriz-tecnica">${icon("workflow")} Matriz técnica</a><a class="button secondary" href="#/atlas">${icon("scissors")} Atlas</a><a class="button secondary" href="#/simulado">${icon("clipboard")} Simulado</a></div></div>
      <section class="blueprint-kpis library-kpis"><article><strong>${DATA.modules.length}</strong><span>trilhas</span></article><article><strong>${allLessons.length}</strong><span>aulas autorais</span></article><article><strong>${allLessons.reduce((sum, lesson) => sum + lesson.duration, 0).toLocaleString("pt-BR")}</strong><span>minutos de conteúdo</span></article><article><strong>${DATA.flashcards.length}</strong><span>flashcards</span></article></section>
      <div class="library-toolbar">${levels.map(level => `<button class="filter-chip ${ui.libraryFilter === level ? "active" : ""}" data-filter="${level}">${level}</button>`).join("")}</div>
      <section class="library-grid">
        ${visible.map(module => {
          const pct = modulePercent(module);
          return `<a class="module-card" style="--tint:${module.color === "teal" ? "#e4f7f2" : module.color === "blue" ? "#eaf0ff" : module.color === "violet" ? "#f0ecff" : module.color === "green" ? "#e9f7ee" : module.color === "rose" ? "#fcebf1" : "#fff0e6"}" href="#/modulo/${module.id}">
            <div class="module-card-top">${moduleIcon(module)}<span class="module-number">MÓDULO ${module.number}</span></div>
            <h2>${esc(module.title)}</h2><p>${esc(module.short)}</p>
            <div class="module-stats"><span>${icon("book")} ${module.lessons.length} aulas</span><span>${icon("clock")} ${moduleMinutes(module)} min</span><span>${module.level}</span></div>
            <div class="module-card-foot"><span class="progress-track"><i style="width:${pct}%"></i></span><strong>${pct}%</strong></div>
          </a>`;
        }).join("")}
      </section>
      ${disclaimer()}
    </div>`;
    app.querySelectorAll("[data-filter]").forEach(button => button.addEventListener("click", () => { ui.libraryFilter = button.dataset.filter; renderLibrary(); }));
  }

  function renderStudyPlans() {
    setPage("Planos de estudo", "PROGRESSÃO CURRICULAR");
    const totalMinutes = allLessons.reduce((sum, lesson) => sum + lesson.duration, 0);
    app.innerHTML = `<div class="view study-plans-view">
      <div class="page-heading"><div><span class="eyebrow">ROTEIRO RECOMENDADO</span><h1>Estude na ordem certa</h1><p>As 115 aulas foram organizadas em três etapas progressivas. A sequência orienta o estudo, mas não substitui currículo institucional, prática supervisionada ou validação de competência.</p></div><a class="button secondary" href="#/biblioteca">${icon("book")} Abrir biblioteca</a></div>
      <section class="blueprint-kpis study-plan-kpis"><article><strong>${DATA.studyPlans.length}</strong><span>etapas progressivas</span></article><article><strong>${DATA.modules.length}</strong><span>trilhas cobertas</span></article><article><strong>${allLessons.length}</strong><span>aulas organizadas</span></article><article><strong>${totalMinutes.toLocaleString("pt-BR")}</strong><span>minutos no percurso</span></article></section>
      <section class="study-sequence" aria-label="Sequência recomendada">${DATA.studyPlans.map((plan,index) => `<span><b>${esc(plan.order)}</b>${esc(plan.title)}</span>${index < DATA.studyPlans.length-1 ? icon("arrow") : ""}`).join("")}</section>
      <section class="study-plan-list">${DATA.studyPlans.map(plan => {
        const modules = planModules(plan);
        const lessons = planLessons(plan);
        const completed = lessons.filter(lesson => lessonDone(lesson.id)).length;
        const minutes = lessons.reduce((sum, lesson) => sum + lesson.duration, 0);
        const pct = planPercent(plan);
        const next = planNextLesson(plan);
        const competenceLabel = plan.competencyIds.length ? `${plan.competencyIds[0]}–${plan.competencyIds.at(-1)}` : "Conteúdo";
        return `<article class="study-plan-card" data-plan="${esc(plan.id)}">
          <header class="study-plan-head"><span class="study-plan-number">ETAPA ${esc(plan.order)}</span><div><span class="eyebrow">${esc(plan.level)} • ${esc(plan.audience)}</span><h2>${esc(plan.title)}</h2><p>${esc(plan.description)}</p></div><div class="study-plan-score"><strong>${pct}%</strong><small>${completed} de ${lessons.length} aulas</small></div></header>
          <div class="study-plan-progress"><div class="progress-track"><i style="width:${pct}%"></i></div><span>${minutes.toLocaleString("pt-BR")} min • ${modules.length} trilhas • ${competenceLabel}</span></div>
          <div class="study-plan-body"><div><h3>Resultados esperados</h3><ul>${plan.outcomes.map(item => `<li>${icon("check")}<span>${esc(item)}</span></li>`).join("")}</ul></div><div><h3>Trilhas desta etapa</h3><div class="study-module-links">${modules.map(module => `<a href="#/modulo/${module.id}"><span>M${esc(module.number)}</span>${esc(module.title)}</a>`).join("")}</div></div></div>
          <footer class="study-plan-foot"><div><span>PRÉ-REQUISITO RECOMENDADO</span><strong>${esc(plan.prerequisite)}</strong><small>${esc(plan.gate)}</small></div><a class="button primary" href="#/aula/${next.id}">${pct === 100 ? "Revisar etapa" : completed ? "Continuar etapa" : "Começar etapa"} ${icon("arrow")}</a></footer>
        </article>`;
      }).join("")}</section>
      <section class="panel study-assessment-note"><div>${icon("info")}</div><div><strong>Conteúdo e avaliação têm funções diferentes</strong><p>Os módulos novos de procedimentos e acessos foram incluídos para completar a formação didática sem aumentar novamente o banco de questões. O simulado continua formativo e cobre as 28 competências já estruturadas.</p></div><a href="#/blueprint">Ver blueprint ${icon("arrow")}</a></section>
      ${disclaimer()}
    </div>`;
  }

  function renderTechnicalMatrix(moduleId = null, topicId = null) {
    const curriculum = DATA.technicalCurriculum;
    if (!curriculum) return renderNotFound();
    const categories = curriculum.categories;
    const categoryFor = item => categories.find(category => category.id === item.categoryId);
    const coverageClass = value => value === "Base existente" ? "base" : value === "Cobertura parcial" ? "partial" : "gap";
    const statusFor = value => curriculum.topicStatusWorkflow.find(item => item.id === value);
    const canonicalFor = id => curriculum.canonicalProcedures.find(item => item.id === id);
    const relationLabel = value => ({"cobertura-direta":"Cobertura direta","fundamento":"Fundamento complementar","pre-requisito":"Pré-requisito"})[value] || value;
    const totalTopics = curriculum.modules.reduce((sum,item) => sum + item.topics.length,0);
    const selected = moduleId ? curriculum.modules.find(item => item.id === moduleId) : null;
    if (moduleId && !selected) return renderNotFound();

    if (selected) {
      const selectedTopic = topicId ? selected.topics.find(item => item.id === topicId) : null;
      if (topicId && !selectedTopic) return renderNotFound();
      const category = categoryFor(selected);
      const relations = (selected.lessonRelations || []).map(relation => ({...relation,lesson:findLesson(relation.lessonId)})).filter(item => item.lesson);
      const directRelations = relations.filter(item => item.relationType === "cobertura-direta");
      const topicStatusCounts = curriculum.topicStatusWorkflow.map(status => ({...status,count:selected.topics.filter(topic => topic.status === status.id).length}));
      setPage(`${selected.id} — ${selected.title}`, "MATRIZ TÉCNICA");
      app.innerHTML = `<div class="view technical-view">
        <a class="back-link" href="#/matriz-tecnica">${icon("back")} Voltar à matriz técnica</a>
        <section class="technical-detail-hero"><div><div class="technical-badges"><span>${esc(selected.id)}</span><span>${esc(selected.priority)}</span><span class="coverage-${coverageClass(selected.coverage)}">${esc(selected.coverage)}</span></div><span class="eyebrow">${esc(category?.title || "Matriz técnica")}</span><h1>${esc(selected.title)}</h1><p>O módulo separa catálogo editorial, conteúdo relacionado e cobertura direta. Uma aula vinculada não altera automaticamente o estado de uma ficha nem comprova validação clínica.</p></div><div class="technical-detail-count"><strong>${selected.topics.length}</strong><span>tópicos técnicos catalogados</span><small>${directRelations.length} vínculos diretos • ${relations.length} totais</small></div></section>
        ${selectedTopic ? `<section class="technical-focus-banner"><div>${icon("target")}</div><div><span class="eyebrow">RESULTADO EXATO DA BUSCA</span><strong>${esc(selectedTopic.id)} — ${esc(selectedTopic.title)}</strong><small>${esc(statusFor(selectedTopic.status)?.title)} • ${esc(selectedTopic.priorityLevels.join(" / "))} • ficha canônica ${esc(selectedTopic.canonicalProcedureId)}</small></div></section>` : ""}
        <section class="technical-status-strip">${topicStatusCounts.map(status => `<article class="${status.count ? "has-items" : ""}"><strong>${status.count}</strong><span>${esc(status.title)}</span></article>`).join("")}</section>
        <section class="technical-detail-layout"><div class="technical-detail-main">
          <section class="panel technical-topic-panel"><div class="section-title-row"><div><span class="eyebrow">ESCOPO OBRIGATÓRIO</span><h2>Procedimentos e conteúdos deste módulo</h2></div><span class="source-count">estado individual por tópico</span></div><div class="technical-topic-list">${selected.topics.map(topic => { const canonical=canonicalFor(topic.canonicalProcedureId); const contextual=canonical?.contexts.length > 1; return `<article id="topic-${esc(topic.id)}" class="${topic.id === topicId ? "selected" : ""}"><span>${esc(topic.id)}</span><div><strong>${esc(topic.title)}</strong><small>${esc(statusFor(topic.status)?.title)} • ${esc(topic.priorityLevels.join(" / "))}</small>${topic.aliases?.length ? `<em>${esc(topic.aliases.slice(0,3).join(" • "))}</em>` : ""}${contextual ? `<b>${canonical.contexts.length} contextos • ficha canônica compartilhada</b>` : ""}${procedureForTopic(topic.id) ? `<a class="topic-ficha-link" href="#/procedimento/${esc(topic.id)}">${icon("book")} Abrir ficha técnica em revisão ${icon("arrow")}</a>` : ""}</div></article>`; }).join("")}</div></section>
          <section class="panel technical-schema-panel"><div class="section-title-row"><div><span class="eyebrow">PADRÃO EDITORIAL</span><h2>Ficha técnica de 14 campos</h2></div><span class="source-count">obrigatória por procedimento</span></div><div class="technical-schema-grid">${curriculum.lessonSchema.map(field => `<article><b>${String(field.order).padStart(2,"0")}</b><div><strong>${esc(field.title)}</strong><p>${esc(field.description)}</p></div></article>`).join("")}</div></section>
        </div><aside class="technical-detail-side">
          <section class="panel technical-audience-card"><span class="eyebrow">PÚBLICO E LIMITE</span><h2>${esc(curriculum.primaryAudience)}</h2><p>${esc(curriculum.scopeStatement)}</p></section>
          <section class="panel technical-metadata-card"><span class="eyebrow">METADADOS OBRIGATÓRIOS</span><h2>Antes da publicação</h2>${curriculum.metadataFields.map(field => `<div><strong>${esc(field.title)}</strong>${field.values ? `<small>${field.values.map(esc).join(" • ")}</small>` : `<small>Preenchimento e revisão obrigatórios</small>`}</div>`).join("")}</section>
          <section class="panel technical-linked-card typed-relations"><span class="eyebrow">ACERVO ATUAL MAPEADO</span><h2>${relations.length} relações classificadas</h2>${relations.length ? `<div>${relations.map(relation => `<a href="#/aula/${relation.lesson.id}" class="relation-${esc(relation.relationType)}"><span><strong>${esc(relation.lesson.title)}</strong><small>${esc(relationLabel(relation.relationType))}${relation.targetTopicIds.length ? ` • ${relation.targetTopicIds.length} tópico(s)` : ""}</small></span>${icon("arrow")}</a>`).join("")}</div>` : `<p>Nenhuma aula atual foi associada. O módulo permanece como lacuna editorial.</p>`}</section>
          <a class="button primary technical-atlas-link" href="#/procedimentos">Fichas técnicas MB03 ${icon("arrow")}</a>
          <a class="button secondary technical-atlas-link" href="#/atlas">Abrir Atlas de materiais ${icon("arrow")}</a>
        </aside></section>
        ${disclaimer()}
      </div>`;
      if (selectedTopic) requestAnimationFrame(() => document.getElementById(`topic-${selectedTopic.id}`)?.scrollIntoView?.({block:"center"}));
      return;
    }

    setPage("Matriz técnica", "EXPANSÃO CURRICULAR");
    const term = normalizeSearch(ui.technicalSearch);
    const priorities = ["P0","P1","P2"];
    const coverageStates = [...new Set(curriculum.modules.map(item => item.coverage))];
    const gaps = curriculum.modules.filter(item => item.coverage === "Lacuna prioritária").length;
    const prepared = curriculum.modules.map(item => {
      const category = categoryFor(item);
      const matchingTopics = term ? item.topics.filter(topic => normalizeSearch(`${topic.id} ${topic.title} ${(topic.aliases || []).join(" ")} ${topic.canonicalProcedureId}`).includes(term)) : item.topics;
      const priorityTopics = ui.technicalPriority === "Todos" ? matchingTopics : matchingTopics.filter(topic => topic.priorityLevels.includes(ui.technicalPriority));
      return {item,category,topics:priorityTopics};
    });
    const visible = prepared.filter(({item,topics}) =>
      (ui.technicalCategory === "Todos" || item.categoryId === ui.technicalCategory) &&
      (ui.technicalCoverage === "Todos" || item.coverage === ui.technicalCoverage) &&
      topics.length > 0
    );
    const visibleTopicCount = visible.reduce((sum,entry) => sum + entry.topics.length,0);
    const catalogued = technicalTopics.filter(topic => topic.status === "catalogado").length;
    app.innerHTML = `<div class="view technical-view">
      <div class="page-heading"><div><span class="eyebrow">MB01 • ARQUITETURA CURRICULAR CORRIGIDA</span><h1>Biblioteca médica de procedimentos</h1><p>A matriz controla cada tópico separadamente, distingue tipos de vínculo e reutiliza procedimentos canônicos em diferentes especialidades.</p></div><div class="result-actions"><a class="button primary" href="#/atlas">${icon("scissors")} Atlas de materiais</a><a class="button secondary" href="#/biblioteca">${icon("book")} Acervo atual</a></div></div>
      <section class="technical-scope-banner"><div>${icon("shield")}</div><div><strong>${esc(curriculum.primaryAudience)}</strong><p>${esc(curriculum.scopeStatement)}</p></div><span>${esc(curriculum.status)}</span></section>
      <section class="blueprint-kpis technical-kpis"><article><strong>${curriculum.modules.length}</strong><span>módulos na matriz</span></article><article><strong>${totalTopics}</strong><span>tópicos rastreáveis</span></article><article><strong>${curriculum.canonicalProcedures.length}</strong><span>procedimentos canônicos</span></article><article><strong>${catalogued}</strong><span>ainda catalogados</span></article></section>
      <section class="panel technical-method"><div><span class="eyebrow">COBERTURA SEM INFLAÇÃO</span><h2>Aula relacionada não significa ficha pronta</h2><p>As ${curriculum.modules.reduce((sum,item)=>sum+item.lessonRelations.length,0)} relações atuais são classificadas como cobertura direta, fundamento complementar ou pré-requisito. Somente uma ficha aprovada poderá avançar nos estados editoriais; relação transversal não altera esse status.</p></div><a href="#/roadmap">Ver implementação por fases ${icon("arrow")}</a></section>
      <section class="technical-controls" aria-label="Filtros da matriz"><form id="technicalSearchForm"><span>${icon("search")}</span><input id="technicalSearchInput" value="${esc(ui.technicalSearch)}" placeholder="Buscar ECG, puncao, PICC, sutura simples..." aria-label="Buscar procedimento"><button class="button primary" type="submit">Buscar</button></form><select id="technicalPriorityFilter" aria-label="Filtrar prioridade"><option>Todos</option>${priorities.map(value => `<option ${ui.technicalPriority === value ? "selected" : ""}>${esc(value)}</option>`).join("")}</select><select id="technicalCoverageFilter" aria-label="Filtrar cobertura"><option>Todos</option>${coverageStates.map(value => `<option ${ui.technicalCoverage === value ? "selected" : ""}>${esc(value)}</option>`).join("")}</select>${ui.technicalSearch || ui.technicalPriority !== "Todos" || ui.technicalCoverage !== "Todos" || ui.technicalCategory !== "Todos" ? `<button class="button secondary" id="clearTechnicalFilters">Limpar filtros</button>` : ""}</section>
      <div class="technical-category-filters"><button class="filter-chip ${ui.technicalCategory === "Todos" ? "active" : ""}" data-technical-category="Todos">Todos</button>${categories.map(category => `<button class="filter-chip ${ui.technicalCategory === category.id ? "active" : ""}" data-technical-category="${esc(category.id)}">${esc(category.title)}</button>`).join("")}</div>
      <div class="technical-results-head"><span><strong>${visible.length}</strong> de ${curriculum.modules.length} módulos</span><small>${visibleTopicCount} tópicos correspondentes${ui.technicalPriority !== "Todos" ? ` com ${esc(ui.technicalPriority)}` : ""}</small></div>
      ${visible.length ? `<section class="technical-module-grid">${visible.map(({item,category,topics}) => `<a class="technical-module-card" href="#/matriz-tecnica/${item.id}${term && topics.length === 1 ? `/${topics[0].id}` : ""}"><div class="technical-card-top"><span class="technical-code">${esc(item.id)}</span><span class="technical-priority">${esc(item.priority)}</span><span class="technical-coverage coverage-${coverageClass(item.coverage)}">${esc(item.coverage)}</span></div><small>${esc(category?.title || "")}</small><h2>${esc(item.title)}</h2><div class="technical-topic-preview">${topics.slice(0,4).map(topic => `<span><i>${esc(topic.id)}</i>${esc(topic.title)}</span>`).join("")}${topics.length > 4 ? `<b>+${topics.length-4}</b>` : ""}</div><footer><span>${topics.length} tópico(s) no recorte</span><span>${item.lessonRelations.length} relações de aula</span>${icon("arrow")}</footer></a>`).join("")}</section>` : `<section class="panel technical-empty"><h2>Nenhum tópico encontrado</h2><p>Revise o termo ou limpe os filtros para voltar à matriz completa.</p></section>`}
      <section class="panel technical-schema-summary"><div><span class="eyebrow">FLUXO EDITORIAL</span><h2>Estado individual e ficha canônica</h2><p>Contextos de especialidade podem compartilhar a mesma ficha principal sem duplicar recomendações clínicas.</p></div><div>${curriculum.topicStatusWorkflow.map(field => `<span><b>${String(field.order).padStart(2,"0")}</b>${esc(field.title)}</span>`).join("")}</div></section>
      ${disclaimer()}
    </div>`;
    document.getElementById("technicalSearchForm").addEventListener("submit", event => { event.preventDefault(); ui.technicalSearch = document.getElementById("technicalSearchInput").value; renderTechnicalMatrix(); });
    document.getElementById("technicalPriorityFilter").addEventListener("change", event => { ui.technicalPriority=event.target.value; renderTechnicalMatrix(); });
    document.getElementById("technicalCoverageFilter").addEventListener("change", event => { ui.technicalCoverage=event.target.value; renderTechnicalMatrix(); });
    app.querySelectorAll("[data-technical-category]").forEach(button => button.addEventListener("click", () => { ui.technicalCategory=button.dataset.technicalCategory; renderTechnicalMatrix(); }));
    document.getElementById("clearTechnicalFilters")?.addEventListener("click", () => { ui.technicalCategory="Todos"; ui.technicalPriority="Todos"; ui.technicalCoverage="Todos"; ui.technicalSearch=""; renderTechnicalMatrix(); });
  }


  function renderProcedures() {
    setPage("Procedimentos fundamentais", "MB03 • FICHAS TÉCNICAS");
    const categories = [...new Set(procedures.map(item => item.scope))].sort();
    const visible = procedures.filter(item => {
      const all = `${item.title} ${item.id} ${item.scope} ${item.fields.definition.join(' ')} ${item.additionalSupplies.join(' ')} ${item.materialLinks.map(id=>materialById(id)?.preferredName||id).join(' ')}`;
      return searchIncludes(all,ui.procedureSearch) && (ui.procedureCategory === "Todos" || ui.procedureCategory === item.scope);
    });
    app.innerHTML = `<div class="view procedures-view">
      <div class="page-heading"><div><span class="eyebrow">MACROBLOCO 03 • ENTREGA EDITORIAL</span><h1>Procedimentos fundamentais</h1><p>${procedures.length} fichas educacionais com 14 campos, materiais rastreáveis, segurança e fontes. Nenhuma ficha possui validação clínica ou certifica execução prática.</p></div><a class="button secondary" href="#/matriz-tecnica">${icon("workflow")} Ver matriz completa</a></div>
      <section class="procedures-warning">${icon("shield")}<div><strong>Conteúdo em revisão técnica — não publicado como protocolo clínico</strong><p>Preparação para simulação e treinamento supervisionado. Aplicação no paciente depende de habilitação e protocolos locais.</p></div></section>
      <div class="procedure-filters"><form id="procedureSearchForm">${icon("search")}<input id="procedureSearchInput" type="search" value="${esc(ui.procedureSearch)}" aria-label="Pesquisar fichas" placeholder="sutura, ferida, cateter, tala, glicemia..."/><button class="button primary" type="submit">Buscar</button></form><select id="procedureCategorySelect" aria-label="Filtrar área"><option value="Todos">Todas as áreas</option>${categories.map(c=>`<option ${c===ui.procedureCategory?'selected':''} value="${esc(c)}">${esc(c)}</option>`).join('')}</select></div>
      <div class="procedure-count"><strong>${visible.length}</strong> fichas encontradas • ${DATA.technicalCurriculum.modules.reduce((n,m)=>n+m.topics.length,0)} tópicos catalogados no programa completo</div>
      ${visible.length ? `<section class="procedure-grid">${visible.map(item=>`<a href="#/procedimento/${esc(item.id)}" class="procedure-card"><span class="proc-area">${esc(item.scope)}</span><span class="proc-code">${esc(item.id)}</span><h2>${esc(item.title)}</h2><p>${esc(item.fields.definition[0])}</p><div class="proc-card-foot"><span>${icon('layers')} ${item.materialLinks.length} materiais do Atlas</span><span>${icon('book')} 14 campos</span>${icon('arrow')}</div><small class="proc-review-pill">${icon('info')} Revisão técnica pendente</small></a>`).join('')}</section>` : `<section class="panel technical-empty"><h2>Nenhuma ficha encontrada</h2><p>Experimente limpar a pesquisa ou utilizar a matriz com todos os tópicos.</p></section>`}
      ${disclaimer()}</div>`;
    document.getElementById('procedureSearchForm').addEventListener('submit',e=>{e.preventDefault();ui.procedureSearch=document.getElementById('procedureSearchInput').value;renderProcedures()});
    document.getElementById('procedureCategorySelect').addEventListener('change',e=>{ui.procedureCategory=e.target.value;renderProcedures()});
  }

  function renderProcedure(id) {
    const proc = procedures.find(item => item.id === id);
    if (!proc) return renderNotFound();
    const fields = DATA.technicalCurriculum.lessonSchema;
    const cards = fields.map(f=>{
      const lines=proc.fields[f.id] || [];
      return `<section class="panel procedure-field" id="field-${esc(f.id)}"><header><span>${String(f.order).padStart(2,'0')}</span><h2>${esc(f.title)}</h2></header>${f.id==='materials' ? `<p class="field-note">Referências vinculadas ao Atlas (conferir fabricante, escala e indicação individual).</p><div class="procedure-materials">${proc.materialLinks.map(mid=>{const m=materialById(mid);return `<a href="#/atlas/${esc(mid)}">${icon('layers')}<span>${esc(m?.preferredName || mid)}<small>${esc(mid)}</small></span>${icon('arrow')}</a>`}).join('')}</div><h3>Outros insumos necessários — cadastro no Atlas pendente</h3><ul>${proc.additionalSupplies.map(item=>`<li>${esc(item)}</li>`).join('')}</ul>`:''}
        ${f.id==='sequence' ? `<p class="field-note">Lote textual para simulação. As ilustrações anatômicas específicas ainda serão desenvolvidas e validadas.</p>` : ''}${f.id==='skills-checklist' ? `<div class="procedure-training"><p>Checklist formativo, sem atribuição automática de competência clínica:</p>${lines.map((line,i)=>`<label><input type="checkbox" class="proc-skill-check"/><span>${esc(line)}</span></label>`).join('')}<small id="skillsStatus" aria-live="polite">0 de ${lines.length} itens marcados nesta sessão</small></div>`:`<ul>${lines.map(line=>`<li>${esc(line)}</li>`).join('')}</ul>`}
        ${f.id==='media-references' ? `<div class="procedure-references">${proc.references.map(s=>`<a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${icon('external')}<span>${esc(s.title)}<small>Conferido em ${esc(s.checkedOn)} • vínculo editorial, sem reprodução do conteúdo</small></span></a>`).join('')}</div>`:''}
      </section>`;
    }).join('');
    setPage(proc.title, "FICHA TÉCNICA • MB03");
    app.innerHTML = `<div class="view procedure-detail"><a href="#/procedimentos" class="back-link">${icon('back')} Voltar às fichas</a>
      <section class="procedure-header"><div><span class="eyebrow">${esc(proc.id)} • ${esc(proc.scope)} • ${esc(proc.level)}</span><h1>${esc(proc.title)}</h1><p>${esc(proc.fields.definition[0])}</p><div class="procedure-tags"><span>${icon('shield')} ${esc(proc.editorial.status.replaceAll('-',' '))}</span><span>${icon('book')} 14 campos técnicos</span><span>${icon('layers')} ${proc.materialLinks.length} materiais rastreáveis</span></div></div><div class="procedure-hold">${icon('lock')}<strong>Não validado clinicamente</strong><small>Revisor clínico: não atribuído. Não usar como protocolo assistencial independente.</small></div></section>
      <section class="procedure-meta"><div><strong>População</strong><span>${esc(proc.population)}</span></div><div><strong>Ambiente</strong><span>${esc(proc.environment)}</span></div><div><strong>Supervisão</strong><span>${esc(proc.supervision)}</span></div><div><strong>Escopo profissional</strong><span>${esc(proc.professionalScope)}</span></div></section>
      <section class="procedure-danger"><strong>${icon('info')} Falhas críticas a evitar</strong><ul>${proc.criticalErrors.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></section>
      <section class="panel procedure-kit"><div class="procedure-kit-head"><div><span class="eyebrow">PREPARO DE SIMULAÇÃO</span><h2>Conferência da bandeja / kit</h2><p>Marque os materiais disponíveis para treinamento. Esta lista é formativa, incompleta para uso assistencial e deve ser conferida com o protocolo do serviço.</p></div><small class="kit-progress" id="kitStatus" aria-live="polite">0 itens conferidos</small></div><div class="procedure-kit-list">${[...proc.materialLinks.map(mid=>({label:materialById(mid)?.preferredName || mid,ref:mid})),...proc.additionalSupplies.map(item=>({label:item,ref:null}))].map(item=>`<label class="kit-item"><input type="checkbox" class="proc-kit-check"/><span>${esc(item.label)}${item.ref?`<small><a href="#/atlas/${esc(item.ref)}">Consultar no Atlas ${icon('arrow')}</a></small>`:''}</span></label>`).join('')}</div><p class="field-note">Não representa conferência para paciente real. O uso requer avaliação clínica, profissional habilitado e materiais conforme fabricante.</p></section>

      <div class="procedure-detail-layout"><div class="procedure-sections">${cards}</div><aside class="procedure-aside"><section class="panel"><h2>Índice da ficha</h2>${fields.map(f=>`<a href="#field-${esc(f.id)}" data-scroll-field="${esc(f.id)}"><span>${String(f.order).padStart(2,'0')}</span>${esc(f.title)}</a>`).join('')}</section><section class="panel"><h2>Pré-requisitos</h2><ul>${proc.prerequisites.map(s=>`<li>${esc(s)}</li>`).join('')}</ul><a class="button secondary" href="#/matriz-tecnica/${esc(proc.id.split('-')[1])}/${esc(proc.id)}">Ver tópico na matriz ${icon('arrow')}</a></section></aside></div>
      ${disclaimer()}</div>`;
    app.querySelectorAll('[data-scroll-field]').forEach(link=>link.addEventListener('click',e=>{e.preventDefault();document.getElementById('field-'+link.dataset.scrollField)?.scrollIntoView({behavior:'smooth',block:'start'})}));
    app.querySelectorAll('.proc-skill-check').forEach(x=>x.addEventListener('change',()=>{let all=app.querySelectorAll('.proc-skill-check');document.getElementById('skillsStatus').textContent=`${[...all].filter(z=>z.checked).length} de ${all.length} itens marcados nesta sessão — não é certificação`;}));
    app.querySelectorAll('.proc-kit-check').forEach(x=>x.addEventListener('change',()=>{const all=[...app.querySelectorAll('.proc-kit-check')];document.getElementById('kitStatus').textContent=`${all.filter(z=>z.checked).length} de ${all.length} itens conferidos — simulação`;}));
  }

  function atlasVisual(material, large = false) {
    const drawings = {
      vascular:'<path d="M17 73 76 27M70 22l12 11M27 63l8 9M73 30l11 11M13 77l8 8"/><path d="m19 69-6 13 13-6"/>',
      infusao:'<path d="M29 14h42v18l-7 9v39H36V41l-7-9Z"/><path d="M40 14v17h20V14M49 80v10M43 90h14M45 52h10M45 61h10"/>',
      medicacao:'<path d="M18 61 61 18l20 20-43 43Z"/><path d="m55 24 20 20M25 61l14 14M67 48l14 14M76 57l11-11"/><path d="m13 87 19-19"/>',
      sondas:'<path d="M21 14v40c0 17 12 31 29 31s29-14 29-31V38"/><path d="M73 14h12v24H73ZM15 14h12M21 14v-6M15 8h12"/><circle cx="50" cy="55" r="10"/>',
      'via-aerea':'<path d="M18 61c14-22 50-22 64 0l-12 23H30Z"/><path d="M50 39V14M43 14h14M38 65h24M50 65v19"/><circle cx="50" cy="52" r="5"/>',
      fechamento:'<path d="M17 72c17-31 39-43 67-52M79 17l8-2-4 8"/><path d="M26 68c8 6 8 14 0 20M39 55c8 6 8 14 0 20M52 43c8 6 8 14 0 20"/>',
      instrumentais:'<circle cx="24" cy="24" r="12"/><circle cx="24" cy="76" r="12"/><path d="m34 32 51 51M34 68 85 17M51 51l13 13M51 49l13-13"/>',
      imobilizacao:'<path d="M21 25h58v50H21z"/><path d="M21 35h58M21 46h58M21 57h58M21 68h58M35 25v50M49 25v50M63 25v50"/>' ,
      'fio-absorvivel':'<circle cx="40" cy="48" r="21"/><path d="M40 27c22 4 22 38 0 42M55 54c15-16 26-13 31-6s-5 16-15 22"/>',
      'fio-monofilamento':'<path d="M13 69c23-37 25-39 43-29s24-4 26-16"/><path d="M77 17l9 6-8 7"/>',
      fitas:'<path d="M13 35h74v32H13Z"/><path d="M23 35v32M34 35v32M45 35v32M56 35v32M67 35v32M78 35v32"/>',
      grampeador:'<path d="M20 22h43l20 17-8 11H50L39 75H24l10-32H20Z"/><path d="M50 50h26M57 57h13"/>',
      removedor:'<path d="M18 27c21 7 41 14 65 46M21 75l61-45M30 32v11M70 66v-9"/>',
      malha:'<path d="M26 18h48v64H26Z"/><path d="M26 34h48M26 50h48M26 66h48M42 18v64M58 18v64"/>',
      acolchoamento:'<rect x="20" y="28" width="60" height="45" rx="18"/><path d="M32 30c20 10 20 31 0 40M44 28c20 12 20 32 0 44M57 29c15 13 15 30 0 43"/>',
      gesso:'<path d="M24 17h52v67H24Z"/><path d="M24 34h52M24 51h52M24 68h52M40 17v67M58 17v67"/>',
      atadura:'<circle cx="50" cy="50" r="31"/><circle cx="50" cy="50" r="11"/><path d="M29 23c36 3 41 49 0 54M23 34c31 5 33 35 0 37"/>'

    };
    return `<div class="atlas-visual ${large ? "large" : ""}" role="img" aria-label="${esc(material.visual.alt)}"><svg viewBox="0 0 100 100" aria-hidden="true">${drawings[material.visual.schematicType] || drawings[material.categoryId] || drawings.instrumentais}</svg><span>ESQUEMA ORIGINAL</span></div>`;
  }

  function renderAtlas(materialId = null) {
    const atlas = DATA.materialAtlas;
    if (!atlas) return renderNotFound();
    const categoryFor = item => atlas.categories.find(category => category.id === item.categoryId);
    const scaleFor = item => atlas.scaleSystems.find(scale => scale.id === item.scaleSystem);
    const topicFor = id => technicalTopics.find(topic => topic.id === id);
    const sourceFor = id => atlas.sources.find(source => source.id === id);
    const selected = materialId ? atlas.materials.find(item => item.id === materialId) : null;
    if (materialId && !selected) return renderNotFound();

    if (selected) {
      const category = categoryFor(selected);
      const scale = scaleFor(selected);
      const linkedTopics = selected.procedureLinks.map(link => ({...link,topic:topicFor(link.topicId)})).filter(item => item.topic);
      const sources = selected.provenance.map(item => ({...item,source:sourceFor(item.sourceId)})).filter(item => item.source);
      setPage(selected.preferredName, "ATLAS DE MATERIAIS");
      app.innerHTML = `<div class="view atlas-view">
        <a class="back-link" href="#/atlas">${icon("back")} Voltar ao Atlas</a>
        <section class="atlas-detail-hero"><div>${atlasVisual(selected,true)}</div><div class="atlas-detail-title"><div class="atlas-detail-badges"><span>${esc(selected.id)}</span><span>Camada ${esc(category.layer)}</span><span>${esc(selected.review.status)}</span></div><span class="eyebrow">${esc(category.title)}</span><h1>${esc(selected.preferredName)}</h1><p>${esc(selected.description)}</p><div class="atlas-aliases">${selected.aliases.map(alias => `<span>${esc(alias)}</span>`).join("")}</div></div></section>
        <section class="atlas-detail-layout"><div class="atlas-main">
          ${scale ? `<section class="atlas-scale-callout"><div><span>${esc(scale.id)}</span></div><div><strong>${esc(scale.title)}</strong><p>${esc(scale.definition)}</p><small>${icon("info")} ${esc(scale.warning)}</small></div></section>` : ""}
          <section class="panel atlas-variants"><div class="section-title-row"><div><span class="eyebrow">VARIANTES E DIMENSÕES</span><h2>${selected.variants.length} configurações iniciais</h2></div><span class="source-count">confirmar sempre o produto</span></div><div class="atlas-variant-grid">${selected.variants.map(variant => `<article><header><strong>${esc(variant.label)}</strong>${variant.scaleValue ? `<span>${esc(variant.scaleValue)}</span>` : ""}</header>${variant.dimensions ? `<dl>${Object.entries(variant.dimensions).map(([key,value]) => `<div><dt>${esc(({nominalOuterDiameterMm:"Ø externo nominal",outerDiameterMm:"Ø externo",internalDiameterMm:"Ø interno",length:"Comprimento",lengthMm:"Comprimento",diameterRange:"Faixa de diâmetro",primingVolume:"Volume de preenchimento"})[key] || key)}</dt><dd>${esc(value)}${key.toLowerCase().includes("mm") && typeof value === "number" ? " mm" : ""}</dd></div>`).join("")}</dl>` : ""}${variant.color ? `<p class="variant-color"><i style="--variant-color:${esc(({"Laranja":"#ed8b3b","Cinza médio":"#8a9497","Branco":"#fff","Verde escuro":"#26785d","Rosa":"#e68aa1","Azul escuro":"#3476b5","Amarelo":"#efd357","Violeta":"#8b67b3","Preto":"#222","Marrom":"#8c6239"})[variant.color.value] || "#cbd6d4")}"></i><span><b>${esc(variant.color.value)}</b><small>${esc(variant.color.context)}</small></span></p>` : ""}${variant.connector ? `<p><b>Conector:</b> ${esc(variant.connector)}</p>` : ""}${variant.compatibility ? `<p><b>Compatibilidade:</b> ${esc(variant.compatibility)}</p>` : ""}<footer>${icon("shield")} Verificação do fabricante obrigatória</footer></article>`).join("")}</div></section>
          <section class="atlas-clinical-grid"><article class="panel"><span class="eyebrow">APLICAÇÕES GERAIS</span><h2>Onde aparece</h2><ul>${selected.generalIndications.map(item => `<li>${icon("check")}<span>${esc(item)}</span></li>`).join("")}</ul></article><article class="panel caution"><span class="eyebrow">PRECAUÇÕES</span><h2>Antes de selecionar</h2><ul>${selected.precautions.map(item => `<li>${icon("info")}<span>${esc(item)}</span></li>`).join("")}</ul></article><article class="panel risk"><span class="eyebrow">RISCOS</span><h2>O que reconhecer</h2><ul>${selected.risks.map(item => `<li>${icon("info")}<span>${esc(item)}</span></li>`).join("")}</ul></article>${selected.alternatives.length ? `<article class="panel"><span class="eyebrow">ALTERNATIVAS</span><h2>Dependem do contexto</h2><ul>${selected.alternatives.map(item => `<li>${icon("arrow")}<span>${esc(item)}</span></li>`).join("")}</ul></article>` : ""}</section>
          ${selected.compatibility.length ? `<section class="panel atlas-compatibility"><div class="section-title-row"><div><span class="eyebrow">COMPATIBILIDADE</span><h2>Relações condicionais</h2></div></div>${selected.compatibility.map(item => { const other=atlas.materials.find(material => material.id === item.withMaterialId); return `<article><span class="compatibility-type ${esc(item.relationship)}">${esc(item.relationship.replaceAll("-"," "))}</span><div><strong>${other ? `<a href="#/atlas/${other.id}">${esc(other.preferredName)}</a>` : esc(item.withMaterialId)}</strong><p>${esc(item.condition)}</p><small>${esc(item.note)}</small></div></article>`; }).join("")}</section>` : ""}
        </div><aside class="atlas-side">
          <section class="panel atlas-procedures"><span class="eyebrow">PROCEDIMENTOS RELACIONADOS</span><h2>${linkedTopics.length} vínculos rastreáveis</h2>${linkedTopics.map(item => {const clinical=procedureForTopic(item.topic.id);return `<a href="${clinical ? `#/procedimento/${clinical.id}` : `#/matriz-tecnica/${item.topic.module.id}/${item.topic.id}`}"><span><strong>${esc(item.topic.title)}</strong><small>${esc(item.topic.id)} • ${esc(item.role.replaceAll("-"," "))}${clinical ? " • ficha disponível" : " • catálogo"}</small></span>${icon("arrow")}</a>`;}).join("")}</section>
          <section class="panel atlas-sources"><span class="eyebrow">PROVENIÊNCIA</span><h2>${sources.length} fontes ou requisitos</h2>${sources.map(item => item.source.url ? `<a href="${esc(item.source.url)}" target="_blank" rel="noopener noreferrer"><span><strong>${esc(item.source.title)}</strong><small>${esc(item.source.organization)} • ${esc(item.source.year)} • ${esc(item.source.status)}</small></span>${icon("external")}</a>` : `<div class="pending-source"><strong>${esc(item.source.title)}</strong><small>${esc(item.source.edition)} • ${esc(item.source.status)}</small></div>`).join("")}</section>
          <section class="panel atlas-license"><span class="eyebrow">VISUAL E LICENÇA</span><h2>${esc(selected.visual.license)}</h2><p>${esc(selected.visual.alt)}</p><small>Autor: ${esc(selected.visual.author)} • ativo ${esc(selected.visual.assetId)}</small></section>
          <section class="panel atlas-review"><span class="eyebrow">REVISÃO</span><h2>${esc(selected.review.status)}</h2><p>Versão ${esc(selected.review.version)}. Sem revisor clínico atribuído; não classificada como validada.</p></section>
        </aside></section>
        ${disclaimer()}
      </div>`;
      return;
    }

    setPage("Atlas de materiais", "MB02 • MATERIAIS MÉDICOS");
    const term = ui.atlasSearch.trim();
    const topicById = new Map(technicalTopics.map(topic => [topic.id,topic]));
    const applicationModules = [...new Map(atlas.materials.flatMap(material => material.procedureLinks.map(link => topicById.get(link.topicId)?.module)).filter(Boolean).map(module => [module.id,module])).values()].sort((a,b)=>a.id.localeCompare(b.id));
    const visible = atlas.materials.filter(material => {
      const linked = material.procedureLinks.map(link => topicById.get(link.topicId)).filter(Boolean);
      const haystack = `${material.id} ${material.preferredName} ${material.aliases.join(" ")} ${material.description} ${material.variants.map(variant => `${variant.label} ${variant.scaleValue || ""}`).join(" ")} ${linked.map(topic => `${topic.id} ${topic.title} ${topic.module.title}`).join(" ")}`;
      return searchIncludes(haystack,term) &&
        (ui.atlasCategory === "Todos" || material.categoryId === ui.atlasCategory) &&
        (ui.atlasScale === "Todos" || (ui.atlasScale === "Sem escala" ? !material.scaleSystem : material.scaleSystem === ui.atlasScale)) &&
        (ui.atlasApplication === "Todos" || linked.some(topic => topic.module.id === ui.atlasApplication));
    });
    const variantCount = atlas.materials.reduce((sum,item)=>sum+item.variants.length,0);
    app.innerHTML = `<div class="view atlas-view">
      <div class="page-heading"><div><span class="eyebrow">MB02 • NÚCLEO INICIAL</span><h1>Atlas de materiais médicos</h1><p>Pesquise materiais, variantes, calibres, compatibilidades e procedimentos relacionados. As fichas são educacionais e permanecem em revisão editorial.</p></div><a class="button secondary" href="#/matriz-tecnica">${icon("workflow")} Voltar à matriz</a></div>
      <section class="atlas-status-banner"><div>${icon("scissors")}</div><div><strong>Material → variante → procedimento → fonte</strong><p>Escalas diferentes não são misturadas. Cores são contextualizadas por família e nunca substituem a marcação ou as instruções do fabricante.</p></div><span>${esc(atlas.status)}</span></section>
      <section class="blueprint-kpis atlas-kpis"><article><strong>${atlas.materials.length}</strong><span>materiais iniciais</span></article><article><strong>${variantCount}</strong><span>variantes estruturadas</span></article><article><strong>${atlas.categories.length}</strong><span>categorias</span></article><article><strong>${atlas.sources.length}</strong><span>fontes e requisitos</span></article></section>
      <section class="atlas-controls"><form id="atlasSearchForm"><span>${icon("search")}</span><input id="atlasSearchInput" value="${esc(ui.atlasSearch)}" placeholder="jelco, IV, 24G, Foley, 14 Fr, nylon 4-0..." aria-label="Buscar material"><button class="button primary">Buscar</button></form><select id="atlasCategoryFilter" aria-label="Categoria"><option value="Todos">Todas as categorias</option>${atlas.categories.map(category => `<option value="${esc(category.id)}" ${ui.atlasCategory===category.id?"selected":""}>${esc(category.title)}</option>`).join("")}</select><select id="atlasScaleFilter" aria-label="Escala"><option value="Todos">Todas as escalas</option>${atlas.scaleSystems.map(scale => `<option value="${esc(scale.id)}" ${ui.atlasScale===scale.id?"selected":""}>${esc(scale.id)} — ${esc(scale.title)}</option>`).join("")}<option ${ui.atlasScale==="Sem escala"?"selected":""}>Sem escala</option></select><select id="atlasApplicationFilter" aria-label="Aplicação"><option value="Todos">Todos os módulos</option>${applicationModules.map(module => `<option value="${esc(module.id)}" ${ui.atlasApplication===module.id?"selected":""}>${esc(module.id)} — ${esc(module.title)}</option>`).join("")}</select>${term || ui.atlasCategory!=="Todos" || ui.atlasScale!=="Todos" || ui.atlasApplication!=="Todos" ? `<button class="button secondary" id="clearAtlasFilters">Limpar</button>` : ""}</section>
      <div class="atlas-results-head"><span><strong>${visible.length}</strong> de ${atlas.materials.length} materiais</span><small>${visible.reduce((sum,item)=>sum+item.variants.length,0)} variantes no recorte</small></div>
      ${visible.length ? `<section class="atlas-grid">${visible.map(material => { const category=categoryFor(material); const scale=scaleFor(material); const linked=material.procedureLinks.map(link=>topicFor(link.topicId)).filter(Boolean); return `<a class="atlas-card" href="#/atlas/${material.id}">${atlasVisual(material)}<div class="atlas-card-body"><div class="atlas-card-tags"><span>Camada ${esc(category.layer)}</span>${scale?`<b>${esc(scale.id)}</b>`:""}</div><small>${esc(category.title)}</small><h2>${esc(material.preferredName)}</h2><p>${esc(material.description)}</p><div class="atlas-card-variants"><strong>${material.variants.length} variantes</strong><span>${esc(material.variants.slice(0,3).map(item=>item.label).join(" • "))}</span></div><div class="atlas-card-procedures">${linked.slice(0,2).map(topic=>`<span>${esc(topic.id)} • ${esc(topic.title)}</span>`).join("")}</div><footer><span>${material.provenance.length} fontes/requisitos</span><span>${esc(material.review.status)}</span>${icon("arrow")}</footer></div></a>`; }).join("")}</section>` : `<section class="panel technical-empty"><h2>Nenhum material encontrado</h2><p>Revise o termo. A busca aceita siglas, nomes alternativos, variantes, dimensões e termos sem acento.</p></section>`}
      <section class="panel atlas-scale-summary"><div><span class="eyebrow">ESCALAS NÃO SÃO INTERCAMBIÁVEIS</span><h2>Leia cada sistema no seu contexto</h2></div><div>${atlas.scaleSystems.map(scale => `<article><span>${esc(scale.id)}</span><div><strong>${esc(scale.title)}</strong><p>${esc(scale.definition)}</p><small>${esc(scale.warning)}</small></div></article>`).join("")}</div></section>
      ${disclaimer()}
    </div>`;
    document.getElementById("atlasSearchForm").addEventListener("submit",event=>{event.preventDefault();ui.atlasSearch=document.getElementById("atlasSearchInput").value;renderAtlas();});
    document.getElementById("atlasCategoryFilter").addEventListener("change",event=>{ui.atlasCategory=event.target.value;renderAtlas();});
    document.getElementById("atlasScaleFilter").addEventListener("change",event=>{ui.atlasScale=event.target.value;renderAtlas();});
    document.getElementById("atlasApplicationFilter").addEventListener("change",event=>{ui.atlasApplication=event.target.value;renderAtlas();});
    document.getElementById("clearAtlasFilters")?.addEventListener("click",()=>{ui.atlasCategory="Todos";ui.atlasScale="Todos";ui.atlasApplication="Todos";ui.atlasSearch="";renderAtlas();});
  }

  function renderModule(moduleId) {
    const module = findModule(moduleId);
    if (!module) return renderNotFound();
    setPage(module.title, "TRILHA");
    const pct = modulePercent(module);
    const allObjectives = [...new Set(module.lessons.flatMap(l => l.objectives))].slice(0,5);
    const moduleSources = DATA.evidence.filter(source => (module.sourceIds || []).includes(source.id));
    app.innerHTML = `<div class="view">
      <a class="back-link" href="#/biblioteca">${icon("back")} Voltar à biblioteca</a>
      <div class="lesson-list-view">
        <div>
          <section class="panel module-intro">
            <div class="module-intro-header">${moduleIcon(module)}<div><span class="eyebrow">MÓDULO ${module.number} • ${module.level.toUpperCase()}</span><h1>${esc(module.title)}</h1><p>${esc(module.description)}</p></div></div>
            <div class="module-progress-box"><div><strong>Seu progresso</strong><span>${completeCountFor(module)} de ${module.lessons.length} aulas concluídas</span></div><div class="progress-track"><i style="width:${pct}%"></i></div></div>
          </section>
          <section class="panel lessons-panel">
            ${module.lessons.map((lesson, index) => `<div class="lesson-row">
              <span class="lesson-state ${lessonDone(lesson.id) ? "done" : ""}">${lessonDone(lesson.id) ? icon("check") : index + 1}</span>
              <span class="lesson-row-copy"><strong>${esc(lesson.title)}</strong><small>${lesson.duration} min • ${esc(lesson.summary)}</small></span>
              <a class="button ${lessonDone(lesson.id) ? "secondary" : "primary"}" href="#/aula/${lesson.id}">${lessonDone(lesson.id) ? "Revisar" : "Abrir aula"}</a>
            </div>`).join("")}
          </section>
        </div>
        <aside class="module-aside-wrap">
          <section class="panel module-aside"><h3>O que você vai aprender</h3><div class="objective-list">${allObjectives.map(item => `<div class="objective-item"><span>${icon("check")}</span><div>${esc(item)}</div></div>`).join("")}</div></section>
          <section class="panel references"><h3>Fontes da trilha</h3><ul>${moduleSources.length ? moduleSources.map(source => `<li><a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer"><strong>${esc(source.title)}</strong><span>${esc(source.organization)} • ${esc(source.year)} ${icon("external")}</span></a></li>`).join("") : `<li>Bibliografia específica em revisão editorial.</li>`}</ul><a class="all-sources-link" href="#/fontes">Ver biblioteca científica ${icon("arrow")}</a></section>
        </aside>
      </div>
    </div>`;
  }

  function renderLesson(lessonId) {
    const lesson = findLesson(lessonId);
    if (!lesson) return renderNotFound();
    setPage(lesson.title, lesson.module.title.toUpperCase());
    const index = curriculumLessons.findIndex(l => l.id === lesson.id);
    const previous = curriculumLessons[index - 1];
    const next = curriculumLessons[index + 1];
    const relatedVideos = DATA.videos.filter(video => video.moduleId === lesson.module.id).slice(0, 2);
    const lessonSourceIds = lesson.sourceIds || lesson.module.sourceIds || [];
    const lessonSources = DATA.evidence.filter(source => lessonSourceIds.includes(source.id));
    app.innerHTML = `<div class="view">
      <a class="back-link" href="#/modulo/${lesson.module.id}">${icon("back")} Voltar para ${esc(lesson.module.title)}</a>
      <div class="lesson-layout">
        <article class="lesson-article">
          <header class="lesson-hero">
            <div class="lesson-meta"><span>${icon("clock")} ${lesson.duration} minutos</span><span>${icon("layers")} ${lesson.module.level}</span><span>${icon("book")} ${lesson.sections.length} tópicos</span></div>
            <h1>${esc(lesson.title)}</h1><p>${esc(lesson.summary)}</p>
          </header>
          <div class="lesson-content">
            <section class="learning-objectives"><h3>Ao final desta aula, você será capaz de:</h3><ul>${lesson.objectives.map(item => `<li>${esc(item)}</li>`).join("")}</ul></section>
            ${lesson.sections.map((section, idx) => `<section class="content-section" id="topico-${idx + 1}"><h2>${esc(section.title)}</h2><p>${esc(section.body)}</p>${section.bullets ? `<ul>${section.bullets.map(item => `<li>${esc(item)}</li>`).join("")}</ul>` : ""}${section.callout ? `<div class="callout">${icon("info")}<span>${esc(section.callout)}</span></div>` : ""}</section>`).join("")}
            ${lessonSources.length ? `<section class="lesson-sources"><div class="section-title-row"><div><span class="eyebrow">BIBLIOGRAFIA DA AULA</span><h2>Fontes para aprofundamento</h2></div><a href="#/fontes">Todas as fontes</a></div><div class="lesson-source-list">${lessonSources.map(source => `<a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer"><span><strong>${esc(source.title)}</strong><small>${esc(source.organization)} • ${esc(source.year)}</small></span>${icon("external")}</a>`).join("")}</div><p class="source-method-note">Conteúdo redigido originalmente a partir destas referências. Protocolos institucionais e instruções do fabricante prevalecem na aplicação local.</p></section>` : ""}
            ${relatedVideos.length ? `<section class="lesson-videos"><div class="section-title-row"><div><span class="eyebrow">MATERIAL COMPLEMENTAR</span><h2>Veja a técnica em vídeo</h2></div><a href="#/videoteca">Ver videoteca</a></div><div class="lesson-video-grid">${relatedVideos.map(video => videoCard(video, true)).join("")}</div>${externalMediaNotice()}</section>` : ""}
          </div>
          <footer class="lesson-footer">
            ${previous ? `<a class="button secondary" href="#/aula/${previous.id}">${icon("back")}<span class="label">Anterior</span></a>` : `<span></span>`}
            <button class="button ${lessonDone(lesson.id) ? "secondary" : "primary"}" id="completeLesson">${icon("check")} ${lessonDone(lesson.id) ? "Aula concluída" : "Marcar como concluída"}</button>
            ${next ? `<a class="button secondary" href="#/aula/${next.id}"><span class="label">Próxima</span>${icon("arrow")}</a>` : `<a class="button secondary" href="#/simulado">Simulado ${icon("arrow")}</a>`}
          </footer>
        </article>
        <aside class="panel lesson-toc"><h3>Nesta aula</h3>${lesson.sections.map((section, idx) => `<a href="#/aula/${lesson.id}" data-scroll="topico-${idx + 1}" class="${idx === 0 ? "active" : ""}">${idx + 1}. ${esc(section.title)}</a>`).join("")}<div class="toc-progress"><div><strong>Trilha</strong><span>${modulePercent(lesson.module)}%</span></div><div class="progress-track"><i style="width:${modulePercent(lesson.module)}%"></i></div></div></aside>
      </div>
      ${disclaimer()}
    </div>`;
    app.querySelectorAll("[data-scroll]").forEach(link => link.addEventListener("click", event => {
      event.preventDefault();
      app.querySelectorAll(".lesson-toc a").forEach(item => item.classList.remove("active"));
      link.classList.add("active");
      document.getElementById(link.dataset.scroll)?.scrollIntoView({behavior:"smooth", block:"start"});
    }));
    document.getElementById("completeLesson").addEventListener("click", () => {
      if (lessonDone(lesson.id)) state.completedLessons = state.completedLessons.filter(id => id !== lesson.id);
      else state.completedLessons.push(lesson.id);
      save(); toast(lessonDone(lesson.id) ? "Aula marcada como concluída." : "Conclusão removida."); renderLesson(lesson.id);
    });
  }

  function visibleCards() {
    return ui.cardDeck === "Todos" ? DATA.flashcards : DATA.flashcards.filter(card => card.deck === ui.cardDeck);
  }

  function renderFlashcards() {
    setPage("Flashcards", "PRATICAR");
    const decks = ["Todos", ...new Set(DATA.flashcards.map(card => card.deck))];
    const cards = visibleCards();
    if (ui.cardIndex >= cards.length) ui.cardIndex = 0;
    const card = cards[ui.cardIndex];
    const learned = state.learnedCards.includes(card.id);
    app.innerHTML = `<div class="view practice-layout">
      <div class="page-heading"><div><span class="eyebrow">REVISÃO ATIVA</span><h1>Flashcards</h1><p>Tente responder antes de virar o cartão. Marque como dominado quando conseguir explicar sem consultar.</p></div><span class="button secondary">${icon("award")} ${state.learnedCards.length} dominados</span></div>
      <div class="deck-tabs">${decks.map(deck => `<button class="filter-chip ${ui.cardDeck === deck ? "active" : ""}" data-deck="${esc(deck)}">${esc(deck)}</button>`).join("")}</div>
      <div class="flashcard-stage" id="flashcardStage" role="button" tabindex="0" aria-label="Virar cartão">
        <div class="flashcard ${ui.cardFlipped ? "flipped" : ""}">
          <div class="card-face front"><span class="card-type">PERGUNTA</span><span class="deck-name">${esc(card.deck)}</span><h2>${esc(card.front)}</h2><span class="flip-hint">${icon("rotate")} Clique para revelar</span></div>
          <div class="card-face back"><span class="card-type">RESPOSTA</span><span class="deck-name">${esc(card.deck)}</span><h2>${esc(card.back)}</h2><span class="flip-hint">${icon("rotate")} Clique para voltar</span></div>
        </div>
      </div>
      <div class="flashcard-controls">
        <button class="icon-button" id="prevCard" aria-label="Cartão anterior">${icon("back")}</button>
        <span class="counter">${ui.cardIndex + 1} de ${cards.length}</span>
        <button class="icon-button" id="nextCard" aria-label="Próximo cartão">${icon("arrow")}</button>
        <button class="button secondary learned-button ${learned ? "active" : ""}" id="learnedCard">${icon("check")} ${learned ? "Dominado" : "Marcar como dominado"}</button>
      </div>
      ${disclaimer()}
    </div>`;
    app.querySelectorAll("[data-deck]").forEach(btn => btn.addEventListener("click", () => { ui.cardDeck = btn.dataset.deck; ui.cardIndex = 0; ui.cardFlipped = false; renderFlashcards(); }));
    const flip = () => { ui.cardFlipped = !ui.cardFlipped; app.querySelector(".flashcard").classList.toggle("flipped", ui.cardFlipped); };
    document.getElementById("flashcardStage").addEventListener("click", flip);
    document.getElementById("flashcardStage").addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); flip(); } });
    document.getElementById("prevCard").addEventListener("click", () => { ui.cardIndex = (ui.cardIndex - 1 + cards.length) % cards.length; ui.cardFlipped = false; renderFlashcards(); });
    document.getElementById("nextCard").addEventListener("click", () => { ui.cardIndex = (ui.cardIndex + 1) % cards.length; ui.cardFlipped = false; renderFlashcards(); });
    document.getElementById("learnedCard").addEventListener("click", () => {
      if (learned) state.learnedCards = state.learnedCards.filter(id => id !== card.id); else state.learnedCards.push(card.id);
      save(); toast(learned ? "Cartão removido dos dominados." : "Cartão marcado como dominado."); renderFlashcards();
    });
  }

  function shuffled(items) {
    const copy = [...items];
    for (let index = copy.length - 1; index > 0; index--) {
      const randomIndex = Math.floor(Math.random() * (index + 1));
      [copy[index], copy[randomIndex]] = [copy[randomIndex], copy[index]];
    }
    return copy;
  }
  function newChallenge() { ui.challenge = {questions: shuffled(DATA.quiz).slice(0,5), index:0, score:0, answered:false, selected:null, finished:false}; }

  function renderChallenge() {
    setPage("Desafio rápido", "PRATICAR");
    if (!ui.challenge) newChallenge();
    const c = ui.challenge;
    if (c.finished) {
      const pct = Math.round(c.score / c.questions.length * 100);
      state.challengeToday = true; save();
      app.innerHTML = `<div class="view quiz-shell"><div class="panel result-card"><div class="score-circle" style="--score:${pct}%"><strong>${pct}%</strong></div><h1>${pct >= 80 ? "Ótimo resultado!" : pct >= 60 ? "Bom começo!" : "Continue revisando"}</h1><p>Você respondeu ${c.score} de ${c.questions.length} questões corretamente.</p><div class="result-stats"><div class="result-stat"><strong>${c.score}</strong><small>acertos</small></div><div class="result-stat"><strong>${c.questions.length-c.score}</strong><small>revisar</small></div><div class="result-stat"><strong>~3 min</strong><small>tempo</small></div></div><div class="result-actions"><button class="button primary" id="retryChallenge">${icon("reset")} Novo desafio</button><a class="button secondary" href="#/flashcards">Revisar flashcards</a></div></div>${disclaimer()}</div>`;
      document.getElementById("retryChallenge").addEventListener("click", () => { newChallenge(); renderChallenge(); });
      return;
    }
    const q = c.questions[c.index];
    app.innerHTML = `<div class="view quiz-shell">
      <div class="page-heading"><div><span class="eyebrow">5 QUESTÕES • FEEDBACK IMEDIATO</span><h1>Desafio rápido</h1><p>Uma prática curta para reforçar os pontos essenciais do dia.</p></div></div>
      <section class="quiz-card">
        <div class="quiz-top"><div class="quiz-status"><span>Questão ${c.index+1} de ${c.questions.length}</span><strong>${c.score} acertos</strong></div><div class="quiz-progress"><i style="width:${(c.index+1)/c.questions.length*100}%"></i></div></div>
        <div class="quiz-body"><div class="quiz-labels"><span class="quiz-category">${esc(q.category)}</span><span class="quiz-difficulty">${esc(q.competencyId)} • ${esc(q.difficulty)}</span></div><h2>${esc(q.question)}</h2><div class="answer-list">${q.options.map((opt, idx) => {
          const cls = c.answered ? (idx === q.answer ? "correct" : idx === c.selected ? "wrong" : "") : (idx === c.selected ? "selected" : "");
          return `<button class="answer-option ${cls}" data-answer="${idx}" ${c.answered ? "disabled" : ""}><span class="answer-letter">${alphabet[idx]}</span><span>${esc(opt)}</span></button>`;
        }).join("")}</div><div class="answer-feedback ${c.answered ? "show " + (c.selected === q.answer ? "correct" : "wrong") : ""}">${c.answered ? `<strong>${c.selected === q.answer ? "Resposta correta." : "Resposta incorreta."}</strong> ${esc(q.explanation)}` : ""}</div></div>
        <div class="quiz-foot"><span>Escolha uma alternativa para ver a explicação.</span><button class="button primary" id="nextChallenge" ${!c.answered ? "disabled" : ""}>${c.index === c.questions.length-1 ? "Ver resultado" : "Próxima"} ${icon("arrow")}</button></div>
      </section>${disclaimer()}
    </div>`;
    app.querySelectorAll("[data-answer]").forEach(btn => btn.addEventListener("click", () => {
      if (c.answered) return;
      c.selected = Number(btn.dataset.answer); c.answered = true;
      if (c.selected === q.answer) c.score++;
      renderChallenge();
    }));
    document.getElementById("nextChallenge").addEventListener("click", () => {
      if (!c.answered) return;
      if (c.index === c.questions.length - 1) c.finished = true;
      else { c.index++; c.answered = false; c.selected = null; }
      renderChallenge();
    });
  }

  function renderSimulation() {
    setPage("Simulado", "AVALIAÇÃO");
    const s = ui.simulation;
    if (!s) {
      const simulationSize = Math.min(20, DATA.quiz.length);
      app.innerHTML = `<div class="view quiz-shell"><section class="panel start-card"><div class="start-icon">${icon("clipboard")}</div><span class="eyebrow">SIMULADO GERAL • BANCO COM ${DATA.quiz.length} QUESTÕES</span><h1>Teste seus conhecimentos</h1><p>Responda a ${simulationSize} questões sorteadas do núcleo perioperatório e das dez trilhas de especialidade P2.</p><div class="start-features"><span>${icon("clock")} cerca de 15 minutos</span><span>${icon("brain")} feedback por questão</span><span>${icon("award")} resultado salvo localmente</span></div><button class="button primary" id="startSimulation">Começar simulado ${icon("arrow")}</button></section>${disclaimer()}</div>`;
      document.getElementById("startSimulation").addEventListener("click", () => { ui.simulation = {questions: shuffled(DATA.quiz).slice(0, simulationSize), index:0, score:0, answered:false, selected:null, finished:false, responses:[]}; renderSimulation(); });
      return;
    }
    if (s.finished) {
      const pct = Math.round(s.score / s.questions.length * 100);
      const responses = s.responses || [];
      const performance = DATA.competencies.map(competency => {
        const questions = s.questions.filter(question => question.competencyId === competency.id);
        if (!questions.length) return null;
        const ids = new Set(questions.map(question => question.id));
        const correct = responses.filter(response => ids.has(response.questionId) && response.correct).length;
        const score = Math.round(correct / questions.length * 100);
        return {...competency, total:questions.length, correct, score};
      }).filter(Boolean).sort((a,b) => a.score - b.score || a.id.localeCompare(b.id));
      if (!s.recorded) {
        state.quizBest = Math.max(state.quizBest, pct);
        state.quizAttempts = [...(state.quizAttempts || []), {
          date:new Date().toISOString(), score:s.score, total:s.questions.length, percentage:pct,
          competencies:performance.map(item => ({id:item.id, correct:item.correct, total:item.total, percentage:item.score})),
          questionIds:s.questions.map(question => question.id),
          missedQuestionIds:responses.filter(response => !response.correct).map(response => response.questionId)
        }].slice(-10);
        s.recorded = true;
        save();
      }
      app.innerHTML = `<div class="view quiz-shell"><section class="panel result-card"><div class="score-circle" style="--score:${pct}%"><strong>${pct}%</strong></div><span class="eyebrow">RESULTADO DO SIMULADO</span><h1>${pct >= 80 ? "Excelente desempenho" : pct >= 60 ? "Você está no caminho" : "Hora de reforçar a base"}</h1><p>${pct >= 80 ? "Você demonstrou boa compreensão dos temas desta amostra." : "Use o relatório por competência para escolher o que revisar antes da próxima tentativa."}</p><div class="result-stats"><div class="result-stat"><strong>${s.score}</strong><small>acertos</small></div><div class="result-stat"><strong>${s.questions.length-s.score}</strong><small>erros</small></div><div class="result-stat"><strong>${state.quizBest}%</strong><small>melhor nota</small></div></div><div class="result-actions"><button class="button primary" id="retrySimulation">${icon("reset")} Novo simulado</button><a class="button secondary" href="#/remediacao">Plano de reforço</a><a class="button secondary" href="#/progresso">Ver progresso</a></div></section>
      <section class="panel competency-report"><div class="section-title-row"><div><span class="eyebrow">RELATÓRIO FORMATIVO</span><h2>Desempenho por competência</h2></div><span class="source-count">${performance.length} avaliadas</span></div><p class="report-caveat">O resultado descreve somente as questões sorteadas nesta tentativa. Competências com poucos itens não devem ser interpretadas como diagnóstico definitivo.</p><div class="report-list">${performance.map(item => `<article class="report-row"><span class="competency-code">${esc(item.id)}</span><span class="report-copy"><strong>${esc(item.title)}</strong><small>${item.correct} de ${item.total} acertos</small></span><div class="report-progress"><div class="progress-track"><i style="width:${item.score}%"></i></div><b>${item.score}%</b></div><span class="report-status ${item.score < 70 ? "review" : item.score < 85 ? "practice" : "good"}">${item.score < 70 ? "Reforçar" : item.score < 85 ? "Consolidar" : "Bom"}</span><a href="#/remediacao/${item.id}" aria-label="Ver reforço de ${esc(item.title)}">${icon("arrow")}</a></article>`).join("")}</div></section>${disclaimer()}</div>`;
      document.getElementById("retrySimulation").addEventListener("click", () => { ui.simulation = null; renderSimulation(); });
      return;
    }
    const q = s.questions[s.index];
    app.innerHTML = `<div class="view quiz-shell"><div class="page-heading"><div><span class="eyebrow">SIMULADO GERAL</span><h1>Avaliação de conhecimentos</h1><p>Leia cada questão com atenção. A explicação aparece após sua resposta.</p></div></div><section class="quiz-card"><div class="quiz-top"><div class="quiz-status"><span>Questão ${s.index+1} de ${s.questions.length}</span><strong>${Math.round(s.index/s.questions.length*100)}% concluído</strong></div><div class="quiz-progress"><i style="width:${(s.index+1)/s.questions.length*100}%"></i></div></div><div class="quiz-body"><div class="quiz-labels"><span class="quiz-category">${esc(q.category)}</span><span class="quiz-difficulty">${esc(q.competencyId)} • ${esc(q.difficulty)}</span></div><h2>${esc(q.question)}</h2><div class="answer-list">${q.options.map((opt, idx) => { const cls = s.answered ? (idx === q.answer ? "correct" : idx === s.selected ? "wrong" : "") : ""; return `<button class="answer-option ${cls}" data-sim-answer="${idx}" ${s.answered ? "disabled" : ""}><span class="answer-letter">${alphabet[idx]}</span><span>${esc(opt)}</span></button>`; }).join("")}</div><div class="answer-feedback ${s.answered ? "show " + (s.selected === q.answer ? "correct" : "wrong") : ""}">${s.answered ? `<strong>${s.selected === q.answer ? "Correto." : "Não foi dessa vez."}</strong> ${esc(q.explanation)}` : ""}</div></div><div class="quiz-foot"><span>${s.score} acertos até agora</span><button class="button primary" id="nextSimulation" ${!s.answered ? "disabled" : ""}>${s.index === s.questions.length-1 ? "Finalizar" : "Próxima"} ${icon("arrow")}</button></div></section>${disclaimer()}</div>`;
    app.querySelectorAll("[data-sim-answer]").forEach(btn => btn.addEventListener("click", () => {
      if (s.answered) return;
      s.selected = Number(btn.dataset.simAnswer);
      s.answered = true;
      const correct = s.selected === q.answer;
      if (correct) s.score++;
      if (!s.responses) s.responses = [];
      s.responses.push({questionId:q.id, competencyId:q.competencyId, selected:s.selected, correct});
      renderSimulation();
    }));
    document.getElementById("nextSimulation").addEventListener("click", () => { if(!s.answered)return;if(s.index===s.questions.length-1)s.finished=true;else{s.index++;s.answered=false;s.selected=null;}renderSimulation(); });
  }

  function caseDone(id) { return (state.completedCases || []).includes(id); }

  function renderCases() {
    setPage("Casos situacionais", "PRATICAR");
    const categories = ["Todos", ...new Set(DATA.cases.map(item => item.category))];
    const visible = ui.caseFilter === "Todos" ? DATA.cases : DATA.cases.filter(item => item.category === ui.caseFilter);
    const completed = (state.completedCases || []).length;
    app.innerHTML = `<div class="view cases-view">
      <div class="page-heading"><div><span class="eyebrow">DECISÃO E SEGURANÇA</span><h1>Casos situacionais</h1><p>Analise o contexto, escolha a melhor decisão e compare seu raciocínio com fontes e consequências. Os casos são sintéticos e não representam pacientes reais.</p></div><a class="button secondary" href="#/blueprint">${icon("chart")} Ver blueprint</a></div>
      <section class="case-progress-banner"><div><span class="eyebrow">PROGRESSO NOS CASOS</span><strong>${completed} de ${DATA.cases.length} concluídos</strong><small>${Math.round(completed / DATA.cases.length * 100)}% da primeira rodada</small></div><div class="progress-track"><i style="width:${completed / DATA.cases.length * 100}%"></i></div></section>
      <div class="case-filters">${categories.map(category => `<button class="filter-chip ${ui.caseFilter === category ? "active" : ""}" data-case-filter="${esc(category)}">${esc(category)}</button>`).join("")}</div>
      <section class="case-grid">${visible.map(item => `<a class="case-card ${caseDone(item.id) ? "done" : ""}" href="#/caso/${item.id}">
        <div class="case-card-top"><span class="case-number">CASO ${esc(item.number)}</span><span class="difficulty-pill">${esc(item.difficulty)}</span></div>
        <span class="case-category">${esc(item.category)}</span><h2>${esc(item.title)}</h2><p>${esc(item.context)}</p>
        <div class="case-card-foot"><span>${caseDone(item.id) ? `${icon("check")} Concluído` : `${icon("brain")} Analisar caso`}</span>${icon("arrow")}</div>
      </a>`).join("")}</section>
      ${disclaimer()}
    </div>`;
    app.querySelectorAll("[data-case-filter]").forEach(button => button.addEventListener("click", () => {
      ui.caseFilter = button.dataset.caseFilter;
      renderCases();
    }));
  }

  function renderCase(caseId) {
    const item = DATA.cases.find(entry => entry.id === caseId);
    if (!item) return renderNotFound();
    setPage(item.title, "CASO SITUACIONAL");
    const session = ui.caseAnswers[item.id] || {selected:null, answered:false};
    ui.caseAnswers[item.id] = session;
    const index = DATA.cases.findIndex(entry => entry.id === item.id);
    const previous = DATA.cases[index - 1];
    const next = DATA.cases[index + 1];
    const sources = DATA.evidence.filter(source => item.sourceIds.includes(source.id));
    const correct = session.answered && session.selected === item.answer;
    app.innerHTML = `<div class="view case-detail-view">
      <a class="back-link" href="#/casos">${icon("back")} Voltar aos casos</a>
      <section class="case-detail-head">
        <div><span class="case-number">CASO ${esc(item.number)} • ${esc(item.category)}</span><h1>${esc(item.title)}</h1><div class="case-meta"><span>${icon("brain")} ${esc(item.difficulty)}</span><span>${icon("target")} ${esc(item.competencyId)}</span>${caseDone(item.id) ? `<span class="case-complete">${icon("check")} Concluído</span>` : ""}</div></div>
      </section>
      <div class="case-detail-layout">
        <section class="case-main-card">
          <section class="case-context"><span class="eyebrow">CONTEXTO</span><p>${esc(item.context)}</p></section>
          <section class="case-decision"><span class="eyebrow">DECISÃO</span><h2>${esc(item.prompt)}</h2><div class="answer-list">${item.options.map((option, optionIndex) => {
            const className = session.answered ? (optionIndex === item.answer ? "correct" : optionIndex === session.selected ? "wrong" : "") : (session.selected === optionIndex ? "selected" : "");
            return `<button class="answer-option ${className}" data-case-answer="${optionIndex}" ${session.answered ? "disabled" : ""}><span class="answer-letter">${alphabet[optionIndex]}</span><span>${esc(option)}</span></button>`;
          }).join("")}</div></section>
          ${session.answered ? `<section class="case-feedback ${correct ? "correct" : "wrong"}"><div class="feedback-title">${correct ? icon("check") : icon("info")}<strong>${correct ? "Decisão adequada" : "Revise a decisão"}</strong></div><p>${esc(item.rationale)}</p><div><span>Consequência e aprendizado</span><p>${esc(item.consequence)}</p></div></section>` : `<div class="case-submit"><span>Escolha uma alternativa e confirme sua decisão.</span><button class="button primary" id="submitCase" ${session.selected === null ? "disabled" : ""}>Confirmar decisão ${icon("arrow")}</button></div>`}
          ${session.answered ? `<section class="case-sources"><span class="eyebrow">FONTES DO CASO</span>${sources.map(source => `<a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer"><span><strong>${esc(source.title)}</strong><small>${esc(source.organization)} • ${esc(source.year)}</small></span>${icon("external")}</a>`).join("")}</section>` : ""}
          <footer class="case-navigation">${previous ? `<a class="button secondary" href="#/caso/${previous.id}">${icon("back")} Caso anterior</a>` : `<span></span>`}<a class="button secondary" href="#/casos">Ver todos</a>${next ? `<a class="button secondary" href="#/caso/${next.id}">Próximo caso ${icon("arrow")}</a>` : `<a class="button primary" href="#/blueprint">Ver blueprint ${icon("arrow")}</a>`}</footer>
        </section>
        <aside class="panel case-side"><span class="eyebrow">COMO RACIOCINAR</span><h3>Priorize a barreira de segurança</h3><ol><li>Identifique o risco imediato.</li><li>Reconheça seu limite profissional.</li><li>Escolha a ação que interrompe ou reduz dano.</li><li>Comunique, registre e escale quando necessário.</li></ol><div class="note-card">O caso avalia decisão educacional. Condutas reais dependem da equipe habilitada e do protocolo vigente.</div></aside>
      </div>
    </div>`;
    app.querySelectorAll("[data-case-answer]").forEach(button => button.addEventListener("click", () => {
      if (session.answered) return;
      session.selected = Number(button.dataset.caseAnswer);
      renderCase(item.id);
    }));
    document.getElementById("submitCase")?.addEventListener("click", () => {
      if (session.selected === null) return;
      session.answered = true;
      if (!caseDone(item.id)) state.completedCases.push(item.id);
      save();
      renderCase(item.id);
    });
  }

  function renderBlueprint() {
    setPage("Blueprint de avaliação", "COMPETÊNCIAS");
    const blueprint = DATA.assessmentBlueprint;
    const difficultyCounts = blueprint.cognitiveDistribution.map(level => ({...level, count:DATA.quiz.filter(question => question.difficulty === level.level).length}));
    app.innerHTML = `<div class="view blueprint-view">
      <div class="page-heading"><div><span class="eyebrow">ARQUITETURA DA AVALIAÇÃO</span><h1>Blueprint de competências</h1><p>Distribuição planejada do banco de questões e dos casos. Os itens ainda precisam de revisão técnica independente e análise após aplicação piloto.</p></div><a class="button primary" href="#/casos">${icon("brain")} Praticar casos</a></div>
      <section class="blueprint-kpis"><article><strong>${DATA.competencies.length}</strong><span>competências</span></article><article><strong>${DATA.quiz.length}</strong><span>questões estruturadas</span></article><article><strong>${DATA.cases.length}</strong><span>casos situacionais</span></article><article><strong>${DATA.evidence.length}</strong><span>fontes catalogadas</span></article></section>
      <section class="panel cognitive-panel"><div class="section-title-row"><div><span class="eyebrow">DOMÍNIO COGNITIVO</span><h2>Distribuição dos itens</h2></div><span class="source-count">meta ${blueprint.targetQuestions}</span></div><div class="cognitive-grid">${difficultyCounts.map(level => `<article><div><strong>${esc(level.level)}</strong><span>${level.count} itens • meta ${level.target}%</span></div><div class="progress-track"><i style="width:${level.count / DATA.quiz.length * 100}%"></i></div><p>${esc(level.description)}</p></article>`).join("")}</div></section>
      <section class="panel competency-panel"><div class="section-title-row"><div><span class="eyebrow">MATRIZ</span><h2>Competência × banco de questões</h2></div><span class="source-count">${DATA.quiz.length} de ${blueprint.targetQuestions}</span></div><div class="competency-list">${DATA.competencies.map(competency => {
        const questionCount = DATA.quiz.filter(question => question.competencyId === competency.id).length;
        const caseCount = DATA.cases.filter(item => item.competencyId === competency.id).length;
        return `<article class="competency-row"><span class="competency-code">${esc(competency.id)}</span><span class="competency-copy"><strong>${esc(competency.title)}</strong><small>${esc(competency.description)}</small></span><span class="competency-measure"><b>${questionCount}/${competency.targetQuestions}</b><small>questões</small></span><span class="competency-measure"><b>${caseCount}</b><small>casos</small></span><div class="progress-track"><i style="width:${Math.min(100, questionCount / competency.targetQuestions * 100)}%"></i></div></article>`;
      }).join("")}</div></section>
      <section class="blueprint-bottom"><article class="panel blueprint-rules"><span class="eyebrow">REGRAS DE ESCRITA</span><h2>Critérios do banco</h2>${blueprint.rules.map(rule => `<p>${icon("check")}<span>${esc(rule)}</span></p>`).join("")}</article><article class="panel blueprint-gate"><span class="eyebrow">STATUS DO GATE</span><h2>Auditoria estrutural aprovada; validação pendente</h2><p>O banco alcançou a distribuição quantitativa planejada e os gabaritos foram balanceados. O próximo gate exige revisão independente, piloto e análise dos itens.</p><a class="button secondary" href="#/roadmap">Ver roadmap ${icon("arrow")}</a></article></section>
      ${disclaimer()}
    </div>`;
  }

  function renderProgress() {
    setPage("Meu progresso", "ACOMPANHAR");
    const pct = overallPercent();
    const attempts = [...(state.quizAttempts || [])].reverse();
    app.innerHTML = `<div class="view"><div class="page-heading"><div><span class="eyebrow">DESEMPENHO</span><h1>Seu progresso</h1><p>Acompanhe aulas, prática com casos e resultados formativos salvos neste navegador.</p></div><div class="result-actions"><a class="button secondary" href="#/remediacao">Plano de reforço</a><a class="button primary" href="#/biblioteca">Continuar estudando ${icon("arrow")}</a></div></div><div class="progress-layout"><section class="panel overall-card"><h2>Progresso geral</h2><div class="progress-ring big-ring" style="--value:${pct}"><strong>${pct}%</strong></div><div class="overall-details"><div class="overall-detail"><strong>${state.completedLessons.length}</strong><small>aulas concluídas</small></div><div class="overall-detail"><strong>${completedMinutes()}</strong><small>minutos estudados</small></div><div class="overall-detail"><strong>${state.learnedCards.length}</strong><small>cards dominados</small></div><div class="overall-detail"><strong>${(state.completedCases || []).length}</strong><small>casos concluídos</small></div><div class="overall-detail"><strong>${state.quizBest}%</strong><small>melhor nota</small></div><div class="overall-detail"><strong>${attempts.length}</strong><small>simulados salvos</small></div></div></section><section class="panel progress-modules"><h2>Progresso por trilha</h2>${DATA.modules.map(module => { const mp=modulePercent(module);return `<div class="progress-module"><div class="progress-module-top">${moduleIcon(module)}<span class="progress-module-name"><strong>${esc(module.title)}</strong><small>${completeCountFor(module)} de ${module.lessons.length} aulas</small></span><strong>${mp}%</strong></div><div class="progress-track"><i style="width:${mp}%"></i></div></div>`;}).join("")}</section><section class="panel attempt-card"><div class="section-title-row"><div><span class="eyebrow">AVALIAÇÃO FORMATIVA</span><h2>Histórico de simulados</h2></div><span class="source-count">últimas ${Math.min(attempts.length,10)}</span></div>${attempts.length ? `<div class="attempt-list">${attempts.map((attempt,index) => `<article class="attempt-row"><span class="attempt-index">${String(attempts.length-index).padStart(2,"0")}</span><span><strong>${new Date(attempt.date).toLocaleDateString("pt-BR")}</strong><small>${attempt.score} de ${attempt.total} acertos</small></span><div class="progress-track"><i style="width:${attempt.percentage}%"></i></div><b>${attempt.percentage}%</b></article>`).join("")}</div>` : `<div class="attempt-empty">${icon("clipboard")}<div><strong>Nenhum simulado concluído</strong><p>Faça uma primeira tentativa para iniciar seu histórico e receber um relatório por competência.</p></div><a class="button secondary" href="#/simulado">Começar simulado</a></div>`}<p class="local-data-note">Os resultados são formativos e ficam somente neste navegador. Não representam certificação nem diagnóstico definitivo de competência.</p></section></div>${disclaimer()}</div>`;
  }

  function renderRemediation(competencyId = null) {
    setPage("Plano de reforço", "REMEDIAÇÃO FORMATIVA");
    const attempts = (state.quizAttempts || []).slice(-10);
    const aggregate = new Map();
    for (const attempt of attempts) for (const item of attempt.competencies || []) {
      const current = aggregate.get(item.id) || {correct:0,total:0,attempts:0};
      current.correct += item.correct || 0;
      current.total += item.total || 0;
      current.attempts += 1;
      aggregate.set(item.id, current);
    }
    const missedCategories = new Map();
    for (const attempt of attempts) for (const questionId of attempt.missedQuestionIds || []) {
      const question = DATA.quiz.find(item => item.id === questionId);
      if (!question) continue;
      if (!missedCategories.has(question.competencyId)) missedCategories.set(question.competencyId, new Set());
      missedCategories.get(question.competencyId).add(question.category);
    }
    const performance = DATA.competencies.map(competency => {
      const result = aggregate.get(competency.id);
      const score = result?.total ? Math.round(result.correct / result.total * 100) : null;
      return {...competency, ...(result || {correct:0,total:0,attempts:0}), score, plan:planForCompetency(competency.id), remediation:remediationDefinition(competency.id), lessons:remediationLessons(competency.id), categories:[...(missedCategories.get(competency.id) || [])]};
    });
    const evaluated = performance.filter(item => item.total > 0);
    const totalAnswered = evaluated.reduce((sum,item) => sum + item.total, 0);
    const totalCorrect = evaluated.reduce((sum,item) => sum + item.correct, 0);
    const overall = totalAnswered ? Math.round(totalCorrect / totalAnswered * 100) : 0;
    const selected = competencyId ? performance.find(item => item.id === competencyId) : null;
    if (competencyId && !selected) return renderNotFound();
    const tabs = [{id:"Todos",title:"Todos"}, ...DATA.studyPlans.map(plan => ({id:plan.id,title:`${plan.order} ${plan.title}`}))];
    const activeFilter = selected ? selected.plan.id : ui.remediationPlanFilter;
    const visiblePlans = selected ? [selected.plan] : activeFilter === "Todos" ? DATA.studyPlans : DATA.studyPlans.filter(plan => plan.id === activeFilter);
    const priorityLabel = score => score === null ? "Não avaliada" : score < 60 ? "Prioridade alta" : score < 80 ? "Reforçar" : "Consolidar";
    const priorityClass = score => score === null ? "pending" : score < 60 ? "high" : score < 80 ? "medium" : "good";

    app.innerHTML = `<div class="view remediation-view">
      <div class="page-heading"><div><span class="eyebrow">DESEMPENHO → AÇÃO</span><h1>${selected ? `Reforço de ${esc(selected.id)}` : "Seu plano de reforço"}</h1><p>O plano transforma os resultados dos simulados em aulas recomendadas. Ele é formativo, considera apenas os itens sorteados e não comprova competência clínica.</p></div>${selected ? `<a class="button secondary" href="#/remediacao">Ver plano completo</a>` : `<a class="button primary" href="#/simulado">Fazer novo simulado ${icon("arrow")}</a>`}</div>
      ${attempts.length ? `<section class="blueprint-kpis remediation-kpis"><article><strong>${attempts.length}</strong><span>simulados analisados</span></article><article><strong>${evaluated.length}</strong><span>competências amostradas</span></article><article><strong>${overall}%</strong><span>acerto agregado</span></article><article><strong>${totalAnswered-totalCorrect}</strong><span>respostas a reforçar</span></article></section>` : ""}
      ${!attempts.length && !selected ? `<section class="panel remediation-empty"><div class="start-icon">${icon("target")}</div><div><span class="eyebrow">SEM AMOSTRA AINDA</span><h2>Conclua um simulado para gerar recomendações</h2><p>Após a tentativa, os acertos serão agrupados por competência e associados às três etapas do plano de estudos.</p></div><a class="button primary" href="#/simulado">Começar simulado ${icon("arrow")}</a></section>` : ""}
      ${!selected ? `<div class="remediation-filters">${tabs.map(tab => `<button class="filter-chip ${activeFilter === tab.id ? "active" : ""}" data-remediation-filter="${esc(tab.id)}">${esc(tab.title)}</button>`).join("")}</div>` : ""}
      <section class="remediation-plans">${visiblePlans.map(plan => {
        let items = performance.filter(item => item.plan.id === plan.id && (selected ? item.id === selected.id : item.total > 0));
        items.sort((a,b) => (a.score ?? 101) - (b.score ?? 101) || a.id.localeCompare(b.id));
        const sampled = items.filter(item => item.total > 0);
        const planTotal = sampled.reduce((sum,item) => sum + item.total,0);
        const planCorrect = sampled.reduce((sum,item) => sum + item.correct,0);
        const planScore = planTotal ? Math.round(planCorrect/planTotal*100) : null;
        return `<article class="remediation-plan-section"><header><div><span class="study-plan-number">ETAPA ${esc(plan.order)}</span><span><strong>${esc(plan.title)}</strong><small>${sampled.length} de ${plan.competencyIds.length} competências amostradas</small></span></div><div><b>${planScore === null ? "—" : `${planScore}%`}</b><small>desempenho da amostra</small></div></header>${items.length ? `<div class="remediation-list">${items.map(item => `<article class="remediation-card ${priorityClass(item.score)}"><div class="remediation-card-head"><span class="competency-code">${esc(item.id)}</span><div><h3>${esc(item.title)}</h3><p>${esc(item.remediation.focus)}</p></div><div class="remediation-score"><strong>${item.score === null ? "—" : `${item.score}%`}</strong><span>${item.total ? `${item.correct}/${item.total} acertos` : "sem itens respondidos"}</span></div><span class="remediation-priority">${priorityLabel(item.score)}</span></div>${item.categories.length ? `<div class="remediation-topics"><span>Erros recentes em:</span>${item.categories.slice(0,3).map(category => `<b>${esc(category)}</b>`).join("")}</div>` : ""}<div class="remediation-lessons"><span>Aulas recomendadas</span>${item.lessons.map(lesson => `<a href="#/aula/${lesson.id}" class="${lessonDone(lesson.id) ? "done" : ""}"><i>${lessonDone(lesson.id) ? icon("check") : icon("book")}</i><span><strong>${esc(lesson.title)}</strong><small>${esc(lesson.module.title)} • ${lesson.duration} min</small></span>${icon("arrow")}</a>`).join("")}</div><footer><small>Amostra: ${item.total} ${item.total === 1 ? "questão" : "questões"} em ${item.attempts} ${item.attempts === 1 ? "tentativa" : "tentativas"}. Não interpretar isoladamente como domínio.</small><a href="#/modulo/${item.moduleId}">Abrir trilha principal</a></footer></article>`).join("")}</div>` : `<div class="remediation-plan-empty"><p>Esta etapa ainda não apareceu nos simulados salvos.</p><a href="#/planos">Revisar o plano de estudo</a></div>`}</article>`;
      }).join("")}</section>
      ${attempts.length ? `<section class="panel remediation-method"><div>${icon("info")}</div><div><strong>Como as recomendações são calculadas</strong><p>As últimas dez tentativas são agregadas por competência. Menos de 60% recebe prioridade alta; de 60% a 79%, reforço; a partir de 80%, consolidação. Aulas concluídas continuam disponíveis para revisão.</p></div></section>` : ""}
      ${disclaimer()}
    </div>`;
    app.querySelectorAll("[data-remediation-filter]").forEach(button => button.addEventListener("click", () => { ui.remediationPlanFilter = button.dataset.remediationFilter; renderRemediation(); }));
  }

  function checklistStats() {
    const total = DATA.checklist.reduce((sum,s)=>sum+s.items.length,0);
    const done = Object.values(state.checklist).filter(Boolean).length;
    return {total,done,pct:Math.round(done/total*100)};
  }

  function renderChecklist() {
    setPage("Checklist de estudo", "ORGANIZAR");
    const stats = checklistStats(); let globalIndex=0;
    app.innerHTML = `<div class="view"><div class="page-heading"><div><span class="eyebrow">PLANO DE REVISÃO</span><h1>Checklist de estudo</h1><p>Use este roteiro para preparar e consolidar o estudo de um procedimento cirúrgico.</p></div></div><div class="checklist-layout"><section class="panel checklist-main"><div class="checklist-progress"><strong>${stats.done} de ${stats.total}</strong><div class="progress-track"><i style="width:${stats.pct}%"></i></div><strong>${stats.pct}%</strong></div>${DATA.checklist.map(section=>`<div class="checklist-section"><h2>${esc(section.title)}</h2>${section.items.map(item=>{const id=`check-${globalIndex++}`;return `<label class="check-item"><input type="checkbox" data-check-id="${id}" ${state.checklist[id]?"checked":""}><span class="custom-check">${icon("check")}</span><span>${esc(item)}</span></label>`;}).join("")}</div>`).join("")}</section><aside><section class="panel checklist-aside"><h3>Use do seu jeito</h3><p>Marque os itens à medida que avança. O progresso fica salvo neste navegador.</p><button class="button secondary" id="printChecklist">${icon("print")} Imprimir checklist</button><button class="button danger" id="resetChecklist">${icon("reset")} Limpar marcações</button><div class="note-card">Este é um checklist de estudo, não um documento assistencial. Adote sempre o protocolo validado da instituição.</div></section></aside></div></div>`;
    app.querySelectorAll("[data-check-id]").forEach(input=>input.addEventListener("change",()=>{state.checklist[input.dataset.checkId]=input.checked;save();renderChecklist();}));
    document.getElementById("printChecklist").addEventListener("click",()=>window.print());
    document.getElementById("resetChecklist").addEventListener("click",()=>{state.checklist={};save();toast("Checklist reiniciado.");renderChecklist();});
  }

  function renderVideoteca() {
    setPage("Videoteca", "MATERIAIS EXTERNOS");
    app.innerHTML = `<div class="view">
      <div class="page-heading"><div><span class="eyebrow">CURADORIA INSTITUCIONAL</span><h1>Videoteca complementar</h1><p>Demonstrações e discussões selecionadas de hospitais, universidades e entidades profissionais. O vídeo complementa a aula; não é a fonte normativa principal.</p></div><a class="button secondary" href="#/fontes">${icon("file")} Ver base científica</a></div>
      ${externalMediaNotice()}
      <section class="video-library-grid">${DATA.videos.map(video => videoCard(video)).join("")}</section>
      <section class="panel editorial-note">
        <div class="start-icon">${icon("shield")}</div>
        <div><span class="eyebrow">CRITÉRIOS DE CURADORIA</span><h2>Institucional, verificável e complementar</h2><p>Priorizamos canais oficiais de hospitais universitários, universidades, associações profissionais e produtores especializados em educação em saúde. Cada item precisa de revisão clínica antes de ser indicado como técnica compatível com protocolos brasileiros.</p></div>
      </section>
      ${disclaimer()}
    </div>`;
  }

  function renderSources() {
    setPage("Fontes e créditos", "BASE CIENTÍFICA");
    const topics = [...new Set(DATA.evidence.map(item => item.topic))];
    const verifiedSources = DATA.evidence.filter(item => item.verifiedOn);
    app.innerHTML = `<div class="view sources-view">
      <div class="page-heading"><div><span class="eyebrow">TRANSPARÊNCIA EDITORIAL</span><h1>Fontes, normas e créditos</h1><p>Base documental usada para orientar a expansão do conteúdo. Sínteses próprias devem ser confrontadas com protocolos institucionais e instruções de uso vigentes.</p></div><a class="button secondary" href="#/videoteca">${icon("video")} Abrir videoteca</a></div>

      <section class="freshness-banner"><div>${icon("check")}<span><strong>${verifiedSources.length} referências verificadas em 13/10/2026</strong><small>As expansões P2, de procedimentos e de acessos priorizam publicações oficiais de 2024–2026. Documentos antigos permanecem apenas quando ainda são a referência institucional identificada.</small></span></div><a href="#/roadmap">Ver plano de atualização ${icon("arrow")}</a></section>

      <section class="source-principles">
        <article class="panel principle-card"><span>01</span><h2>Normas primeiro</h2><p>Legislação e documentos oficiais brasileiros definem requisitos de segurança, processamento e exercício profissional.</p></article>
        <article class="panel principle-card"><span>02</span><h2>Diretrizes como síntese</h2><p>OMS, associações profissionais e revisões científicas sustentam conceitos, sempre adaptados ao contexto e ao protocolo local.</p></article>
        <article class="panel principle-card"><span>03</span><h2>Vídeo é complemento</h2><p>Material audiovisual ilustra uma prática, mas não substitui a instrução validada, a supervisão nem as instruções de uso do fabricante.</p></article>
      </section>

      <section class="panel evidence-panel">
        <div class="section-title-row"><div><span class="eyebrow">PUBLICAÇÕES-BASE</span><h2>Referências por tema</h2></div><span class="source-count">${DATA.evidence.length} documentos</span></div>
        ${topics.map(topic => `<div class="source-group"><h3>${esc(topic)}</h3><div class="source-list">${DATA.evidence.filter(item => item.topic === topic).map(item => `<a class="source-row" href="${esc(item.url)}" target="_blank" rel="noopener noreferrer"><span class="source-year">${esc(item.year)}</span><span><strong>${esc(item.title)}</strong><small>${esc(item.organization)} • ${esc(item.access)}</small>${item.verifiedOn ? `<em class="source-status">Verificada ${esc(item.verifiedOn)} • ${esc(item.referenceStatus)}</em>` : ""}</span><span class="source-open">${icon("external")}</span></a>`).join("")}</div></div>`).join("")}
      </section>

      <section class="panel evidence-panel media-credits">
        <div class="section-title-row"><div><span class="eyebrow">BANCO DE MÍDIA</span><h2>Fontes visuais compatíveis</h2></div><span class="source-count">licença por item</span></div>
        <div class="media-credit-grid">${DATA.mediaSources.map(source => `<article><h3>${esc(source.name)}</h3><span class="license-pill">${esc(source.license)}</span><p>${esc(source.use)}</p><a href="${esc(source.url)}" target="_blank" rel="noopener noreferrer">Consultar fonte ${icon("external")}</a></article>`).join("")}</div>
      </section>

      <div class="rights-note">${icon("info")}<div><strong>Registro de direitos recomendado</strong><span>Antes de publicar qualquer imagem, registre título, autor ou instituição, URL original, licença exata, data de consulta e alterações realizadas. Crédito sozinho não substitui autorização quando a licença não permite reutilização.</span></div></div>
      ${disclaimer()}
    </div>`;
  }

  function renderRoadmap() {
    setPage("Roadmap", "PLANO DE EVOLUÇÃO");
    const roadmap = DATA.roadmap;
    const macroblocks = DATA.technicalCurriculum?.macroblocks || [];
    const slugStatus = value => value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, "-");
    app.innerHTML = `<div class="view roadmap-view">
      <section class="roadmap-hero">
        <div><span class="eyebrow">ROADMAP EDITORIAL E DE PRODUTO</span><h1>Do protótipo à plataforma validada</h1><p>${esc(roadmap.northStar)}</p></div>
        <div class="roadmap-release"><span>ESTADO ATUAL</span><strong>${DATA.modules.length} trilhas</strong><small>${totalLessons} aulas • ${DATA.quiz.length} questões • ${DATA.evidence.length} fontes</small></div>
      </section>

      <section class="roadmap-summary">
        <article><strong>${macroblocks.filter(item => item.status === "Entregue").length}/${macroblocks.length}</strong><span>macroblocos concluídos</span></article>
        <article><strong>${DATA.technicalCurriculum?.modules.length || 0}</strong><span>módulos na matriz técnica</span></article>
        <article><strong>${DATA.technicalCurriculum?.modules.reduce((sum,item) => sum + item.topics.length,0) || 0}</strong><span>tópicos catalogados</span></article>
        <article><strong>${DATA.technicalCurriculum?.lessonSchema.length || 0}</strong><span>campos por ficha técnica</span></article>
      </section>

      ${macroblocks.length ? `<section class="roadmap-macroblocks"><div class="section-title-row"><div><span class="eyebrow">EXPANSÃO PROCEDIMENTAL</span><h2>Implementação por macroblocos</h2></div><a href="#/matriz-tecnica">Abrir matriz ${icon("arrow")}</a></div><div>${macroblocks.map(item => `<article class="macroblock-card ${slugStatus(item.status)}"><header><span>${esc(item.id)}</span><b>${esc(item.status)}</b></header><h3>${esc(item.title)}</h3><p>${esc(item.description)}</p></article>`).join("")}</div></section>` : ""}

      <section class="roadmap-timeline">
        ${roadmap.phases.map(phase => `<article class="roadmap-phase ${slugStatus(phase.status)}">
          <div class="phase-rail"><span>${esc(phase.order)}</span><i></i></div>
          <div class="panel phase-card">
            <div class="phase-head"><div><span class="status-pill ${slugStatus(phase.status)}">${esc(phase.status)}</span><h2>${esc(phase.title)}</h2></div><span class="phase-horizon">${esc(phase.horizon)}</span></div>
            <p>${esc(phase.description)}</p>
            <div class="phase-progress"><div><strong>${phase.progress}%</strong><span>maturidade da fase</span></div><div class="progress-track"><i style="width:${phase.progress}%"></i></div></div>
            <div class="phase-deliverables">${phase.deliverables.map(item => `<span>${icon("check")} ${esc(item)}</span>`).join("")}</div>
          </div>
        </article>`).join("")}
      </section>

      <section class="panel roadmap-gate">
        <div class="start-icon">${icon("shield")}</div>
        <div><span class="eyebrow">DEFINIÇÃO DE PRONTO</span><h2>Uma trilha só atravessa o gate clínico quando...</h2><div class="gate-grid"><span>${icon("check")} Competências e público definidos</span><span>${icon("check")} Fontes e versão registradas</span><span>${icon("check")} Revisão técnica assinada</span><span>${icon("check")} Questões revisadas e justificadas</span><span>${icon("check")} Mídia e licença documentadas</span><span>${icon("check")} Acessibilidade e errata verificadas</span></div></div>
      </section>
      <p class="roadmap-updated">Roadmap atualizado em ${esc(roadmap.updatedOn)}. Percentuais representam maturidade editorial, não certificação clínica.</p>
    </div>`;
  }

  function renderNotFound() {
    setPage("Página não encontrada");
    app.innerHTML = `<div class="view"><section class="panel empty-state"><div class="start-icon">${icon("search")}</div><h2>Conteúdo não encontrado</h2><p>O endereço pode ter mudado ou o conteúdo ainda não faz parte deste protótipo.</p><a class="button primary" href="#/dashboard">Voltar ao início</a></section></div>`;
  }

  function renderRoute() {
    const raw = location.hash.replace(/^#\/?/, "");
    const [route = "dashboard", id, subId] = raw.split("/");
    document.querySelectorAll(".side-nav a").forEach(link => {
      const key = link.dataset.route;
      const active = key === route || (route === "procedimento" && key === "procedimentos") || (route === "modulo" || route === "aula") && key === "biblioteca" || (route === "caso" || route === "blueprint") && key === "casos";
      link.classList.toggle("active", active);
    });
    if (route === "dashboard") renderDashboard();
    else if (route === "biblioteca") renderLibrary();
    else if (route === "procedimentos") renderProcedures();
    else if (route === "procedimento") renderProcedure(id);
    else if (route === "planos") renderStudyPlans();
    else if (route === "matriz-tecnica") renderTechnicalMatrix(id, subId);
    else if (route === "atlas") renderAtlas(id);
    else if (route === "modulo") renderModule(id);
    else if (route === "aula") renderLesson(id);
    else if (route === "flashcards") renderFlashcards();
    else if (route === "desafio") renderChallenge();
    else if (route === "simulado") renderSimulation();
    else if (route === "casos") renderCases();
    else if (route === "caso") renderCase(id);
    else if (route === "blueprint") renderBlueprint();
    else if (route === "progresso") renderProgress();
    else if (route === "remediacao") renderRemediation(id);
    else if (route === "checklist") renderChecklist();
    else if (route === "videoteca") renderVideoteca();
    else if (route === "fontes") renderSources();
    else if (route === "roadmap") renderRoadmap();
    else renderNotFound();
    window.scrollTo(0,0);
    app.focus({preventScroll:true});
  }

  function setupChrome() {
    hydrateIcons(); updateProfileChrome();
    const sidebar = document.getElementById("sidebar");
    const scrim = document.getElementById("scrim");
    const closeMenu = () => { sidebar.classList.remove("open"); scrim.classList.remove("open"); };
    document.getElementById("menuButton").addEventListener("click", () => { sidebar.classList.toggle("open"); scrim.classList.toggle("open"); });
    scrim.addEventListener("click", closeMenu);
    document.getElementById("sideNav").addEventListener("click", closeMenu);

    const dialog = document.getElementById("profileDialog");
    const openProfile = () => { document.getElementById("profileName").value = state.name === "Visitante" ? "" : state.name; dialog.showModal(); };
    document.getElementById("profileButton").addEventListener("click", openProfile);
    document.getElementById("topProfile").addEventListener("click", openProfile);
    document.getElementById("saveProfile").addEventListener("click", () => {
      const value = document.getElementById("profileName").value.trim();
      state.name = value || "Visitante"; save(); dialog.close(); toast("Perfil atualizado."); renderRoute();
    });

    const search = document.getElementById("globalSearch");
    const results = document.getElementById("searchResults");
    function performSearch() {
      const term = search.value.trim();
      if (!term) { results.classList.remove("open"); results.innerHTML=""; return; }
      const matches = [
        ...procedures.filter(proc => searchIncludes(`${proc.id} ${proc.title} ${proc.scope} ${proc.additionalSupplies.join(" ")} ${proc.materialLinks.map(id => materialById(id)?.preferredName||id).join(" ")}`,term)).map(proc => ({title:proc.title,meta:`Ficha técnica MB03 • ${proc.id} • revisão pendente`,url:`#/procedimento/${proc.id}`})),
        ...technicalTopics.filter(topic => searchIncludes(`${topic.id} ${topic.title} ${(topic.aliases || []).join(" ")} ${topic.canonicalProcedureId}`,term)).map(topic => ({title:`${topic.id} — ${topic.title}`,meta:`Procedimento • ${topic.module.id} ${topic.module.title}`,url:`#/matriz-tecnica/${topic.module.id}/${topic.id}`})),
        ...atlasMaterials.filter(material => searchIncludes(`${material.id} ${material.preferredName} ${material.aliases.join(" ")} ${material.variants.map(variant => `${variant.label} ${variant.scaleValue || ""}`).join(" ")}`,term)).map(material => ({title:material.preferredName,meta:`Atlas de materiais • ${material.id}`,url:`#/atlas/${material.id}`})),
        ...DATA.modules.filter(m => searchIncludes(`${m.title} ${m.short} ${m.description}`,term)).map(m => ({title:m.title,meta:"Trilha",url:`#/modulo/${m.id}`})),
        ...allLessons.filter(l => searchIncludes(`${l.title} ${l.summary} ${l.sections.map(s=>s.body).join(" ")}`,term)).map(l => ({title:l.title,meta:l.module.title,url:`#/aula/${l.id}`})),
        ...DATA.videos.filter(v => searchIncludes(`${v.title} ${v.originalTitle} ${v.channel} ${v.note}`,term)).map(v => ({title:v.title,meta:`Vídeo • ${v.channel}`,url:"#/videoteca"})),
        ...DATA.evidence.filter(item => searchIncludes(`${item.title} ${item.organization} ${item.topic}`,term)).map(item => ({title:item.title,meta:`Fonte • ${item.organization}`,url:"#/fontes"})),
        ...DATA.cases.filter(item => searchIncludes(`${item.title} ${item.category} ${item.context} ${item.prompt}`,term)).map(item => ({title:item.title,meta:`Caso • ${item.category}`,url:`#/caso/${item.id}`})),
        ...DATA.competencies.filter(item => searchIncludes(`${item.id} ${item.title} ${item.description}`,term)).map(item => ({title:`${item.id} — ${item.title}`,meta:"Competência",url:"#/blueprint"})),
        ...DATA.roadmap.phases.filter(phase => searchIncludes(`${phase.title} ${phase.description} ${phase.deliverables.join(" ")}`,term)).map(phase => ({title:phase.title,meta:`Roadmap • ${phase.status}`,url:"#/roadmap"}))
      ].slice(0,10);
      results.innerHTML = matches.length ? matches.map(item=>`<a class="search-item" href="${item.url}"><strong>${esc(item.title)}</strong><small>${esc(item.meta)}</small></a>`).join("") : `<div class="search-empty">Nenhum conteúdo encontrado.</div>`;
      results.classList.add("open");
    }
    search.addEventListener("input",performSearch);
    search.addEventListener("focus",performSearch);
    search.parentElement.addEventListener("click", () => { if(window.innerWidth<=620){search.parentElement.classList.add("mobile-open");search.focus();} });
    results.addEventListener("click",()=>{results.classList.remove("open");search.value="";search.parentElement.classList.remove("mobile-open");});
    document.addEventListener("click",e=>{if(!search.parentElement.contains(e.target)){results.classList.remove("open");search.parentElement.classList.remove("mobile-open");}});
    document.addEventListener("keydown", e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); search.parentElement.classList.add("mobile-open"); search.focus(); }
      if (e.key === "Escape") { results.classList.remove("open"); search.parentElement.classList.remove("mobile-open"); }
    });
  }

  window.addEventListener("hashchange", renderRoute);
  setupChrome();
  if (!location.hash) location.hash = "#/dashboard"; else renderRoute();
})();
