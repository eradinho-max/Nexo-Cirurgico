# Nexo Cirúrgico — auditoria estrutural do banco 1.2

**Data:** 13 de outubro de 2026  
**Escopo:** 210 questões, 30 casos e 28 competências  
**Resultado:** **aprovado na auditoria automatizada estrutural**  
**Limite:** este resultado não equivale a validação clínica, psicométrica ou regulatória

## 1. Expansão P2 incorporada

- competências C19–C28;
- 60 questões originais, seis por competência;
- dez casos situacionais, um por especialidade;
- pelo menos uma referência com verificação documental em cada nova questão e caso;
- foco em processo perioperatório, decisão segura, comunicação, rastreabilidade e escalonamento;
- limites explícitos para protocolo local, equipe habilitada e instruções do fabricante.

## 2. Resultado reproduzível

| Indicador | Resultado |
|---|---:|
| Competências | 28 |
| Questões | 210 |
| Casos | 30 |
| Fontes catalogadas | 72 |
| Erros estruturais | 0 |
| Sinais para revisão contextual futura | 92 |

Comando:

```bash
node qa_assessment.js
```

O teste verifica unicidade de IDs, quatro alternativas, alternativas não duplicadas, gabarito válido, vínculos de competência/módulo/fonte, metas por competência, totais do blueprint, distribuição cognitiva aproximada, equilíbrio das posições de gabarito e presença de referência documentalmente verificada nos itens P2.

## 3. Distribuição cognitiva

| Nível | Itens | Percentual |
|---|---:|---:|
| Básico | 53 | 25,2% |
| Aplicação | 115 | 54,8% |
| Análise | 42 | 20,0% |
| **Total** | **210** | **100%** |

A distribuição preserva a meta aproximada de 25% básico, 55% aplicação e 20% análise.

## 4. Distribuição dos gabaritos

| Tipo | A | B | C | D |
|---|---:|---:|---:|---:|
| Questões | 53 | 53 | 52 | 52 |
| Casos | 8 | 8 | 7 | 7 |

A diferença máxima entre posições é um item.

## 5. Sinais contextuais

O detector lexical marcou 92 sinais de revisão, principalmente pelo uso de “sempre”, “nunca”, “somente” ou “apenas”, além de alguns enunciados curtos do núcleo anterior. Esses sinais não constituem erros automáticos: podem ocorrer em distratores intencionalmente inadequados e deverão ser julgados na revisão humana consolidada.

## 6. Gate pendente

Por decisão do projeto, permanecem adiados até a conclusão editorial:

- revisão clínica independente;
- auditoria contextual de enunciados, justificativas e distratores;
- revisão regulatória e de escopo profissional;
- piloto com público-alvo;
- análise psicométrica;
- definição de nota de aprovação ou certificação.

Até esse gate, os resultados são formativos e o conteúdo permanece como primeira redação profissional não validada.
