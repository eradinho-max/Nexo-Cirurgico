/* Smoke test de interface MB01/MB02. Requer `npm install`; execute com `npm run qa:ui`. */
const http=require('http');
const fs=require('fs');
const path=require('path');
const {JSDOM,VirtualConsole}=require('jsdom');
const root=__dirname;
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css'};
const server=http.createServer((req,res)=>{
  const pathname=new URL(req.url,'http://localhost').pathname;
  const file=path.join(root,pathname==='/'?'index.html':pathname.slice(1));
  if(!file.startsWith(root)||!fs.existsSync(file)){res.writeHead(404);return res.end('Not found')}
  res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);
});
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const {port}=server.address();
  const virtualConsole=new VirtualConsole();
  const consoleErrors=[];
  virtualConsole.on('jsdomError',error=>consoleErrors.push(error.message));
  const dom=await JSDOM.fromURL(`http://127.0.0.1:${port}/#/dashboard`,{resources:'usable',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole,beforeParse(window){window.scrollTo=()=>{};window.HTMLElement.prototype.scrollIntoView=()=>{}}});
  const {window}=dom,document=window.document;
  await new Promise((resolve,reject)=>{if(document.readyState==='complete')resolve();else{window.addEventListener('load',resolve,{once:true});setTimeout(()=>reject(Error('Timeout de carregamento')),5000)}});
  await wait(20);
  const text=()=>document.querySelector('#app').textContent.replace(/\s+/g,' ');
  const go=async hash=>{window.location.hash=hash;window.dispatchEvent(new window.HashChangeEvent('hashchange'));await wait(12)};
  const assert=(condition,message)=>{if(!condition)throw Error(message)};
  const submitSearch=async term=>{const input=document.querySelector('#atlasSearchInput');input.value=term;document.querySelector('#atlasSearchForm').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await wait(8)};

  const dashboard=document.querySelector('.dashboard-view');
  assert(dashboard?.dataset.dashboardModules==='33'&&dashboard?.dataset.dashboardLessons==='115','Dashboard não deriva 33 trilhas e 115 aulas dos dados');
  assert(document.querySelectorAll('.dashboard-stat').length===4,'Dashboard não exibiu os quatro indicadores');
  assert(document.querySelectorAll('.study-area-card').length===5,'Atalhos principais do dashboard incompletos');
  assert(document.querySelectorAll('.featured-procedure-card').length===4,'Destaques de procedimentos incompletos');
  assert(document.querySelectorAll('.recommended-item').length===3,'Sequência recomendada incompleta');
  assert(text().includes('Não emitida')&&text().includes('não representa competência clínica adquirida'),'Limites de certificação ou competência ausentes');
  assert(document.querySelector('.brand img[src="assets/nexo-cirurgico-logo.svg"]'),'Logomarca vetorial não aplicada');
  assert(fs.existsSync(path.join(root,'INTERFACE_NEXO_CIRURGICO.md'))&&fs.existsSync(path.join(root,'interface.css')),'Documentação ou folha da nova interface ausente');
  await go('#/biblioteca'); assert(document.querySelectorAll('.module-card').length===33,'Biblioteca não preservou 33 trilhas');
  await go('#/planos'); assert(document.querySelectorAll('.study-plan-card').length===3,'Planos anteriores não preservados');
  await go('#/remediacao'); assert(text().includes('Conclua um simulado'),'Remediação anterior indisponível');
  await go('#/simulado');document.querySelector('#startSimulation').click();
  for(let index=0;index<20;index++){document.querySelector('[data-sim-answer="0"]').click();document.querySelector('#nextSimulation').click()}
  assert(text().includes('Plano de reforço')&&document.querySelector('.report-row a[href^="#/remediacao/C"]'),'Fluxo do simulado anterior falhou');
  const persisted=JSON.parse(window.localStorage.getItem('nexo-cirurgico-state'));assert(persisted.quizAttempts.at(-1).questionIds.length===20,'Detalhes da tentativa não preservados');
  await go('#/remediacao');assert(document.querySelectorAll('.remediation-card').length>0,'Plano de reforço não foi gerado');

  await go('#/matriz-tecnica');
  assert(document.querySelectorAll('.technical-module-card').length===28,'Matriz não exibiu 28 módulos');
  const priority=document.querySelector('#technicalPriorityFilter');priority.value='P0';priority.dispatchEvent(new window.Event('change',{bubbles:true}));await wait(8);
  assert(document.querySelectorAll('.technical-module-card').length===17,'Filtro P0 não incluiu faixas combinadas');
  document.querySelector('#clearTechnicalFilters').click();await wait(8);
  const techInput=document.querySelector('#technicalSearchInput');techInput.value='ECG';document.querySelector('#technicalSearchForm').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await wait(8);
  assert(document.querySelectorAll('.technical-module-card').length===2&&text().includes('PT-M20-01'),'Busca ECG não retornou tópicos exatos');
  document.querySelector('#clearTechnicalFilters').click();await wait(8);
  document.querySelector('#technicalSearchInput').value='puncao';document.querySelector('#technicalSearchForm').dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));await wait(8);
  assert(document.querySelectorAll('.technical-module-card').length===4,'Busca sem acento por puncao falhou');
  await go('#/matriz-tecnica/M20/PT-M20-01');assert(document.querySelector('.technical-topic-list article.selected')&&text().toLowerCase().includes('ficha canônica'),'Rota de tópico exato falhou');
  await go('#/matriz-tecnica/M12');assert(text().includes('ficha canônica compartilhada'),'Contexto canônico duplicado não sinalizado');

  await go('#/atlas');assert(document.querySelectorAll('.atlas-card').length===41,'Atlas não exibiu 41 materiais');
  const searches=[['jelco','MAT-VAS-001'],['cateter intravenoso','MAT-VAS-001'],['IV','MAT-VAS-001'],['24G','MAT-VAS-001'],['sonda Foley','MAT-SON-001'],['14 Fr','MAT-SON-001'],['nylon 4-0','MAT-SUT-001'],['lamina 15','MAT-INS-002']];
  for(const [term,id] of searches){await submitSearch(term);assert(document.querySelector(`.atlas-card[href="#/atlas/${id}"]`),`Busca Atlas falhou: ${term}`);document.querySelector('#clearAtlasFilters').click();await wait(6)}
  await go('#/atlas/MAT-VAS-001');
  assert(document.querySelectorAll('.atlas-variant-grid>article').length===8,'Variantes PIVC incompletas');
  assert(text().includes('Agulhas hipodérmicas e cateteres intravenosos usam códigos de cor distintos'),'Alerta de cor/escala ausente');
  assert(document.querySelector('.atlas-license')&&document.querySelector('.atlas-sources a')&&document.querySelector('.atlas-procedures a'),'Rastreabilidade da ficha Atlas incompleta');
  await go('#/atlas/MAT-SON-004');assert(text().includes('incompativel por design')&&text().includes('ISO 80369-3'),'Compatibilidade ENFit/Luer não exibida');

  await go('#/dashboard');
  const global=document.querySelector('#globalSearch');global.value='ECG';global.dispatchEvent(new window.Event('input',{bubbles:true}));await wait(5);
  assert(document.querySelector('#searchResults a[href="#/matriz-tecnica/M20/PT-M20-01"]'),'Busca global ECG sem tópico exato');
  global.value='puncao';global.dispatchEvent(new window.Event('input',{bubbles:true}));await wait(5);
  assert(document.querySelector('#searchResults a[href^="#/matriz-tecnica/"]'),'Busca global sem acento falhou');
  global.value='Foley';global.dispatchEvent(new window.Event('input',{bubbles:true}));await wait(5);
  assert(document.querySelector('#searchResults a[href="#/atlas/MAT-SON-001"]'),'Busca global não integrou Atlas');
  await go('#/roadmap');assert(document.querySelectorAll('.macroblock-card.entregue').length===2&&text().includes('2/8macroblocos concluídos'),'Roadmap não marcou 2/8');
  assert(consoleErrors.length===0,`Erros JSDOM: ${consoleErrors.join('|')}`);

  console.log(JSON.stringify({status:'APROVADO — INTERFACE 1.3 + MB01/MB02',interface:{logo:'SVG próprio',dashboardStats:4,studyAreas:5,featured:4,recommended:3,certification:'não emitida'},legacy:{modules:33,lessons:115,plans:3,remediation:'OK'},matrix:{modules:28,priorityP0Inclusive:17,ECG:'OK',puncao:'OK',canonicalContext:'OK'},atlas:{materials:41,searches:searches.length,pivVariants:8,traceability:'OK',enfitCompatibility:'OK'},globalSearch:'OK',roadmap:'2/8',consoleErrors:0},null,2));
  dom.window.close();server.close();
})().catch(error=>{console.error(error.stack);server.close();process.exit(1)});
