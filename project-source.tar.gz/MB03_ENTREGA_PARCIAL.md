# Nexo Cirúrgico — MB03, lote 1 / auditoria de transição

**Data:** 14/10/2026  
**Versão:** 1.4.0-mb03.1  
**Decisão:** pacote técnico de expansão entregue; **MB03 permanece em desenvolvimento**.  
**Público:** estudantes de Medicina e médicos em treinamento supervisionado.

## 1. Histórico e preservação

- Backup da versão com interface 1.3 foi mantido **fora** do ZIP novo (`NEXO_BACKUP_PRE_MB03_2026-10-14.zip`).
- `data.js` foi **preservado byte a byte**. Permanecem as 33 trilhas, 115 aulas, 210 questões, 30 casos, 137 flashcards, 90 itens de checklist e 72 fontes catalogadas anteriormente.
- A camada de expansão de conteúdo é carregada **depois** do banco legado e **antes** do app. Não houve migração destrutiva.
- O Atlas permanece com 30 materiais / 133 variantes. Sua expansão de insumos específicos continua pendente.

## 2. O que foi efetivamente implementado

1. Marca vetorial compacta provisória com tipografia alinhada, sem recorte do logo institucional; rodapé contém `Product by InMed` em texto.
2. Nova rota `#/procedimentos`, com 15 cards, pesquisa e filtro por área.
3. Nova rota `#/procedimento/PT-Mxx-yy`, que expõe todos os **14 campos** em cada ficha.
4. Navegação bidirecional: ficha → material do Atlas; material do Atlas → ficha disponível; tópico da matriz → ficha; busca global → ficha.
5. Conteúdo original por procedimento com avaliação de indicação/risco, materiais rastreáveis, insumos adicionais, medidas de segurança, supervisão, contraindicações, sequência de simulação, cuidados e fontes.
6. Checklist educacional de sessão **não certificante** e indicação de falhas críticas.
7. Status **revisão técnica** para os 15 tópicos redigidos; os demais permanecem **catalogados**. O MB03 permanece **em desenvolvimento** no roadmap.
8. Remoção de progresso demonstrativo padrão em **novos perfis**, sem zerar o histórico local já existente.
9. `qa_atlas.js` passou a detectar variante duplicada, diâmetro não positivo, escala de variante inconsistente e material declarado validado sem revisor/data (4 cenários negativos adicionais).
10. `qa_mb03.js` novo: smoke test das rotas de aplicação por ambiente simulado em Node, com 112 verificações, sem dependências npm.

## 3. Fichas do primeiro lote (15)

- PT-M01-01 — Higienização das mãos
- PT-M04-05 — Administração intramuscular de medicamentos
- PT-M05-01 — Acesso venoso periférico
- PT-M05-02 — Coleta de sangue venoso
- PT-M06-01 — Avaliação estruturada da ferida
- PT-M06-03 — Irrigação de ferida
- PT-M06-06 — Classificação clínica e cirúrgica das feridas
- PT-M06-07 — Seleção e troca de curativos
- PT-M06-09 — Feridas por mordedura animal ou humana
- PT-M07-03 — Sutura simples interrompida
- PT-M07-11 — Retirada de pontos e grampos cutâneos
- PT-M13-02 — Tala antebraquiopalmar
- PT-M13-10 — Avaliação neurovascular antes e depois da imobilização
- PT-M27-01 — Glicemia capilar à beira-leito
- PT-M27-02 — Eletrocardiograma de 12 derivações à beira-leito

**Nenhuma das 15 fichas está validada clinicamente ou aprovada para uso como protocolo assistencial.** O status 'revisão técnica' significa que a redação existe e aguarda revisão clínica assinada, não que essa revisão ocorreu.

## 4. Auditoria / testes

### Executados nesta entrega

- `node --check app.js`, `node --check data.js`, `node --check procedimentos_mb03.js` — passaram.
- `node qa_content.js` — sem erros estruturais.
- `node qa_assessment.js` — sem erros estruturais; 92 alertas editoriais anteriores continuam pendentes.
- `node qa_atlas.js` — passou, incluindo 12 testes negativos com rejeição de dados inválidos.
- `node qa_mb03.js` — 112/112 verificações aprovadas, com renderização das rotas em DOM simulado.
- Inspeção de integridade do ZIP e preservação do banco — confirmadas.

### Não executados / não comprovados

- Teste visual real de Chromium/Playwright: bloqueado pela política do navegador deste ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`), tanto em localhost como em arquivo local.
- `qa_ui.js` (legado) requer `jsdom`, não instalado no ambiente de auditoria. A suíte estrutural independente roda offline; `qa:ui` pode ser executado após `npm install` em ambiente permissivo.
- Avaliação clínica independente, teste com alunos e acessibilidade integral — **pendentes**.
- As etapas são roteiros textuais: ilustrações anatômicas específicas por procedimento **ainda não foram produzidas**.
- Fotos JPG herdadas da interface: origem/licença não foi auditada nesta etapa. Confirmar direitos antes de publicação pública/comercial.
- Não houve instalação nem deploy no servidor do usuário.

## 5. Defeitos e pendências abertas

| Criticidade | Pendência | Destino |
|---|---|---|
| Alta | Revisão médico-assistencial específica e autorização editorial | MB08 / gate de publicação |
| Alta | Abrangência: restam 212 tópicos da matriz sem ficha técnica no MB03 | MB03 lotes seguintes e MB04/05 |
| Alta | Complementar o Atlas com campos materiais/insumos de curativos, imobilizações e diagnóstico | MB03 lote 2 / Atlas |
| Média | Produzir imagens originais específicas por dispositivo/técnica e instruções visuais reais | MB03 lote 2 + MB06 |
| Média | Realizar teste real em desktop/mobile com captura e acessibilidade | Próxima sessão em navegador habilitado / MB08 |
| Média | Revisar criticamente os 92 alertas editoriais do banco de questões | MB07 / MB08 |
| Média | Verificar a licença dos JPGs da interface herdada | MB08 |

## 6. Próximo passo específico

**MB03 — lote 2: completar técnicas fundamentais e fortalecer o Atlas, sem iniciar MB04 antes de consolidar o MB03.** Escopo inicial: administração SC/ID/IV, infusão e cálculo de segurança, hemocultura, punção capilar, tipos de sutura, curativos avançados, tala posterior de membro inferior, tala tipo sugar-tong, gesso/complicações, profilaxias em feridas, preparação de kits/insumos, referências específicas e testes de regressão. Priorizar primeiro os procedimentos P0 ausentes; manter gate de revisão clínica.

Entregar novamente dois ZIPs (versão atualizada + backup anterior), registro dos testes e passo seguinte.
