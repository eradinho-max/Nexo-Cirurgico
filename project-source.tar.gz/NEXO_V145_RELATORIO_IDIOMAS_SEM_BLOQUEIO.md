# Nexo Cirúrgico — Auditoria e correção PT/ES v1.4.5

**Escopo:** eliminar a falsa trava de revisão externa na interface, tornar a seleção ES funcional e preservar segurança e rastreabilidade.

## Realizado

- Removido `localePending` e aviso de tradução condicionada à revisão.
- Removidas mensagens que apresentavam conteúdo didático como indisponível ou pendente de aprovação clínica.
- Mantido aviso não bloqueador: a plataforma é educacional e não substitui supervisão, competência profissional ou protocolos locais.
- Reescrita da internacionalização com seleção reversível PT/ES e memória no navegador. O idioma alcança conteúdo inserido dinamicamente por rotas.
- Catálogo espanhol: 517 pares de tradução, cobrindo os títulos das 115 aulas, os nomes das 46 fichas e seus 46 resumos introdutórios, 33 nomes de trilhas, 28 nomes de módulos técnicos e termos da interface.
- Busca com aliases clínicos PT/ES (por exemplo: `sutura simple`, `inmovilización`, `acceso`).
- Ajustados testes automatizados para distinguir acesso educacional de certificação profissional. Sem revisor obrigatório para disponibilização educacional; integridade de dados, fontes, fabricantes e licença permanecem verificáveis.
- Fonte de leitura e seletor A−/A+ preservados.

## Pendências declaradas

- Tradução integral dos parágrafos, 14 campos de cada ficha, corpo das 115 aulas, questões e casos. O texto original em português permanece visível nessas passagens; não é apresentado como traduzido.
- Conferência visual no navegador de desktop/celular: não executada nesta sessão, sem alegar aprovação.
- Conteúdo médico deve continuar recebendo atualizações baseadas em fontes, principalmente quando mudam diretrizes. Revisão externa não é requisito de navegação ou publicação educacional.

## QA local

`npm run qa:all`: conteúdo, avaliação, Atlas, 302 verificações MB03, 17 verificações estrut. idioma, 16 verificações funcionais de idioma, 472 tamanhos CSS, build e allowlist de 15 arquivos públicos.

## Próximo passo

1. Tradução progressiva e fiel dos 14 campos de cada ficha procedimental para espanhol (prioridade M16 e M07); depois aulas teóricas, quizzes e casos.
2. Encerramento de lacunas curriculares da Cirurgia Geral e preparação do MB04.
3. Verificar visualmente PT/ES e leitura nos dispositivos reais.

Nenhum PDF dos livros foi colocado no site ou no repositório.
