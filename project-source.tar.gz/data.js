window.NEXO_DATA = {
  "modules": [
    {
      "id": "instrumentais",
      "number": "01",
      "title": "Instrumentais cirúrgicos",
      "short": "Reconheça categorias, funções e cuidados essenciais.",
      "description": "Uma trilha visual para entender a lógica dos instrumentais — da diérese à síntese — e diferenciar peças de aparência semelhante.",
      "icon": "scissors",
      "color": "teal",
      "level": "Essencial",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "lessons": [
        {
          "id": "instrumentais-logica",
          "title": "A lógica das categorias",
          "duration": 12,
          "summary": "Classifique os instrumentais pela função antes de memorizar nomes isolados.",
          "objectives": [
            "Distinguir diérese, hemostasia, preensão, afastamento e síntese",
            "Relacionar forma e função",
            "Aplicar uma sequência segura de reconhecimento"
          ],
          "sections": [
            {
              "title": "Forma segue função",
              "body": "A identificação fica mais simples quando você observa primeiro o que a ponta faz. Lâminas e tesouras separam tecidos; pinças com cremalheira podem manter pressão; afastadores ampliam o campo; porta-agulhas estabilizam a agulha durante a síntese.",
              "bullets": [
                "Diérese: corte ou separação de planos",
                "Hemostasia: controle temporário de vasos e pedículos",
                "Preensão: manipulação de tecidos ou materiais",
                "Afastamento: exposição do campo",
                "Síntese: aproximação e fechamento"
              ]
            },
            {
              "title": "Roteiro de identificação",
              "body": "Observe, nesta ordem: ponta, serrilha, presença de dentes, articulação, cremalheira, comprimento e robustez. Só depois associe o conjunto a um nome.",
              "callout": "A nomenclatura pode variar entre fabricantes e instituições. Confirme sempre o catálogo e a padronização do serviço."
            },
            {
              "title": "Organização por tempo operatório",
              "body": "Na montagem da mesa, agrupar por função favorece leitura visual e passagem previsível. A disposição exata depende da técnica, do profissional e do protocolo institucional.",
              "bullets": [
                "Mantenha peças delicadas protegidas",
                "Deixe anéis alinhados e pontas visíveis com segurança",
                "Separe perfurocortantes conforme o fluxo definido",
                "Confira integridade e funcionamento antes do uso"
              ]
            }
          ]
        },
        {
          "id": "instrumentais-diferencas",
          "title": "Diferenças que confundem",
          "duration": 18,
          "summary": "Compare tesouras, hemostáticas e pinças de preensão sem depender apenas do tamanho.",
          "objectives": [
            "Diferenciar Mayo e Metzenbaum",
            "Comparar Kelly, Crile e Kocher",
            "Reconhecer preensão traumática e delicada"
          ],
          "sections": [
            {
              "title": "Mayo × Metzenbaum",
              "body": "A tesoura Mayo tem construção mais robusta e é usada conforme sua configuração para materiais ou tecidos mais resistentes. A Metzenbaum apresenta hastes proporcionalmente longas e lâminas delicadas, sendo destinada à dissecção de tecidos delicados.",
              "callout": "Tesouras delicadas não devem ser usadas para cortar fios, telas ou materiais que prejudiquem o fio de corte."
            },
            {
              "title": "Kelly × Crile × Kocher",
              "body": "Em descrições clássicas, a Kelly possui serrilha transversal na porção distal da mandíbula; a Crile apresenta serrilha ao longo de toda a mandíbula; a Kocher combina serrilha com dente na extremidade, aumentando a firmeza e também o potencial traumático.",
              "bullets": [
                "Examine a mandíbula aberta, não apenas o contorno externo",
                "Procure dentes terminais",
                "Observe a extensão da serrilha",
                "Considere variações de fabricação"
              ]
            },
            {
              "title": "Allis × Babcock",
              "body": "A Allis possui dentes e promove preensão firme, com maior potencial de trauma. A Babcock tem ponta fenestrada e arredondada, apropriada para manipulação mais delicada de estruturas tubulares, conforme indicação técnica.",
              "callout": "A escolha do instrumental é responsabilidade da equipe habilitada e deve seguir a técnica e o protocolo do procedimento."
            }
          ]
        },
        {
          "id": "instrumentais-integridade-funcional",
          "title": "Integridade, teste funcional e resposta a falhas",
          "duration": 18,
          "summary": "Aprenda a reconhecer sinais de falha antes que o instrumental alcance uma etapa crítica.",
          "objectives": [
            "Inspecionar integridade sem depender apenas da aparência",
            "Relacionar falha funcional ao risco do procedimento",
            "Segregar e comunicar um item não conforme"
          ],
          "sections": [
            {
              "title": "Inspeção com propósito",
              "body": "Inspecionar não é apenas procurar sujeira visível. A avaliação considera alinhamento, articulação, cremalheira, isolamento, corte, superfície e compatibilidade entre partes, de acordo com o desenho do item e o fluxo institucional.",
              "bullets": [
                "Comparar pontas e mandíbulas simétricas",
                "Abrir e fechar articulações sem forçar",
                "Observar trincas, corrosão, rebarbas e deformações",
                "Confirmar montagem de componentes desmontáveis"
              ]
            },
            {
              "title": "Teste proporcional ao risco",
              "body": "O teste funcional deve ser compatível com o tipo de instrumental e realizado no momento previsto pelo serviço. Um item que fecha, mas não mantém alinhamento ou pressão, pode falhar justamente quando a equipe depende dele.",
              "bullets": [
                "Não improvisar testes que danifiquem a peça",
                "Usar materiais de teste previstos pelo fabricante",
                "Distinguir desgaste, montagem incorreta e incompatibilidade"
              ],
              "callout": "A disponibilidade de um instrumento semelhante não autoriza substituição silenciosa. Mudanças precisam ser confirmadas pela equipe habilitada."
            },
            {
              "title": "Falha identificada",
              "body": "Ao encontrar uma não conformidade, o foco é impedir uso acidental e preservar rastreabilidade. O item é retirado do conjunto, identificado e encaminhado pelo fluxo de manutenção ou avaliação, enquanto a equipe confirma uma alternativa segura.",
              "bullets": [
                "Segregar fisicamente",
                "Comunicar o impacto para a sala",
                "Registrar conforme o sistema local",
                "Nunca devolver a peça defeituosa ao conjunto sem controle"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "fios-suturas",
      "number": "02",
      "title": "Fios e suturas",
      "short": "Compare estruturas, absorção, agulhas e princípios de síntese.",
      "description": "Entenda como estrutura, comportamento e apresentação influenciam a seleção e o manuseio dos materiais de sutura.",
      "icon": "thread",
      "color": "blue",
      "level": "Essencial",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "lessons": [
        {
          "id": "fios-classificacao",
          "title": "Como classificar um fio",
          "duration": 14,
          "summary": "Leia um fio por quatro eixos: absorção, origem, estrutura e calibre.",
          "objectives": [
            "Comparar fios absorvíveis e não absorvíveis",
            "Distinguir mono e multifilamentos",
            "Interpretar calibre sem decorar marcas"
          ],
          "sections": [
            {
              "title": "Absorção não é sinônimo de resistência",
              "body": "A perda de resistência tênsil e a absorção completa são eventos diferentes. O material pode perder capacidade de sustentação antes de ser totalmente absorvido. A escolha considera tempo de cicatrização, tecido, tensão e risco de contaminação.",
              "bullets": [
                "Absorvível: degradado pelo organismo ao longo do tempo",
                "Não absorvível: permanece ou é removido, conforme aplicação",
                "Origem e revestimento alteram o comportamento",
                "Consulte a ficha técnica de cada produto"
              ]
            },
            {
              "title": "Monofilamento × multifilamento",
              "body": "Monofilamentos tendem a apresentar menor capilaridade e maior memória. Multifilamentos costumam oferecer manuseio e segurança de nó favoráveis, mas sua estrutura trançada pode aumentar capilaridade e atrito.",
              "callout": "Não existe um fio universalmente melhor; existe o material adequado ao tecido, à técnica e ao contexto clínico."
            },
            {
              "title": "Calibre",
              "body": "Na escala USP, mais zeros geralmente indicam menor diâmetro: 4-0 é mais fino que 2-0. Acima de zero, números maiores indicam fios mais espessos. A equivalência exata deve ser conferida na embalagem.",
              "bullets": [
                "Leia calibre e comprimento",
                "Confirme composição",
                "Verifique tipo e curvatura da agulha",
                "Observe validade e integridade da embalagem"
              ]
            }
          ]
        },
        {
          "id": "agulhas-principios",
          "title": "Agulhas e princípios de sutura",
          "duration": 16,
          "summary": "Associe ponta, corpo e curvatura ao tecido e revise princípios de aproximação.",
          "objectives": [
            "Reconhecer componentes da agulha",
            "Comparar pontas cilíndricas e cortantes",
            "Revisar princípios de aproximação tecidual"
          ],
          "sections": [
            {
              "title": "Anatomia da agulha",
              "body": "Uma agulha cirúrgica possui ponta, corpo e região de união com o fio. A curvatura facilita o trabalho em diferentes profundidades e espaços. A montagem atraumática integra fio e agulha, reduzindo o diâmetro de passagem.",
              "bullets": [
                "Ponta cilíndrica: separa fibras e é comum em tecidos macios",
                "Ponta cortante: possui arestas para tecidos resistentes",
                "Cortante reversa: aresta principal orientada para a convexidade",
                "Curvaturas usuais variam conforme acesso e profundidade"
              ]
            },
            {
              "title": "Aproximar sem estrangular",
              "body": "A síntese busca aproximar bordas com tensão adequada, preservar perfusão e reduzir espaços mortos quando indicado. Nós excessivamente apertados podem comprometer o tecido.",
              "callout": "Técnicas de sutura exigem treinamento prático supervisionado. Este conteúdo é uma revisão conceitual."
            },
            {
              "title": "Segurança no manuseio",
              "body": "A transferência de agulhas deve respeitar a zona neutra ou o método institucional. O descarte ocorre imediatamente em coletor apropriado, sem reencapar ou manipular desnecessariamente.",
              "bullets": [
                "Conte e confira agulhas conforme protocolo",
                "Comunique perdas imediatamente",
                "Use porta-agulhas compatível",
                "Evite tocar a ponta com as mãos"
              ]
            }
          ]
        },
        {
          "id": "fios-selecao-rastreabilidade",
          "title": "Seleção contextual e rastreabilidade de suturas",
          "duration": 17,
          "summary": "Organize a conferência de fios e agulhas sem transformar preferência técnica em regra universal.",
          "objectives": [
            "Ler informações essenciais da embalagem",
            "Diferenciar disponibilidade de seleção clínica",
            "Preservar rastreabilidade e segurança com agulhas"
          ],
          "sections": [
            {
              "title": "Leitura estruturada da embalagem",
              "body": "A conferência começa pela identificação completa, e não pela cor da embalagem. Material, estrutura, calibre, comprimento, agulha, validade e integridade da barreira devem corresponder ao pedido confirmado.",
              "bullets": [
                "Material e estrutura do fio",
                "Calibre e comprimento",
                "Geometria e tamanho da agulha",
                "Lote, validade e integridade"
              ]
            },
            {
              "title": "Escolha é uma decisão contextual",
              "body": "A seleção depende do tecido, da finalidade, da técnica, das características do paciente e da decisão do profissional habilitado. A função perioperatória é preparar alternativas previstas, verbalizar diferenças e impedir trocas não percebidas.",
              "bullets": [
                "Evitar equivalência baseada só no calibre",
                "Confirmar mudança de material ou agulha",
                "Separar opções parecidas para reduzir confusão"
              ],
              "callout": "A aula ensina conferência e organização; não prescreve o fio para um paciente ou procedimento específico."
            },
            {
              "title": "Rastreabilidade e descarte",
              "body": "Quando o protocolo exige registro, a identificação do produto precisa permanecer legível e vinculada ao atendimento. Agulhas devem integrar a contagem e o descarte perfurocortante sem recapeamento ou manipulação desnecessária.",
              "bullets": [
                "Preservar etiqueta quando aplicável",
                "Contar agulhas nos momentos definidos",
                "Tratar fragmento ou discrepância como evento a reconciliar"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "posicionamento",
      "number": "03",
      "title": "Posicionamento cirúrgico",
      "short": "Entenda objetivos, riscos e pontos de proteção.",
      "description": "Revise posições frequentes e desenvolva um olhar sistemático para alinhamento, pressão, nervos, respiração e circulação.",
      "icon": "position",
      "color": "violet",
      "level": "Intermediário",
      "sourceIds": [
        "positioning-review",
        "aorn-safety",
        "sobecc8"
      ],
      "lessons": [
        {
          "id": "posicoes-base",
          "title": "Posições fundamentais",
          "duration": 15,
          "summary": "Compare decúbito dorsal, ventral, lateral e litotomia.",
          "objectives": [
            "Identificar posições fundamentais",
            "Relacionar posição e exposição",
            "Mapear riscos frequentes"
          ],
          "sections": [
            {
              "title": "Decúbitos",
              "body": "No decúbito dorsal, o paciente permanece em posição supina; no ventral, em prona; no lateral, apoiado sobre um dos lados. Cada configuração modifica a exposição, a mecânica respiratória e os pontos de pressão.",
              "bullets": [
                "Dorsal: atenção a occipital, escápulas, sacro e calcâneos",
                "Ventral: proteção de face, olhos, tórax, genitais e proeminências",
                "Lateral: alinhamento cervical, plexo braquial, orelha e membros",
                "Reavaliar fixações após qualquer movimentação da mesa"
              ]
            },
            {
              "title": "Litotomia",
              "body": "Na litotomia, os membros inferiores são elevados e apoiados. Elevação e descida devem ser coordenadas e simultâneas, conforme protocolo, para reduzir torção lombar e alterações hemodinâmicas.",
              "callout": "A proteção do nervo fibular na região lateral do joelho e a prevenção de pressão excessiva são pontos críticos."
            },
            {
              "title": "Inclinações da mesa",
              "body": "Trendelenburg e reverso de Trendelenburg descrevem inclinações cefálica e caudal. Elas afetam deslocamento de vísceras, ventilação, perfusão e risco de deslizamento.",
              "bullets": [
                "Use sistemas de contenção aprovados",
                "Evite pressão focal e cisalhamento",
                "Confirme acesso a vias e dispositivos",
                "Documente posição e proteções utilizadas"
              ]
            }
          ]
        },
        {
          "id": "posicionamento-seguranca",
          "title": "Checklist de posicionamento",
          "duration": 11,
          "summary": "Aplique uma varredura de segurança antes, durante e após posicionar.",
          "objectives": [
            "Usar uma checagem estruturada",
            "Identificar risco de pressão e estiramento",
            "Reconhecer a necessidade de reavaliação"
          ],
          "sections": [
            {
              "title": "A varredura em cinco eixos",
              "body": "Uma revisão sistemática evita que um detalhe seja esquecido: alinhamento, respiração, circulação, nervos e pele. A equipe compartilha a responsabilidade e comunica qualquer limitação.",
              "bullets": [
                "Alinhamento: cabeça, coluna e articulações",
                "Respiração: expansão torácica e acesso à via aérea",
                "Circulação: ausência de compressão e dispositivos livres",
                "Nervos: evitar estiramento, rotação e pressão",
                "Pele: acolchoamento, umidade e cisalhamento"
              ]
            },
            {
              "title": "Antes de cobrir o campo",
              "body": "A checagem final deve ocorrer antes da antissepsia e da colocação dos campos, quando ainda é possível visualizar todos os pontos de apoio.",
              "callout": "Condições clínicas e restrições individuais exigem avaliação da equipe assistencial. Não use um checklist genérico como substituto da avaliação clínica."
            },
            {
              "title": "Reavaliar é parte do processo",
              "body": "Procedimentos prolongados, mudanças de inclinação e movimentação de equipamentos podem alterar apoios. Defina momentos de reavaliação e registre intercorrências conforme o protocolo institucional."
            }
          ]
        },
        {
          "id": "posicionamento-reavaliacao",
          "title": "Reavaliação após mudanças de posição e mesa",
          "duration": 18,
          "summary": "Use uma pausa curta e sistemática sempre que a posição deixar de ser estática.",
          "objectives": [
            "Identificar mudanças que exigem nova checagem",
            "Reavaliar paciente, dispositivos e equipe",
            "Comunicar limites antes de movimentar"
          ],
          "sections": [
            {
              "title": "Posição é um processo",
              "body": "A checagem inicial perde validade quando a mesa inclina, um membro é reposicionado, equipamento se aproxima ou o campo limita o acesso. Cada mudança relevante cria um novo estado que precisa ser verificado.",
              "bullets": [
                "Inclinação ou flexão da mesa",
                "Mudança de apoios ou membros",
                "Docking e entrada de equipamentos",
                "Ajuste que tensione circuitos ou linhas"
              ]
            },
            {
              "title": "Varredura em três camadas",
              "body": "Uma reavaliação breve pode seguir três camadas: corpo e pontos de pressão; dispositivos, circuitos e acessos; ambiente, fixação e possibilidade de resgate. A equipe verbaliza achados críticos antes de retomar.",
              "bullets": [
                "Olhos, face, alinhamento e proeminências",
                "Tubos, cateteres, cabos e campos",
                "Estabilidade, acesso e rota de emergência"
              ]
            },
            {
              "title": "Movimento coordenado",
              "body": "Antes da mudança, alguém confirma liderança, sequência e prontidão das áreas envolvidas. Durante o movimento, comandos curtos reduzem ações simultâneas não coordenadas; depois, uma leitura de retorno confirma que a nova posição é aceitável.",
              "bullets": [
                "Definir quem comanda",
                "Parar diante de resistência ou perda de visualização",
                "Documentar conforme protocolo"
              ],
              "callout": "Nenhuma posição é universalmente segura. Condição clínica, procedimento, dispositivo e avaliação dos profissionais habilitados determinam a decisão."
            }
          ]
        }
      ]
    },
    {
      "id": "assepsia-seguranca",
      "number": "04",
      "title": "Assepsia e segurança",
      "short": "Revise barreiras, campo estéril e comunicação segura.",
      "description": "Consolide princípios de técnica asséptica, contagem, prevenção de eventos e comunicação no centro cirúrgico.",
      "icon": "shield",
      "color": "green",
      "level": "Essencial",
      "sourceIds": [
        "anvisa-isc-2025",
        "br-safe-surgery",
        "who-safe-surgery",
        "who-retained"
      ],
      "lessons": [
        {
          "id": "campo-esteril",
          "title": "Princípios do campo estéril",
          "duration": 13,
          "summary": "Reconheça limites, eventos de contaminação e respostas seguras.",
          "objectives": [
            "Identificar os limites do campo",
            "Reconhecer contaminação potencial",
            "Comunicar e corrigir desvios"
          ],
          "sections": [
            {
              "title": "Princípios consistentes",
              "body": "A técnica asséptica se apoia em barreiras íntegras, separação entre áreas estéreis e não estéreis, vigilância contínua e ação imediata quando a esterilidade é duvidosa.",
              "bullets": [
                "Confirme integridade, validade e indicadores",
                "Abra embalagens sem cruzar sobre o campo",
                "Mantenha o campo sob observação",
                "Considere contaminado aquilo cuja esterilidade não pode ser confirmada"
              ]
            },
            {
              "title": "Umidade, bordas e movimento",
              "body": "Umidade pode favorecer passagem de microrganismos através de barreiras. Bordas de embalagens e áreas abaixo do nível do campo requerem atenção. Movimentos devem minimizar contato e turbulência desnecessária.",
              "callout": "Siga a política institucional para limites do campo, abertura de materiais e substituição de itens."
            },
            {
              "title": "Comunicar sem hesitar",
              "body": "Qualquer membro da equipe deve poder verbalizar uma possível quebra de técnica. A resposta segura é interromper, avaliar e corrigir — sem normalizar o desvio."
            }
          ]
        },
        {
          "id": "contagem-comunicacao",
          "title": "Contagem e comunicação",
          "duration": 15,
          "summary": "Entenda os momentos e princípios de uma contagem confiável.",
          "objectives": [
            "Reconhecer itens sujeitos à contagem",
            "Entender momentos críticos",
            "Saber como agir diante de divergência"
          ],
          "sections": [
            {
              "title": "Contagem é um processo em dupla",
              "body": "Compressas, agulhas, lâminas e instrumentais são controlados conforme protocolo. A contagem deve ser audível, visual e realizada por profissionais designados, com registro dos resultados.",
              "bullets": [
                "Antes do início, para estabelecer a linha de base",
                "Antes do fechamento de cavidades",
                "No fechamento da ferida",
                "Na troca de equipe ou quando houver necessidade definida"
              ]
            },
            {
              "title": "Divergência nunca é presumida",
              "body": "Em caso de contagem incorreta, comunique imediatamente, interrompa o fechamento quando clinicamente possível, repita a contagem e execute a busca sistemática definida pelo serviço.",
              "callout": "A conduta clínica e o uso de métodos de imagem dependem da liderança da equipe e do protocolo institucional."
            },
            {
              "title": "Comunicação estruturada",
              "body": "Briefing, pausa cirúrgica e debriefing ajudam a alinhar identidade, procedimento, lateralidade, riscos, materiais, amostras e plano pós-operatório.",
              "bullets": [
                "Use comunicação em alça fechada",
                "Repita informações críticas",
                "Nomeie dúvidas e riscos",
                "Registre eventos e ações corretivas"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "anatomia",
      "number": "05",
      "title": "Anatomia aplicada",
      "short": "Conecte planos, regiões e estruturas ao campo operatório.",
      "description": "Uma revisão orientada à leitura do campo: planos da parede, regiões abdominais e relações anatômicas essenciais.",
      "icon": "anatomy",
      "color": "rose",
      "level": "Intermediário",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "lessons": [
        {
          "id": "planos-teciduais",
          "title": "Planos e tecidos",
          "duration": 14,
          "summary": "Revise a progressão da superfície aos planos profundos.",
          "objectives": [
            "Reconhecer planos gerais",
            "Relacionar tecido e instrumental",
            "Entender por que a dissecção respeita planos"
          ],
          "sections": [
            {
              "title": "Da pele à cavidade",
              "body": "A sequência exata varia por região, mas a leitura em camadas costuma considerar pele, tecido subcutâneo, fáscias, planos musculares e revestimentos cavitários. Vasos e nervos atravessam ou acompanham esses planos.",
              "bullets": [
                "Pele: barreira e referência da incisão",
                "Subcutâneo: espessura e vascularização variáveis",
                "Fáscias: envolvem e separam compartimentos",
                "Músculos: orientação das fibras influencia o acesso",
                "Serosas: revestem cavidades e órgãos"
              ]
            },
            {
              "title": "Dissecção por planos",
              "body": "Planos anatômicos naturais podem facilitar separação com menor trauma. Reconhecer textura, direção das fibras e vascularização ajuda a antecipar instrumental e técnica.",
              "callout": "Variações anatômicas são comuns. Imagens e descrições didáticas não substituem identificação direta por profissional habilitado."
            },
            {
              "title": "Fechamento em camadas",
              "body": "A síntese considera função de cada plano, tensão, vascularização e risco de espaço morto. Nem toda camada é fechada isoladamente; a decisão depende da técnica e do procedimento."
            }
          ]
        },
        {
          "id": "abdome-referencias",
          "title": "Abdome: referências de orientação",
          "duration": 17,
          "summary": "Use quadrantes e regiões para organizar relações anatômicas.",
          "objectives": [
            "Distinguir quadrantes e nove regiões",
            "Relacionar órgãos de forma geral",
            "Usar referências sem simplificar excessivamente"
          ],
          "sections": [
            {
              "title": "Quatro quadrantes",
              "body": "Uma linha vertical mediana e uma linha horizontal ao nível umbilical dividem o abdome em quadrantes superiores e inferiores, direitos e esquerdos. É uma linguagem clínica de localização, não um limite anatômico rígido.",
              "bullets": [
                "QSD: fígado e vesícula são referências frequentes",
                "QSE: estômago e baço são referências frequentes",
                "QID: ceco e apêndice são referências frequentes",
                "QIE: sigmoide é uma referência frequente"
              ]
            },
            {
              "title": "Nove regiões",
              "body": "Hipocôndrios, epigástrio, flancos, região umbilical, fossas ilíacas e hipogástrio oferecem uma descrição mais detalhada da superfície abdominal.",
              "callout": "Órgãos atravessam regiões e mudam de posição com respiração, distensão, biotipo e posicionamento."
            },
            {
              "title": "Relações importam",
              "body": "No campo operatório, a orientação depende de relações entre estruturas, pedículos, mesentérios e planos — não apenas de um mapa de superfície. Revise sempre a anatomia específica do procedimento."
            }
          ]
        },
        {
          "id": "anatomia-orientacao-comunicacao",
          "title": "Orientação anatômica e comunicação espacial",
          "duration": 20,
          "summary": "Transforme termos anatômicos em uma linguagem comum para localização, espécimes e eventos.",
          "objectives": [
            "Aplicar planos e relações espaciais",
            "Descrever local sem depender de apontar",
            "Reconhecer quando uma referência se tornou ambígua"
          ],
          "sections": [
            {
              "title": "Referência antes do detalhe",
              "body": "Uma descrição anatômica útil começa pela referência compartilhada: região, lado, plano, profundidade e relação com estruturas reconhecíveis. Isso reduz frases vagas como “aqui” ou “mais para cima”, que podem mudar com a posição da equipe.",
              "bullets": [
                "Direita e esquerda do paciente",
                "Superficial e profundo",
                "Medial e lateral",
                "Proximal e distal quando aplicável"
              ]
            },
            {
              "title": "Orientação muda com exposição e posição",
              "body": "Rotação, retração, insuflação e mudança de decúbito alteram a aparência do campo. A equipe deve confirmar a referência sempre que uma amostra, imagem ou dispositivo puder ser associado ao local errado.",
              "bullets": [
                "Relacionar a orientação ao paciente, não ao observador",
                "Verbalizar mudanças de posição",
                "Usar mapas ou esquemas institucionais para múltiplos locais"
              ]
            },
            {
              "title": "Comunicação rastreável",
              "body": "Ao receber um espécime ou registrar um achado, repita local, lado e denominação por extenso. Se a descrição conflitar com o pedido ou com o mapa, interrompa o fluxo e reconcilie antes do envio.",
              "bullets": [
                "Evitar abreviações ambíguas",
                "Fazer leitura de retorno",
                "Registrar correções sem apagar o histórico"
              ],
              "callout": "O objetivo é apoiar comunicação e rastreabilidade. Reconhecimento anatômico educacional não autoriza dissecção ou decisão operatória autônoma."
            }
          ]
        }
      ]
    },
    {
      "id": "fluxo-procedimentos",
      "number": "06",
      "title": "Fluxo de procedimentos",
      "short": "Conecte preparo, tempos operatórios e encerramento seguro.",
      "description": "Organize o raciocínio do pré-operatório imediato ao processamento de amostras e à desmontagem da sala.",
      "icon": "workflow",
      "color": "orange",
      "level": "Intermediário",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "lessons": [
        {
          "id": "tempos-operatorios",
          "title": "Tempos operatórios",
          "duration": 12,
          "summary": "Use os tempos clássicos como mapa mental do procedimento.",
          "objectives": [
            "Revisar diérese, hemostasia, exérese e síntese",
            "Antecipar famílias de instrumentais",
            "Entender que os tempos podem se sobrepor"
          ],
          "sections": [
            {
              "title": "Um mapa, não uma regra rígida",
              "body": "Diérese, hemostasia, exérese e síntese descrevem ações recorrentes. Na prática, elas se alternam: uma dissecção pode exigir hemostasia, seguida de nova diérese antes da retirada ou correção planejada.",
              "bullets": [
                "Diérese: acesso e separação",
                "Hemostasia: prevenção ou controle do sangramento",
                "Exérese: retirada ou tratamento da estrutura-alvo",
                "Síntese: reconstrução e fechamento"
              ]
            },
            {
              "title": "Antecipação segura",
              "body": "Antecipar não significa agir sem solicitação. Significa acompanhar o campo, reconhecer a etapa provável, preparar opções e confirmar a necessidade antes da passagem.",
              "callout": "A comunicação clara prevalece sobre suposições. Em caso de dúvida, confirme."
            },
            {
              "title": "Leitura do procedimento",
              "body": "Estude cada cirurgia por objetivo, acesso, anatomia, equipamentos, instrumentais, materiais implantáveis, possíveis conversões e cuidados com amostras."
            }
          ]
        },
        {
          "id": "encerramento-seguro",
          "title": "Amostras e encerramento seguro",
          "duration": 14,
          "summary": "Revise identificação de espécimes, contagem final e transição da sala.",
          "objectives": [
            "Descrever uma cadeia segura de amostras",
            "Organizar a conferência final",
            "Preparar a transição pós-procedimento"
          ],
          "sections": [
            {
              "title": "Amostras: identidade preservada",
              "body": "O espécime deve ser identificado com dados e descrição compatíveis, recipiente e conservante adequados e documentação correspondente. A confirmação verbal com a equipe reduz trocas.",
              "bullets": [
                "Nome do material e localização",
                "Lateralidade quando aplicável",
                "Exame solicitado",
                "Meio de conservação definido",
                "Registro de quem entrega e recebe, conforme fluxo"
              ]
            },
            {
              "title": "Antes de sair da sala",
              "body": "A equipe confirma contagens, identificação de amostras, problemas com equipamentos, procedimento realizado e preocupações para recuperação e continuidade do cuidado.",
              "callout": "Peças para exame intraoperatório, culturas e materiais especiais podem exigir fluxos distintos."
            },
            {
              "title": "Desmontagem responsável",
              "body": "Perfurocortantes são descartados no ponto de uso; instrumentais seguem abertos ou desmontados conforme orientação; materiais contaminados são segregados; equipamentos e não conformidades são encaminhados corretamente.",
              "bullets": [
                "Proteja peças delicadas",
                "Mantenha itens completos e identificados",
                "Não permita ressecamento de matéria orgânica, conforme protocolo",
                "Registre perdas e danos"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "ambiente-equipe",
      "number": "07",
      "title": "Ambiente e equipe cirúrgica",
      "short": "Compreenda áreas, fluxo, papéis e limites profissionais.",
      "description": "Estude como o ambiente, a circulação de pessoas, a comunicação e as responsabilidades profissionais sustentam a segurança perioperatória.",
      "icon": "workflow",
      "color": "teal",
      "level": "Essencial",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "lessons": [
        {
          "id": "ambiente-areas-fluxo",
          "title": "Áreas, circulação e fluxo seguro",
          "duration": 16,
          "summary": "Relacione zoneamento, circulação e controle ambiental à redução de riscos.",
          "objectives": [
            "Distinguir princípios de zoneamento",
            "Reconhecer fluxos de pessoas e materiais",
            "Identificar comportamentos que aumentam risco"
          ],
          "sections": [
            {
              "title": "Zoneamento orienta comportamento",
              "body": "O centro cirúrgico adota áreas com níveis crescentes de controle para organizar acesso, vestimenta, circulação e barreiras. A terminologia e os limites físicos variam entre instituições; o ponto central é cumprir a sinalização e a política local em cada área.",
              "bullets": [
                "Acesso definido conforme função e necessidade",
                "Vestimenta compatível com a área",
                "Portas e barreiras mantidas conforme protocolo",
                "Circulação de visitantes controlada"
              ]
            },
            {
              "title": "Fluxos que não devem se improvisar",
              "body": "Pacientes, profissionais, materiais esterilizados, resíduos, roupas e produtos para processamento percorrem fluxos planejados. Cruzamentos indevidos, transporte sem contenção e devolução de material ao caminho limpo podem romper barreiras do sistema.",
              "callout": "Mapeie o fluxo real da instituição. Um diagrama genérico não substitui a planta, o plano de resíduos e as rotinas locais."
            },
            {
              "title": "Movimento e ambiente",
              "body": "Tráfego desnecessário, abertura frequente de portas e armazenamento inadequado dificultam o controle do ambiente. Antes do procedimento, confirme sala, equipamentos, limpeza concorrente ou terminal conforme indicação e disponibilidade dos materiais previstos.",
              "bullets": [
                "Reduza entradas e saídas evitáveis",
                "Antecipe materiais sem superlotar a sala",
                "Mantenha rotas de emergência livres",
                "Comunique falhas ambientais antes de iniciar"
              ]
            }
          ]
        },
        {
          "id": "equipe-papeis-limites",
          "title": "Papéis, limites e responsabilidade",
          "duration": 18,
          "summary": "Diferencie funções da equipe e reconheça quando confirmar, interromper ou escalar.",
          "objectives": [
            "Reconhecer responsabilidades compartilhadas",
            "Respeitar habilitação e supervisão",
            "Usar escalonamento diante de risco"
          ],
          "sections": [
            {
              "title": "Trabalho interdependente",
              "body": "Cirurgiões, anestesiologistas, enfermagem, instrumentação, apoio e outros profissionais atuam com competências próprias e objetivos comuns. Segurança não depende de uma única pessoa: identificação, posicionamento, contagem e comunicação requerem participação coordenada.",
              "bullets": [
                "Apresente-se e confirme sua função",
                "Saiba quem lidera cada decisão",
                "Repita informações críticas",
                "Registre o que cabe ao seu papel"
              ]
            },
            {
              "title": "Limite profissional é barreira de segurança",
              "body": "Conhecimento teórico não autoriza executar um ato para o qual não há habilitação, designação ou supervisão. Em dúvida, interrompa a ação não urgente, consulte o responsável e siga a legislação e o protocolo institucional vigentes.",
              "callout": "A plataforma não concede habilitação profissional. Competências legais devem ser confirmadas com o conselho profissional, o empregador e a instituição formadora."
            },
            {
              "title": "Escalar sem silenciar",
              "body": "Diante de risco não resolvido, comunique de forma objetiva, declare a preocupação e acione a cadeia de comando. Em urgências, atue somente dentro de sua competência e do plano institucional.",
              "bullets": [
                "Descreva o fato observado",
                "Explique o risco imediato",
                "Confirme que a mensagem foi compreendida",
                "Documente e notifique conforme o fluxo"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "cirurgia-segura",
      "number": "08",
      "title": "Cirurgia segura",
      "short": "Aplique checklist, comunicação e barreiras de segurança.",
      "description": "Aprofunde os três momentos da lista de verificação e transforme a checagem em conversa efetiva da equipe.",
      "icon": "shield",
      "color": "blue",
      "level": "Essencial",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "lessons": [
        {
          "id": "checklist-tres-momentos",
          "title": "Os três momentos do checklist",
          "duration": 20,
          "summary": "Entenda entrada, pausa antes da incisão e saída como barreiras complementares.",
          "objectives": [
            "Distinguir os três momentos",
            "Relacionar itens aos riscos que controlam",
            "Reconhecer quando a checagem não foi efetiva"
          ],
          "sections": [
            {
              "title": "Antes da indução anestésica",
              "body": "A entrada confirma identidade, procedimento, local, consentimento e aspectos de segurança anestésica, alergias e riscos previstos. Os itens exatos seguem a lista adotada pelo serviço e devem ser verificados com participação do paciente sempre que possível.",
              "bullets": [
                "Identidade por identificadores aceitos",
                "Procedimento e local compatíveis",
                "Alergias e riscos conhecidos",
                "Equipamentos e monitorização checados pela equipe responsável"
              ]
            },
            {
              "title": "Antes da incisão",
              "body": "Na pausa cirúrgica, os membros se apresentam, reconfirmam paciente, procedimento e sítio e compartilham etapas críticas, necessidades de equipamentos, profilaxia e exames de imagem quando aplicáveis. A incisão aguarda a resolução de discrepâncias relevantes.",
              "callout": "Recitar itens sem atenção compartilhada não equivale a uma checagem efetiva."
            },
            {
              "title": "Antes de o paciente sair da sala",
              "body": "A saída confirma procedimento, contagens, espécimes, problemas com equipamentos e preocupações para recuperação e continuidade do cuidado. Pendências devem ter responsável e destino definidos.",
              "bullets": [
                "Procedimento registrado de forma compatível",
                "Contagens e divergências comunicadas",
                "Espécimes verbalmente confirmados",
                "Plano de recuperação compartilhado"
              ]
            }
          ]
        },
        {
          "id": "comunicacao-fatores-humanos",
          "title": "Comunicação e fatores humanos",
          "duration": 17,
          "summary": "Use briefing, alça fechada e escalonamento para reduzir falhas de equipe.",
          "objectives": [
            "Aplicar comunicação em alça fechada",
            "Reconhecer vieses e distrações",
            "Estruturar transferência de cuidado"
          ],
          "sections": [
            {
              "title": "Alça fechada",
              "body": "Uma mensagem crítica é dirigida a alguém, repetida por quem a recebe e confirmada por quem a emitiu. O ciclo reduz ambiguidade em solicitações, contagens, medicamentos, equipamentos e resposta a eventos.",
              "bullets": [
                "Chame a pessoa pelo nome ou função",
                "Declare a informação de modo específico",
                "Ouça a repetição",
                "Corrija imediatamente qualquer diferença"
              ]
            },
            {
              "title": "Briefing e debriefing",
              "body": "O briefing antecipa objetivo, sequência, riscos, necessidades e alternativas. O debriefing registra o que ocorreu, pendências, falhas de equipamento e oportunidades de melhoria. Ambos devem ser curtos, participativos e adequados ao contexto.",
              "callout": "Hierarquia não deve impedir que qualquer integrante verbalize uma preocupação de segurança."
            },
            {
              "title": "Transferência sem lacunas",
              "body": "Na passagem de cuidado, comunique identidade, procedimento, anestesia, eventos, acessos e dispositivos, perdas e balanço conforme atribuição, medicamentos críticos, espécimes, riscos e plano imediato. Use o instrumento padronizado da instituição.",
              "bullets": [
                "Evite múltiplas conversas paralelas",
                "Permita perguntas",
                "Confirme pendências",
                "Registre informações essenciais"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "prevencao-isc",
      "number": "09",
      "title": "Prevenção de infecção cirúrgica",
      "short": "Organize medidas pré, intra e pós-operatórias contra ISC.",
      "description": "Estude prevenção de infecção de sítio cirúrgico como um conjunto de medidas coordenadas, não como uma única ação.",
      "icon": "shield",
      "color": "green",
      "level": "Essencial",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "lessons": [
        {
          "id": "isc-preparo-preoperatorio",
          "title": "Preparação pré-operatória",
          "duration": 20,
          "summary": "Relacione avaliação, banho, pelos, pele e antimicrobiano ao protocolo de prevenção.",
          "objectives": [
            "Reconhecer componentes do preparo",
            "Evitar práticas sem indicação",
            "Identificar pontos de checagem da equipe"
          ],
          "sections": [
            {
              "title": "Prevenção começa antes da sala",
              "body": "Avaliação de condições do paciente, higiene, controle de focos infecciosos e preparo conforme o procedimento fazem parte da prevenção. A equipe verifica se medidas prescritas foram realizadas e comunica desvios antes de prosseguir.",
              "bullets": [
                "Confirmar orientação e preparo previstos",
                "Comunicar infecção ativa ou alteração clínica",
                "Evitar remoção rotineira de pelos",
                "Aplicar protocolo para banho e higiene"
              ]
            },
            {
              "title": "Pelos e integridade da pele",
              "body": "Quando a remoção de pelos é necessária, método, local e momento devem seguir o protocolo, reduzindo lesão cutânea. A pele é avaliada antes da antissepsia e alterações relevantes são comunicadas.",
              "callout": "Não transforme uma orientação geral em prescrição individual. Indicação e método dependem do procedimento e do protocolo vigente."
            },
            {
              "title": "Profilaxia antimicrobiana é processo de equipe",
              "body": "Seleção, dose, momento e redose pertencem ao plano clínico e ao protocolo. A equipe perioperatória contribui confirmando prescrição, administração e registro, além de comunicar atrasos ou divergências.",
              "bullets": [
                "Conferir alergias",
                "Confirmar medicamento e dose prescritos",
                "Registrar horário",
                "Verbalizar necessidade de reavaliação conforme protocolo"
              ]
            }
          ]
        },
        {
          "id": "isc-intra-posoperatorio",
          "title": "Medidas intra e pós-operatórias",
          "duration": 19,
          "summary": "Integre técnica asséptica, ambiente, condições fisiológicas e vigilância.",
          "objectives": [
            "Relacionar múltiplas barreiras à prevenção",
            "Reconhecer desvios intraoperatórios",
            "Orientar vigilância sem diagnosticar"
          ],
          "sections": [
            {
              "title": "Barreiras que trabalham juntas",
              "body": "Higiene e preparo das mãos, barreiras íntegras, preparo da pele, técnica asséptica, controle do ambiente e manejo apropriado de materiais atuam de forma combinada. Uma medida não compensa a falha deliberada de outra.",
              "bullets": [
                "Monitorar integridade do campo",
                "Reduzir tráfego desnecessário",
                "Proteger dispositivos e soluções",
                "Corrigir quebra de técnica imediatamente"
              ]
            },
            {
              "title": "Condições fisiológicas",
              "body": "Temperatura, oxigenação, perfusão e glicemia em pacientes selecionados integram o cuidado clínico e podem influenciar risco. Monitorização e intervenções pertencem aos profissionais responsáveis e ao protocolo institucional.",
              "callout": "A plataforma não define metas clínicas individuais nem substitui prescrição ou avaliação anestésico-cirúrgica."
            },
            {
              "title": "Ferida e vigilância",
              "body": "Curativo, higiene das mãos, orientação ao paciente e acompanhamento de sinais de alerta seguem o tipo de cirurgia e o protocolo. Suspeitas devem ser registradas e encaminhadas à avaliação clínica, sem diagnóstico por material educacional.",
              "bullets": [
                "Manter técnica indicada no curativo",
                "Orientar sinais que exigem contato com o serviço",
                "Evitar manipulação desnecessária",
                "Participar da vigilância e notificação conforme função"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "contagens-itens",
      "number": "10",
      "title": "Contagens e itens retidos",
      "short": "Padronize contagem, reconciliação e resposta à divergência.",
      "description": "Aprofunde o sistema de prevenção de retenção não intencional de compressas, agulhas, instrumentais e outros itens controlados.",
      "icon": "checklist",
      "color": "violet",
      "level": "Essencial",
      "sourceIds": [
        "who-retained",
        "aorn-safety",
        "sobecc8"
      ],
      "lessons": [
        {
          "id": "contagem-sistema-confiavel",
          "title": "Como construir uma contagem confiável",
          "duration": 18,
          "summary": "Entenda padronização, linha de base, reconciliação e comunicação audível.",
          "objectives": [
            "Descrever requisitos de uma contagem",
            "Identificar momentos definidos",
            "Reconhecer fatores que fragilizam o processo"
          ],
          "sections": [
            {
              "title": "Padronizar antes de contar",
              "body": "A instituição define quais itens são contados, como são organizados, quem participa, quais momentos exigem conferência e como o resultado é documentado. Itens devem permanecer identificáveis e controlados durante todo o procedimento.",
              "bullets": [
                "Contagem visual e audível",
                "Participação simultânea dos profissionais designados",
                "Sequência consistente",
                "Registro imediato conforme protocolo"
              ]
            },
            {
              "title": "Momentos e transições",
              "body": "A linha de base é estabelecida antes do uso. Novas contagens ocorrem nos momentos definidos para cavidades e fechamento, e podem ser necessárias em trocas de equipe ou eventos não planejados.",
              "callout": "Os momentos exatos e a conduta em emergência devem constar da política institucional."
            },
            {
              "title": "Fatores humanos",
              "body": "Interrupções, ruído, pressa, múltiplas conversas, itens não padronizados e mudanças de equipe elevam o risco de falha. Se a contagem for interrompida ou houver dúvida, reinicie a etapa conforme protocolo.",
              "bullets": [
                "Proteja o momento da contagem",
                "Não presuma o resultado",
                "Verbalize itens adicionados",
                "Mantenha descarte e campo organizados"
              ]
            }
          ]
        },
        {
          "id": "contagem-divergencia",
          "title": "Divergência: resposta e documentação",
          "duration": 16,
          "summary": "Aplique uma resposta escalonada sem normalizar contagem incorreta.",
          "objectives": [
            "Reconhecer prioridade da comunicação",
            "Organizar busca sistemática",
            "Documentar fatos e ações"
          ],
          "sections": [
            {
              "title": "Pare e comunique",
              "body": "Quando o resultado diverge, a equipe responsável é informada imediatamente. O fechamento é interrompido quando clinicamente possível, a contagem é repetida e inicia-se busca sistemática no campo, na sala e nos recipientes conforme o plano institucional.",
              "bullets": [
                "Declare qual categoria divergiu",
                "Repita a contagem completa indicada",
                "Procure de forma organizada",
                "Mantenha liderança e comunicação centralizadas"
              ]
            },
            {
              "title": "Escalonamento clínico",
              "body": "Se o item não for localizado, a liderança médica e de enfermagem segue o protocolo, incluindo avaliação do campo e eventual método de imagem quando aplicável. A urgência clínica pode modificar a sequência, mas não elimina a necessidade de comunicação e registro.",
              "callout": "Nunca registre uma contagem como correta para encerrar o processo quando existe divergência conhecida."
            },
            {
              "title": "Aprender com o evento",
              "body": "Documente resultado, notificações, buscas, decisões e desfecho conforme o prontuário e o sistema de segurança. A análise posterior deve buscar causas do sistema, não apenas culpabilização individual.",
              "bullets": [
                "Preservar relato factual",
                "Notificar conforme política",
                "Identificar interrupções e mudanças",
                "Implementar melhoria e acompanhar resultado"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "especimes-implantes",
      "number": "11",
      "title": "Espécimes e implantes",
      "short": "Preserve identidade, integridade e rastreabilidade.",
      "description": "Aprenda os princípios de cadeia segura para amostras e o controle documental de materiais implantáveis.",
      "icon": "layers",
      "color": "rose",
      "level": "Essencial",
      "sourceIds": [
        "aorn-specimen",
        "br-safe-surgery",
        "sobecc8"
      ],
      "lessons": [
        {
          "id": "especimes-cadeia-segura",
          "title": "Cadeia segura de espécimes",
          "duration": 19,
          "summary": "Evite trocas e perdas desde a retirada até a entrega ao destino.",
          "objectives": [
            "Reconhecer pontos de risco",
            "Confirmar identificação e destino",
            "Diferenciar fluxos especiais"
          ],
          "sections": [
            {
              "title": "Identidade acompanha o material",
              "body": "Amostra, solicitação e registro precisam corresponder. Identificação do paciente, descrição anatômica, localização e lateralidade quando aplicável são confirmadas verbalmente pela equipe e registradas conforme o sistema institucional.",
              "bullets": [
                "Usar identificadores aceitos",
                "Descrever material e origem",
                "Confirmar exame solicitado",
                "Registrar responsável pela transferência conforme fluxo"
              ]
            },
            {
              "title": "Recipiente e conservação",
              "body": "Tipo de recipiente, conservante, temperatura e urgência dependem do exame. Material para congelação, cultura, citologia, cálculo ou outros estudos pode exigir fluxo específico, sem conservante inadequado.",
              "callout": "Em dúvida sobre acondicionamento, interrompa o envio e confirme com anatomia patológica, laboratório e protocolo."
            },
            {
              "title": "Transferência e reconciliação",
              "body": "O material permanece em local seguro e designado até a transferência. Na saída, equipe confirma nome, quantidade, destino e pendências; qualquer perda, vazamento ou divergência é comunicada imediatamente.",
              "bullets": [
                "Evitar recipientes sem rótulo",
                "Não deixar material sem supervisão",
                "Separar solicitações diferentes",
                "Confirmar recebimento quando previsto"
              ]
            }
          ]
        },
        {
          "id": "implantes-rastreabilidade",
          "title": "Implantes e rastreabilidade",
          "duration": 17,
          "summary": "Organize conferência, documentação e resposta a não conformidades.",
          "objectives": [
            "Reconhecer dados de rastreabilidade",
            "Verificar integridade e compatibilidade",
            "Responder a não conformidade antes do uso"
          ],
          "sections": [
            {
              "title": "Do recebimento ao registro",
              "body": "Implantes e materiais associados requerem controle de identificação, fabricante, referência, lote ou série, validade e paciente, conforme produto e norma aplicável. A disponibilidade deve ser confirmada antes do procedimento.",
              "bullets": [
                "Conferir produto e tamanho solicitados",
                "Verificar embalagem e validade",
                "Preservar etiquetas e registros",
                "Documentar itens efetivamente utilizados"
              ]
            },
            {
              "title": "Compatibilidade e instruções de uso",
              "body": "Componentes, instrumentais e equipamentos precisam ser compatíveis. A equipe consulta instruções de uso e protocolo, sem improvisar combinação, processamento ou substituição não autorizada.",
              "callout": "Decisões sobre escolha e implantação pertencem aos profissionais habilitados."
            },
            {
              "title": "Não conformidade e vigilância",
              "body": "Produto danificado, vencido, sem rastreabilidade ou com suspeita de falha é segregado e comunicado. Eventos e queixas técnicas seguem o fluxo institucional e de vigilância aplicável.",
              "bullets": [
                "Não usar produto com integridade duvidosa",
                "Preservar embalagem e evidências",
                "Registrar o ocorrido",
                "Acionar responsáveis e alternativa segura"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "cme-processamento",
      "number": "12",
      "title": "CME e processamento",
      "short": "Acompanhe o produto da limpeza à liberação segura.",
      "description": "Compreenda o sistema de processamento de produtos para saúde, seus controles e a integração entre Centro Cirúrgico e CME.",
      "icon": "rotate",
      "color": "orange",
      "level": "Essencial",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022",
        "sobecc8"
      ],
      "lessons": [
        {
          "id": "cme-fluxo-limpeza",
          "title": "Fluxo, classificação e limpeza",
          "duration": 22,
          "summary": "Entenda por que limpeza validada precede desinfecção ou esterilização.",
          "objectives": [
            "Explicar fluxo do processamento",
            "Relacionar classificação e método",
            "Reconhecer fatores que comprometem limpeza"
          ],
          "sections": [
            {
              "title": "Fluxo do contaminado ao processado",
              "body": "O processamento organiza recepção, limpeza, enxágue, secagem, inspeção, preparo, desinfecção ou esterilização, armazenamento e distribuição. Barreiras e fluxo evitam recontaminação de produtos já processados.",
              "bullets": [
                "Transporte em recipiente adequado",
                "Separação de áreas e atividades",
                "Equipe capacitada e protegida",
                "Rastreabilidade das etapas"
              ]
            },
            {
              "title": "Limpeza é etapa crítica",
              "body": "Matéria orgânica e sujidade interferem nas etapas posteriores. Método manual ou automatizado, água, detergente, tempo, ação mecânica e compatibilidade seguem instruções validadas para o produto e os equipamentos.",
              "callout": "Desinfecção ou esterilização não corrige uma limpeza inadequada."
            },
            {
              "title": "Classificação orienta o nível de processamento",
              "body": "A finalidade de uso e o contato com tecidos, mucosas ou pele ajudam a definir o nível mínimo de processamento, sempre respeitando regulamentação e instrução de uso do fabricante.",
              "bullets": [
                "Produto crítico: requer esterilização quando aplicável",
                "Semicrítico: processamento conforme risco e norma",
                "Não crítico: limpeza e desinfecção indicada",
                "Produto de uso único não deve ser presumido reprocessável"
              ]
            }
          ]
        },
        {
          "id": "cme-inspecao-preparo",
          "title": "Inspeção, preparo e embalagem",
          "duration": 20,
          "summary": "Detecte sujidade e dano antes de preparar o conjunto para processamento final.",
          "objectives": [
            "Aplicar princípios de inspeção",
            "Reconhecer não conformidades",
            "Relacionar embalagem e método"
          ],
          "sections": [
            {
              "title": "Limpo, seco e funcional",
              "body": "Após a limpeza, o produto é inspecionado quanto a resíduos, corrosão, fissuras, alinhamento, corte, isolamento, lúmens e funcionamento conforme sua construção. Iluminação e magnificação podem ser necessárias.",
              "bullets": [
                "Reprocessar quando houver sujidade",
                "Segregar item danificado",
                "Lubrificar somente com produto indicado",
                "Manter componentes completos e identificados"
              ]
            },
            {
              "title": "Montagem padronizada",
              "body": "Conjuntos são montados conforme lista e configuração validadas, sem impedir contato do agente esterilizante. Articulações, desmontagem e proteção de pontas seguem instruções do fabricante.",
              "callout": "Peso, densidade e disposição inadequados podem comprometer secagem, esterilização e integridade da embalagem."
            },
            {
              "title": "Sistema de barreira estéril",
              "body": "A embalagem deve ser compatível com o método, permitir penetração e remoção do agente, manter integridade e possibilitar abertura asséptica. Selagem, identificação e indicadores são aplicados conforme processo validado.",
              "bullets": [
                "Conferir integridade do material",
                "Usar selagem validada",
                "Identificar sem danificar a barreira",
                "Registrar lote e conteúdo conforme sistema"
              ]
            }
          ]
        },
        {
          "id": "cme-monitoramento-rastreabilidade",
          "title": "Monitoramento e rastreabilidade",
          "duration": 21,
          "summary": "Interprete controles do processo e preserve a liberação segura do produto.",
          "objectives": [
            "Distinguir tipos de monitoramento",
            "Reconhecer critérios de liberação",
            "Manter armazenamento e rastreabilidade"
          ],
          "sections": [
            {
              "title": "Controles complementares",
              "body": "Parâmetros físicos, indicadores químicos e indicadores biológicos fornecem informações diferentes e complementares sobre o ciclo. Frequência, localização e interpretação seguem regulamentação, protocolo e instrução do equipamento.",
              "bullets": [
                "Revisar parâmetros do ciclo",
                "Conferir indicadores previstos",
                "Relacionar resultado ao lote",
                "Não liberar diante de critério não atendido"
              ]
            },
            {
              "title": "Liberação e não conformidade",
              "body": "A liberação considera registros, parâmetros, indicadores, integridade e secagem quando aplicável. Falha exige retenção do lote, investigação, documentação e ações definidas pelo sistema de qualidade.",
              "callout": "A decisão de recolhimento e reprocessamento deve seguir o responsável técnico e o protocolo validado."
            },
            {
              "title": "Armazenar e rastrear",
              "body": "Produtos processados são protegidos de umidade, poeira, manipulação excessiva e danos. A rastreabilidade conecta ciclo, lote, conteúdo, equipamentos, resultados e destino conforme o sistema institucional.",
              "bullets": [
                "Inspecionar embalagem antes da distribuição e uso",
                "Adotar rotação de estoque",
                "Transportar em condições protegidas",
                "Registrar destino quando requerido"
              ]
            }
          ]
        },
        {
          "id": "cme-barreira-eventos",
          "title": "Barreira estéril, armazenamento e eventos de pacote",
          "duration": 18,
          "summary": "Raciocine sobre integridade do sistema de barreira do preparo até a abertura no ponto de uso.",
          "objectives": [
            "Avaliar condições que comprometem a barreira",
            "Distinguir validade administrativa de integridade",
            "Responder a evento sem improvisar liberação"
          ],
          "sections": [
            {
              "title": "A barreira é um sistema",
              "body": "Embalagem, selagem, indicador, transporte, armazenamento e manuseio funcionam em conjunto. Um pacote dentro da data pode estar inadequado se houver umidade, perfuração, abertura, selagem irregular ou identificação insuficiente.",
              "bullets": [
                "Inspecionar todas as faces acessíveis",
                "Proteger contra compressão e atrito",
                "Confirmar identificação e método de processamento"
              ]
            },
            {
              "title": "Evento relacionado, não apenas calendário",
              "body": "A manutenção da esterilidade depende dos eventos a que o pacote foi exposto e das regras validadas pelo serviço. Queda, umidade, dano ou armazenamento inadequado exigem avaliação conforme protocolo, mesmo quando a validade impressa não expirou.",
              "bullets": [
                "Não secar e usar pacote molhado",
                "Não reparar embalagem danificada no ponto de uso",
                "Preservar dados para rastreabilidade"
              ]
            },
            {
              "title": "Resposta a não conformidade",
              "body": "Diante de dúvida, o item não deve entrar no campo até que a condição seja esclarecida. A equipe segrega, comunica a necessidade de substituição e registra o evento pelo fluxo da instituição.",
              "bullets": [
                "Impedir abertura acidental",
                "Buscar alternativa processada e liberada",
                "Escalar padrões repetidos ao CME"
              ],
              "callout": "A liberação de carga e o reprocessamento seguem responsabilidade definida, qualificação dos equipamentos e normas vigentes; a sala não substitui esse processo."
            }
          ]
        }
      ]
    },
    {
      "id": "energia-fogo-fumaca",
      "number": "13",
      "title": "Energia, fogo e fumaça",
      "short": "Previna queimaduras, incêndio e exposição à fumaça cirúrgica.",
      "description": "Compreenda os riscos dos dispositivos de energia e aplique barreiras de segurança antes, durante e após o uso.",
      "icon": "shield",
      "color": "orange",
      "level": "Intermediário",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke",
        "nr32"
      ],
      "lessons": [
        {
          "id": "energia-cirurgica-principios",
          "title": "Princípios de energia cirúrgica",
          "duration": 21,
          "summary": "Diferencie sistemas monopolar e bipolar e reconheça pontos de falha.",
          "objectives": [
            "Comparar circuitos monopolar e bipolar",
            "Reconhecer riscos de queimadura e acoplamento",
            "Aplicar uma checagem pré-uso"
          ],
          "sections": [
            {
              "title": "Corrente, circuito e tecido",
              "body": "Na eletrocirurgia monopolar, a corrente percorre um circuito que inclui eletrodo ativo, paciente e eletrodo de retorno compatível. Na bipolar, a corrente se concentra entre os polos do instrumento. Efeito tecidual depende de forma de onda, potência, tempo, contato e características do tecido.",
              "bullets": [
                "Usar equipamento e acessórios compatíveis",
                "Confirmar configuração solicitada",
                "Manter cabos organizados e íntegros",
                "Seguir instruções de uso do fabricante"
              ]
            },
            {
              "title": "Retorno seguro e vias alternativas",
              "body": "Quando o sistema requer eletrodo de retorno, seleção, local, contato e monitoramento devem seguir fabricante e protocolo. Umidade, contato incompleto, dobra ou produto incompatível podem concentrar energia e favorecer lesão.",
              "callout": "Não corte, redimensione, reposicione ou improvise eletrodos e acessórios fora das instruções de uso."
            },
            {
              "title": "Antes de ativar",
              "body": "Inspecione isolamento e conexões, mantenha a ponta ativa em suporte isolante quando fora de uso e confirme que o campo está livre de risco evitável. Alarmes não devem ser silenciados sem identificar e corrigir a causa.",
              "bullets": [
                "Visualizar a ponta ativa antes da ativação",
                "Evitar contato não intencional com metal",
                "Comunicar mudança de potência",
                "Retirar de uso equipamento com dano ou comportamento anormal"
              ]
            }
          ]
        },
        {
          "id": "fogo-cirurgico-prevencao",
          "title": "Incêndio no campo: prevenção",
          "duration": 18,
          "summary": "Use o triângulo do fogo para antecipar combinações perigosas.",
          "objectives": [
            "Identificar oxidante, ignição e combustível",
            "Realizar avaliação compartilhada do risco",
            "Reconhecer prioridades diante de fogo"
          ],
          "sections": [
            {
              "title": "Três elementos que se encontram",
              "body": "Incêndio requer oxidante, fonte de ignição e combustível. Oxigênio e outros oxidantes, dispositivos de energia ou laser e campos, gazes, soluções ou materiais inflamáveis podem coexistir no ambiente cirúrgico.",
              "bullets": [
                "Oxidante: concentração e acúmulo importam",
                "Ignição: energia, laser e faísca",
                "Combustível: campos, gazes, pelos e soluções",
                "Risco aumenta quando a equipe não compartilha o plano"
              ]
            },
            {
              "title": "Prevenção é interdisciplinar",
              "body": "Antes do início, equipe discute localização, uso de energia, presença de oxidantes e materiais inflamáveis. Soluções de preparo devem ser utilizadas e secas conforme instruções; acúmulos e vapores precisam ser evitados.",
              "callout": "A estratégia depende do sítio, anestesia, equipamento e protocolo. Cirurgião, anestesia e enfermagem precisam concordar sobre as barreiras."
            },
            {
              "title": "Resposta treinada",
              "body": "Ao reconhecer fogo, a equipe declara o evento, interrompe fontes conforme sua função, executa o protocolo de controle, protege o paciente, aciona ajuda e avalia lesões. Simulação define quem faz cada ação sem depender de improviso.",
              "bullets": [
                "Conhecer alarme e rota de emergência",
                "Localizar recursos de controle",
                "Treinar cenários de campo e via aérea",
                "Preservar equipamento e registros para investigação"
              ]
            }
          ]
        },
        {
          "id": "fumaca-cirurgica-controle",
          "title": "Fumaça cirúrgica e hierarquia de controles",
          "duration": 16,
          "summary": "Priorize captura na fonte, manutenção e práticas de trabalho.",
          "objectives": [
            "Reconhecer fumaça como risco ocupacional",
            "Aplicar a hierarquia de controles",
            "Verificar o sistema de evacuação"
          ],
          "sections": [
            {
              "title": "Pluma não é apenas odor",
              "body": "Dispositivos que aquecem tecido geram aerossóis, partículas e gases. A composição varia com energia e tecido. Exposição pode causar irritação e outros efeitos; por isso, o risco deve ser controlado mesmo quando a pluma parece pequena.",
              "bullets": [
                "Considerar paciente e trabalhadores",
                "Não usar odor como medida de segurança",
                "Incluir fumaça no programa de riscos",
                "Capacitar a equipe"
              ]
            },
            {
              "title": "Capturar antes de dispersar",
              "body": "Controle de engenharia com evacuação local próxima à fonte é preferível a depender apenas da ventilação geral ou de equipamento de proteção individual. Posicionamento, fluxo, filtro e descarte seguem o fabricante e a política institucional.",
              "callout": "Máscara cirúrgica não substitui sistema de captura e filtração apropriado."
            },
            {
              "title": "Sistema pronto para funcionar",
              "body": "Antes do caso, confirme disponibilidade, montagem, sucção e filtro. Durante o uso, mantenha a captação efetiva; após o procedimento, manipule consumíveis e resíduos conforme precauções e registre falhas.",
              "bullets": [
                "Não aguardar a sala encher de fumaça",
                "Trocar filtros no intervalo indicado",
                "Realizar manutenção programada",
                "Notificar indisponibilidade ou baixa eficiência"
              ]
            }
          ]
        },
        {
          "id": "energia-falhas-contingencia",
          "title": "Falhas de energia cirúrgica e contingência segura",
          "duration": 18,
          "summary": "Planeje o que fazer quando um sistema não ativa, alerta ou se comporta de modo inesperado.",
          "objectives": [
            "Diferenciar falha percebida de causa presumida",
            "Interromper tentativas repetidas inseguras",
            "Aplicar uma sequência de contingência rastreável"
          ],
          "sections": [
            {
              "title": "Parar antes de compensar",
              "body": "Quando a ativação não produz o efeito esperado, aumentar potência ou repetir acionamentos sem diagnóstico pode ampliar dano. A resposta inicial é interromper, comunicar e manter o instrumento sob controle visual quando possível.",
              "bullets": [
                "Confirmar qual dispositivo e função estavam ativos",
                "Verificar conexões acessíveis sem desmontagem imprópria",
                "Observar dano, isolamento ou alerta"
              ]
            },
            {
              "title": "Sequência de verificação",
              "body": "A equipe segue a instrução de uso e o protocolo local: identifica equipamento, acessórios e configurações autorizadas; troca componentes apenas quando indicado; e confirma que a alternativa é compatível.",
              "bullets": [
                "Não misturar acessórios sem confirmação",
                "Evitar atalhos para contornar alarmes",
                "Preservar item suspeito para avaliação"
              ]
            },
            {
              "title": "Contingência e registro",
              "body": "O briefing deve prever alternativa técnica e efeitos da indisponibilidade. Após uma falha, dados do equipamento, acessório, lote ou série e circunstâncias relevantes sustentam manutenção e tecnovigilância.",
              "bullets": [
                "Comunicar impacto ao procedimento",
                "Segregar o componente quando necessário",
                "Registrar pelo canal institucional"
              ],
              "callout": "Configurações e uso clínico são definidos pelo operador habilitado, instrução do fabricante e protocolo. Esta aula não fornece parâmetros de potência."
            }
          ]
        }
      ]
    },
    {
      "id": "medicamentos-rotulagem",
      "number": "14",
      "title": "Medicamentos e rotulagem",
      "short": "Reduza erros no preparo, identificação e administração.",
      "description": "Estude barreiras de segurança para medicamentos no ambiente perioperatório, com foco em rotulagem, comunicação e rastreabilidade.",
      "icon": "clipboard",
      "color": "blue",
      "level": "Intermediário",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide",
        "rdc36"
      ],
      "lessons": [
        {
          "id": "medicamentos-campo-rotulagem",
          "title": "Rotulagem no campo e na sala",
          "duration": 19,
          "summary": "Não permita que seringa, copo ou solução permaneça sem identificação segura.",
          "objectives": [
            "Reconhecer elementos do rótulo",
            "Evitar troca e ambiguidade",
            "Aplicar leitura e confirmação verbal"
          ],
          "sections": [
            {
              "title": "Identificar imediatamente",
              "body": "Todo medicamento ou solução transferido da embalagem original para seringa, cuba, copo ou outro recipiente deve ser identificado imediatamente segundo o padrão institucional. Recipiente sem rótulo ou com conteúdo incerto não deve ser usado.",
              "bullets": [
                "Nome do medicamento ou solução",
                "Concentração e quantidade quando aplicáveis",
                "Diluente e volume conforme padrão",
                "Data, horário e responsável conforme protocolo"
              ]
            },
            {
              "title": "Preparar uma coisa de cada vez",
              "body": "Organização reduz trocas. Compare prescrição, embalagem e rótulo nos pontos definidos; separe medicamentos de aparência ou nome semelhante e preserve a embalagem até a confirmação quando previsto.",
              "callout": "Cor de etiqueta é uma pista visual, não substitui leitura completa do rótulo."
            },
            {
              "title": "Comunicação antes da entrega",
              "body": "Ao passar um medicamento, declare nome, concentração ou dose e finalidade quando necessário; quem recebe repete e confirma. Dúvidas, divergências e ordens verbais seguem o protocolo e são resolvidas antes da administração, salvo resposta emergencial definida.",
              "bullets": [
                "Dirigir a mensagem a uma pessoa",
                "Evitar abreviações não padronizadas",
                "Confirmar alergias e identificação",
                "Documentar administração e intercorrências"
              ]
            }
          ]
        },
        {
          "id": "medicamentos-alta-vigilancia",
          "title": "Alta vigilância e barreiras de administração",
          "duration": 21,
          "summary": "Aplique checagens proporcionais ao risco sem transformar listas em automatismo.",
          "objectives": [
            "Reconhecer medicamentos de maior risco",
            "Diferenciar checagem de dupla checagem independente",
            "Responder a erro ou quase erro"
          ],
          "sections": [
            {
              "title": "Risco exige barreiras adicionais",
              "body": "Medicamentos potencialmente perigosos podem causar dano grave quando ocorre erro. Armazenamento, prescrição, preparo, bombas, acesso e monitorização devem seguir lista e política institucional, com alertas que sejam claros e não excessivos.",
              "bullets": [
                "Confirmar paciente e alergias",
                "Ler medicamento, concentração, dose e via",
                "Rastrear a linha até o paciente",
                "Verificar programação e registro"
              ]
            },
            {
              "title": "Dupla checagem precisa ser independente",
              "body": "Quando exigida, cada profissional verifica os elementos críticos sem apenas aceitar a conclusão do outro. O processo deve ser definido para o medicamento e não pode substituir competência, cálculo correto ou monitorização.",
              "callout": "A plataforma não fornece doses, diluições ou velocidades individuais. Use prescrição, farmácia, protocolo e fonte farmacológica atual."
            },
            {
              "title": "Erro e quase erro geram aprendizado",
              "body": "Ao identificar erro ou risco, proteja o paciente, comunique imediatamente, acione avaliação clínica, registre fatos e notifique conforme o sistema. Não ocultar, apagar ou alterar retrospectivamente a informação.",
              "bullets": [
                "Priorizar avaliação do paciente",
                "Preservar embalagens e dados",
                "Descrever o fato sem julgamento",
                "Participar da análise e melhoria do sistema"
              ]
            }
          ]
        },
        {
          "id": "medicamentos-reconciliacao-campo",
          "title": "Reconciliação de medicamentos no campo estéril",
          "duration": 17,
          "summary": "Acompanhe o medicamento desde a apresentação até o descarte ou devolução.",
          "objectives": [
            "Aplicar comunicação em alça fechada",
            "Manter rótulo junto ao recipiente",
            "Resolver discrepâncias sem suposição"
          ],
          "sections": [
            {
              "title": "Cadeia de identificação",
              "body": "A segurança depende de preservar nome, concentração, quantidade preparada quando aplicável, diluente, horário e responsável conforme política. Seringa ou cuba sem identificação deixa de ser confiável, mesmo que alguém “lembre” o conteúdo.",
              "bullets": [
                "Rotular imediatamente",
                "Manter rótulo visível",
                "Separar apresentações semelhantes",
                "Usar somente abreviações aprovadas"
              ]
            },
            {
              "title": "Transferência para o campo",
              "body": "Quem entrega verbaliza os dados essenciais e quem recebe repete para confirmação. O recipiente original permanece disponível pelo tempo definido no protocolo para permitir reconciliação.",
              "bullets": [
                "Evitar entrega durante interrupções críticas",
                "Confirmar antes de passar mais de um produto",
                "Não completar recipiente parcialmente identificado"
              ]
            },
            {
              "title": "Discrepância ou sobra",
              "body": "Se rótulo, ordem e conteúdo não puderem ser reconciliados, o produto não deve ser administrado. A equipe segrega, comunica e segue o fluxo de descarte, devolução e registro.",
              "bullets": [
                "Não cheirar, provar ou inferir pela cor",
                "Preservar evidências em caso de evento",
                "Registrar conforme responsabilidade profissional"
              ],
              "callout": "Prescrição, preparo e administração dependem de habilitação, ordem válida e protocolos específicos. O conteúdo não substitui dupla checagem institucional."
            }
          ]
        }
      ]
    },
    {
      "id": "anestesia-srpa",
      "number": "15",
      "title": "Anestesia e SRPA",
      "short": "Compreenda fases, monitorização e transferência de cuidado.",
      "description": "Uma visão interdisciplinar do cuidado anestésico e da recuperação, respeitando atribuições profissionais e normas vigentes.",
      "icon": "workflow",
      "color": "violet",
      "level": "Intermediário",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "who-safe-surgery",
        "sobecc8"
      ],
      "lessons": [
        {
          "id": "anestesia-fases-seguranca",
          "title": "Fases e segurança anestésica",
          "duration": 22,
          "summary": "Relacione avaliação, indução, manutenção, despertar e transferência.",
          "objectives": [
            "Reconhecer fases do cuidado anestésico",
            "Diferenciar responsabilidades",
            "Identificar checagens de ambiente e comunicação"
          ],
          "sections": [
            {
              "title": "Um contínuo de cuidado",
              "body": "O cuidado anestésico inclui avaliação prévia, plano, preparação de equipamentos e medicamentos, indução quando aplicável, manutenção, emergência ou despertar e recuperação. Risco e monitorização variam com paciente, procedimento, técnica e ambiente.",
              "bullets": [
                "Confirmar avaliação e consentimentos previstos",
                "Checar máquina, monitorização e suporte",
                "Compartilhar via aérea e riscos críticos",
                "Registrar eventos e transferência de responsabilidade"
              ]
            },
            {
              "title": "Atribuições não são intercambiáveis",
              "body": "Indicação e condução do ato anestésico pertencem ao médico responsável, conforme normas. A equipe perioperatória prepara ambiente, materiais e comunicação dentro de sua competência, reconhece alterações e aciona ajuda sem executar atos não autorizados.",
              "callout": "A Resolução CFM nº 2.471/2026, publicada em setembro de 2026, disciplina especificamente sedação ambulatorial e possui prazo próprio de entrada em vigor. Verifique a situação normativa antes de aplicar."
            },
            {
              "title": "Checagem antes de começar",
              "body": "Identidade, alergias, jejum conforme avaliação, acesso, equipamentos, fontes de gases, aspiração, monitorização, fármacos e recursos para intercorrências são confirmados pela equipe responsável. Inconformidades críticas são comunicadas antes do procedimento.",
              "bullets": [
                "Não presumir que outra pessoa checou",
                "Testar alarmes e limites conforme função",
                "Conhecer localização de recursos de emergência",
                "Antecipar transferência e destino pós-operatório"
              ]
            }
          ]
        },
        {
          "id": "srpa-transferencia-vigilancia",
          "title": "SRPA: transferência e vigilância",
          "duration": 20,
          "summary": "Estruture a passagem de cuidado e reconheça deterioração durante a recuperação.",
          "objectives": [
            "Organizar transferência estruturada",
            "Reconhecer domínios de observação",
            "Respeitar critérios e responsabilidade de alta"
          ],
          "sections": [
            {
              "title": "Transferir é compartilhar responsabilidade",
              "body": "Na admissão à recuperação, a equipe recebe identificação, procedimento, técnica anestésica, eventos, via aérea, acessos, dispositivos, medicamentos relevantes, perdas, balanço e preocupações. A passagem deve ocorrer sem conversas paralelas e permitir perguntas.",
              "bullets": [
                "Confirmar quem entrega e quem recebe",
                "Conectar monitorização antes de encerrar a passagem",
                "Reconciliar dispositivos e infusões",
                "Registrar horário e pendências"
              ]
            },
            {
              "title": "Observar tendências, não apenas números",
              "body": "Consciência, ventilação, oxigenação, circulação, temperatura, dor, náusea, sangramento, bloqueio motor quando aplicável e outros critérios prescritos são acompanhados. Mudança ou tendência preocupante exige comunicação imediata.",
              "callout": "Reconhecimento não significa diagnóstico autônomo. Acione o profissional responsável e o protocolo de resposta rápida."
            },
            {
              "title": "Alta é decisão responsável",
              "body": "Critérios de alta e destino seguem norma, avaliação e protocolo. Escore pode apoiar, mas não substitui julgamento e responsabilidade do médico designado. Orientações e continuidade do cuidado devem acompanhar o paciente.",
              "bullets": [
                "Não acelerar alta por pressão de fluxo",
                "Registrar critérios e decisão",
                "Comunicar risco residual",
                "Assegurar transporte e destino adequados"
              ]
            }
          ]
        },
        {
          "id": "anestesia-alarmes-interface",
          "title": "Alarmes e interface multiprofissional com a anestesia",
          "duration": 19,
          "summary": "Entenda como reconhecer, comunicar e apoiar a resposta a mudanças sem ultrapassar funções.",
          "objectives": [
            "Tratar alarmes como informação clínica ou técnica",
            "Preservar acesso e comunicação",
            "Organizar apoio dentro do papel profissional"
          ],
          "sections": [
            {
              "title": "Alarme exige leitura de contexto",
              "body": "Silenciar um som não resolve sua causa. A equipe identifica qual sistema alarmou, torna a informação audível para quem conduz a anestesia e observa se há mudança simultânea no paciente, circuito, equipamento ou campo.",
              "bullets": [
                "Localizar a origem do alarme",
                "Evitar desconectar ou alterar parâmetros sem autorização",
                "Reduzir ruído e conversas não essenciais"
              ]
            },
            {
              "title": "Acesso à via aérea e aos dispositivos",
              "body": "Campos, equipamentos e posição podem dificultar a resposta. Antes de etapas que reduzam acesso, a equipe confirma como chegar ao paciente e como desfazer rapidamente a limitação se necessário.",
              "bullets": [
                "Planejar antes de inclinar, girar ou acoplar",
                "Manter circuitos sem tensão",
                "Verbalizar manipulações solicitadas"
              ]
            },
            {
              "title": "Apoio coordenado",
              "body": "Quando há deterioração ou incerteza, declare a preocupação, interrompa ações não essenciais e confirme liderança. Quem não conduz a anestesia pode liberar espaço, buscar recursos previstos, registrar marcos e fechar a comunicação.",
              "bullets": [
                "Executar somente funções atribuídas",
                "Confirmar pedidos por leitura de retorno",
                "Preparar transferência se indicada pela equipe"
              ],
              "callout": "Medicamentos, doses, ventilação e decisões anestésicas pertencem aos profissionais habilitados e aos protocolos assistenciais."
            }
          ]
        }
      ]
    },
    {
      "id": "seguranca-ocupacional",
      "number": "16",
      "title": "Segurança ocupacional",
      "short": "Controle riscos biológicos, químicos, físicos e ergonômicos.",
      "description": "Aprofunde a aplicação da NR-32 e reconheça responsabilidades do trabalhador e do empregador no ambiente cirúrgico.",
      "icon": "shield",
      "color": "green",
      "level": "Intermediário",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "lessons": [
        {
          "id": "nr32-biologico-perfurocortante",
          "title": "Risco biológico e perfurocortantes",
          "duration": 19,
          "summary": "Previna exposição e acione o fluxo pós-acidente sem atraso.",
          "objectives": [
            "Aplicar práticas com perfurocortantes",
            "Reconhecer responsabilidades de descarte",
            "Descrever o fluxo inicial pós-exposição"
          ],
          "sections": [
            {
              "title": "Prevenção começa na organização",
              "body": "Planeje a passagem e o descarte, mantenha coletor acessível e visível e reduza manipulação desnecessária. Quem utiliza o perfurocortante é responsável pelo descarte imediato conforme NR-32 e protocolo.",
              "bullets": [
                "Não reencapar de rotina",
                "Não desconectar manualmente sem indicação segura",
                "Não ultrapassar limite do coletor",
                "Usar zona neutra quando adotada"
              ]
            },
            {
              "title": "Barreiras não eliminam o risco",
              "body": "EPI, dispositivos de segurança, vacinação, capacitação e práticas de trabalho se complementam. Luvas reduzem contato, mas não impedem perfuração; atenção e engenharia do processo continuam necessárias.",
              "callout": "Adorno, vestimenta e EPI devem seguir avaliação de risco e regras da instituição."
            },
            {
              "title": "Exposição exige resposta imediata",
              "body": "Interrompa a atividade com segurança, realize o cuidado local indicado, comunique e procure avaliação ocupacional sem atraso. Registre circunstâncias e material envolvido conforme o plano de exposição.",
              "bullets": [
                "Não ocultar o acidente",
                "Não aplicar substância irritante não indicada",
                "Seguir avaliação e acompanhamento do serviço",
                "Participar da análise preventiva"
              ]
            }
          ]
        },
        {
          "id": "nr32-quimico-fisico-ergonomia",
          "title": "Riscos químicos, físicos e ergonômicos",
          "duration": 20,
          "summary": "Use inventário, controles de engenharia e práticas de trabalho adequadas.",
          "objectives": [
            "Reconhecer diferentes classes de risco",
            "Priorizar medidas coletivas",
            "Identificar quando interromper e notificar"
          ],
          "sections": [
            {
              "title": "Químicos e gases",
              "body": "Produtos químicos precisam de identificação, ficha de segurança, armazenamento compatível e resposta a derramamento. Sistemas de gases e anestesia exigem manutenção e controle de vazamentos; equipamento com falha não deve permanecer em uso.",
              "bullets": [
                "Manter rótulo e identificação",
                "Conhecer chuveiro, lava-olhos e kit aplicável",
                "Não misturar produtos sem procedimento",
                "Notificar odor, vazamento ou falha"
              ]
            },
            {
              "title": "Radiação e outras energias",
              "body": "Tempo, distância, blindagem, dosimetria e controle de acesso integram o plano de proteção radiológica. Laser, ruído e outras fontes requerem capacitação e barreiras específicas definidas por responsável técnico.",
              "callout": "EPI é uma camada; ele não substitui proteção coletiva, manutenção, sinalização e planejamento."
            },
            {
              "title": "Ergonomia é segurança assistencial",
              "body": "Longa permanência em pé, posturas estáticas, levantamento, transporte e repetição podem causar lesão e perda de atenção. Ajuste de altura, auxílio mecânico, equipe suficiente, alternância e pausas conforme organização do trabalho reduzem carga.",
              "bullets": [
                "Planejar transferência do paciente",
                "Ajustar mesa e monitores",
                "Solicitar ajuda antes da movimentação",
                "Relatar risco ergonômico recorrente"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "documentacao-etica-privacidade",
      "number": "17",
      "title": "Documentação, ética e privacidade",
      "short": "Registre com precisão e proteja dados sensíveis.",
      "description": "Integre registro perioperatório, responsabilidade ética, prontuário eletrônico e proteção de dados de saúde.",
      "icon": "file",
      "color": "rose",
      "level": "Intermediário",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "lessons": [
        {
          "id": "registro-perioperatorio-qualidade",
          "title": "Registro perioperatório de qualidade",
          "duration": 18,
          "summary": "Documente fatos, horários, intervenções e respostas com autoria identificável.",
          "objectives": [
            "Reconhecer atributos de um registro válido",
            "Diferenciar fato de julgamento",
            "Corrigir sem ocultar o histórico"
          ],
          "sections": [
            {
              "title": "Claro, objetivo e cronológico",
              "body": "O registro sustenta continuidade, rastreabilidade, avaliação de qualidade e responsabilidade profissional. Descreva o que foi observado e realizado, horário, resposta e comunicação, usando terminologia e campos padronizados.",
              "bullets": [
                "Identificar paciente e procedimento",
                "Registrar contagens, posição e dispositivos conforme função",
                "Documentar espécimes, implantes e intercorrências",
                "Assinar com identificação profissional"
              ]
            },
            {
              "title": "Precisão sem reconstrução fictícia",
              "body": "Não registre ação não realizada nem altere informação para parecer contemporânea. Correção ou anotação tardia deve preservar autoria, data, hora e conteúdo anterior conforme sistema e política.",
              "callout": "Prontuário, notificação de incidente e documento administrativo têm finalidades diferentes e podem ser complementares."
            },
            {
              "title": "Comunicação também precisa aparecer",
              "body": "Quando uma alteração, divergência ou risco é comunicado, registre destinatário, horário, orientação recebida e resposta dentro de sua atribuição. Expressões vagas não substituem descrição factual.",
              "bullets": [
                "Evitar copiar texto sem verificar",
                "Não usar abreviação não aprovada",
                "Não atribuir culpa",
                "Registrar pendências na transferência"
              ]
            }
          ]
        },
        {
          "id": "privacidade-dados-saude",
          "title": "Privacidade e dados de saúde",
          "duration": 17,
          "summary": "Acesse somente o necessário e evite exposição em telas, conversas e imagens.",
          "objectives": [
            "Reconhecer dados de saúde como sensíveis",
            "Aplicar acesso mínimo e seguro",
            "Responder a incidente de privacidade"
          ],
          "sections": [
            {
              "title": "Necessidade assistencial não é acesso irrestrito",
              "body": "Dados de saúde são sensíveis. O profissional acessa e compartilha o necessário para cuidado e dever legal, pelos canais autorizados. Curiosidade, conveniência ou divulgação informal não justificam acesso.",
              "bullets": [
                "Usar login individual",
                "Bloquear tela ao se afastar",
                "Evitar prontuário aberto ao público",
                "Confirmar destinatário antes de enviar informação"
              ]
            },
            {
              "title": "Imagem clínica requer governança",
              "body": "Foto ou vídeo de paciente, campo operatório, exame ou tela não deve ser feito em dispositivo pessoal nem publicado em grupo ou rede social. Consentimento, finalidade, armazenamento e autorização institucional precisam ser avaliados formalmente.",
              "callout": "Anonimizar não é apenas ocultar o nome; contexto, voz, imagem, tatuagem, data e caso raro podem identificar a pessoa."
            },
            {
              "title": "Incidente deve ser contido e comunicado",
              "body": "Acesso indevido, tela exposta, envio incorreto ou perda de dispositivo exige contenção e comunicação imediata ao canal institucional. Não tente apagar evidências ou resolver silenciosamente.",
              "bullets": [
                "Interromper o compartilhamento",
                "Preservar informações do evento",
                "Acionar segurança da informação ou privacidade",
                "Seguir orientação sobre comunicação e mitigação"
              ]
            }
          ]
        },
        {
          "id": "documentacao-linha-tempo",
          "title": "Linha do tempo perioperatória e rastreabilidade",
          "duration": 18,
          "summary": "Registre marcos no momento adequado para reduzir reconstruções tardias e lacunas.",
          "objectives": [
            "Distinguir dado observado de interpretação",
            "Vincular dispositivos e eventos à linha do tempo",
            "Corrigir registros preservando autoria"
          ],
          "sections": [
            {
              "title": "Registro contemporâneo",
              "body": "Marcos como entrada, pausas, contagens, implantes, espécimes, mudanças de posição e transferência ganham valor quando registrados próximos ao evento. Anotações tardias baseadas em memória aumentam risco de omissão.",
              "bullets": [
                "Usar horário de referência comum",
                "Registrar quem realizou ou confirmou quando exigido",
                "Evitar copiar dados não verificados"
              ]
            },
            {
              "title": "Rastreabilidade de materiais e eventos",
              "body": "Lote, série, local, destino e condição devem ser vinculados ao atendimento conforme o tipo de produto e a política. Uma lista de etiquetas sem contexto não substitui um registro coerente.",
              "bullets": [
                "Associar implante ao local correto",
                "Documentar destino de espécimes",
                "Registrar divergências e resolução"
              ]
            },
            {
              "title": "Correção e privacidade",
              "body": "Erros devem ser corrigidos pelo mecanismo do sistema, preservando histórico, autoria e justificativa. Acesso e compartilhamento ficam limitados à finalidade assistencial ou legal autorizada.",
              "bullets": [
                "Não apagar para ocultar erro",
                "Não reutilizar credenciais",
                "Comunicar envio ao destinatário errado"
              ],
              "callout": "O prontuário é documento assistencial e legal. Modelos educacionais devem ser ajustados às normas profissionais e ao sistema da instituição."
            }
          ]
        }
      ]
    },
    {
      "id": "eventos-criticos",
      "number": "18",
      "title": "Eventos críticos e emergências",
      "short": "Organize liderança, papéis e auxílios cognitivos sob pressão.",
      "description": "Desenvolva competências não técnicas para reconhecer deterioração, mobilizar recursos e apoiar a resposta institucional.",
      "icon": "target",
      "color": "teal",
      "level": "Intermediário",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "anvisa-fire-2014",
        "cfm2174-2017",
        "mhaus-crisis"
      ],
      "lessons": [
        {
          "id": "crise-lideranca-comunicacao",
          "title": "Liderança e comunicação em crise",
          "duration": 19,
          "summary": "Declare o evento, distribua funções e proteja a atenção da equipe.",
          "objectives": [
            "Reconhecer princípios de gestão de recursos",
            "Usar funções explícitas",
            "Integrar auxílio cognitivo e registro"
          ],
          "sections": [
            {
              "title": "Tornar a crise visível",
              "body": "Ao reconhecer deterioração ou evento crítico, verbalize a preocupação, solicite ajuda e confirme quem lidera. A liderança mantém visão global; funções técnicas são distribuídas a pessoas identificadas.",
              "bullets": [
                "Líder e executor não precisam ser a mesma pessoa",
                "Definir comunicação e registro",
                "Designar busca de materiais",
                "Controlar acesso e ruído"
              ]
            },
            {
              "title": "Mensagens curtas e fechadas",
              "body": "Solicitações incluem destinatário, tarefa e confirmação. Mudanças clínicas, resultado de intervenção e dificuldade são anunciados. A equipe evita sugestões simultâneas sem priorização do líder.",
              "callout": "Qualquer membro pode apontar risco. O líder deve criar espaço para que a preocupação seja ouvida."
            },
            {
              "title": "Auxílio cognitivo não substitui competência",
              "body": "Manual de emergência ou checklist ajuda a não omitir etapas conhecidas. Um leitor pode acompanhar a sequência enquanto os responsáveis executam o protocolo. Ferramenta precisa ser adaptada, treinada e estar imediatamente disponível.",
              "bullets": [
                "Usar a versão institucional vigente",
                "Não improvisar doses a partir de memória parcial",
                "Registrar tempos e ações",
                "Realizar debriefing depois da estabilização"
              ]
            }
          ]
        },
        {
          "id": "crise-preparo-simulacao",
          "title": "Preparação para eventos de alto risco",
          "duration": 20,
          "summary": "Treine resposta a eventos raros sem transformar a aula em prescrição clínica.",
          "objectives": [
            "Mapear recursos para eventos selecionados",
            "Reconhecer sinais que exigem escalonamento",
            "Planejar simulação e debriefing"
          ],
          "sections": [
            {
              "title": "Raro não significa dispensável",
              "body": "Incêndio, hemorragia maciça, anafilaxia, via aérea difícil, parada cardiorrespiratória e hipertermia maligna exigem protocolos, recursos e treinamento. A equipe deve conhecer localização de carrinhos, listas, contatos e rotas de transferência.",
              "bullets": [
                "Verificar disponibilidade e validade",
                "Definir quem aciona apoio",
                "Treinar acesso rápido ao protocolo",
                "Planejar continuidade e transferência"
              ]
            },
            {
              "title": "Reconhecer e chamar ajuda",
              "body": "Alteração abrupta de ventilação, circulação, consciência, sangramento, temperatura ou funcionamento de equipamento deve ser comunicada imediatamente. Padrões inesperados após agentes anestésicos podem exigir ativação do protocolo específico pelo anestesiologista.",
              "callout": "Tratamento, medicamentos e doses pertencem ao protocolo de emergência e aos profissionais habilitados; não devem ser improvisados a partir desta aula."
            },
            {
              "title": "Simular o sistema",
              "body": "Simulação testa pessoas, ambiente, comunicação e logística. Cenário deve ter objetivo, papéis, observadores e debriefing sem culpabilização, gerando plano de melhoria com responsável e prazo.",
              "bullets": [
                "Testar em diferentes turnos",
                "Incluir falha de equipamento ou comunicação",
                "Medir tempo para localizar recursos",
                "Repetir após corrigir o sistema"
              ]
            }
          ]
        },
        {
          "id": "eventos-debriefing-aprendizado",
          "title": "Debriefing após eventos e aprendizagem do sistema",
          "duration": 19,
          "summary": "Transforme a experiência de uma crise em melhoria sem confundir análise com culpabilização.",
          "objectives": [
            "Distinguir debriefing imediato de investigação formal",
            "Reconstruir fatos e barreiras",
            "Converter achados em ações verificáveis"
          ],
          "sections": [
            {
              "title": "Primeiro, segurança e cuidado",
              "body": "O debriefing só começa quando o paciente, a equipe e o ambiente estão estabilizados. Necessidades clínicas, apoio aos profissionais e preservação de informações têm prioridade sobre explicações apressadas.",
              "bullets": [
                "Confirmar continuidade assistencial",
                "Identificar necessidade de apoio",
                "Preservar registros e materiais relevantes"
              ]
            },
            {
              "title": "Conversa estruturada",
              "body": "Uma revisão breve pode perguntar o que era esperado, o que ocorreu, o que ajudou e o que dificultou. Fatos observáveis são separados de interpretações; dúvidas seguem para análise institucional.",
              "bullets": [
                "Incluir diferentes funções",
                "Evitar exposição desnecessária",
                "Reconhecer boas barreiras, não apenas falhas"
              ]
            },
            {
              "title": "Ação e fechamento do ciclo",
              "body": "Aprendizado exige responsável, prazo e forma de verificar a mudança. Recomendações vagas como “ter mais atenção” são fracas quando o problema envolve ambiente, fluxo, treinamento ou tecnologia.",
              "bullets": [
                "Definir ação específica",
                "Testar em simulação quando aplicável",
                "Compartilhar retorno com a equipe"
              ],
              "callout": "Debriefing educacional não substitui notificação, investigação, comunicação ao paciente ou obrigações legais previstas pela instituição."
            }
          ]
        }
      ]
    },
    {
      "id": "cirurgia-geral-digestiva",
      "number": "19",
      "title": "Cirurgia geral e digestiva",
      "short": "Conecte anatomia abdominal, acesso, contaminação e recuperação segura.",
      "description": "Uma introdução perioperatória à cirurgia abdominal aberta e minimamente invasiva, com foco em preparação da sala, transições críticas, espécimes e integração com vias de recuperação.",
      "icon": "workflow",
      "color": "teal",
      "level": "Especialidade",
      "sourceIds": [
        "eras-colorectal-2025",
        "espen-surgery-2025",
        "eaes-sages-older-2026",
        "anvisa-isc-2025"
      ],
      "lessons": [
        {
          "id": "geral-mapa-abdominal",
          "title": "Mapa da cirurgia abdominal",
          "duration": 18,
          "summary": "Use regiões, planos e tempos operatórios para antecipar necessidades sem transformar preferência em regra.",
          "objectives": [
            "Relacionar acesso e exposição à região anatômica",
            "Reconhecer transições entre tempos limpos e contaminados",
            "Organizar equipamentos e espécimes com rastreabilidade"
          ],
          "sections": [
            {
              "title": "Região, acesso e exposição",
              "body": "A preparação começa pelo local anatômico e pela via prevista. Incisões abertas, portais laparoscópicos e conversão exigem arranjos diferentes, mas compartilham o mesmo princípio: acesso visível, cabos sem tração, proteção dos pontos de apoio e possibilidade de ampliar o campo com segurança.",
              "bullets": [
                "Quadrantes e relações anatômicas orientam a posição dos equipamentos",
                "A via de acesso deve ser confirmada na pausa",
                "Planos alternativos precisam estar disponíveis antes da incisão"
              ]
            },
            {
              "title": "Transições do campo",
              "body": "Procedimentos digestivos podem alternar etapas de dissecção, abertura de víscera, reconstrução, lavagem e fechamento. A equipe deve verbalizar mudanças que alterem risco de contaminação, necessidade de instrumentais ou destino de materiais.",
              "bullets": [
                "Separar etapas e materiais conforme protocolo local",
                "Substituir itens contaminados quando indicado",
                "Reconciliar contagens antes de mudanças irreversíveis"
              ]
            },
            {
              "title": "Grampos, energia e espécimes",
              "body": "Dispositivos de grampeamento e energia exigem compatibilidade, conferência da carga, integridade da embalagem e respeito às instruções de uso. Espécimes precisam de identificação e orientação acordadas antes de sair da sala.",
              "callout": "A plataforma não define carga, regulagem ou técnica. Confirme o dispositivo, a anatomia e a instrução do fabricante com o cirurgião e o protocolo institucional."
            }
          ]
        },
        {
          "id": "geral-recuperacao-integrada",
          "title": "Recuperação integrada e handoff",
          "duration": 17,
          "summary": "Entenda a lógica dos programas ERAS e traduza o plano em comunicação, registros e transições de cuidado.",
          "objectives": [
            "Explicar ERAS como programa multidisciplinar",
            "Identificar elementos perioperatórios de processo",
            "Construir um handoff que preserve riscos e metas"
          ],
          "sections": [
            {
              "title": "Programa, não item isolado",
              "body": "Vias de recuperação combinam educação, otimização, prevenção de infecção, manejo de temperatura, analgesia multimodal, alimentação e mobilização. A aplicação depende de elegibilidade e protocolo; copiar apenas um componente pode romper a coerência do programa.",
              "bullets": [
                "Equipe e responsabilidades definidas",
                "Adesão aos elementos medida",
                "Exceções clínicas documentadas"
              ]
            },
            {
              "title": "O intraoperatório informa a recuperação",
              "body": "Via de acesso, perdas, dispositivos, intercorrências, espécimes e conversão alteram o plano pós-operatório. A informação precisa chegar à recuperação sem depender da memória de uma única pessoa.",
              "bullets": [
                "Estado de drenos, sondas e acessos",
                "Contagens e espécimes encerrados",
                "Riscos, metas e desvios do plano verbalizados"
              ]
            },
            {
              "title": "Fontes atuais e protocolo local",
              "body": "As recomendações colorretais de 2025 e os documentos recentes de nutrição oferecem referências atualizadas, mas não substituem avaliação individual nem protocolo institucional.",
              "callout": "Não aplique jejum, dieta, analgesia ou profilaxia a um paciente com base nesta aula. Esses componentes exigem prescrição e avaliação da equipe habilitada."
            }
          ]
        },
        {
          "id": "geral-transicoes-contaminacao",
          "title": "Transições de contaminação e reorganização do campo",
          "duration": 19,
          "summary": "Antecipe mudanças de risco em cirurgia abdominal e coordene barreiras sem regras universais.",
          "objectives": [
            "Reconhecer uma transição relevante",
            "Organizar comunicação e materiais",
            "Aplicar protocolo sem automatismos"
          ],
          "sections": [
            {
              "title": "A mudança precisa ser visível",
              "body": "Abertura de víscera, retorno a uma etapa limpa ou mudança de acesso pode alterar o plano de materiais e barreiras. A equipe verbaliza o marco antes de movimentar itens ou iniciar o fechamento.",
              "bullets": [
                "Nomear a etapa",
                "Confirmar o que muda no protocolo",
                "Evitar circulação desnecessária durante a reorganização"
              ]
            },
            {
              "title": "Separação funcional",
              "body": "Quando previsto, instrumentos, luvas, campos ou mesas são reorganizados de forma controlada. A estratégia deve ser definida pelo protocolo e pela avaliação do procedimento, não por uma regra isolada aplicada a todos os casos.",
              "bullets": [
                "Manter contagem durante a transição",
                "Evitar misturar itens já utilizados",
                "Confirmar disponibilidade para o fechamento"
              ]
            },
            {
              "title": "Cenário de pressão de tempo",
              "body": "Se a equipe solicita fechamento imediato enquanto a reorganização está incompleta, declare a pendência e confirme prioridade e barreiras mínimas com a liderança.",
              "bullets": [
                "Comunicação curta",
                "Atribuição de funções",
                "Registro de exceção quando aplicável"
              ],
              "callout": "O profissional não cria uma técnica nova na sala; ele aplica o plano validado e escala conflitos para a equipe habilitada."
            }
          ]
        },
        {
          "id": "geral-dispositivos-handoff",
          "title": "Drenos, ostomias e handoff abdominal",
          "duration": 18,
          "summary": "Construa uma transferência que preserve localização, função e pendências dos dispositivos.",
          "objectives": [
            "Mapear dispositivos antes do curativo",
            "Verificar identificação e fixação",
            "Comunicar plano e sinais de alerta prescritos"
          ],
          "sections": [
            {
              "title": "Mapa antes de perder visibilidade",
              "body": "Drenos, cateteres, sondas e ostomias devem ser reconciliados antes que campos e curativos ocultem pontos importantes. O mapa registra local, tipo, conexão e condição observada.",
              "bullets": [
                "Contar dispositivos",
                "Diferenciar lados e sítios",
                "Confirmar conexões e coletores"
              ]
            },
            {
              "title": "Do campo para a transferência",
              "body": "A equipe compara o mapa com o registro e com o paciente. O handoff inclui dispositivos presentes, perdas relevantes, espécimes, implantes, intercorrências e pendências.",
              "bullets": [
                "Evitar “está tudo no prontuário”",
                "Mostrar e verbalizar quando seguro",
                "Confirmar quem recebe a informação"
              ]
            },
            {
              "title": "Pendência tem dono",
              "body": "Resultado aguardado, plano de retirada ou necessidade de avaliação devem chegar com responsável definido. Informação sem destinatário não fecha o circuito.",
              "bullets": [
                "Usar leitura de retorno",
                "Registrar discrepâncias",
                "Escalar dispositivo sem identificação"
              ],
              "callout": "Manejo clínico de drenos e ostomias segue prescrição e protocolo; a aula trata de rastreabilidade e comunicação."
            }
          ]
        }
      ]
    },
    {
      "id": "ortopedia-trauma",
      "number": "20",
      "title": "Ortopedia e trauma",
      "short": "Prepare implantes, imagem, posicionamento e rastreabilidade com barreiras redundantes.",
      "description": "Cobertura introdutória de artroplastias, osteossíntese e trauma, concentrada em lateralidade, implantes, radioscopia, torniquete, espécimes e prevenção de infecção.",
      "icon": "position",
      "color": "blue",
      "level": "Especialidade",
      "sourceIds": [
        "aaos-trauma-ssi-2022",
        "aaos-guidelines-current",
        "fda-patient-guides-2026",
        "anvisa-iras-criteria-2026"
      ],
      "lessons": [
        {
          "id": "ortopedia-implantes-imagem",
          "title": "Implantes, lateralidade e imagem",
          "duration": 17,
          "summary": "Monte um sistema de conferência que ligue paciente, lado, imagem, instrumental e implante.",
          "objectives": [
            "Reconhecer pontos críticos da lateralidade",
            "Descrever rastreabilidade de implantes",
            "Organizar radioscopia e proteção ocupacional"
          ],
          "sections": [
            {
              "title": "Uma cadeia de confirmação",
              "body": "A lateralidade aparece no agendamento, consentimento, marcação, imagem, posicionamento, pausa e documentação. Divergência em qualquer elo exige interrupção e reconciliação antes de uma etapa irreversível.",
              "bullets": [
                "Imagens corretas e disponíveis",
                "Membro e nível expostos conforme plano",
                "Equipe concorda verbalmente antes da incisão"
              ]
            },
            {
              "title": "Implante é sistema",
              "body": "Implantes, guias e instrumentais formam um conjunto com tamanhos, lotes e compatibilidades. A conferência inclui disponibilidade das alternativas, embalagem, validade, esterilidade e plano para componente aberto e não utilizado.",
              "bullets": [
                "Registrar lote e identificação",
                "Separar componente de teste do definitivo",
                "Não improvisar compatibilidade entre fabricantes"
              ]
            },
            {
              "title": "Radioscopia sem improviso",
              "body": "A posição do arco, monitores, pedais e proteção radiológica deve ser testada antes da antissepsia. O arranjo precisa preservar acesso ao paciente e reduzir cruzamentos sobre o campo.",
              "callout": "Princípios ALARA e regras de dosimetria dependem do programa de proteção radiológica do serviço e da NR-32."
            }
          ]
        },
        {
          "id": "ortopedia-trauma-seguranca",
          "title": "Trauma, torniquete e prevenção de infecção",
          "duration": 16,
          "summary": "Antecipe mudanças rápidas sem perder tempo, rastreabilidade ou integridade do campo.",
          "objectives": [
            "Preparar cenários de trauma com plano escalonado",
            "Reconhecer barreiras relacionadas ao torniquete",
            "Diferenciar amostra clínica, implante removido e espécime"
          ],
          "sections": [
            {
              "title": "Plano escalonado",
              "body": "Trauma combina incerteza anatômica, contaminação variável, sangramento e necessidade de implantes. A sala deve distinguir o essencial imediato das alternativas que serão abertas apenas após confirmação.",
              "bullets": [
                "Disponibilidade sem abertura desnecessária",
                "Comunicação de mudança de estratégia",
                "Contagem compatível com múltiplas equipes e campos"
              ]
            },
            {
              "title": "Torniquete como ponto de controle",
              "body": "Seleção, posicionamento, proteção da pele, pressão e tempo pertencem ao protocolo e à responsabilidade da equipe habilitada. O papel perioperatório inclui verificar documentação, visibilidade dos alarmes e comunicação dos marcos de tempo.",
              "callout": "Nunca defina pressão ou duração por regra memorizada. Use prescrição, características do paciente, equipamento e instrução de uso."
            },
            {
              "title": "Culturas, tecidos e componentes removidos",
              "body": "Materiais enviados para microbiologia, anatomia patológica ou análise do fabricante têm destinos diferentes. Antes do envio, confirmar tipo de exame, recipiente, identificação, lateralidade e cadeia de custódia quando aplicável.",
              "bullets": [
                "Não colocar fixador ou implante em conservante sem confirmação",
                "Distinguir cultura de tecido de espécime histológico",
                "Registrar destino e responsável pelo transporte"
              ]
            }
          ]
        },
        {
          "id": "ortopedia-torniquete-interface",
          "title": "Torniquete: interface, tempo e resposta a alertas",
          "duration": 18,
          "summary": "Acompanhe o sistema de torniquete com foco em comunicação, documentação e limites profissionais.",
          "objectives": [
            "Verificar interface e equipamento",
            "Registrar marcos verbalizados",
            "Responder a alerta sem alterar parâmetros autonomamente"
          ],
          "sections": [
            {
              "title": "Preparação da interface",
              "body": "Tamanho, local, proteção, conexões e integridade do manguito são conferidos conforme o dispositivo e o plano da equipe. A posição deve permanecer observável ou documentada antes de ser coberta.",
              "bullets": [
                "Confirmar membro e lateralidade",
                "Evitar cabos e tubos comprimidos",
                "Registrar identificação quando aplicável"
              ]
            },
            {
              "title": "Marcos e comunicação",
              "body": "Insuflação, mudanças autorizadas e desinsuflação são verbalizadas e registradas no momento. A equipe usa uma referência de tempo comum e não depende de memória no encerramento.",
              "bullets": [
                "Leitura de retorno",
                "Aviso nos intervalos previstos",
                "Correlação com etapas do procedimento"
              ]
            },
            {
              "title": "Alerta não é convite à improvisação",
              "body": "Diante de vazamento, alarme ou discrepância, comunique imediatamente e siga a instrução de uso e o protocolo. Parâmetros são definidos por profissional habilitado.",
              "bullets": [
                "Não silenciar repetidamente",
                "Verificar conexões acessíveis",
                "Preparar alternativa autorizada"
              ],
              "callout": "A aula não define pressão nem duração. Esses parâmetros dependem do paciente, do dispositivo, do procedimento e da decisão clínica."
            }
          ]
        },
        {
          "id": "ortopedia-componentes-cimento",
          "title": "Componentes, prova e cimento: comunicação de marcos",
          "duration": 20,
          "summary": "Reduza trocas entre componentes e antecipe etapas que exigem coordenação multiprofissional.",
          "objectives": [
            "Separar prova de implante definitivo",
            "Reconciliar componentes compatíveis",
            "Comunicar marcos do cimento conforme protocolo"
          ],
          "sections": [
            {
              "title": "Prova não é implante",
              "body": "Componentes de prova e definitivos podem ser visualmente semelhantes. Eles permanecem segregados, identificados e verbalizados durante a passagem, com conferência antes da abertura ou implantação.",
              "bullets": [
                "Usar área dedicada",
                "Confirmar fabricante, sistema e tamanho",
                "Evitar embalagens abertas sem decisão"
              ]
            },
            {
              "title": "Compatibilidade como cadeia",
              "body": "Compatibilidade não é inferida por encaixe aparente. Modelo, tamanho, lado, lote e documentação do sistema são reconciliados com a decisão da equipe e a instrução do fabricante.",
              "bullets": [
                "Conferência em dupla quando prevista",
                "Preservar etiquetas",
                "Registrar componentes implantados e explantados"
              ]
            },
            {
              "title": "Marcos do cimento",
              "body": "Quando há cimento ósseo, preparo, entrega e fase de uso exigem comunicação com cirurgia e anestesia conforme protocolo. Ventilação ambiental, temporização e sinais clínicos pertencem a um plano coordenado.",
              "bullets": [
                "Anunciar início do preparo",
                "Manter material e equipe prontos",
                "Não fornecer parâmetros clínicos fora do protocolo"
              ],
              "callout": "A seleção do implante e a técnica de cimentação são decisões dos profissionais habilitados; o foco aqui é processo seguro e rastreável."
            }
          ]
        }
      ]
    },
    {
      "id": "ginecologia-obstetricia",
      "number": "21",
      "title": "Ginecologia e obstetrícia",
      "short": "Integre anatomia pélvica, prevenção de infecção e segurança materno-neonatal.",
      "description": "Introdução a procedimentos ginecológicos e cesariana, com foco em posicionamento, vias de acesso, espécimes, hemorragia e coordenação entre equipes.",
      "icon": "anatomy",
      "color": "rose",
      "level": "Especialidade",
      "sourceIds": [
        "eras-gyn-2026",
        "eras-cesarean-2025",
        "anvisa-iras-criteria-2026",
        "aorn-2026"
      ],
      "lessons": [
        {
          "id": "ginecologia-pelve-vias",
          "title": "Pelve e vias de acesso",
          "duration": 17,
          "summary": "Relacione anatomia, via abdominal, vaginal ou minimamente invasiva e riscos de posicionamento.",
          "objectives": [
            "Reconhecer estruturas pélvicas relevantes",
            "Comparar demandas das principais vias de acesso",
            "Preparar espécimes ginecológicos com orientação clara"
          ],
          "sections": [
            {
              "title": "Anatomia relacional",
              "body": "Útero, anexos, bexiga, ureteres, reto e vasos pélvicos ocupam um espaço compacto. A equipe precisa compreender quais estruturas estão em risco e quais equipamentos podem ser solicitados, sem executar atos fora de sua habilitação.",
              "bullets": [
                "Relação ureter–vasos uterinos",
                "Proximidade entre bexiga e colo uterino",
                "Acesso vaginal e abdominal podem coexistir"
              ]
            },
            {
              "title": "Posição e acesso simultâneo",
              "body": "Litotomia, inclinação e braços junto ao corpo podem ampliar exposição e também criar riscos neurológicos, respiratórios e de pressão. A checagem deve ocorrer antes dos campos e ser repetida após movimentar a mesa.",
              "bullets": [
                "Pernas movimentadas de forma coordenada",
                "Dispositivos sem compressão indevida",
                "Tubos, cabos e acessos permanecem livres"
              ]
            },
            {
              "title": "Espécimes e orientação",
              "body": "Útero, anexos, linfonodos e margens podem demandar identificação específica. Fragmentação, retirada por vias diferentes ou exames intraoperatórios exigem briefing prévio e comunicação direta.",
              "callout": "A rotulagem deve usar a nomenclatura acordada com cirurgião e patologia; nunca inferir lado ou origem pelo aspecto."
            }
          ]
        },
        {
          "id": "obstetricia-duas-equipes",
          "title": "Cesárea: duas equipes, um plano",
          "duration": 17,
          "summary": "Organize a segurança materna e neonatal sem apagar as diferenças entre cirurgia eletiva e urgência.",
          "objectives": [
            "Descrever a pausa adaptada à cesárea",
            "Reconhecer prontidão para hemorragia e cuidado neonatal",
            "Realizar transições com identificação inequívoca"
          ],
          "sections": [
            {
              "title": "Pausa adaptada, não omitida",
              "body": "Urgência modifica a forma e o momento da lista de verificação, mas não elimina identificação, procedimento, alergias, risco hemorrágico e plano neonatal. Itens críticos podem ser confirmados em blocos curtos e retomados quando a situação estabiliza.",
              "bullets": [
                "Identidade materna e indicação",
                "Prontidão anestésica e cirúrgica",
                "Equipe neonatal e equipamentos confirmados"
              ]
            },
            {
              "title": "Hemorragia: reconhecer e convocar",
              "body": "A preparação inclui acesso a protocolo institucional, comunicação de perdas, disponibilidade de recursos e definição de liderança. O conteúdo educacional limita-se a prontidão, funções e escalonamento.",
              "callout": "Medicamentos, fluidos, transfusão e técnica são decisões da equipe habilitada conforme protocolo de hemorragia obstétrica."
            },
            {
              "title": "Nascimento e rastreabilidade",
              "body": "Após o nascimento, identificação, horário, destino de placenta e amostras, contagens e comunicação entre as equipes precisam ser inequívocos. A pressa não justifica rótulo antecipado nem transporte sem conferência.",
              "bullets": [
                "Pulseiras e identificação conforme protocolo",
                "Placenta: descarte ou exame definidos",
                "Contagem final antes do encerramento"
              ]
            }
          ]
        },
        {
          "id": "ginecologia-fluidos-especimes",
          "title": "Fluidos e espécimes em procedimentos ginecológicos",
          "duration": 19,
          "summary": "Organize balanço, recipientes e mapa anatômico para evitar perda de informação.",
          "objectives": [
            "Distinguir volumes fornecidos e recuperados",
            "Mapear múltiplas amostras",
            "Escalar discrepâncias precocemente"
          ],
          "sections": [
            {
              "title": "Balanço requer método comum",
              "body": "Em procedimentos com irrigação ou distensão, entradas e saídas precisam de fonte de dados definida. Troca de bolsas, perdas no campo e conteúdo de coletores são comunicados para evitar um número aparentemente preciso, mas incompleto.",
              "bullets": [
                "Definir quem registra",
                "Usar unidade consistente",
                "Verbalizar trocas e perdas não mensuradas"
              ]
            },
            {
              "title": "Múltiplos sítios, múltiplos riscos",
              "body": "Margens, anexos, lesões ou amostras endometriais podem exigir recipientes distintos. Um mapa acordado liga local anatômico, lado, exame e sequência de coleta.",
              "bullets": [
                "Rotular um recipiente por vez",
                "Fazer leitura de retorno",
                "Não reutilizar abreviação ambígua"
              ]
            },
            {
              "title": "Discrepância antes do envio",
              "body": "Se o volume calculado não fecha ou a orientação da amostra não está clara, a equipe interrompe o envio e reconcilia com o profissional responsável.",
              "bullets": [
                "Preservar amostra",
                "Corrigir mantendo histórico",
                "Comunicar impacto clínico"
              ],
              "callout": "Limites de fluidos e decisões clínicas são definidos pela equipe habilitada e pelo equipamento; esta aula não fornece valores terapêuticos."
            }
          ]
        },
        {
          "id": "obstetricia-hemorragia-fluxo",
          "title": "Hemorragia obstétrica: fluxo e coordenação da sala",
          "duration": 18,
          "summary": "Reconheça como a equipe perioperatória apoia um protocolo de resposta sem prescrever tratamento.",
          "objectives": [
            "Tornar a deterioração visível",
            "Organizar recursos e funções",
            "Preservar identificação e documentação"
          ],
          "sections": [
            {
              "title": "Ativação explícita",
              "body": "Sangramento crescente, instabilidade comunicada ou mudança rápida do plano exigem linguagem direta. A equipe chama ajuda e ativa o protocolo institucional conforme liderança definida.",
              "bullets": [
                "Declarar a preocupação",
                "Confirmar quem lidera",
                "Reduzir circulação e tarefas não essenciais"
              ]
            },
            {
              "title": "Recursos e rastreabilidade",
              "body": "Materiais, medicamentos e hemocomponentes seguem fluxos autorizados, com identificação, comunicação em alça fechada e registro de marcos. A pressa não elimina conferências críticas.",
              "bullets": [
                "Preservar identidade materna",
                "Registrar entregas e devoluções",
                "Comunicar perdas pela métrica definida"
              ]
            },
            {
              "title": "Duas trajetórias assistenciais",
              "body": "Quando há nascimento, a coordenação materna e neonatal precisa manter equipes, equipamentos e registros conectados sem confundir pacientes ou responsabilidades.",
              "bullets": [
                "Handoff neonatal explícito",
                "Identificadores inequívocos",
                "Destino e equipe receptora confirmados"
              ],
              "callout": "Tratamento, transfusão e medicamentos são decisões clínicas e seguem protocolo. O papel educacional é compreender o sistema de resposta."
            }
          ]
        }
      ]
    },
    {
      "id": "urologia",
      "number": "22",
      "title": "Urologia",
      "short": "Entenda endoscopia, irrigação, laser, litotomia e rastreabilidade de dispositivos.",
      "description": "Visão perioperatória de endourologia e cirurgia urológica, com ênfase em cultura, pressão de irrigação, radiação, stents, cateteres e posicionamento.",
      "icon": "layers",
      "color": "violet",
      "level": "Especialidade",
      "sourceIds": [
        "aua-stones-2026",
        "eau-urolithiasis-current",
        "eau-urological-infections-current",
        "nr32"
      ],
      "lessons": [
        {
          "id": "urologia-endourologia",
          "title": "Endourologia, irrigação e energia",
          "duration": 17,
          "summary": "Prepare o circuito endoscópico e reconheça riscos de infecção, pressão, laser e radiação.",
          "objectives": [
            "Mapear componentes do sistema endourológico",
            "Reconhecer sinais de perda de fluxo ou visibilidade",
            "Integrar cultura e prevenção de infecção ao fluxo"
          ],
          "sections": [
            {
              "title": "Do monitor ao campo",
              "body": "Torre, fonte de luz, câmera, irrigação, acessórios e energia precisam ser compatíveis e testados antes do uso. Conexões são organizadas para permitir movimento sem contaminar o campo ou tracionar o endoscópio.",
              "bullets": [
                "Balanço entre entrada e saída",
                "Imagem orientada e foco funcional",
                "Plano para falha de equipamento"
              ]
            },
            {
              "title": "Pressão, temperatura e visibilidade",
              "body": "Irrigação inadequada pode prejudicar visão; excesso de pressão ou falha de drenagem cria risco. A equipe observa fluxo, distensão dos sistemas e alertas, comunicando mudança de padrão imediatamente.",
              "callout": "Parâmetros de laser, pressão e volume são definidos pela equipe habilitada e pelas instruções de uso; não há configuração universal."
            },
            {
              "title": "Infecção e amostras",
              "body": "Diretrizes atuais enfatizam avaliação de urina e manejo de infecção antes da intervenção. Amostras de urina, cálculo ou pelve renal devem seguir solicitação, recipiente e fluxo laboratorial corretos.",
              "bullets": [
                "Não confundir cálculo para análise com cultura",
                "Confirmar antibiótico pelo protocolo, sem prescrever",
                "Escalonar sinais sistêmicos no pós-operatório"
              ]
            }
          ]
        },
        {
          "id": "urologia-posicao-dispositivos",
          "title": "Litotomia, stents e cateteres",
          "duration": 16,
          "summary": "Conecte posição, via de acesso e documentação de dispositivos temporários ou permanentes.",
          "objectives": [
            "Aplicar checagem coordenada da litotomia",
            "Distinguir dispositivos e destinos",
            "Registrar itens que exigem retirada ou seguimento"
          ],
          "sections": [
            {
              "title": "Posição compartilhada",
              "body": "Acesso perineal, abdominal e radiológico pode ocorrer no mesmo procedimento. Pernas, braços, arco e monitores são planejados como um único sistema e reavaliados após mudanças de posição.",
              "bullets": [
                "Mover pernas simultaneamente",
                "Evitar pressão em cabeça da fíbula e panturrilha",
                "Preservar acesso anestésico e possibilidade de conversão"
              ]
            },
            {
              "title": "Dispositivo com plano de saída",
              "body": "Stent ureteral, cateter e dreno não devem aparecer apenas como itens implantados. O registro precisa incluir tipo, lado, identificação disponível e plano de manejo comunicado no handoff.",
              "bullets": [
                "Lado e localização",
                "Presença de fio externo quando aplicável",
                "Responsável e prazo definidos pelo serviço"
              ]
            },
            {
              "title": "Fragmentos e contagem",
              "body": "Fragmentos de cálculo, fios-guia, bainhas e componentes descartáveis precisam de controle visual. Quebra ou ausência de parte do dispositivo exige pausa, reconciliação e protocolo de item retido.",
              "callout": "Nunca assumir que um fragmento é clinicamente irrelevante. Comunicar e seguir o fluxo institucional de avaliação."
            }
          ]
        },
        {
          "id": "urologia-irrigacao-balanco",
          "title": "Irrigação: circuito, balanço e perda de retorno",
          "duration": 18,
          "summary": "Avalie o sistema como circuito e evite compensar problemas apenas aumentando fluxo ou pressão.",
          "objectives": [
            "Mapear entrada e retorno",
            "Identificar perda de continuidade",
            "Comunicar dados úteis à equipe"
          ],
          "sections": [
            {
              "title": "Circuito completo",
              "body": "Fonte, equipo, conexão, instrumento, cavidade, via de retorno e coletor formam um único sistema. Observar apenas a bolsa de entrada pode ocultar obstrução, desconexão ou extravasamento.",
              "bullets": [
                "Confirmar compatibilidade",
                "Manter conexões visíveis quando possível",
                "Registrar volumes pelo método local"
              ]
            },
            {
              "title": "Quando o retorno muda",
              "body": "Visibilidade pior, retorno reduzido ou distensão observada exigem pausa e avaliação coordenada. A equipe comunica o que mudou e verifica causas acessíveis sem manipulação não autorizada.",
              "bullets": [
                "Comparar entrada e saída",
                "Inspecionar dobras e conexões",
                "Não aumentar parâmetros por tentativa"
              ]
            },
            {
              "title": "Balanço com incerteza",
              "body": "Se parte do fluido não pode ser medida, a incerteza deve ser verbalizada, não escondida em um cálculo. Horário, volumes conhecidos e eventos ajudam a decisão clínica.",
              "bullets": [
                "Usar unidade comum",
                "Anotar troca de bolsas",
                "Escalar discrepância crescente"
              ],
              "callout": "Pressão, fluxo e limites dependem do equipamento, do procedimento e da equipe habilitada. Consulte a instrução de uso e o protocolo."
            }
          ]
        },
        {
          "id": "urologia-stents-cadeia-saida",
          "title": "Stents, cateteres e cadeia de saída",
          "duration": 18,
          "summary": "Evite que dispositivos temporários percam vínculo com lado, data e plano de seguimento.",
          "objectives": [
            "Registrar presença e lateralidade",
            "Reconciliar dispositivos no encerramento",
            "Construir handoff com plano de saída"
          ],
          "sections": [
            {
              "title": "Identificação no momento certo",
              "body": "A presença do dispositivo é confirmada quando ainda há equipe e informação disponíveis. Tipo, lado, características rastreáveis e circunstâncias relevantes seguem o sistema institucional.",
              "bullets": [
                "Evitar registro retrospectivo",
                "Associar ao paciente e ao lado correto",
                "Preservar etiqueta quando aplicável"
              ]
            },
            {
              "title": "Reconciliação no encerramento",
              "body": "Antes da saída, a equipe diferencia o que foi removido, substituído ou deixado. Fios-guia, fragmentos e componentes entram na contagem ou na verificação de integridade prevista.",
              "bullets": [
                "Confirmar integridade",
                "Escalar ponta incompleta",
                "Registrar exceções"
              ]
            },
            {
              "title": "Plano que chega ao destino",
              "body": "O handoff precisa dizer que o dispositivo existe e qual acompanhamento foi definido. “Tem um stent” é incompleto sem lado, plano e responsável pela continuidade.",
              "bullets": [
                "Leitura de retorno",
                "Destino confirmado",
                "Pendência com responsável"
              ],
              "callout": "Retirada e seguimento são definidos pelo profissional responsável; a plataforma ensina comunicação e rastreabilidade, não conduta individual."
            }
          ]
        }
      ]
    },
    {
      "id": "cirurgia-vascular",
      "number": "23",
      "title": "Cirurgia vascular",
      "short": "Prepare controle proximal, implantes, imagem e transições entre técnica aberta e endovascular.",
      "description": "Introdução à sala vascular e híbrida, com foco em clampeamento, heparinização como comunicação, próteses, contraste, radiação e prevenção de infecção de enxertos.",
      "icon": "workflow",
      "color": "blue",
      "level": "Especialidade",
      "sourceIds": [
        "esvs-vgei-2026",
        "esvs-trauma-2025",
        "esvs-pad-2024",
        "acc-periop-2026"
      ],
      "lessons": [
        {
          "id": "vascular-aberta-endovascular",
          "title": "Sala aberta, endovascular e híbrida",
          "duration": 18,
          "summary": "Antecipe conversão, imagem e controle vascular sem bloquear acesso ao paciente.",
          "objectives": [
            "Comparar demandas de técnica aberta e endovascular",
            "Planejar zonas estéreis e radiológicas",
            "Reconhecer marcos de comunicação vascular"
          ],
          "sections": [
            {
              "title": "Dois ambientes no mesmo procedimento",
              "body": "A sala híbrida reúne mesa radiotransparente, imagem, contraste, implantes e possibilidade de acesso aberto. A disposição deve manter via de circulação, visualização de monitores e acesso rápido para conversão.",
              "bullets": [
                "Equipamentos testados antes da antissepsia",
                "Instrumental vascular aberto disponível",
                "Proteção radiológica sem romper esterilidade"
              ]
            },
            {
              "title": "Marcos que precisam ser verbalizados",
              "body": "Clampeamento, desclampeamento, passagem de fio, liberação de dispositivo, administração de anticoagulante e reversão são marcos de equipe. A comunicação em alça fechada reduz o risco de ações fora de sequência.",
              "callout": "Dose e momento de medicamentos pertencem à prescrição e ao protocolo. O papel educacional aqui é reconhecer, repetir e documentar a ordem."
            },
            {
              "title": "Contraste, radiação e inventário",
              "body": "A equipe confirma alergias, função renal conforme avaliação, disponibilidade de contraste e rastreabilidade dos dispositivos. Bainhas, fios e cateteres são controlados como sistema, incluindo componentes removíveis.",
              "bullets": [
                "Registrar lote e tamanho",
                "Confirmar compatibilidade antes de abrir",
                "Manter plano para falha ou dispositivo não implantado"
              ]
            }
          ]
        },
        {
          "id": "vascular-enxertos-seguranca",
          "title": "Enxertos, isquemia e prevenção de infecção",
          "duration": 17,
          "summary": "Organize barreiras para próteses vasculares e momentos de alto risco.",
          "objectives": [
            "Descrever manejo asséptico de enxertos",
            "Reconhecer implicações do tempo de isquemia",
            "Preparar espécimes e documentação vascular"
          ],
          "sections": [
            {
              "title": "Implante de alto impacto",
              "body": "Enxerto ou endoprótese exige rastreabilidade, compatibilidade e campo rigorosamente controlado. Embalagens são abertas apenas após confirmação; manipulação segue instruções do fabricante e técnica definida.",
              "bullets": [
                "Lote, modelo, tamanho e validade",
                "Soluções e preparo somente conforme instrução",
                "Destino de componente explantado registrado"
              ]
            },
            {
              "title": "Tempo de isquemia como dado de equipe",
              "body": "Momentos de interrupção e restauração do fluxo influenciam decisões. O relógio deve ser visível e os tempos registrados sem depender de estimativa retrospectiva.",
              "bullets": [
                "Anotar clampeamento e reperfusão",
                "Comunicar mudanças hemodinâmicas",
                "Antecipar coleta e envio de exames solicitados"
              ]
            },
            {
              "title": "Infecção de enxerto",
              "body": "A diretriz ESVS 2026 reforça abordagem multidisciplinar para infecção de prótese vascular. No intraoperatório, a contribuição inclui obtenção correta de amostras, separação de materiais e documentação do implante ou explante.",
              "callout": "A escolha de antimicrobianos e estratégia cirúrgica é médica e individualizada; esta aula aborda apenas processo e segurança."
            }
          ]
        },
        {
          "id": "vascular-sala-hibrida",
          "title": "Sala híbrida: imagem, circulação e prontidão para conversão",
          "duration": 20,
          "summary": "Coordene tecnologia e acesso aberto no mesmo ambiente sem bloquear resposta ao paciente.",
          "objectives": [
            "Planejar zonas de equipamento",
            "Integrar proteção radiológica",
            "Preservar rota de conversão"
          ],
          "sections": [
            {
              "title": "Ambiente dinâmico",
              "body": "Arco, mesa, monitores, injetores e materiais criam zonas que mudam durante o procedimento. O briefing define movimentos, circulação, campos e acesso à anestesia.",
              "bullets": [
                "Testar alcance antes dos campos",
                "Proteger cabos e rotas",
                "Confirmar comunicação durante aquisição de imagem"
              ]
            },
            {
              "title": "Imagem com responsabilidade compartilhada",
              "body": "Proteção, distância, tempo de exposição e monitorização ocupacional seguem o programa local. A equipe anuncia aquisições e evita permanência desnecessária em área de maior exposição.",
              "bullets": [
                "Usar proteção definida",
                "Posicionar monitores sem comprometer ergonomia",
                "Registrar conforme política"
              ]
            },
            {
              "title": "Conversão possível desde o início",
              "body": "Instrumental, equipe, acesso e circulação para abordagem aberta precisam estar previstos antes da emergência. A disponibilidade é organizada sem abrir itens prematuramente.",
              "bullets": [
                "Definir comando de conversão",
                "Liberar acesso ao paciente",
                "Confirmar recursos críticos"
              ],
              "callout": "Parâmetros de radiação, contraste e técnica são definidos por profissionais habilitados e protocolos específicos."
            }
          ]
        },
        {
          "id": "vascular-clampeamento-explantes",
          "title": "Clampeamento, reperfusão e explantes vasculares",
          "duration": 18,
          "summary": "Registre marcos vasculares e preserve o destino de enxertos ou dispositivos removidos.",
          "objectives": [
            "Tratar tempos como marcos de equipe",
            "Separar destinos de explantes",
            "Preservar cadeia de custódia"
          ],
          "sections": [
            {
              "title": "Marcos em tempo real",
              "body": "Clampeamento, reperfusão e administração associada ao plano são verbalizados e registrados no momento. Isso permite que cirurgia, anestesia e enfermagem compartilhem a mesma linha do tempo.",
              "bullets": [
                "Horário comum",
                "Leitura de retorno",
                "Correção documentada quando necessária"
              ]
            },
            {
              "title": "Um explante, possíveis destinos",
              "body": "Microbiologia, anatomia patológica e análise do fabricante podem exigir porções, recipientes e documentos diferentes. A equipe confirma solicitações antes de colocar o material em conservante ou descartá-lo.",
              "bullets": [
                "Separar recipientes",
                "Identificar local e dispositivo",
                "Evitar formalina quando incompatível com exame solicitado"
              ]
            },
            {
              "title": "Suspeita de infecção",
              "body": "Quando há suspeita, barreiras, amostras e documentação seguem o plano institucional. A equipe reduz contaminação cruzada e mantém rastreabilidade do enxerto e dos materiais.",
              "bullets": [
                "Verbalizar mudança de risco",
                "Confirmar coleta antes de antimicrobiano quando prescrito",
                "Registrar lote e local"
              ],
              "callout": "Diagnóstico e tratamento de infecção vascular pertencem à equipe assistencial. O conteúdo aborda processo de sala e envio seguro."
            }
          ]
        }
      ]
    },
    {
      "id": "neurocirurgia-coluna",
      "number": "24",
      "title": "Neurocirurgia e coluna",
      "short": "Proteja tecido neural, posicionamento, implantes e fluxo microscópico.",
      "description": "Introdução ao ambiente neurocirúrgico e de coluna, contemplando microscopia, neuronavegação, neuromonitorização, posicionamento, implantes e espécimes.",
      "icon": "brain",
      "color": "violet",
      "level": "Especialidade",
      "sourceIds": [
        "cns-spine-risk",
        "cns-pituitary-2025",
        "acc-periop-2026",
        "anvisa-isc-2025"
      ],
      "lessons": [
        {
          "id": "neuro-cranio-micro",
          "title": "Crânio, microscopia e navegação",
          "duration": 18,
          "summary": "Organize tecnologia, espécimes e transições mantendo acesso à via aérea e ao campo.",
          "objectives": [
            "Reconhecer zonas funcionais da sala neurocirúrgica",
            "Preparar microscópio e navegação",
            "Diferenciar espécimes e materiais de reconstrução"
          ],
          "sections": [
            {
              "title": "Sala orientada por linha de visão",
              "body": "Microscópio, navegação, aspirador ultrassônico, monitores e anestesia competem por espaço. O planejamento considera trajetória do equipamento, referência do paciente e acesso para emergência antes da fixação definitiva.",
              "bullets": [
                "Cabos protegidos de tração e roda",
                "Imagem e lateralidade confirmadas",
                "Plano de falha tecnológica disponível"
              ]
            },
            {
              "title": "Tecnologia não substitui conferência",
              "body": "Registro de navegação e microscopia depende de referência correta e pode perder precisão. Mudança de posição, deslocamento de fixação ou inconsistência anatômica devem ser comunicados e reconciliados.",
              "callout": "O sistema auxilia; a decisão anatômica permanece com o cirurgião habilitado."
            },
            {
              "title": "Espécimes e hemostáticos",
              "body": "Tumor, tecido para cultura, material para congelação e implante explantado têm requisitos diferentes. Agentes hemostáticos e materiais de reconstrução também precisam de controle para evitar confusão com espécime ou item retido.",
              "bullets": [
                "Recipiente e exame confirmados",
                "Local anatômico específico no rótulo",
                "Comunicação direta com patologia quando necessário"
              ]
            }
          ]
        },
        {
          "id": "coluna-posicao-implantes",
          "title": "Coluna: posição, nível e implantes",
          "duration": 17,
          "summary": "Conecte nível vertebral, posicionamento, imagem, neuromonitorização e rastreabilidade.",
          "objectives": [
            "Aplicar barreiras para nível correto",
            "Reconhecer riscos de prona e tração",
            "Preparar implantes e neuromonitorização"
          ],
          "sections": [
            {
              "title": "Nível é uma verificação própria",
              "body": "Marcação cutânea não substitui confirmação intraoperatória do nível. A equipe integra documentação, imagem, orientação e pausa específica antes de intervenção irreversível.",
              "bullets": [
                "Imagem correta e identificada",
                "Contagem vertebral verbalizada",
                "Divergência interrompe a progressão"
              ]
            },
            {
              "title": "Prona e integridade fisiológica",
              "body": "A posição prona exige proteção ocular, facial, torácica e de pontos de pressão, além de liberdade abdominal quando prevista e acesso a dispositivos. Após qualquer movimentação, o checklist é repetido.",
              "callout": "A posição é responsabilidade compartilhada; alterações devem ser autorizadas e comunicadas à anestesia e cirurgia."
            },
            {
              "title": "Implantes e sinais",
              "body": "Parafusos, hastes, cages e enxertos exigem compatibilidade e rastreabilidade. Neuromonitorização requer linha de base, comunicação de eventos e controle de fatores técnicos antes de atribuir uma alteração ao paciente.",
              "bullets": [
                "Registrar lotes e níveis",
                "Distinguir implante de teste e definitivo",
                "Documentar mudanças e ações da equipe"
              ]
            }
          ]
        },
        {
          "id": "neuro-navegacao-monitorizacao",
          "title": "Navegação e neuromonitorização: discrepâncias e escalonamento",
          "duration": 19,
          "summary": "Use tecnologia como apoio verificável, não como substituta da anatomia e da comunicação.",
          "objectives": [
            "Reconhecer perda de referência",
            "Responder a alteração de sinal",
            "Separar causa técnica, posicional e fisiológica"
          ],
          "sections": [
            {
              "title": "Registro pode mudar",
              "body": "Movimento da cabeça, deslocamento de referência ou alteração do campo podem reduzir precisão. Se a navegação diverge de marcos anatômicos ou imagem, a progressão é interrompida até nova verificação.",
              "bullets": [
                "Confirmar fixação e referência",
                "Revisar etapa em que ocorreu a mudança",
                "Não “corrigir mentalmente” o desvio"
              ]
            },
            {
              "title": "Sinal alterado é evento de equipe",
              "body": "Uma mudança na neuromonitorização é comunicada imediatamente. A avaliação coordenada considera conexões, equipamento, posição, anestesia e etapa cirúrgica sem presumir uma única causa.",
              "bullets": [
                "Marcar horário",
                "Interromper ações quando solicitado",
                "Relatar mudanças recentes"
              ]
            },
            {
              "title": "Retomada com critério",
              "body": "Após a intervenção, a equipe confirma que a referência ou o sinal atende ao critério definido pelos profissionais responsáveis. A sequência e as ações ficam registradas.",
              "bullets": [
                "Leitura de retorno",
                "Documentar causas confirmadas e não confirmadas",
                "Manter plano de contingência"
              ],
              "callout": "Interpretação de sinais e decisão operatória cabem aos profissionais habilitados. A equipe perioperatória apoia equipamento, posição e comunicação."
            }
          ]
        },
        {
          "id": "coluna-nivel-tecnologia",
          "title": "Nível correto e reconciliação de tecnologia em coluna",
          "duration": 20,
          "summary": "Construa barreiras redundantes antes de uma etapa irreversível.",
          "objectives": [
            "Distinguir identidade, lado e nível",
            "Correlacionar imagem e anatomia",
            "Interromper diante de divergência"
          ],
          "sections": [
            {
              "title": "Nível é uma confirmação própria",
              "body": "Paciente, procedimento e lado corretos não garantem nível vertebral correto. A equipe precisa de uma barreira específica, realizada no momento e com o método definido pelo serviço.",
              "bullets": [
                "Imagem disponível e identificada",
                "Referência anatômica visível",
                "Concordância verbal antes da intervenção"
              ]
            },
            {
              "title": "Divergência entre fontes",
              "body": "Se planejamento, imagem, navegação ou marcação não coincidem, não se escolhe silenciosamente uma fonte. A divergência é declarada e reconciliada com documentação e equipe apropriadas.",
              "bullets": [
                "Pausar a progressão",
                "Confirmar paciente e exame",
                "Registrar a resolução"
              ]
            },
            {
              "title": "Mudanças durante o caso",
              "body": "Reposicionamento, extensão da abordagem ou novo implante podem exigir nova confirmação. A barreira não é um evento único quando a decisão espacial mudou.",
              "bullets": [
                "Repetir no ponto de risco",
                "Atualizar contagem de componentes",
                "Comunicar nova meta"
              ],
              "callout": "A aula não ensina escolha de nível ou técnica de coluna; ensina como apoiar a verificação definida pela equipe habilitada."
            }
          ]
        }
      ]
    },
    {
      "id": "cabeca-pescoco",
      "number": "25",
      "title": "Cabeça e pescoço",
      "short": "Coordene via aérea compartilhada, espécimes complexos e reconstrução.",
      "description": "Visão perioperatória de oncologia de cabeça e pescoço, tireoide, traqueostomia e reconstrução microvascular, com ênfase em comunicação e rastreabilidade.",
      "icon": "anatomy",
      "color": "rose",
      "level": "Especialidade",
      "sourceIds": [
        "eras-head-neck-2017",
        "head-neck-review-2024",
        "asa-pain-2026",
        "anvisa-isc-2025"
      ],
      "lessons": [
        {
          "id": "cabeca-via-aerea-especimes",
          "title": "Via aérea compartilhada e espécimes",
          "duration": 17,
          "summary": "Prepare um campo em que anestesia e cirurgia dependem do mesmo espaço anatômico.",
          "objectives": [
            "Reconhecer conflitos da via aérea compartilhada",
            "Organizar espécimes orientados",
            "Antecipar fogo e energia em ambiente enriquecido por oxigênio"
          ],
          "sections": [
            {
              "title": "Um espaço, duas equipes",
              "body": "Tubo, circuito, campo e acesso cirúrgico podem se cruzar. A estratégia é combinada antes do início, incluindo como comunicar manipulação da via aérea, pausa ventilatória e necessidade de acesso emergencial.",
              "bullets": [
                "Fixação e posição do tubo confirmadas",
                "Conexões visíveis e protegidas",
                "Plano de resgate conhecido"
              ]
            },
            {
              "title": "Energia próxima à via aérea",
              "body": "Oxidante, fonte de ignição e combustível podem convergir. A avaliação do risco de incêndio deve ser explícita, com comunicação antes de usar energia e resposta institucional disponível.",
              "callout": "Concentração de oxigênio e técnica anestésica são decisões da equipe habilitada; nunca alterar fluxo sem comunicação direta."
            },
            {
              "title": "Mapa de espécimes",
              "body": "Margens, níveis cervicais, glândulas, linfonodos e peças compostas exigem nomenclatura consistente e orientação. Um mapa simples, construído com o cirurgião, reduz troca entre recipientes.",
              "bullets": [
                "Lado e nível por extenso",
                "Margem orientada conforme acordo",
                "Congelação diferenciada de peça definitiva"
              ]
            }
          ]
        },
        {
          "id": "cabeca-reconstrucao-handoff",
          "title": "Reconstrução, traqueostomia e handoff",
          "duration": 17,
          "summary": "Preserve informações críticas após procedimentos longos e multiequipe.",
          "objectives": [
            "Descrever transição para reconstrução",
            "Reconhecer prioridades do retalho e da via aérea",
            "Estruturar handoff para unidade especializada"
          ],
          "sections": [
            {
              "title": "Troca de equipe sem perda de contexto",
              "body": "Ressecção e reconstrução podem envolver times distintos, sítio doador e receptor, novos instrumentais e novas contagens. A transição deve incluir status de margens, perdas, implantes e pontos pendentes.",
              "bullets": [
                "Nova contagem quando o campo muda",
                "Instrumental microcirúrgico separado",
                "Identificação de vasos e sítio doador no handoff"
              ]
            },
            {
              "title": "Retalho e via aérea",
              "body": "Monitorização do retalho e cuidado da traqueostomia dependem de parâmetros definidos pelo serviço. O registro deve indicar método, local de avaliação, frequência prescrita e quem acionar diante de mudança.",
              "callout": "Não improvisar teste de perfusão nem manipular pedículo. Sinais de alteração exigem escalonamento imediato conforme protocolo."
            },
            {
              "title": "Recuperação como continuidade",
              "body": "Diretrizes de recuperação valorizam comunicação, analgesia multimodal, nutrição e mobilização, mas a complexidade da via aérea e da reconstrução exige individualização e unidade preparada.",
              "bullets": [
                "Destino e nível de cuidado confirmados",
                "Equipamentos acompanham o paciente",
                "Handoff presencial e em alça fechada"
              ]
            }
          ]
        },
        {
          "id": "cabeca-via-aerea-fogo",
          "title": "Via aérea compartilhada e prevenção de fogo",
          "duration": 18,
          "summary": "Integre energia, oxidante e comunicação em um campo onde anestesia e cirurgia dividem o mesmo espaço.",
          "objectives": [
            "Reconhecer elementos do risco de fogo",
            "Coordenar manipulação da via aérea",
            "Responder sem ações conflitantes"
          ],
          "sections": [
            {
              "title": "Risco construído pela combinação",
              "body": "Fonte de ignição, oxidante e combustível podem coexistir próximo à via aérea. O briefing identifica quando essa combinação é provável e como a equipe comunicará cada ativação crítica.",
              "bullets": [
                "Confirmar energia e materiais",
                "Verbalizar condição de oxidante conforme anestesia",
                "Evitar preparação que acumule solução inflamável"
              ]
            },
            {
              "title": "Um espaço, duas equipes",
              "body": "Movimentar tubo, campos ou instrumentos sem coordenação pode comprometer ventilação ou esterilidade. Solicitações são repetidas e confirmadas antes da ação.",
              "bullets": [
                "Acesso de resgate preservado",
                "Comando de pausa acordado",
                "Cabos e circuitos visíveis quando possível"
              ]
            },
            {
              "title": "Se houver suspeita de fogo",
              "body": "A equipe declara o evento e executa o protocolo institucional com funções previamente treinadas. A resposta específica depende da localização e das responsabilidades profissionais.",
              "bullets": [
                "Interromper fontes conforme função",
                "Chamar ajuda",
                "Preservar materiais para análise quando seguro"
              ],
              "callout": "Treinamento local e simulação são indispensáveis. Esta aula não substitui o protocolo de fogo cirúrgico nem define tratamento de lesões."
            }
          ]
        },
        {
          "id": "cabeca-retalho-monitorizacao",
          "title": "Retalho livre: transição e plano de monitorização",
          "duration": 20,
          "summary": "Preserve a cadeia de informação da reconstrução até a unidade receptora.",
          "objectives": [
            "Organizar transição entre equipes",
            "Identificar método e local de avaliação",
            "Comunicar sinais e escalonamento prescritos"
          ],
          "sections": [
            {
              "title": "Transição entre ressecção e reconstrução",
              "body": "Antes da mudança de equipe, contagens, espécimes, perdas, dispositivos e pendências são reconciliados. A reconstrução começa com uma linha de base compartilhada, não com suposições.",
              "bullets": [
                "Handoff formal",
                "Mapa de vasos e sítios conforme registro",
                "Materiais e implantes confirmados"
              ]
            },
            {
              "title": "Linha de base do retalho",
              "body": "Método, local e parâmetros prescritos de avaliação precisam ser definidos enquanto a equipe responsável está disponível. Marcação anatômica e linguagem comum reduzem avaliações no ponto errado.",
              "bullets": [
                "Local de monitorização identificado",
                "Frequência conforme prescrição",
                "Dispositivos e drenos mapeados"
              ]
            },
            {
              "title": "Escalonamento sem atraso",
              "body": "O handoff informa o que observar e quem acionar. Uma mudança não deve ser normalizada nem guardada para o próximo registro.",
              "bullets": [
                "Contato e rota de escalonamento",
                "Horário da última avaliação",
                "Eventos de transporte comunicados"
              ],
              "callout": "A interpretação da viabilidade e o tratamento são clínicos. O foco é transferência confiável e execução do plano prescrito."
            }
          ]
        }
      ]
    },
    {
      "id": "toracica-cardiaca",
      "number": "26",
      "title": "Cirurgia torácica e cardíaca",
      "short": "Integre ventilação, circulação extracorpórea, drenos e implantes de alto risco.",
      "description": "Introdução aos fluxos torácico e cardíaco, incluindo posição lateral, isolamento pulmonar, esternotomia, circulação extracorpórea e transições para terapia intensiva.",
      "icon": "target",
      "color": "blue",
      "level": "Especialidade",
      "sourceIds": [
        "eras-cardiac-2024",
        "eras-thoracic-2019",
        "asa-pain-2026",
        "acc-periop-2026"
      ],
      "lessons": [
        {
          "id": "toracica-pulmao-drenos",
          "title": "Pulmão, posição lateral e drenos",
          "duration": 18,
          "summary": "Organize a sala torácica em torno de ventilação, acesso lateral e sistema de drenagem.",
          "objectives": [
            "Reconhecer implicações do isolamento pulmonar",
            "Aplicar checagem da posição lateral",
            "Preparar drenos e espécimes pulmonares"
          ],
          "sections": [
            {
              "title": "Ventilação e cirurgia conectadas",
              "body": "Isolamento pulmonar e mudanças de ventilação alteram o campo e a fisiologia. Pedidos para insuflar, colabar ou realizar teste devem ser repetidos e confirmados entre cirurgia e anestesia.",
              "bullets": [
                "Lado operado confirmado",
                "Posição do dispositivo verificada pela equipe habilitada",
                "Mudanças hemodinâmicas comunicadas imediatamente"
              ]
            },
            {
              "title": "Lateral com acesso posterior e anterior",
              "body": "A proteção de plexo, orelha, olhos, joelhos e proeminências é combinada com fixação que permita inclinação da mesa. Circuitos e acessos devem tolerar movimento sem tração.",
              "callout": "Reavaliar alinhamento e dispositivos após toda flexão ou rotação da mesa."
            },
            {
              "title": "Dreno é um sistema",
              "body": "Dreno, conexão, selo e coletor precisam estar íntegros e identificados antes da transferência. O handoff inclui quantidade, localização, presença de sucção prescrita e eventos durante o transporte.",
              "bullets": [
                "Evitar pinçamento não autorizado",
                "Manter coletor abaixo do tórax conforme protocolo",
                "Espécimes por lobo ou segmento identificados"
              ]
            }
          ]
        },
        {
          "id": "cardiaca-cec-handoff",
          "title": "Cardíaca, CEC e transições críticas",
          "duration": 18,
          "summary": "Reconheça marcos da circulação extracorpórea e preserve rastreabilidade na transferência.",
          "objectives": [
            "Descrever funções da equipe na CEC",
            "Reconhecer implantes e contagens críticas",
            "Estruturar handoff para terapia intensiva"
          ],
          "sections": [
            {
              "title": "Marcos de uma equipe ampliada",
              "body": "Canulação, início e saída da circulação extracorpórea, clampeamento aórtico e reperfusão exigem comunicação padronizada entre cirurgia, anestesia, perfusão e enfermagem.",
              "bullets": [
                "Liderança e resposta verbal clara",
                "Tempos registrados no momento",
                "Mudança de plano compartilhada com todos"
              ]
            },
            {
              "title": "Implantes e materiais",
              "body": "Próteses valvares, enxertos, anéis, fios temporários e dispositivos de suporte têm alto impacto e rastreabilidade específica. Compatibilidade e lote são confirmados antes da abertura.",
              "callout": "Seleção do implante e manejo de anticoagulação pertencem à equipe habilitada e ao protocolo cardíaco."
            },
            {
              "title": "Da sala para a UTI",
              "body": "O handoff reúne estado hemodinâmico, via aérea, dispositivos, drenos, fios, contagens, perdas, produtos administrados, exames e eventos. A transferência só ocorre com monitorização e suporte definidos.",
              "bullets": [
                "Linhas identificadas",
                "Drenos e fios descritos",
                "Pendências e critérios de escalonamento verbalizados"
              ]
            }
          ]
        },
        {
          "id": "toracica-ventilacao-conversao",
          "title": "Ventilação, posição lateral e plano de conversão torácica",
          "duration": 19,
          "summary": "Coordene marcos entre cirurgia e anestesia quando acesso e ventilação mudam.",
          "objectives": [
            "Tratar insuflação e desinsuflação como marcos",
            "Reavaliar posição lateral",
            "Preservar prontidão para conversão"
          ],
          "sections": [
            {
              "title": "Marcos ventilatórios",
              "body": "Pedidos para isolar, reinsuflar ou testar o pulmão exigem comunicação em alça fechada. A equipe reduz ruído e confirma que cirurgia e anestesia compartilham o mesmo momento.",
              "bullets": [
                "Repetir o pedido",
                "Aguardar confirmação",
                "Registrar quando previsto"
              ]
            },
            {
              "title": "Lateral não permanece igual",
              "body": "Inclinação da mesa, pressão do afastador e duração podem alterar pontos de apoio, circuitos e fixação. A reavaliação inclui paciente, dispositivos e acesso de emergência.",
              "bullets": [
                "Olhos e face",
                "Membros e proeminências",
                "Tubos, drenos e cabos"
              ]
            },
            {
              "title": "Conversão organizada",
              "body": "A abordagem aberta deve ter espaço, instrumental e funções previstos. Em uma conversão, movimentos não essenciais param e o acesso ao paciente é liberado.",
              "bullets": [
                "Comando reconhecido",
                "Contagem preservada",
                "Equipamento reposicionado de forma coordenada"
              ],
              "callout": "Decisões ventilatórias e de conversão cabem aos profissionais habilitados; a equipe apoia comunicação e logística segura."
            }
          ]
        },
        {
          "id": "cardiaca-marcos-transferencia",
          "title": "Marcos cardíacos e transferência para terapia intensiva",
          "duration": 20,
          "summary": "Reconstrua a linha do tempo e entregue dispositivos, implantes e pendências sem lacunas.",
          "objectives": [
            "Registrar marcos multiprofissionais",
            "Reconciliar linhas, drenos e fios",
            "Realizar handoff presencial estruturado"
          ],
          "sections": [
            {
              "title": "Linha do tempo compartilhada",
              "body": "Entrada e saída de circulação extracorpórea, clampeamento, implantes e eventos relevantes são verbalizados e registrados com referência comum. A documentação deve refletir o momento, não apenas o resumo final.",
              "bullets": [
                "Cirurgia, anestesia, perfusão e enfermagem",
                "Leitura de retorno",
                "Correções rastreáveis"
              ]
            },
            {
              "title": "Mapa de dispositivos",
              "body": "Antes do transporte, linhas, drenos, fios e suportes são contados, identificados e protegidos. Conexões e equipamentos de transporte são verificados conforme protocolo.",
              "bullets": [
                "Origem e destino de cada linha",
                "Baterias e gases",
                "Fixação e acesso"
              ]
            },
            {
              "title": "Handoff sem multitarefa crítica",
              "body": "A transferência ocorre para uma equipe receptora pronta, com informação sobre via aérea, hemodinâmica, implantes, perdas, eventos e pendências. Perguntas e leitura de retorno fecham o ciclo.",
              "bullets": [
                "Paciente identificado",
                "Responsáveis presentes",
                "Documentos e amostras reconciliados"
              ],
              "callout": "O handoff comunica o plano clínico definido; não cria prescrição ou metas terapêuticas fora da responsabilidade profissional."
            }
          ]
        }
      ]
    },
    {
      "id": "cirurgia-pediatrica-neonatal",
      "number": "27",
      "title": "Cirurgia pediátrica e neonatal",
      "short": "Adapte cada barreira a peso, temperatura, desenvolvimento e participação familiar.",
      "description": "Fundamentos perioperatórios para crianças e neonatos, com foco em termorregulação, microvolumes, identificação, equipamentos dimensionados e comunicação com familiares.",
      "icon": "shield",
      "color": "orange",
      "level": "Especialidade",
      "sourceIds": [
        "eras-neonatal-2024",
        "neonatal-pain-2025",
        "apsa-eras",
        "anvisa-iras-criteria-2026"
      ],
      "lessons": [
        {
          "id": "pediatria-escala-fisiologia",
          "title": "Escala, fisiologia e termorregulação",
          "duration": 17,
          "summary": "Recalibre ambiente, equipamentos e comunicação para pacientes pequenos.",
          "objectives": [
            "Reconhecer impacto do tamanho no risco",
            "Preparar medidas de termorregulação",
            "Evitar erros de identificação e volume"
          ],
          "sections": [
            {
              "title": "Pequeno não é adulto reduzido",
              "body": "Peso, superfície corporal, reserva térmica, via aérea e volume circulante tornam pequenas perdas e exposições proporcionalmente relevantes. A preparação usa peso atualizado e equipamentos apropriados.",
              "bullets": [
                "Tamanho correto antes da indução",
                "Perdas registradas com precisão",
                "Dispositivos de aquecimento testados"
              ]
            },
            {
              "title": "Temperatura como processo contínuo",
              "body": "Sala, superfícies, fluidos e exposição contribuem para hipotermia. Monitorização e aquecimento começam antes da incisão e seguem na transferência, com cuidado para evitar lesão térmica.",
              "callout": "Metas e dispositivos devem seguir protocolo pediátrico, avaliação anestésica e instrução do fabricante."
            },
            {
              "title": "Identificação redundante",
              "body": "Recém-nascidos podem não responder e podem compartilhar sobrenomes ou datas. Pulseira, responsável, prontuário, procedimento, peso e alergias são confirmados com dois identificadores e participação familiar quando possível.",
              "bullets": [
                "Não usar leito como identificador",
                "Rotular amostras junto ao paciente",
                "Confirmar dose ou volume em sistema próprio, sem cálculo mental isolado"
              ]
            }
          ]
        },
        {
          "id": "neonatal-equipe-familia",
          "title": "Neonato, equipe e família",
          "duration": 17,
          "summary": "Integre NICU, centro cirúrgico e responsáveis em uma transição segura.",
          "objectives": [
            "Descrever uma via neonatal multidisciplinar",
            "Reconhecer participação parental segura",
            "Preparar microinstrumentais e transferências"
          ],
          "sections": [
            {
              "title": "Uma linha de cuidado entre unidades",
              "body": "O transporte neonatal exige incubadora ou suporte adequado, controle térmico, monitorização, acessos e plano de retorno. NICU, cirurgia e anestesia realizam briefing antes de cada deslocamento.",
              "bullets": [
                "Equipamento e bateria verificados",
                "Responsáveis por via aérea e linhas definidos",
                "Destino liberado antes de sair"
              ]
            },
            {
              "title": "Família como parceira",
              "body": "Recomendações atuais incluem comunicação e participação parental adaptadas à situação. Isso envolve expectativas, idioma, consentimento e orientação sobre quando e como a família pode participar.",
              "callout": "Participação familiar não substitui consentimento formal nem permite presença em área sem política institucional."
            },
            {
              "title": "Instrumentos e contagem em microescala",
              "body": "Itens pequenos, gazes especiais e dispositivos delicados requerem organização visual e contagem explícita. Componentes desmontáveis são conferidos antes e depois do uso.",
              "bullets": [
                "Evitar sobrepor itens pequenos",
                "Usar recipientes de contagem",
                "Comunicar imediatamente quebra ou ausência"
              ]
            }
          ]
        },
        {
          "id": "pediatria-microcomponentes-medicamentos",
          "title": "Microcomponentes, peso e barreiras de medicação pediátrica",
          "duration": 18,
          "summary": "Adapte contagem e identificação à escala pediátrica sem fornecer cálculos terapêuticos.",
          "objectives": [
            "Confirmar peso e identidade",
            "Controlar componentes pequenos",
            "Aplicar barreiras contra confusão de dose e apresentação"
          ],
          "sections": [
            {
              "title": "Peso é dado crítico",
              "body": "Quando o peso diverge entre fontes, cálculos e seleção dependentes dele devem aguardar reconciliação pelo fluxo assistencial. A equipe registra o valor validado e sua unidade.",
              "bullets": [
                "Evitar estimativa silenciosa",
                "Confirmar quilograma",
                "Atualizar sistemas e etiquetas conforme política"
              ]
            },
            {
              "title": "Escala pequena, risco grande",
              "body": "Agulhas, pledgets, clipes e componentes pediátricos podem se perder em campos e embalagens. Organização por zona e contagem adaptada aumentam visibilidade.",
              "bullets": [
                "Abrir somente o necessário",
                "Separar embalagens vazias",
                "Tratar fragmento como discrepância"
              ]
            },
            {
              "title": "Medicamentos concentrados",
              "body": "Apresentações semelhantes e volumes pequenos exigem rotulagem imediata, comunicação e checagens previstas. Nenhum cálculo deve ser inferido a partir desta aula.",
              "bullets": [
                "Nome e concentração",
                "Seringa adequada e identificada",
                "Dupla checagem quando exigida"
              ],
              "callout": "Dose, diluição e administração pertencem a profissionais habilitados e fontes farmacológicas específicas do serviço."
            }
          ]
        },
        {
          "id": "neonatal-termica-transporte",
          "title": "Termorregulação e transporte neonatal",
          "duration": 19,
          "summary": "Planeje a continuidade térmica e tecnológica entre unidade, sala e destino.",
          "objectives": [
            "Preparar ambiente e dispositivos",
            "Monitorar sem causar lesão térmica",
            "Estruturar transporte e handoff"
          ],
          "sections": [
            {
              "title": "Cadeia térmica contínua",
              "body": "Temperatura ambiente, superfícies, fluidos e dispositivos são planejados antes da chegada. Aquecer sem monitorar pode trocar hipotermia por hipertermia ou lesão.",
              "bullets": [
                "Dispositivo apropriado",
                "Sensor e local conforme protocolo",
                "Reavaliar após mudanças de ambiente"
              ]
            },
            {
              "title": "Equipamentos em escala correta",
              "body": "Circuitos, sensores, manguitos e suportes precisam ser compatíveis com tamanho e condição. A disponibilidade é confirmada antes do transporte, não após a chegada.",
              "bullets": [
                "Reserva de bateria",
                "Conexões seguras",
                "Fixação sem compressão"
              ]
            },
            {
              "title": "Transporte como fase de risco",
              "body": "Origem e destino confirmam equipe, rota, suporte de via aérea, monitorização e plano de contingência. O handoff inclui última temperatura, dispositivos e eventos.",
              "bullets": [
                "Checklist de partida",
                "Comunicação com família conforme política",
                "Leitura de retorno"
              ],
              "callout": "Parâmetros térmicos e suporte clínico seguem prescrição, protocolo e avaliação dos profissionais responsáveis."
            }
          ]
        }
      ]
    },
    {
      "id": "minimamente-invasiva-robotica",
      "number": "28",
      "title": "Minimamente invasiva e robótica",
      "short": "Planeje docking, energia, interfaces e conversão como um sistema humano-tecnológico.",
      "description": "Fundamentos de laparoscopia e cirurgia robótica para equipes perioperatórias, incluindo acesso ao paciente, configuração, falha, comunicação, esterilidade e instruções de uso.",
      "icon": "workflow",
      "color": "teal",
      "level": "Especialidade",
      "sourceIds": [
        "aorn-2026",
        "aorn-robotic-2026",
        "fda-rasd-draft-2026",
        "aorn-energy-2026",
        "nr32"
      ],
      "lessons": [
        {
          "id": "robotica-docking-equipe",
          "title": "Docking, zonas e funções da equipe",
          "duration": 18,
          "summary": "Organize braços, console, mesa e equipe sem perder acesso de emergência.",
          "objectives": [
            "Mapear componentes do sistema robótico",
            "Descrever briefing e docking",
            "Manter prontidão para undocking e conversão"
          ],
          "sections": [
            {
              "title": "Sistema distribuído",
              "body": "Console, carrinho do paciente, torre, insuflação, energia e mesa funcionam como uma rede. Cada membro precisa saber quem controla movimento, quem observa colisões e quem pode interromper o sistema.",
              "bullets": [
                "Zonas de movimento demarcadas",
                "Cabos e rodas protegidos",
                "Comunicação audível entre console e campo"
              ]
            },
            {
              "title": "Antes de acoplar",
              "body": "Posição, portais, alcance, possibilidade de colisão e acesso anestésico são checados antes do docking. Depois, toda movimentação da mesa segue compatibilidade e autorização específicas.",
              "callout": "Nunca mover sistema, mesa ou paciente fora da sequência definida pelo fabricante e pela equipe treinada."
            },
            {
              "title": "Conversão começa no briefing",
              "body": "Conversão não é sinônimo de falha: é uma alternativa prevista. Instrumental aberto, acesso ao paciente, funções para undocking e liderança devem estar definidos antes da incisão.",
              "bullets": [
                "Palavra de comando conhecida",
                "Sequência de retirada treinada",
                "Materiais de conversão disponíveis sem abrir desnecessariamente"
              ]
            }
          ]
        },
        {
          "id": "robotica-interface-falha",
          "title": "Interface estéril, falha e uso seguro",
          "duration": 17,
          "summary": "Aplique instruções de uso, controle de instrumentos e resposta estruturada a alertas.",
          "objectives": [
            "Proteger a interface estéril–não estéril",
            "Controlar vida útil e compatibilidade de instrumentos",
            "Responder a falha sem improviso"
          ],
          "sections": [
            {
              "title": "Barreiras e conexões",
              "body": "Drapes, adaptadores e instrumentos criam uma interface entre partes estéreis e não estéreis. Montagem incorreta pode impedir reconhecimento do instrumento ou comprometer a barreira.",
              "bullets": [
                "Integridade do drape verificada",
                "Conexões feitas sem tensão",
                "Instrumento reconhecido antes de entrar no paciente"
              ]
            },
            {
              "title": "Instrumento tem identidade e limite",
              "body": "Sistemas podem controlar usos, compatibilidade e alertas. A equipe confere instrumento, indicação, energia e condição antes da inserção, respeitando a instrução do fabricante.",
              "callout": "Não contornar bloqueio, alerta ou vida útil. Interromper, manter o instrumento sob visão quando possível e seguir o fluxo técnico autorizado."
            },
            {
              "title": "Falha como evento de equipe",
              "body": "Diante de imagem perdida, colisão, instrumento preso ou alerta, a prioridade é estabilizar a situação, comunicar e seguir o procedimento do sistema. Reiniciar sem compreender o estado pode adicionar risco.",
              "bullets": [
                "Nomear o problema",
                "Confirmar posição dos instrumentos",
                "Acionar suporte e documentar conforme política"
              ]
            }
          ]
        },
        {
          "id": "robotica-posicionamento-acesso",
          "title": "Posicionamento, docking e acesso de emergência",
          "duration": 18,
          "summary": "Planeje a geometria da sala antes que o sistema limite o acesso ao paciente.",
          "objectives": [
            "Mapear zonas e braços",
            "Proteger via aérea e pontos de pressão",
            "Definir comando de parada"
          ],
          "sections": [
            {
              "title": "Geometria antes do acoplamento",
              "body": "Carrinho, braços, torre, mesa e equipe devem caber no plano sem bloquear anestesia, circulação ou saída. O teste de alcance ocorre antes de o acesso ficar restrito.",
              "bullets": [
                "Rota da via aérea",
                "Movimento dos braços",
                "Posição da equipe e cabos"
              ]
            },
            {
              "title": "Posição sob novas forças",
              "body": "Inclinação, insuflação e duração podem alterar pressão e estabilidade. Após posicionar e antes do docking, a equipe reavalia apoios, fixação, olhos, dispositivos e possibilidade de resgate.",
              "bullets": [
                "Comando de movimento",
                "Circuitos sem tensão",
                "Mesa compatível com o sistema"
              ]
            },
            {
              "title": "Parada compartilhada",
              "body": "Qualquer membro deve reconhecer o comando acordado para colisão, quebra de barreira ou risco ao paciente. Movimentos só retomam após coordenação com o operador e a equipe.",
              "bullets": [
                "Linguagem curta",
                "Controle visual quando possível",
                "Registro do evento conforme protocolo"
              ],
              "callout": "Movimento de mesa acoplada depende de compatibilidade do sistema, instrução do fabricante e equipe treinada; nunca é presumido."
            }
          ]
        },
        {
          "id": "robotica-conversao-rastreabilidade",
          "title": "Conversão, falhas e rastreabilidade robótica",
          "duration": 20,
          "summary": "Integre undocking, instrumental alternativo e registro de alertas em um plano único.",
          "objectives": [
            "Distinguir pausa, recuperação e conversão",
            "Atribuir funções de undocking",
            "Preservar dados de instrumentos e alertas"
          ],
          "sections": [
            {
              "title": "Plano antes da falha",
              "body": "Briefing define quem afasta braços, libera acesso, protege os portais, prepara instrumental e comunica com anestesia. Funções treinadas reduzem movimentos conflitantes.",
              "bullets": [
                "Sequência autorizada",
                "Acesso ao paciente",
                "Instrumental de conversão disponível"
              ]
            },
            {
              "title": "Alerta de instrumento",
              "body": "Diante de resposta inesperada, a equipe para, comunica e mantém controle visual quando possível. O fluxo de recuperação segue o sistema e a instrução de uso; atalhos podem criar dano ou perda de fragmento.",
              "bullets": [
                "Identificar braço e instrumento",
                "Verificar integridade ao retirar",
                "Segregar item suspeito"
              ]
            },
            {
              "title": "Registro útil",
              "body": "Modelo, identificação do instrumento, mensagem de alerta, etapa e ação tomada ajudam manutenção, fabricante e tecnovigilância. O registro evita expressões vagas como “robô falhou”.",
              "bullets": [
                "Horário e contexto",
                "Lote ou série quando disponível",
                "Impacto e resolução"
              ],
              "callout": "A orientação FDA de 2026 citada na trilha é rascunho não vinculante; prática assistencial depende de requisitos vigentes, protocolo e fabricante."
            }
          ]
        }
      ]
    },
    {
      "id": "procedimentos-vias-cirurgicas",
      "number": "29",
      "title": "Procedimentos e vias de acesso cirúrgico",
      "short": "Compare abordagens abertas, minimamente invasivas, endoscópicas e percutâneas.",
      "description": "Uma trilha para reconhecer famílias de procedimentos, preparar recursos e apoiar transições sem ensinar execução cirúrgica autônoma.",
      "icon": "workflow",
      "color": "blue",
      "level": "Intermediário",
      "sourceIds": [
        "aorn-2026",
        "br-safe-surgery",
        "who-safe-surgery",
        "anvisa-isc-2025"
      ],
      "lessons": [
        {
          "id": "procedimentos-classificacao-jornada",
          "title": "Classificação e jornada do procedimento",
          "duration": 17,
          "summary": "Organize o procedimento por finalidade, urgência, porte e trajetória perioperatória.",
          "objectives": [
            "Distinguir classificações que mudam o preparo",
            "Relacionar urgência a barreiras preservadas",
            "Construir uma visão do início ao handoff"
          ],
          "sections": [
            {
              "title": "Classificar para preparar",
              "body": "Finalidade, urgência, potencial de contaminação, necessidade de implante, posição e destino pós-operatório influenciam sala, equipe e recursos. A classificação serve para antecipar riscos, não para rotular o paciente.",
              "bullets": [
                "Eletivo, urgente ou emergente",
                "Diagnóstico, terapêutico ou reconstrutivo",
                "Acesso previsto e possibilidade de conversão"
              ]
            },
            {
              "title": "Jornada em fases",
              "body": "Admissão, preparação, indução, posicionamento, acesso, etapa principal, fechamento e transferência formam uma cadeia. Cada transição pede confirmação de identidade, recursos, dispositivos e pendências.",
              "bullets": [
                "Definir marcos antes da entrada",
                "Identificar etapas irreversíveis",
                "Planejar destino e transporte"
              ]
            },
            {
              "title": "Urgência não elimina barreiras",
              "body": "Em emergência, a checagem pode ser abreviada e distribuída, mas identidade, indicação, riscos imediatos, prontidão e comunicação continuam explícitos.",
              "bullets": [
                "Declarar o que foi confirmado",
                "Marcar o que ficou pendente",
                "Reconciliar depois da estabilização"
              ],
              "callout": "A equipe adapta a forma da checagem ao tempo disponível; não omite silenciosamente barreiras essenciais."
            }
          ]
        },
        {
          "id": "procedimentos-acesso-aberto",
          "title": "Acesso aberto e incisões: leitura perioperatória",
          "duration": 20,
          "summary": "Entenda como região e extensão do acesso alteram posição, mesa, materiais e encerramento.",
          "objectives": [
            "Reconhecer princípios de acesso aberto",
            "Antecipar exposição e fechamento",
            "Relacionar região a riscos de preparação"
          ],
          "sections": [
            {
              "title": "Acesso é uma decisão técnica",
              "body": "Incisão, orientação e extensão dependem da anatomia, do objetivo e da decisão cirúrgica. Para o perioperatório, importa prever região exposta, posição, afastamento, energia, hemostasia e possibilidade de ampliação.",
              "bullets": [
                "Confirmar lado e região",
                "Preparar sem limitar extensão autorizada",
                "Preservar acesso da anestesia"
              ]
            },
            {
              "title": "Do superficial ao profundo",
              "body": "Planos são atravessados e depois reconstruídos conforme técnica. A equipe acompanha mudanças de instrumental, contagem e espécimes sem presumir a próxima manobra.",
              "bullets": [
                "Organizar por função",
                "Proteger materiais delicados",
                "Verbalizar mudança de cavidade ou plano"
              ]
            },
            {
              "title": "Fechamento começa no planejamento",
              "body": "Fios, drenos, curativos, contagens e dispositivos devem estar previstos antes do encerramento. Ampliação inesperada exige nova reconciliação de materiais e posição.",
              "bullets": [
                "Confirmar contagens nos marcos",
                "Mapear drenos antes do curativo",
                "Registrar exceções e conversão"
              ],
              "callout": "A aula explica implicações de sala; não ensina onde ou como realizar uma incisão."
            }
          ]
        },
        {
          "id": "procedimentos-video-robotico",
          "title": "Acesso laparoscópico e robótico: portais e geometria",
          "duration": 19,
          "summary": "Planeje equipamento, posição e contingência sem fornecer técnica de inserção de portais.",
          "objectives": [
            "Mapear zonas de trabalho",
            "Distinguir acesso de manutenção do pneumoperitônio",
            "Preparar conversão segura"
          ],
          "sections": [
            {
              "title": "Geometria da sala",
              "body": "Torre, insuflador, fonte de energia, mesa e braços precisam de linhas de visão e circulação. O briefing confirma lado, posição dos equipamentos e acesso ao paciente.",
              "bullets": [
                "Cabos fora de zonas de compressão",
                "Monitor visível para a equipe",
                "Rota de emergência preservada"
              ]
            },
            {
              "title": "Portais como dispositivos rastreáveis",
              "body": "Tipo, tamanho e função dos portais dependem da técnica. A equipe organiza disponibilidade, integridade, válvulas e compatibilidade sem escolher local ou executar punção autonomamente.",
              "bullets": [
                "Conferir componentes",
                "Evitar mistura entre sistemas",
                "Contar peças removíveis"
              ]
            },
            {
              "title": "Perda de acesso ou conversão",
              "body": "Vazamento, falha, sangramento ou impossibilidade técnica podem mudar o plano. A equipe responde ao comando, libera espaço e disponibiliza o conjunto aberto previsto.",
              "bullets": [
                "Parar movimentos não essenciais",
                "Preservar contagem",
                "Reconfirmar funções"
              ],
              "callout": "Pressão, posição dos portais e decisão de conversão pertencem ao operador habilitado, ao protocolo e ao equipamento."
            }
          ]
        },
        {
          "id": "procedimentos-endoscopico-percutaneo",
          "title": "Acessos endoscópicos e percutâneos",
          "duration": 18,
          "summary": "Compare trajetórias por orifício natural e punção guiada, com foco em preparação e segurança.",
          "objectives": [
            "Diferenciar famílias de acesso",
            "Antecipar imagem, irrigação e amostras",
            "Reconhecer limites de posicionamento e esterilidade"
          ],
          "sections": [
            {
              "title": "Trajetória muda o ambiente",
              "body": "Endoscopia usa uma via natural; acesso percutâneo atravessa pele até um alvo. Ambos podem depender de imagem, guias, dilatadores, irrigação e coleta de material.",
              "bullets": [
                "Confirmar equipamento e processamento",
                "Mapear entrada e retorno de fluidos",
                "Organizar guias e componentes longos"
              ]
            },
            {
              "title": "Imagem e orientação",
              "body": "Ultrassom, fluoroscopia ou endoscopia ajudam orientação, mas não substituem confirmação anatômica. Proteção radiológica e posicionamento seguem o programa institucional.",
              "bullets": [
                "Paciente e exame identificados",
                "Lateridade reconciliada",
                "Cabos e campos sem bloquear resgate"
              ]
            },
            {
              "title": "Amostras e dispositivos deixados",
              "body": "Biópsias, cálculos, cateteres ou drenos precisam de destino e plano. Antes da saída, a equipe diferencia o que foi removido do que permaneceu.",
              "bullets": [
                "Recipiente e exame confirmados",
                "Integridade de guias verificada",
                "Handoff com plano de saída"
              ],
              "callout": "Acesso percutâneo é procedimento invasivo executado por profissional habilitado; o conteúdo aborda apoio e rastreabilidade."
            }
          ]
        },
        {
          "id": "procedimentos-conversao-encerramento",
          "title": "Conversão, encerramento e handoff do procedimento",
          "duration": 18,
          "summary": "Use uma sequência comum para mudanças de abordagem e finalização segura.",
          "objectives": [
            "Apoiar conversão sem desorganizar a sala",
            "Reconciliar materiais e dispositivos",
            "Estruturar transferência"
          ],
          "sections": [
            {
              "title": "Conversão é um novo estado",
              "body": "Mudar de minimamente invasivo para aberto altera espaço, instrumental, contagem e exposição. O comando é repetido, funções são redistribuídas e movimentos não essenciais param.",
              "bullets": [
                "Liberar acesso",
                "Trazer apenas recursos previstos",
                "Atualizar contagem e documentação"
              ]
            },
            {
              "title": "Encerramento com visão completa",
              "body": "Antes do curativo, a equipe reconcilia contagens, espécimes, implantes, drenos, acessos e eventos. Pendência não deve desaparecer sob o campo.",
              "bullets": [
                "Leitura final de dispositivos",
                "Destino de amostras",
                "Integridade de materiais"
              ]
            },
            {
              "title": "Handoff pelo que mudou",
              "body": "A transferência inclui abordagem realizada, conversão, perdas comunicadas, implantes, acessos, drenos, curativos e pendências.",
              "bullets": [
                "Equipe receptora pronta",
                "Informação presencial quando possível",
                "Leitura de retorno"
              ],
              "callout": "O handoff transmite decisões já definidas; não substitui prescrição ou avaliação clínica do destino."
            }
          ]
        }
      ]
    },
    {
      "id": "acessos-vasculares-infusao",
      "number": "30",
      "title": "Acessos vasculares e terapia infusional",
      "short": "Estude acesso periférico, central, arterial e de emergência com foco perioperatório.",
      "description": "Conteúdo sobre seleção conceitual, preparo, barreiras, manutenção, complicações e handoff; a execução exige competência validada.",
      "icon": "target",
      "color": "teal",
      "level": "Intermediário",
      "sourceIds": [
        "who-catheter-peripheral-2024",
        "who-catheter-central-2026",
        "ins-infusion-2024",
        "asa-central-venous-2020"
      ],
      "lessons": [
        {
          "id": "vascular-mapa-dispositivos",
          "title": "Mapa dos dispositivos vasculares",
          "duration": 18,
          "summary": "Relacione finalidade, duração, terapia e risco sem escolher um dispositivo para um caso real.",
          "objectives": [
            "Distinguir acesso periférico, central e arterial",
            "Reconhecer fatores de planejamento",
            "Montar um mapa de dispositivos"
          ],
          "sections": [
            {
              "title": "Função antes do nome",
              "body": "Acesso pode servir a infusão, coleta, monitorização ou terapia especializada. Tipo, número de lúmens e localização dependem da necessidade clínica, duração, características da solução, anatomia e competência do operador.",
              "bullets": [
                "Periférico curto e midline",
                "PICC e cateter central",
                "Port implantado",
                "Cateter arterial"
              ]
            },
            {
              "title": "Mapa perioperatório",
              "body": "Antes do procedimento, registre quais acessos existem, onde estão, como estão identificados e para que são usados. O mapa evita desconexão ou administração em via errada durante posição e transporte.",
              "bullets": [
                "Lado e local",
                "Tipo e lúmens",
                "Curativo e condição observada",
                "Função e restrições prescritas"
              ]
            },
            {
              "title": "Necessidade muda",
              "body": "Acesso útil no início pode deixar de ser necessário; outro pode se tornar insuficiente. Mudanças são decididas pela equipe habilitada e documentadas.",
              "bullets": [
                "Reavaliar antes da indução",
                "Reconciliar após posicionamento",
                "Incluir no handoff"
              ],
              "callout": "A plataforma não indica qual cateter um paciente deve receber; ensina a organizar informação e barreiras."
            }
          ]
        },
        {
          "id": "vascular-periferico",
          "title": "Acesso venoso periférico: preparo e vigilância",
          "duration": 20,
          "summary": "Compreenda o fluxo seguro de um acesso periférico sem substituir treinamento prático supervisionado.",
          "objectives": [
            "Preparar materiais e ambiente",
            "Reconhecer perda de integridade",
            "Comunicar sinais de complicação"
          ],
          "sections": [
            {
              "title": "Antes da punção",
              "body": "Indicação, identidade, local planejado, condição da pele, terapia prevista e alergias são confirmadas. Material fica organizado para reduzir interrupções e descarte é preparado antes do perfurocortante.",
              "bullets": [
                "Higiene das mãos",
                "Antissepsia e tempo de secagem conforme produto",
                "Dispositivo e curativo compatíveis",
                "Identificação após conclusão"
              ]
            },
            {
              "title": "Durante: limite educacional",
              "body": "A execução envolve seleção de veia, punção, avanço, confirmação e estabilização por profissional treinado. O estudante deve praticar em simulação e sob supervisão, nunca a partir de texto isolado.",
              "bullets": [
                "Não repalpar área preparada sem técnica prevista",
                "Não insistir em tentativas fora do limite local",
                "Descartar imediatamente o perfurocortante"
              ]
            },
            {
              "title": "Depois: vigiar o sistema",
              "body": "Dor, edema, eritema, vazamento, resistência, curativo comprometido ou mudança de resposta exigem pausa e avaliação. Não se força infusão em acesso duvidoso.",
              "bullets": [
                "Inspecionar local e conexões",
                "Proteger contra tração",
                "Registrar inserção, avaliação e remoção"
              ],
              "callout": "Conduta diante de infiltração, extravasamento, flebite ou suspeita de infecção segue protocolo e avaliação clínica."
            }
          ]
        },
        {
          "id": "vascular-central",
          "title": "Acesso venoso central: assistência e barreira máxima",
          "duration": 21,
          "summary": "Prepare ambiente, checklist e rastreabilidade para um procedimento realizado por operador habilitado.",
          "objectives": [
            "Distinguir dispositivos centrais",
            "Organizar barreiras e equipamento",
            "Apoiar confirmação e documentação"
          ],
          "sections": [
            {
              "title": "Central é uma categoria ampla",
              "body": "Cateter não tunelizado, PICC, tunelizado e port têm trajetórias e manutenção diferentes. A escolha considera terapia, duração, risco e contexto clínico.",
              "bullets": [
                "Confirmar dispositivo e lúmens",
                "Verificar kit e compatibilidade",
                "Não presumir equivalência"
              ]
            },
            {
              "title": "Assistência à inserção",
              "body": "O ambiente permite técnica asséptica, barreiras definidas, ultrassom quando indicado e checklist. O assistente lê etapas, mantém recursos e verbaliza quebra de técnica.",
              "bullets": [
                "Kit padronizado",
                "Barreira máxima conforme diretriz",
                "Contagem de fio-guia e componentes",
                "Descarte seguro"
              ]
            },
            {
              "title": "Confirmação e liberação",
              "body": "Uso depende da confirmação exigida para o tipo e local, do registro e da decisão do responsável. Curativo, conectores, identificação e pendências chegam ao handoff.",
              "bullets": [
                "Não usar por suposição",
                "Registrar tentativas e eventos",
                "Manter portas protegidas"
              ],
              "callout": "Inserção central não é ensinada passo a passo aqui e requer habilitação, treinamento e protocolo específico."
            }
          ]
        },
        {
          "id": "vascular-arterial",
          "title": "Acesso arterial e sistema de pressão",
          "duration": 19,
          "summary": "Reconheça o circuito de monitorização e os riscos de conexões indevidas.",
          "objectives": [
            "Mapear componentes do sistema",
            "Preservar esterilidade e identificação",
            "Escalar alteração de perfusão ou traçado"
          ],
          "sections": [
            {
              "title": "Finalidade distinta",
              "body": "Cateter arterial pode apoiar monitorização e coleta, não deve ser tratado como via venosa comum. Identificação visual e organização reduzem administração acidental.",
              "bullets": [
                "Linha claramente identificada",
                "Sistema fechado",
                "Conexões protegidas"
              ]
            },
            {
              "title": "Do paciente ao monitor",
              "body": "Cateter, extensão, transdutor, solução e monitor formam um circuito. Posição, nivelamento e configuração são executados segundo equipamento e profissional habilitado.",
              "bullets": [
                "Evitar bolhas e desconexões conforme protocolo",
                "Proteger contra tração",
                "Não administrar pela linha sem autorização específica"
              ]
            },
            {
              "title": "Sinais de alerta",
              "body": "Sangramento, perda de traçado, dor, alteração de cor ou temperatura, curativo comprometido e desconexão pedem resposta imediata.",
              "bullets": [
                "Comprimir ou manipular somente conforme função",
                "Comunicar e marcar horário",
                "Preservar perfusão e segurança"
              ],
              "callout": "A aula não fornece técnica de punção arterial nem parâmetros de monitorização."
            }
          ]
        },
        {
          "id": "vascular-intraosseo-emergencia",
          "title": "Acesso intraósseo e opções de emergência",
          "duration": 16,
          "summary": "Entenda o lugar do acesso de resgate e como apoiar sua disponibilidade.",
          "objectives": [
            "Reconhecer contexto de emergência",
            "Preparar sistema sem extrapolar competência",
            "Preservar identificação e tempo"
          ],
          "sections": [
            {
              "title": "Quando o plano muda",
              "body": "Em emergência, acesso convencional pode não estar disponível. A decisão por uma via de resgate depende do protocolo e do profissional habilitado.",
              "bullets": [
                "Ativação explícita",
                "Dispositivo apropriado à população",
                "Plano para substituição quando estabilizado"
              ]
            },
            {
              "title": "Preparação sem improviso",
              "body": "Kit, tamanho, extensão, fixação e descarte precisam estar acessíveis e dentro da validade. Treinamento por simulação antecede uso real.",
              "bullets": [
                "Não aprender durante a crise",
                "Confirmar lado e local verbalizados",
                "Evitar componentes incompatíveis"
              ]
            },
            {
              "title": "Handoff do acesso de resgate",
              "body": "Hora, local, dispositivo, uso e eventos são comunicados. A via não deve perder identidade durante transporte.",
              "bullets": [
                "Fixação conferida",
                "Local visível quando possível",
                "Pendência com responsável"
              ],
              "callout": "A inserção intraóssea é invasiva e depende de habilitação e protocolo; esta aula é de reconhecimento e apoio."
            }
          ]
        },
        {
          "id": "vascular-manutencao-complicacoes",
          "title": "Manutenção, complicações e handoff vascular",
          "duration": 20,
          "summary": "Vigie o acesso como sistema e feche o ciclo quando algo muda.",
          "objectives": [
            "Inspecionar local, curativo e conexões",
            "Reconhecer categorias de complicação",
            "Comunicar e documentar resposta"
          ],
          "sections": [
            {
              "title": "Avaliação estruturada",
              "body": "Observe necessidade, local, dor, pele, curativo, fixação, permeabilidade conforme protocolo, conexões e identificação. A frequência depende do dispositivo e da condição.",
              "bullets": [
                "Local e trajeto",
                "Curativo seco e aderido",
                "Lúmens e conectores protegidos",
                "Necessidade atual"
              ]
            },
            {
              "title": "Complicações possíveis",
              "body": "Infiltração, extravasamento, flebite, oclusão, deslocamento, sangramento, trombose, embolia e infecção têm apresentações e respostas diferentes. Suspeita exige interromper a ação insegura e escalar.",
              "bullets": [
                "Não forçar resistência",
                "Não recolocar componente deslocado",
                "Preservar evidências quando houver evento"
              ]
            },
            {
              "title": "Handoff e remoção",
              "body": "Motivo, tipo, local, data, condição e restrições são transmitidos. Remoção e integridade do cateter seguem protocolo e registro.",
              "bullets": [
                "Confirmar ponta íntegra quando aplicável",
                "Curativo e observação",
                "Plano de continuidade"
              ],
              "callout": "Tratamento de complicações e decisão de remoção são clínicos; protocolos específicos prevalecem."
            }
          ]
        }
      ]
    },
    {
      "id": "via-aerea-sondas-drenos",
      "number": "31",
      "title": "Via aérea, sondas e drenos",
      "short": "Reconheça dispositivos, prepare assistência e preserve segurança nas transições.",
      "description": "Trilha sobre via aérea, cateter urinário, sondas digestivas, drenos e acessos regionais com foco em processo e limites profissionais.",
      "icon": "position",
      "color": "violet",
      "level": "Intermediário",
      "sourceIds": [
        "asa-difficult-airway-2022",
        "cdc-cauti-2025",
        "aorn-2026",
        "cfm2174-2017"
      ],
      "lessons": [
        {
          "id": "via-aerea-dispositivos",
          "title": "Mapa de dispositivos de via aérea",
          "duration": 18,
          "summary": "Diferencie dispositivos básicos, supraglóticos, traqueais e cirúrgicos pelo papel na estratégia.",
          "objectives": [
            "Reconhecer categorias",
            "Preparar tamanhos e alternativas",
            "Preservar rastreabilidade e acesso"
          ],
          "sections": [
            {
              "title": "Dispositivos em camadas",
              "body": "Máscaras, cânulas, dispositivos supraglóticos, tubos traqueais e acessos cirúrgicos têm finalidades e riscos distintos. A estratégia é definida por anestesia e equipe habilitada.",
              "bullets": [
                "Plano principal",
                "Alternativa",
                "Resgate",
                "Estratégia de extubação"
              ]
            },
            {
              "title": "Preparação da sala",
              "body": "Equipamento de ventilação, sucção, monitorização e carro de via aérea difícil devem estar acessíveis e testados conforme rotina.",
              "bullets": [
                "Tamanhos previstos",
                "Baterias e luz",
                "Capnografia ou confirmação prevista",
                "Fixação disponível"
              ]
            },
            {
              "title": "Após a colocação",
              "body": "Posição, fixação, circuito, marca de profundidade e eventos são comunicados. Movimentação do paciente exige nova checagem.",
              "bullets": [
                "Evitar tensão do circuito",
                "Proteger dentes, lábios e pele",
                "Handoff explícito"
              ],
              "callout": "Escolha e inserção do dispositivo cabem ao profissional habilitado; a trilha ensina apoio, não intubação autônoma."
            }
          ]
        },
        {
          "id": "via-aerea-assistencia-crise",
          "title": "Assistência à via aérea difícil e crise",
          "duration": 19,
          "summary": "Organize ajuda, equipamento e comunicação quando o plano inicial falha.",
          "objectives": [
            "Reconhecer escalonamento",
            "Reduzir tarefas conflitantes",
            "Registrar tentativas e transições"
          ],
          "sections": [
            {
              "title": "Tornar a dificuldade visível",
              "body": "A equipe declara a dificuldade, chama ajuda e confirma liderança. Ruído e circulação diminuem para que tempo, oxigenação e tentativas permaneçam visíveis.",
              "bullets": [
                "Comando curto",
                "Leitor de auxílio cognitivo",
                "Pessoa dedicada a buscar equipamento"
              ]
            },
            {
              "title": "Alternativas preparadas",
              "body": "Dispositivos e acesso invasivo de resgate fazem parte de uma estratégia prévia. O assistente entrega o item confirmado e evita abrir todo o carro sem coordenação.",
              "bullets": [
                "Repetir nome e tamanho",
                "Testar quando aplicável",
                "Preservar acesso ao pescoço"
              ]
            },
            {
              "title": "Depois da crise",
              "body": "Dificuldade, dispositivos, tentativas, lesões observadas e plano de extubação seguem para registro e handoff.",
              "bullets": [
                "Não minimizar evento resolvido",
                "Informar destino",
                "Debriefing após estabilização"
              ],
              "callout": "A diretriz de via aérea orienta profissionais treinados; esta aula não oferece algoritmo terapêutico para execução por leigos."
            }
          ]
        },
        {
          "id": "sonda-vesical-perioperatoria",
          "title": "Cateter urinário no perioperatório",
          "duration": 18,
          "summary": "Entenda indicação, inserção asséptica, sistema fechado e remoção oportuna.",
          "objectives": [
            "Questionar necessidade conforme protocolo",
            "Preparar inserção por pessoa treinada",
            "Manter drenagem segura"
          ],
          "sections": [
            {
              "title": "Não é item automático",
              "body": "Cateter urinário deve ter indicação, e sua necessidade é reavaliada. Uso apenas por conveniência aumenta exposição a dano.",
              "bullets": [
                "Indicação registrada",
                "Alternativas consideradas",
                "Plano de retirada"
              ]
            },
            {
              "title": "Inserção e identificação",
              "body": "No hospital agudo, inserção usa técnica asséptica e equipamento estéril por pessoa treinada. Tipo, calibre e balão seguem prescrição e protocolo.",
              "bullets": [
                "Identidade e anatomia confirmadas",
                "Material completo antes de começar",
                "Fixação e sistema fechado"
              ]
            },
            {
              "title": "Manutenção e transporte",
              "body": "Fluxo permanece livre, bolsa abaixo da bexiga e fora do piso, sem desconexões desnecessárias. Handoff inclui indicação e plano.",
              "bullets": [
                "Evitar dobras",
                "Esvaziar pelo método local",
                "Escalar obstrução, dor ou vazamento"
              ],
              "callout": "A aula não autoriza sondagem sem competência validada nem define tamanho ou volume para um paciente."
            }
          ]
        },
        {
          "id": "sondas-gastricas-enterais",
          "title": "Sondas gástricas e enterais: preparo e confirmação",
          "duration": 18,
          "summary": "Organize dispositivo, finalidade, confirmação e conexão segura.",
          "objectives": [
            "Distinguir descompressão de alimentação",
            "Evitar conexão em via errada",
            "Comunicar confirmação e restrições"
          ],
          "sections": [
            {
              "title": "Finalidade determina sistema",
              "body": "Descompressão, drenagem, alimentação ou acesso temporário exigem dispositivos e conectores diferentes. A equipe confirma pedido, via e material antes de abrir.",
              "bullets": [
                "Tipo e tamanho prescritos",
                "Conector compatível",
                "Sucção ou drenagem prevista"
              ]
            },
            {
              "title": "Inserção e confirmação",
              "body": "Inserção é realizada por profissional competente. Uso só começa após o método de confirmação exigido pelo protocolo; aparência do aspirado ou ausculta isolada não devem ser tratadas como autorização universal.",
              "bullets": [
                "Marcar e registrar referência externa",
                "Não iniciar uso por suposição",
                "Reavaliar após deslocamento"
              ]
            },
            {
              "title": "Transporte e manutenção",
              "body": "Fixação, pele, conexão, coletor e função são verificados. Medicamentos e dietas seguem rotas e checagens próprias.",
              "bullets": [
                "Cabeceira e posição conforme prescrição",
                "Evitar tração",
                "Plano de retirada no handoff"
              ],
              "callout": "Método de confirmação, uso e alimentação dependem de prescrição, população e protocolo institucional."
            }
          ]
        },
        {
          "id": "drenos-toracicos-cirurgicos",
          "title": "Drenos cirúrgicos e torácicos",
          "duration": 20,
          "summary": "Mapeie localização, conexão e função sem manipular sistemas fora do protocolo.",
          "objectives": [
            "Distinguir dreno de coletor",
            "Proteger circuito e sítio",
            "Estruturar transporte e handoff"
          ],
          "sections": [
            {
              "title": "Um dreno é um sistema",
              "body": "Sítio, tubo, conexão, reservatório ou selo e fixação precisam ser avaliados juntos. A denominação isolada não informa função nem configuração.",
              "bullets": [
                "Local e lado",
                "Tipo de sistema",
                "Sucção prescrita",
                "Débito observado conforme rotina"
              ]
            },
            {
              "title": "Antes de mover",
              "body": "Transporte exige conexões seguras, coletor na posição indicada e equipamento de contingência. Clampeamento ou desconexão não são ações automáticas.",
              "bullets": [
                "Trajeto sem dobras",
                "Fixação visível",
                "Destino preparado"
              ]
            },
            {
              "title": "Sinais de alerta",
              "body": "Desconexão, saída parcial, perda súbita de função, vazamento, sangramento ou alteração clínica são comunicados imediatamente.",
              "bullets": [
                "Não reinserir dreno deslocado",
                "Preservar esterilidade",
                "Marcar evento e resposta"
              ],
              "callout": "Manipulação de dreno torácico ou cirúrgico segue prescrição e protocolo; condutas específicas são clínicas."
            }
          ]
        },
        {
          "id": "acessos-neuroeixo-regionais",
          "title": "Cateteres de neuroeixo e acessos regionais",
          "duration": 18,
          "summary": "Reconheça interfaces de segurança com anestesia regional sem ensinar punção.",
          "objectives": [
            "Identificar cateter e via",
            "Evitar administração em rota errada",
            "Preservar curativo e documentação"
          ],
          "sections": [
            {
              "title": "Via exclusiva e alto risco",
              "body": "Cateter epidural, intratecal ou regional não deve ser confundido com acesso venoso. Identificação, conexão e medicamentos autorizados precisam de barreiras próprias.",
              "bullets": [
                "Etiqueta clara",
                "Conector e bomba dedicados conforme sistema",
                "Separação física quando possível"
              ]
            },
            {
              "title": "Assistência ao procedimento",
              "body": "Posição, monitorização, material estéril, ultrassom e ressuscitação são preparados conforme equipe de anestesia. O assistente observa quebra de técnica e mantém comunicação.",
              "bullets": [
                "Checklist local",
                "Medicamentos confirmados",
                "Perfurocortantes controlados"
              ]
            },
            {
              "title": "Pós-procedimento e handoff",
              "body": "Local, tipo, medicação prescrita, última administração, avaliação e sinais de alerta seguem para o destino.",
              "bullets": [
                "Curativo íntegro",
                "Bloqueio e função avaliados pela equipe",
                "Plano de remoção"
              ],
              "callout": "Punção e administração neuraxial ou regional exigem habilitação específica e não são ensinadas passo a passo."
            }
          ]
        }
      ]
    },
    {
      "id": "assepsia-antissepsia-pele",
      "number": "32",
      "title": "Assepsia, antissepsia e preparo da pele",
      "short": "Aprofunde conceitos, mãos, pele, campos e prevenção de fogo.",
      "description": "Trilha dedicada à prevenção de contaminação desde a avaliação da pele até a colocação dos campos, condicionada à IFU e ao protocolo.",
      "icon": "shield",
      "color": "green",
      "level": "Essencial",
      "sourceIds": [
        "aorn-skin-antisepsis-2026",
        "aorn-2026",
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "nr32"
      ],
      "lessons": [
        {
          "id": "assepsia-conceitos",
          "title": "Assepsia, antissepsia, limpeza e esterilidade",
          "duration": 16,
          "summary": "Use cada termo corretamente para evitar processos incompatíveis.",
          "objectives": [
            "Diferenciar conceitos",
            "Relacionar método ao alvo",
            "Reconhecer limite de cada barreira"
          ],
          "sections": [
            {
              "title": "Palavras representam processos",
              "body": "Limpeza remove sujidade; antissepsia reduz microrganismos em tecido vivo; desinfecção se aplica a superfícies ou produtos compatíveis; esterilização busca eliminar formas viáveis em artigos processáveis.",
              "bullets": [
                "Tecido vivo não é artigo",
                "Antisséptico não esteriliza pele",
                "Desinfetante não é automaticamente seguro na pele"
              ]
            },
            {
              "title": "Assepsia é uma condição de trabalho",
              "body": "Técnica asséptica reúne ações para impedir introdução de contaminantes. Ela depende de mãos, materiais, ambiente, sequência e comportamento.",
              "bullets": [
                "Preparar antes de iniciar",
                "Separar limpo de contaminado",
                "Reduzir interrupções"
              ]
            },
            {
              "title": "Barreira tem limites",
              "body": "Luvas, campos e antisséptico reduzem risco, mas não corrigem material processado inadequadamente ou quebra não reconhecida.",
              "bullets": [
                "Inspecionar integridade",
                "Trocar barreira comprometida",
                "Comunicar e registrar evento"
              ],
              "callout": "Produtos e métodos não são intercambiáveis; seguir rótulo, instrução do fabricante e protocolo validado."
            }
          ]
        },
        {
          "id": "assepsia-maos-paramentacao",
          "title": "Antissepsia cirúrgica das mãos e paramentação",
          "duration": 20,
          "summary": "Compreenda preparação, sequência e pontos de contaminação sem depender de tempo universal.",
          "objectives": [
            "Preparar mãos e antebraços",
            "Preservar sequência asséptica",
            "Reconhecer contaminação de avental ou luva"
          ],
          "sections": [
            {
              "title": "Antes da antissepsia",
              "body": "Unhas, pele, adornos e vestimenta seguem política institucional. Lesões ou condição que comprometa a prática devem ser comunicadas.",
              "bullets": [
                "Mãos e antebraços acessíveis",
                "Produto aprovado",
                "Pias e dispensadores funcionais"
              ]
            },
            {
              "title": "Produto e técnica",
              "body": "Método com água ou preparação alcoólica segue instrução de uso, área coberta e tempo específico do produto. Não se mistura duração de um produto com outro.",
              "bullets": [
                "Cobertura completa",
                "Evitar retorno de água para área limpa",
                "Secagem antes da paramentação"
              ]
            },
            {
              "title": "Avental e luvas",
              "body": "Sequência reduz contato da face externa com pele ou ambiente. Contaminação percebida exige troca controlada, não correção improvisada.",
              "bullets": [
                "Mãos dentro da zona segura",
                "Manguitos e punhos protegidos",
                "Troca assistida quando prevista"
              ],
              "callout": "Competência prática deve ser validada presencialmente; o texto não substitui demonstração e observação direta."
            }
          ]
        },
        {
          "id": "assepsia-avaliacao-pele-pelos",
          "title": "Avaliação da pele, limpeza e manejo de pelos",
          "duration": 18,
          "summary": "Prepare o sítio sem criar lesão adicional ou remover pelos rotineiramente.",
          "objectives": [
            "Avaliar integridade e sujidade",
            "Reconhecer quando pelos interferem",
            "Documentar achados e desvios"
          ],
          "sections": [
            {
              "title": "Avaliar antes de aplicar",
              "body": "Feridas, dermatite, adesivos, piercings, umidade, sujidade e reação prévia influenciam o plano. Achado relevante é discutido antes da preparação.",
              "bullets": [
                "Confirmar sítio e extensão",
                "Investigar reação documentada",
                "Proteger áreas vulneráveis conforme protocolo"
              ]
            },
            {
              "title": "Pelos não são removidos por rotina",
              "body": "Remoção ocorre quando interfere com campo, fechamento, curativo ou segurança. Método e momento seguem diretriz e política para reduzir trauma.",
              "bullets": [
                "Evitar lâmina quando não indicada",
                "Conter pelos soltos",
                "Inspecionar pele após manejo"
              ]
            },
            {
              "title": "Limpeza e antissepsia não são sinônimos",
              "body": "Sujidade visível pode exigir limpeza antes do antisséptico. Aplicar produto sobre matéria orgânica sem processo previsto pode reduzir desempenho.",
              "bullets": [
                "Usar material compatível",
                "Evitar espalhar contaminação",
                "Secar conforme fluxo"
              ],
              "callout": "Decisão deve considerar paciente, região e produto; não há uma preparação idêntica para todos os sítios."
            }
          ]
        },
        {
          "id": "assepsia-selecao-antisseptico",
          "title": "Seleção do antisséptico e regiões especiais",
          "duration": 20,
          "summary": "Compare princípios de seleção sem prescrever uma solução universal.",
          "objectives": [
            "Ler contraindicações e IFU",
            "Distinguir pele íntegra de mucosa",
            "Planejar alternativa segura"
          ],
          "sections": [
            {
              "title": "Escolha baseada em contexto",
              "body": "Evidência, região, condição da pele, idade, reação prévia, risco de fogo e procedimento orientam a escolha institucional. Concentração e aplicador pertencem ao produto específico.",
              "bullets": [
                "Pele íntegra",
                "Mucosa ou região próxima",
                "Olhos, ouvido e tecido neural",
                "Populações especiais"
              ]
            },
            {
              "title": "Álcool muda o risco",
              "body": "Formulações alcoólicas podem ter vantagens e também inflamabilidade. Acúmulo em pregas, pelos, campos ou posicionadores aumenta risco.",
              "bullets": [
                "Usar quantidade indicada",
                "Impedir pooling",
                "Aguardar secagem completa conforme IFU"
              ]
            },
            {
              "title": "Reação relatada precisa ser esclarecida",
              "body": "Rótulos vagos como “alergia a iodo” não devem gerar substituição automática. A equipe confirma qual produto causou qual reação e consulta protocolo.",
              "bullets": [
                "Registrar descrição",
                "Evitar mitos de equivalência",
                "Ter alternativa aprovada"
              ],
              "callout": "A plataforma não define marca, concentração ou aplicação em mucosa; essas escolhas dependem da política e da IFU."
            }
          ]
        },
        {
          "id": "assepsia-aplicacao-campos-fogo",
          "title": "Aplicação, secagem, campos e risco de fogo",
          "duration": 20,
          "summary": "Conecte aplicação do antisséptico à proteção do campo durante todo o procedimento.",
          "objectives": [
            "Planejar área e sequência",
            "Evitar acúmulo de solução",
            "Reconhecer quebra de campo"
          ],
          "sections": [
            {
              "title": "Área suficiente e controlada",
              "body": "A preparação cobre a região planejada e possibilidade de extensão autorizada, respeitando direção e técnica do produto. Materiais de absorção são removidos quando previsto.",
              "bullets": [
                "Aplicador compatível com área",
                "Não retornar material contaminado",
                "Proteger dispositivos e eletrodos"
              ]
            },
            {
              "title": "Secagem é uma barreira",
              "body": "Campos não são colocados antes da secagem completa prevista. A equipe verifica pregas, pelos, bordas e materiais que possam reter solução.",
              "bullets": [
                "Anunciar produto alcoólico",
                "Confirmar secagem",
                "Reavaliar antes da energia"
              ]
            },
            {
              "title": "Campo estéril continua dinâmico",
              "body": "Deslocamento de campo, perfuração, umidade ou contato não controlado exigem interrupção e correção. Cobrir uma quebra não a torna inexistente.",
              "bullets": [
                "Tornar a quebra visível",
                "Substituir ou reforçar conforme protocolo",
                "Registrar quando houver impacto"
              ],
              "callout": "Risco de fogo é multiprofissional: oxidante, combustível e ignição devem ser coordenados antes da ativação de energia."
            }
          ]
        }
      ]
    },
    {
      "id": "procedimentos-perioperatorios",
      "number": "33",
      "title": "Procedimentos perioperatórios essenciais",
      "short": "Integre admissão, transferência, monitorização, curativos e handoff.",
      "description": "Uma trilha de procedimentos assistenciais que conecta preparação, apoio seguro, registro e continuidade do cuidado.",
      "icon": "checklist",
      "color": "orange",
      "level": "Essencial",
      "sourceIds": [
        "aorn-2026",
        "br-safe-surgery",
        "who-safe-surgery",
        "cofen736-2024",
        "cofen754-2024"
      ],
      "lessons": [
        {
          "id": "perioperatorio-admissao-verificacao",
          "title": "Admissão e verificação pré-procedimento",
          "duration": 17,
          "summary": "Transforme documentos e entrevista em uma linha de base compartilhada.",
          "objectives": [
            "Confirmar identidade e procedimento",
            "Reconciliar documentos e dispositivos",
            "Escalar pendências antes da sala"
          ],
          "sections": [
            {
              "title": "Identidade por fontes confiáveis",
              "body": "A equipe usa identificadores definidos e compara pulseira, prontuário, consentimento, programação e fala do paciente quando possível.",
              "bullets": [
                "Não usar leito como identificador",
                "Resolver divergência",
                "Confirmar responsável quando aplicável"
              ]
            },
            {
              "title": "Linha de base",
              "body": "Alergias, jejum conforme prescrição, pele, mobilidade, dor, acessos, implantes, exames e riscos comunicados formam a fotografia de entrada.",
              "bullets": [
                "Distinguir observado de relatado",
                "Registrar dispositivos presentes",
                "Comunicar mudança recente"
              ]
            },
            {
              "title": "Pendência tem destino",
              "body": "Documento ausente, lateralidade conflitante ou preparo incompleto é declarado e atribuído. O paciente não avança por inércia.",
              "bullets": [
                "Pausar quando necessário",
                "Definir responsável",
                "Registrar resolução"
              ],
              "callout": "A verificação não substitui avaliação médica ou anestésica; organiza o gate multiprofissional."
            }
          ]
        },
        {
          "id": "perioperatorio-transferencia-monitorizacao",
          "title": "Transferência, monitorização e proteção de dispositivos",
          "duration": 18,
          "summary": "Mova o paciente sem perder acesso, alinhamento ou informação.",
          "objectives": [
            "Planejar transferência",
            "Proteger linhas e dispositivos",
            "Reconfirmar após movimento"
          ],
          "sections": [
            {
              "title": "Antes de mover",
              "body": "Equipe, superfície, travas, altura, cabos, sondas e destino são preparados. Quem lidera dá comandos claros.",
              "bullets": [
                "Número de pessoas adequado",
                "Equipamento de auxílio disponível",
                "Privacidade e dignidade"
              ]
            },
            {
              "title": "Durante o movimento",
              "body": "Cada membro controla uma zona definida; via aérea e dispositivos críticos têm responsáveis. Resistência ou tração interrompe a ação.",
              "bullets": [
                "Movimento coordenado",
                "Sem puxar por membros ou dispositivos",
                "Atenção a quedas e perfurocortantes"
              ]
            },
            {
              "title": "Depois",
              "body": "Alinhamento, pontos de pressão, acessos, circuitos, monitores e identificação são reavaliados.",
              "bullets": [
                "Nova linha de base",
                "Achados comunicados",
                "Documentação conforme política"
              ],
              "callout": "A técnica de mobilização depende da condição, peso, equipamento e avaliação ocupacional do serviço."
            }
          ]
        },
        {
          "id": "perioperatorio-puncoes-biopsias",
          "title": "Apoio a punções, biópsias e procedimentos guiados",
          "duration": 18,
          "summary": "Prepare imagem, amostras e contingência para procedimentos invasivos de menor ou maior complexidade.",
          "objectives": [
            "Organizar materiais por finalidade",
            "Preservar orientação da amostra",
            "Apoiar resposta a complicações"
          ],
          "sections": [
            {
              "title": "Procedimento curto não é procedimento simples",
              "body": "Punção ou biópsia pode envolver sedação, imagem, sangramento, pneumotórax, reação ou necessidade de conversão. Briefing e monitorização seguem risco e protocolo.",
              "bullets": [
                "Identidade e alvo",
                "Imagem correta",
                "Equipamento e resgate"
              ]
            },
            {
              "title": "Amostra nasce identificada",
              "body": "Número de fragmentos, local, lado, exame e meio de transporte são confirmados com a equipe. Recipiente inadequado pode inviabilizar análise.",
              "bullets": [
                "Um recipiente por fluxo",
                "Leitura de retorno",
                "Horário quando relevante"
              ]
            },
            {
              "title": "Observação e destino",
              "body": "Curativo, sinais comunicados, dispositivos e instruções seguem para recuperação ou unidade. Evento durante o procedimento é documentado.",
              "bullets": [
                "Handoff estruturado",
                "Amostras reconciliadas",
                "Critérios definidos pela equipe"
              ],
              "callout": "Punção e biópsia são executadas por profissionais habilitados; o foco é assistência e rastreabilidade."
            }
          ]
        },
        {
          "id": "perioperatorio-feridas-curativos-estomas",
          "title": "Feridas, curativos e estomas no encerramento",
          "duration": 19,
          "summary": "Preserve pele, dispositivo e informação quando o campo é fechado.",
          "objectives": [
            "Avaliar pele e incisão sem diagnóstico autônomo",
            "Organizar materiais e dispositivos",
            "Documentar condição inicial"
          ],
          "sections": [
            {
              "title": "Curativo corresponde ao plano",
              "body": "Tipo, local e material dependem da incisão, exsudato previsto, pele e orientação da equipe. A embalagem é conferida e a técnica permanece asséptica.",
              "bullets": [
                "Local correto",
                "Pele seca conforme produto",
                "Sem tensão desnecessária"
              ]
            },
            {
              "title": "Drenos e estomas",
              "body": "Antes de cobrir, posição, fixação, conexão e identificação são verificadas. Estoma é protegido e descrito conforme parâmetros institucionais.",
              "bullets": [
                "Não ocultar conexão duvidosa",
                "Mapear lado e local",
                "Coletor compatível"
              ]
            },
            {
              "title": "Linha de base para o destino",
              "body": "Aspecto observado, curativo, dispositivos e eventos são registrados para comparação posterior. Alteração relevante é comunicada antes da saída.",
              "bullets": [
                "Horário",
                "Integridade e drenagem observada",
                "Plano de revisão"
              ],
              "callout": "Avaliação diagnóstica e tratamento de ferida ou estoma dependem de profissionais habilitados e protocolo."
            }
          ]
        },
        {
          "id": "perioperatorio-transporte-handoff",
          "title": "Transporte e handoff com reconciliação de dispositivos",
          "duration": 18,
          "summary": "Feche o ciclo entre sala, recuperação, terapia intensiva ou unidade.",
          "objectives": [
            "Confirmar prontidão de transporte",
            "Reconciliar todos os dispositivos",
            "Transferir pendências com responsável"
          ],
          "sections": [
            {
              "title": "Partida segura",
              "body": "Destino, equipe receptora, monitorização, oxigênio, baterias, medicações em curso e documentação são confirmados antes do movimento.",
              "bullets": [
                "Paciente identificado",
                "Rota livre",
                "Equipamentos testados"
              ]
            },
            {
              "title": "Inventário visível",
              "body": "Via aérea, acessos, sondas, drenos, curativos, implantes temporários e amostras são contados e associados ao local e à função.",
              "bullets": [
                "Conexões protegidas",
                "Coletores posicionados",
                "Nada deixado sem nome"
              ]
            },
            {
              "title": "Handoff e responsabilidade",
              "body": "Procedimento, abordagem, eventos, perdas, medicamentos comunicados, dispositivos e pendências são transmitidos com oportunidade para perguntas.",
              "bullets": [
                "Leitura de retorno",
                "Responsável por cada pendência",
                "Registro da transferência"
              ],
              "callout": "Transferência só termina quando a equipe receptora aceita a responsabilidade e dispõe dos recursos necessários."
            }
          ]
        }
      ]
    }
  ],
  "flashcards": [
    {
      "id": 1,
      "deck": "Instrumentais",
      "front": "Qual detalhe clássico diferencia a Kelly da Crile?",
      "back": "A extensão da serrilha: na descrição clássica, a Kelly tem serrilha na porção distal; a Crile, ao longo de toda a mandíbula. Confirme variações do fabricante."
    },
    {
      "id": 2,
      "deck": "Instrumentais",
      "front": "Por que a Metzenbaum não deve cortar fios?",
      "back": "Porque suas lâminas delicadas são destinadas à dissecção de tecidos; materiais podem danificar o fio de corte."
    },
    {
      "id": 3,
      "deck": "Instrumentais",
      "front": "Qual instrumento possui dente terminal e preensão firme?",
      "back": "A pinça Kocher, em sua configuração clássica. Seu potencial traumático exige indicação apropriada."
    },
    {
      "id": 4,
      "deck": "Fios e suturas",
      "front": "4-0 é mais fino ou mais grosso que 2-0?",
      "back": "Mais fino. Na escala USP, quanto mais zeros, menor tende a ser o diâmetro."
    },
    {
      "id": 5,
      "deck": "Fios e suturas",
      "front": "Absorção completa e perda de resistência são o mesmo evento?",
      "back": "Não. Um fio pode perder sustentação antes de ser totalmente absorvido."
    },
    {
      "id": 6,
      "deck": "Fios e suturas",
      "front": "Qual estrutura tende a ter maior capilaridade: mono ou multifilamento?",
      "back": "O multifilamento, devido à estrutura trançada. O comportamento também depende de material e revestimento."
    },
    {
      "id": 7,
      "deck": "Posicionamento",
      "front": "Quais cinco eixos orientam a varredura de posicionamento?",
      "back": "Alinhamento, respiração, circulação, nervos e pele."
    },
    {
      "id": 8,
      "deck": "Posicionamento",
      "front": "Qual nervo merece atenção especial na litotomia?",
      "back": "O nervo fibular comum, vulnerável à pressão na face lateral do joelho."
    },
    {
      "id": 9,
      "deck": "Segurança",
      "front": "O que fazer quando a esterilidade de um item é duvidosa?",
      "back": "Tratê-lo como contaminado e seguir o protocolo de substituição ou correção."
    },
    {
      "id": 10,
      "deck": "Segurança",
      "front": "Como deve ser uma contagem cirúrgica?",
      "back": "Visual, audível, realizada pelos profissionais designados e registrada conforme protocolo."
    },
    {
      "id": 11,
      "deck": "Procedimentos",
      "front": "Quais são os quatro tempos operatórios clássicos?",
      "back": "Diérese, hemostasia, exérese e síntese."
    },
    {
      "id": 12,
      "deck": "Anatomia",
      "front": "Quadrantes abdominais são limites anatômicos rígidos?",
      "back": "Não. São referências clínicas de localização; órgãos atravessam regiões e variam com posição e biotipo."
    },
    {
      "id": 13,
      "deck": "Ambiente e equipe",
      "front": "Por que o zoneamento do centro cirúrgico não deve ser decorado como um mapa universal?",
      "back": "Porque limites, nomes e fluxos variam entre instituições. O essencial é seguir sinalização, vestimenta, acesso e política local de cada área."
    },
    {
      "id": 14,
      "deck": "Ambiente e equipe",
      "front": "O que fazer ao receber uma solicitação fora da sua habilitação ou supervisão?",
      "back": "Não executar por conta própria; confirmar com o responsável e seguir legislação e protocolo institucional."
    },
    {
      "id": 15,
      "deck": "Ambiente e equipe",
      "front": "Quais elementos devem aparecer ao escalar uma preocupação?",
      "back": "Fato observado, risco, solicitação ou necessidade de ação e confirmação de que a mensagem foi compreendida."
    },
    {
      "id": 16,
      "deck": "Ambiente e equipe",
      "front": "Como o tráfego desnecessário pode afetar a sala?",
      "back": "Aumenta interrupções e dificulta o controle ambiental; entradas e saídas devem ser antecipadas e reduzidas."
    },
    {
      "id": 17,
      "deck": "Cirurgia segura",
      "front": "Quais são os três momentos da lista de verificação cirúrgica?",
      "back": "Antes da indução anestésica, antes da incisão e antes de o paciente sair da sala."
    },
    {
      "id": 18,
      "deck": "Cirurgia segura",
      "front": "O que caracteriza comunicação em alça fechada?",
      "back": "Mensagem dirigida, repetição por quem recebe e confirmação por quem emitiu."
    },
    {
      "id": 19,
      "deck": "Cirurgia segura",
      "front": "Checklist lido rapidamente, sem atenção da equipe, é suficiente?",
      "back": "Não. A checagem precisa de participação e resolução de discrepâncias, não apenas recitação."
    },
    {
      "id": 20,
      "deck": "Cirurgia segura",
      "front": "Qual é a diferença entre briefing e debriefing?",
      "back": "O briefing antecipa plano e riscos; o debriefing reconcilia o ocorrido, pendências e melhorias."
    },
    {
      "id": 21,
      "deck": "Prevenção de ISC",
      "front": "A remoção de pelos deve ser rotineira?",
      "back": "Não. Só quando indicada, usando método, local e momento definidos pelo protocolo para reduzir lesão cutânea."
    },
    {
      "id": 22,
      "deck": "Prevenção de ISC",
      "front": "Uma única medida compensa a quebra deliberada de outra barreira?",
      "back": "Não. A prevenção de ISC depende de medidas coordenadas e de correção imediata dos desvios."
    },
    {
      "id": 23,
      "deck": "Prevenção de ISC",
      "front": "Qual é o papel da equipe na profilaxia antimicrobiana?",
      "back": "Confirmar alergias, prescrição, administração e horário, e comunicar divergências dentro de sua atribuição."
    },
    {
      "id": 24,
      "deck": "Prevenção de ISC",
      "front": "Vídeo ou aula pode definir meta clínica individual de temperatura ou glicemia?",
      "back": "Não. Metas e intervenções dependem da avaliação clínica, profissionais responsáveis e protocolo."
    },
    {
      "id": 25,
      "deck": "Contagens",
      "front": "Quais características tornam uma contagem confiável?",
      "back": "Ela é padronizada, visual, audível, simultânea entre profissionais designados e registrada."
    },
    {
      "id": 26,
      "deck": "Contagens",
      "front": "O que fazer se uma contagem for interrompida ou gerar dúvida?",
      "back": "Reiniciar a etapa indicada conforme o protocolo, sem presumir o resultado."
    },
    {
      "id": 27,
      "deck": "Contagens",
      "front": "Uma divergência pode ser registrada como correta para acelerar o encerramento?",
      "back": "Não. A divergência deve ser comunicada, investigada e documentada de forma factual."
    },
    {
      "id": 28,
      "deck": "Contagens",
      "front": "Qual é a primeira resposta a uma contagem divergente?",
      "back": "Comunicar imediatamente, interromper quando clinicamente possível, repetir a contagem e iniciar busca sistemática."
    },
    {
      "id": 29,
      "deck": "Espécimes e implantes",
      "front": "O que deve acompanhar a identidade de um espécime?",
      "back": "Identificadores aceitos, descrição, localização e lateralidade quando aplicável, exame e documentação correspondentes."
    },
    {
      "id": 30,
      "deck": "Espécimes e implantes",
      "front": "Todo espécime deve receber o mesmo conservante?",
      "back": "Não. Recipiente e conservação dependem do exame; em dúvida, confirme antes do envio."
    },
    {
      "id": 31,
      "deck": "Espécimes e implantes",
      "front": "Quais dados costumam sustentar a rastreabilidade de um implante?",
      "back": "Fabricante, referência, lote ou série, validade, produto e vínculo com o paciente, conforme norma e sistema."
    },
    {
      "id": 32,
      "deck": "Espécimes e implantes",
      "front": "O que fazer com implante cuja embalagem está danificada?",
      "back": "Segregar, não utilizar, comunicar e seguir o fluxo de não conformidade."
    },
    {
      "id": 33,
      "deck": "CME",
      "front": "Por que a limpeza precede desinfecção ou esterilização?",
      "back": "Porque sujidade e matéria orgânica interferem nas etapas posteriores; processamento final não corrige limpeza inadequada."
    },
    {
      "id": 34,
      "deck": "CME",
      "front": "O que deve ser verificado após a limpeza?",
      "back": "Resíduos, secagem, corrosão, fissuras, alinhamento, corte, isolamento, lúmens, componentes e funcionamento."
    },
    {
      "id": 35,
      "deck": "CME",
      "front": "Parâmetros físicos, indicadores químicos e biológicos têm a mesma função?",
      "back": "Não. Fornecem informações complementares e devem ser interpretados conforme processo validado."
    },
    {
      "id": 36,
      "deck": "CME",
      "front": "O que fazer quando um critério de liberação do lote não foi atendido?",
      "back": "Reter o lote, investigar, documentar e seguir o sistema de qualidade; não liberar por conveniência."
    },
    {
      "id": 37,
      "deck": "Energia e fogo",
      "front": "Qual é a diferença básica entre eletrocirurgia monopolar e bipolar?",
      "back": "Na monopolar, o circuito inclui paciente e eletrodo de retorno; na bipolar, a corrente se concentra entre os polos do instrumento."
    },
    {
      "id": 38,
      "deck": "Energia e fogo",
      "front": "Quais elementos formam o triângulo do fogo cirúrgico?",
      "back": "Oxidante, fonte de ignição e combustível."
    },
    {
      "id": 39,
      "deck": "Energia e fogo",
      "front": "Máscara cirúrgica substitui evacuação da fumaça na fonte?",
      "back": "Não. Captura local e filtração são controles de engenharia prioritários."
    },
    {
      "id": 40,
      "deck": "Energia e fogo",
      "front": "O que fazer diante de alarme persistente da unidade de energia?",
      "back": "Não silenciar sem causa; interromper, identificar e corrigir conforme fabricante e protocolo."
    },
    {
      "id": 41,
      "deck": "Medicamentos",
      "front": "O que fazer com uma seringa cujo conteúdo não pode ser confirmado?",
      "back": "Não utilizar. Segregar e descartar conforme protocolo; nunca tentar adivinhar pelo aspecto."
    },
    {
      "id": 42,
      "deck": "Medicamentos",
      "front": "Cor da etiqueta identifica o medicamento com segurança?",
      "back": "Não. É apenas pista visual; nome, concentração e demais elementos precisam ser lidos."
    },
    {
      "id": 43,
      "deck": "Medicamentos",
      "front": "O que torna uma dupla checagem independente?",
      "back": "Cada profissional verifica os elementos críticos sem apenas aceitar a conclusão do outro."
    },
    {
      "id": 44,
      "deck": "Medicamentos",
      "front": "Qual é a prioridade ao reconhecer um erro de medicação?",
      "back": "Proteger e avaliar o paciente, comunicar imediatamente, registrar fatos e notificar pelo sistema."
    },
    {
      "id": 45,
      "deck": "Anestesia e SRPA",
      "front": "Quais são as fases gerais do cuidado anestésico?",
      "back": "Avaliação e planejamento, preparação, indução quando aplicável, manutenção, emergência ou despertar e recuperação."
    },
    {
      "id": 46,
      "deck": "Anestesia e SRPA",
      "front": "O que deve ocorrer na admissão à SRPA?",
      "back": "Transferência estruturada com identificação, procedimento, técnica, eventos, via aérea, acessos, medicamentos, perdas e pendências."
    },
    {
      "id": 47,
      "deck": "Anestesia e SRPA",
      "front": "Um escore, isoladamente, determina alta da SRPA?",
      "back": "Não. Ele apoia a avaliação, mas não substitui critérios, julgamento e responsabilidade do médico designado."
    },
    {
      "id": 48,
      "deck": "Anestesia e SRPA",
      "front": "A equipe não médica pode decidir e conduzir o ato anestésico?",
      "back": "Não. Atua dentro de sua competência, preparando o ambiente, observando, comunicando e apoiando o plano médico."
    },
    {
      "id": 49,
      "deck": "Segurança ocupacional",
      "front": "Quem utiliza um perfurocortante é responsável por quê?",
      "back": "Pelo descarte imediato e seguro, conforme NR-32 e protocolo."
    },
    {
      "id": 50,
      "deck": "Segurança ocupacional",
      "front": "Qual é a resposta geral a uma exposição ocupacional?",
      "back": "Interromper com segurança, fazer cuidado local indicado, comunicar e buscar avaliação ocupacional sem atraso."
    },
    {
      "id": 51,
      "deck": "Segurança ocupacional",
      "front": "EPI é suficiente para controlar todo risco químico ou físico?",
      "back": "Não. Proteção coletiva, engenharia, manutenção, sinalização e práticas de trabalho têm prioridade."
    },
    {
      "id": 52,
      "deck": "Segurança ocupacional",
      "front": "Quais princípios ajudam a reduzir exposição à radiação?",
      "back": "Tempo, distância, blindagem, controle de acesso e dosimetria conforme o plano de proteção."
    },
    {
      "id": 53,
      "deck": "Documentação e ética",
      "front": "Quais atributos deve ter um registro perioperatório?",
      "back": "Claro, objetivo, cronológico, completo para a finalidade e com autoria identificável."
    },
    {
      "id": 54,
      "deck": "Documentação e ética",
      "front": "Como corrigir informação sem ocultar o histórico?",
      "back": "Seguir a função de correção ou anotação tardia, preservando conteúdo, autoria, data e hora."
    },
    {
      "id": 55,
      "deck": "Documentação e ética",
      "front": "É permitido fotografar o campo em celular pessoal se o nome não aparecer?",
      "back": "Não. Contexto e imagem podem identificar; finalidade, consentimento, dispositivo e armazenamento exigem governança institucional."
    },
    {
      "id": 56,
      "deck": "Documentação e ética",
      "front": "O que fazer após enviar dado de saúde ao destinatário errado?",
      "back": "Conter o compartilhamento, preservar dados do evento e comunicar imediatamente pelo canal institucional."
    },
    {
      "id": 57,
      "deck": "Eventos críticos",
      "front": "Qual é a primeira competência não técnica diante de uma crise?",
      "back": "Tornar o evento visível: declarar a preocupação, chamar ajuda e confirmar liderança."
    },
    {
      "id": 58,
      "deck": "Eventos críticos",
      "front": "Para que serve um leitor de auxílio cognitivo?",
      "back": "Para acompanhar a sequência do protocolo enquanto os demais executam as ações e comunicam resultados."
    },
    {
      "id": 59,
      "deck": "Eventos críticos",
      "front": "Por que simular eventos raros?",
      "back": "Para testar pessoas, comunicação, ambiente, materiais e logística antes de uma ocorrência real."
    },
    {
      "id": 60,
      "deck": "Eventos críticos",
      "front": "A aula pode substituir o protocolo de tratamento de uma emergência?",
      "back": "Não. Tratamento, medicamentos e doses dependem do protocolo vigente e de profissionais habilitados."
    },
    {
      "id": 61,
      "deck": "Cirurgia geral",
      "front": "Por que uma mudança para etapa contaminada deve ser verbalizada?",
      "back": "Porque pode alterar instrumentais, barreiras, contagens e organização do campo. A resposta exata segue o protocolo do procedimento e da instituição."
    },
    {
      "id": 62,
      "deck": "Cirurgia geral",
      "front": "O que caracteriza ERAS na prática?",
      "back": "Um programa multidisciplinar com elementos coordenados e auditados, não a aplicação isolada de uma única medida."
    },
    {
      "id": 63,
      "deck": "Ortopedia",
      "front": "Quais dados mínimos sustentam rastreabilidade de um implante?",
      "back": "Identificação do implante, fabricante/modelo, lote ou série, tamanho quando aplicável, local e vínculo com o paciente, conforme sistema institucional."
    },
    {
      "id": 64,
      "deck": "Ortopedia",
      "front": "A marcação cutânea sozinha confirma lateralidade?",
      "back": "Não. Ela integra uma cadeia com documentos, imagens, posicionamento, pausa e concordância verbal da equipe."
    },
    {
      "id": 65,
      "deck": "Ginecologia e obstetrícia",
      "front": "Qual cuidado é central ao movimentar pernas em litotomia?",
      "back": "Movimento coordenado e simultâneo, com reavaliação de alinhamento, pressão, acessos e estabilidade."
    },
    {
      "id": 66,
      "deck": "Ginecologia e obstetrícia",
      "front": "A urgência da cesárea elimina a lista de verificação?",
      "back": "Não. A forma pode ser adaptada e fracionada, preservando identidade, indicação, riscos e prontidão materno-neonatal."
    },
    {
      "id": 67,
      "deck": "Urologia",
      "front": "Por que stent e cateter precisam de plano de saída?",
      "back": "Porque presença, lado e necessidade de retirada ou seguimento precisam chegar ao handoff e ao registro, evitando dispositivos esquecidos."
    },
    {
      "id": 68,
      "deck": "Urologia",
      "front": "Como agir diante de perda súbita de fluxo de irrigação?",
      "back": "Comunicar e interromper a progressão até avaliar conexões, drenagem e sistema conforme função da equipe; não compensar cegamente com mais pressão."
    },
    {
      "id": 69,
      "deck": "Vascular",
      "front": "Por que clampeamento e reperfusão devem ter horário registrado?",
      "back": "São marcos clínicos e operatórios que orientam comunicação, decisões e documentação; não devem depender de memória retrospectiva."
    },
    {
      "id": 70,
      "deck": "Vascular",
      "front": "O que diferencia disponibilidade de abertura antecipada de um enxerto?",
      "back": "Disponibilidade mantém alternativas prontas; abertura só ocorre após confirmação de modelo, tamanho e decisão, preservando esterilidade e recursos."
    },
    {
      "id": 71,
      "deck": "Neurocirurgia",
      "front": "Navegação elimina a necessidade de confirmação anatômica?",
      "back": "Não. Registro pode perder precisão; anatomia, imagem e verificação clínica continuam essenciais."
    },
    {
      "id": 72,
      "deck": "Neurocirurgia",
      "front": "Qual barreira adicional existe para nível correto na coluna?",
      "back": "Confirmação intraoperatória do nível com imagem e concordância da equipe antes da etapa irreversível."
    },
    {
      "id": 73,
      "deck": "Cabeça e pescoço",
      "front": "Qual conflito define a via aérea compartilhada?",
      "back": "Cirurgia e anestesia dependem do mesmo espaço; qualquer manipulação exige plano e comunicação em alça fechada."
    },
    {
      "id": 74,
      "deck": "Cabeça e pescoço",
      "front": "Como reduzir troca entre múltiplas margens?",
      "back": "Usar mapa e nomenclatura acordados, confirmar lado/local e fazer leitura de retorno antes do envio."
    },
    {
      "id": 75,
      "deck": "Torácica e cardíaca",
      "front": "O que o handoff de um dreno torácico deve preservar?",
      "back": "Localização, conexão, estado do sistema, débito observado, sucção prescrita e eventos do transporte."
    },
    {
      "id": 76,
      "deck": "Torácica e cardíaca",
      "front": "Quem precisa participar dos marcos da circulação extracorpórea?",
      "back": "Cirurgia, anestesia, perfusão e enfermagem, com liderança, resposta verbal e registro de tempos."
    },
    {
      "id": 77,
      "deck": "Pediatria",
      "front": "Por que peso atualizado é uma barreira de segurança?",
      "back": "Ele influencia seleção de equipamentos, avaliação de perdas e decisões clínicas; deve ser confirmado no sistema assistencial."
    },
    {
      "id": 78,
      "deck": "Pediatria",
      "front": "Qual risco existe ao aquecer um neonato?",
      "back": "Além de hipotermia, há risco de hipertermia e lesão térmica; monitorização e dispositivo adequado são indispensáveis."
    },
    {
      "id": 79,
      "deck": "Robótica",
      "front": "Quando começa o plano de conversão?",
      "back": "No briefing, antes da incisão, com funções, acesso ao paciente, sequência de undocking e instrumental disponíveis."
    },
    {
      "id": 80,
      "deck": "Robótica",
      "front": "O que fazer diante de alerta do instrumento robótico?",
      "back": "Estabilizar, comunicar, manter controle visual quando possível e seguir a instrução do fabricante; nunca contornar o alerta."
    },
    {
      "id": 81,
      "deck": "Instrumentais",
      "front": "Por que fechar uma pinça não basta como teste funcional?",
      "back": "Porque alinhamento, pressão, cremalheira, articulação e integridade podem falhar mesmo quando a peça parece fechar."
    },
    {
      "id": 82,
      "deck": "Fios e suturas",
      "front": "Qual conferência vem antes de usar cor ou tamanho como atalho?",
      "back": "Material, estrutura, calibre, comprimento, agulha, validade, lote e integridade da embalagem."
    },
    {
      "id": 83,
      "deck": "Posicionamento",
      "front": "Quando a posição deve ser reavaliada?",
      "back": "Após qualquer mudança relevante de mesa, membro, apoio, equipamento ou acesso ao paciente."
    },
    {
      "id": 84,
      "deck": "Anatomia",
      "front": "Como reduzir ambiguidade em uma descrição anatômica?",
      "back": "Usar região, lado, plano, profundidade e relação com referências compartilhadas, sempre do ponto de vista do paciente."
    },
    {
      "id": 85,
      "deck": "CME",
      "front": "Um pacote dentro da validade pode ser recusado?",
      "back": "Sim. Umidade, dano, abertura, selagem irregular ou identificação insuficiente podem comprometer a barreira."
    },
    {
      "id": 86,
      "deck": "Anestesia e SRPA",
      "front": "Qual é a primeira resposta segura a um alarme de origem incerta?",
      "back": "Tornar o alarme visível, localizar a origem, reduzir ruído e comunicar quem conduz a anestesia, sem alterar parâmetros autonomamente."
    },
    {
      "id": 87,
      "deck": "Energia e fogo",
      "front": "Por que não aumentar potência após uma ativação ineficaz?",
      "back": "Porque a causa pode ser conexão, acessório, isolamento ou equipamento; repetir sem diagnóstico pode ampliar o dano."
    },
    {
      "id": 88,
      "deck": "Medicamentos",
      "front": "O que fazer com uma seringa de conteúdo não reconciliável?",
      "back": "Não administrar; segregar, comunicar e seguir o fluxo institucional de descarte e registro."
    },
    {
      "id": 89,
      "deck": "Documentação e ética",
      "front": "Por que registrar marcos em tempo real?",
      "back": "Para reduzir omissões e reconstruções tardias, mantendo uma linha do tempo confiável e rastreável."
    },
    {
      "id": 90,
      "deck": "Eventos críticos",
      "front": "O que torna uma ação de melhoria verificável?",
      "back": "Ter responsável, prazo, resultado esperado e forma de testar se a mudança funcionou."
    },
    {
      "id": 91,
      "deck": "Cirurgia geral",
      "front": "O que deve ocorrer antes de uma transição de contaminação?",
      "back": "Verbalizar a nova etapa e confirmar quais barreiras, materiais e contagens mudam segundo o protocolo."
    },
    {
      "id": 92,
      "deck": "Cirurgia geral",
      "front": "O que um handoff de dreno precisa preservar?",
      "back": "Local, tipo, conexão, condição, plano definido e responsável pela pendência."
    },
    {
      "id": 93,
      "deck": "Ortopedia",
      "front": "Um alarme de torniquete autoriza ajuste autônomo?",
      "back": "Não. Deve ser comunicado e tratado conforme protocolo, instrução de uso e decisão do profissional habilitado."
    },
    {
      "id": 94,
      "deck": "Ortopedia",
      "front": "Como evitar troca entre componente de prova e implante?",
      "back": "Segregar, identificar e verbalizar cada função, reconciliando modelo e tamanho antes da implantação."
    },
    {
      "id": 95,
      "deck": "Ginecologia e obstetrícia",
      "front": "Como lidar com volume de irrigação que não pode ser medido?",
      "back": "Declarar a incerteza e registrar volumes conhecidos e eventos, em vez de produzir um balanço falsamente preciso."
    },
    {
      "id": 96,
      "deck": "Ginecologia e obstetrícia",
      "front": "A urgência elimina identificação durante resposta à hemorragia?",
      "back": "Não. O fluxo pode ser acelerado, mas identidade, leitura de retorno e rastreabilidade continuam essenciais."
    },
    {
      "id": 97,
      "deck": "Urologia",
      "front": "Por que avaliar irrigação como circuito completo?",
      "back": "Porque a falha pode estar na fonte, conexão, instrumento, retorno ou coletor; olhar apenas a entrada oculta o problema."
    },
    {
      "id": 98,
      "deck": "Urologia",
      "front": "Que dado transforma “há um stent” em handoff útil?",
      "back": "Lado, identificação disponível, plano de retirada ou seguimento e responsável pela continuidade."
    },
    {
      "id": 99,
      "deck": "Vascular",
      "front": "O que precisa permanecer possível em uma sala híbrida?",
      "back": "Acesso ao paciente, proteção radiológica, circulação segura e conversão aberta planejada."
    },
    {
      "id": 100,
      "deck": "Vascular",
      "front": "Por que um explante vascular pode exigir recipientes separados?",
      "back": "Microbiologia, patologia e análise do fabricante têm requisitos e cadeias de custódia diferentes."
    },
    {
      "id": 101,
      "deck": "Neurocirurgia",
      "front": "O que fazer se navegação e anatomia divergem?",
      "back": "Interromper e verificar registro, referência, posição e imagem antes de prosseguir."
    },
    {
      "id": 102,
      "deck": "Neurocirurgia",
      "front": "Paciente e lado corretos confirmam o nível da coluna?",
      "back": "Não. O nível requer barreira própria com correlação de imagem, anatomia e concordância da equipe."
    },
    {
      "id": 103,
      "deck": "Cabeça e pescoço",
      "front": "Quais elementos formam o risco de fogo próximo à via aérea?",
      "back": "Fonte de ignição, oxidante e combustível presentes na mesma região e momento."
    },
    {
      "id": 104,
      "deck": "Cabeça e pescoço",
      "front": "O que o handoff de retalho livre deve indicar?",
      "back": "Método e local de avaliação, linha de base, frequência prescrita, última avaliação e quem acionar."
    },
    {
      "id": 105,
      "deck": "Torácica e cardíaca",
      "front": "Como tratar um pedido de reinsuflação pulmonar?",
      "back": "Como marco de comunicação em alça fechada entre cirurgia e anestesia."
    },
    {
      "id": 106,
      "deck": "Torácica e cardíaca",
      "front": "O que deve ser reconciliado antes do transporte cardíaco?",
      "back": "Linhas, drenos, fios, suportes, implantes, perdas, eventos, equipamentos e pendências."
    },
    {
      "id": 107,
      "deck": "Pediatria",
      "front": "Por que a unidade do peso deve ser confirmada?",
      "back": "Porque peso orienta decisões e cálculos; confusão entre unidades pode produzir erro grave."
    },
    {
      "id": 108,
      "deck": "Pediatria",
      "front": "Aquecer um neonato sem monitorar é seguro?",
      "back": "Não. Pode ocorrer hipertermia ou lesão térmica; o plano exige monitorização e dispositivo adequado."
    },
    {
      "id": 109,
      "deck": "Robótica",
      "front": "Quando a geometria da sala deve ser testada?",
      "back": "Antes do docking, enquanto ainda é possível reposicionar sistema, equipe e cabos sem restringir acesso."
    },
    {
      "id": 110,
      "deck": "Robótica",
      "front": "Que informação é útil ao registrar um alerta robótico?",
      "back": "Instrumento e braço, mensagem, horário, etapa, ação tomada, identificação disponível e impacto."
    },
    {
      "id": 111,
      "deck": "Procedimentos e acessos",
      "front": "Que classificações mais mudam a preparação de um procedimento?",
      "back": "Urgência, finalidade, potencial de contaminação, abordagem, posição, implantes e destino pós-operatório."
    },
    {
      "id": 112,
      "deck": "Procedimentos e acessos",
      "front": "O que a equipe perioperatória precisa antecipar em um acesso aberto?",
      "back": "Região exposta, posição, afastamento, energia, hemostasia, contagens, fechamento e possibilidade de ampliação."
    },
    {
      "id": 113,
      "deck": "Procedimentos e acessos",
      "front": "Portais laparoscópicos podem ser escolhidos pelo profissional de apoio?",
      "back": "Não. Local e técnica são decisões do operador; o apoio organiza compatibilidade, integridade, contagem e conversão."
    },
    {
      "id": 114,
      "deck": "Procedimentos e acessos",
      "front": "O que endoscopia e acesso percutâneo podem ter em comum?",
      "back": "Imagem, guias, irrigação, componentes longos, amostras e necessidade de rastrear dispositivos deixados."
    },
    {
      "id": 115,
      "deck": "Procedimentos e acessos",
      "front": "Qual é a primeira ação organizacional em uma conversão?",
      "back": "Repetir o comando, parar movimentos não essenciais, liberar acesso e redistribuir funções."
    },
    {
      "id": 116,
      "deck": "Acessos vasculares",
      "front": "Quais dados formam um mapa de acesso vascular?",
      "back": "Tipo, local, lado, lúmens, identificação, condição do curativo, função e restrições prescritas."
    },
    {
      "id": 117,
      "deck": "Acessos vasculares",
      "front": "O que fazer diante de acesso periférico doloroso, edemaciado ou com vazamento?",
      "back": "Interromper a ação insegura, avaliar e escalar conforme protocolo; não forçar a infusão."
    },
    {
      "id": 118,
      "deck": "Acessos vasculares",
      "front": "Qual é o papel do assistente em acesso venoso central?",
      "back": "Preparar barreiras e kit, ler checklist, fornecer recursos, observar quebra de técnica e rastrear componentes."
    },
    {
      "id": 119,
      "deck": "Acessos vasculares",
      "front": "Por que uma linha arterial deve ser claramente identificada?",
      "back": "Para evitar administração indevida e preservar a função específica de monitorização ou coleta."
    },
    {
      "id": 120,
      "deck": "Acessos vasculares",
      "front": "Acesso intraósseo é uma alternativa de rotina?",
      "back": "Não. É via de resgate decidida por equipe habilitada e protocolo, com treinamento e plano de substituição."
    },
    {
      "id": 121,
      "deck": "Acessos vasculares",
      "front": "Quais categorias de complicação devem ser reconhecidas em acessos?",
      "back": "Infiltração, extravasamento, flebite, oclusão, deslocamento, sangramento, trombose, embolia e infecção."
    },
    {
      "id": 122,
      "deck": "Vias, sondas e drenos",
      "front": "Quais camadas compõem uma estratégia de via aérea?",
      "back": "Plano principal, alternativas, resgate e estratégia de extubação, com equipamentos e ajuda disponíveis."
    },
    {
      "id": 123,
      "deck": "Vias, sondas e drenos",
      "front": "O que deve ficar visível durante uma crise de via aérea?",
      "back": "Tempo, oxigenação, número de tentativas, liderança e próximo plano."
    },
    {
      "id": 124,
      "deck": "Vias, sondas e drenos",
      "front": "Cateter urinário deve ser usado rotineiramente em todo procedimento?",
      "back": "Não. Precisa de indicação, inserção por pessoa treinada, sistema fechado e reavaliação para retirada."
    },
    {
      "id": 125,
      "deck": "Vias, sondas e drenos",
      "front": "Quando uma sonda gástrica ou enteral pode ser usada?",
      "back": "Depois do método de confirmação exigido pelo protocolo e da autorização da equipe responsável."
    },
    {
      "id": 126,
      "deck": "Vias, sondas e drenos",
      "front": "É seguro clampear um dreno torácico automaticamente para transportar?",
      "back": "Não. Clampeamento depende de indicação e protocolo; transporte exige sistema e conexões protegidos."
    },
    {
      "id": 127,
      "deck": "Vias, sondas e drenos",
      "front": "Como evitar confusão entre cateter regional e acesso venoso?",
      "back": "Identificação clara, conectores e bombas dedicados, separação física e handoff específico."
    },
    {
      "id": 128,
      "deck": "Assepsia e antissepsia",
      "front": "Antissepsia esteriliza a pele?",
      "back": "Não. Ela reduz a carga microbiana em tecido vivo; pele não se torna estéril."
    },
    {
      "id": 129,
      "deck": "Assepsia e antissepsia",
      "front": "O tempo de antissepsia cirúrgica das mãos é universal?",
      "back": "Não. Técnica, área e tempo seguem o produto aprovado e sua instrução de uso."
    },
    {
      "id": 130,
      "deck": "Assepsia e antissepsia",
      "front": "Pelos devem ser removidos de todo sítio cirúrgico?",
      "back": "Não. Somente quando interferem, pelo método e momento definidos pelo protocolo."
    },
    {
      "id": 131,
      "deck": "Assepsia e antissepsia",
      "front": "Por que não existe um antisséptico universal?",
      "back": "Região, pele, idade, reação prévia, mucosa, risco de fogo e IFU mudam a seleção."
    },
    {
      "id": 132,
      "deck": "Assepsia e antissepsia",
      "front": "Quando os campos podem ser colocados após produto alcoólico?",
      "back": "Após secagem completa conforme a instrução do produto e verificação de que não houve acúmulo."
    },
    {
      "id": 133,
      "deck": "Procedimentos perioperatórios",
      "front": "O que fazer com uma divergência entre pulseira, consentimento e programação?",
      "back": "Interromper o avanço e reconciliar as fontes antes do procedimento."
    },
    {
      "id": 134,
      "deck": "Procedimentos perioperatórios",
      "front": "Quando termina uma transferência de paciente?",
      "back": "Quando o paciente e dispositivos foram reavaliados e a equipe receptora aceitou a responsabilidade."
    },
    {
      "id": 135,
      "deck": "Procedimentos perioperatórios",
      "front": "Por que uma biópsia exige confirmação do meio de transporte?",
      "back": "Porque exames diferentes podem exigir recipientes ou conservantes incompatíveis."
    },
    {
      "id": 136,
      "deck": "Procedimentos perioperatórios",
      "front": "O que deve ser registrado sobre curativo e dispositivos ao final?",
      "back": "Local, condição observada, tipo, conexões, drenagem, horário e plano comunicado."
    },
    {
      "id": 137,
      "deck": "Procedimentos perioperatórios",
      "front": "O que diferencia handoff de simples envio de prontuário?",
      "back": "Comunicação ativa, oportunidade para perguntas, leitura de retorno e responsabilidade definida para pendências."
    }
  ],
  "quiz": [
    {
      "id": 1,
      "category": "Instrumentais",
      "question": "Ao comparar Kelly e Crile, qual característica deve ser observada primeiro?",
      "options": [
        "O peso total",
        "A cor do cabo",
        "A extensão da serrilha na mandíbula",
        "O fabricante gravado"
      ],
      "answer": 2,
      "explanation": "A extensão da serrilha é a diferença morfológica clássica mais útil.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 2,
      "category": "Fios e suturas",
      "question": "Qual afirmação sobre monofilamentos está correta?",
      "options": [
        "Sempre têm melhor segurança de nó",
        "São todos absorvíveis",
        "Não apresentam memória",
        "Tendem a ter menor capilaridade"
      ],
      "answer": 3,
      "explanation": "A estrutura de um único filamento tende a reduzir capilaridade, embora outras propriedades variem por material.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 3,
      "category": "Posicionamento",
      "question": "Antes de colocar os campos, qual ação é mais adequada?",
      "options": [
        "Realizar uma checagem final do alinhamento e das proteções",
        "Retirar contenções",
        "Ocultar todos os pontos de apoio",
        "Alterar a posição sem comunicar"
      ],
      "answer": 0,
      "explanation": "A checagem final deve ocorrer enquanto os pontos de apoio ainda estão visíveis.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 4,
      "category": "Assepsia",
      "question": "Se não for possível confirmar a esterilidade de um item, ele deve ser:",
      "options": [
        "Considerado contaminado",
        "Limpo com gaze",
        "Devolvido ao campo",
        "Utilizado rapidamente"
      ],
      "answer": 0,
      "explanation": "Na dúvida, o item é considerado contaminado e a equipe aplica a correção prevista.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 5,
      "category": "Fluxo de procedimentos",
      "question": "Qual tempo operatório está relacionado à aproximação e ao fechamento?",
      "options": [
        "Diérese",
        "Hemostasia",
        "Exérese",
        "Síntese"
      ],
      "answer": 3,
      "explanation": "Síntese descreve reconstrução, aproximação e fechamento dos planos.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 6,
      "category": "Anatomia",
      "question": "Qual estrutura separa e envolve compartimentos e grupos musculares?",
      "options": [
        "Epiderme",
        "Serosa",
        "Fáscia",
        "Cartilagem articular"
      ],
      "answer": 2,
      "explanation": "Fáscias envolvem estruturas e ajudam a organizar planos e compartimentos.",
      "competencyId": "C05",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 7,
      "category": "Instrumentais",
      "question": "Qual opção descreve melhor a Babcock?",
      "options": [
        "Ponta fenestrada e arredondada",
        "Dente terminal 1×2",
        "Lâmina cortante",
        "Afastador autoestático"
      ],
      "answer": 0,
      "explanation": "A ponta fenestrada e arredondada favorece manipulação mais delicada de estruturas tubulares.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 8,
      "category": "Contagens",
      "question": "Diante de uma contagem divergente, a primeira conduta é:",
      "options": [
        "Ignorar se a cirurgia foi longa",
        "Substituir toda a caixa",
        "Registrar apenas no fim do turno",
        "Comunicar imediatamente e repetir a contagem"
      ],
      "answer": 3,
      "explanation": "A divergência deve ser verbalizada imediatamente e o protocolo de busca deve ser iniciado.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 9,
      "category": "Fios e suturas",
      "question": "Na escala USP, qual fio tende a ser mais fino?",
      "options": [
        "4-0",
        "0",
        "2-0",
        "2"
      ],
      "answer": 0,
      "explanation": "Mais zeros indicam menor diâmetro: 4-0 tende a ser mais fino que 2-0.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 10,
      "category": "Espécimes e implantes",
      "question": "Qual dado é essencial na identificação de uma amostra?",
      "options": [
        "Cor favorita do paciente",
        "Modelo da mesa cirúrgica",
        "Descrição e localização do material",
        "Quantidade de pessoas na sala"
      ],
      "answer": 2,
      "explanation": "Descrição e localização, com lateralidade quando aplicável, ajudam a preservar a identidade da amostra.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 11,
      "category": "Ambiente e equipe",
      "question": "Ao entrar em uma área do centro cirúrgico cuja classificação você não conhece, a conduta mais segura é:",
      "options": [
        "Imitar outra pessoa sem perguntar",
        "Usar sempre a mesma vestimenta",
        "Circular livremente",
        "Confirmar sinalização e política local"
      ],
      "answer": 3,
      "explanation": "Zoneamento e requisitos variam; acesso e vestimenta devem ser confirmados na política da instituição.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 12,
      "category": "Ambiente e equipe",
      "question": "Uma solicitação está fora da habilitação do profissional. O que deve ocorrer?",
      "options": [
        "Executar para não atrasar",
        "Ocultar a dúvida",
        "Confirmar com o responsável e não agir sem competência",
        "Delegar informalmente a qualquer pessoa"
      ],
      "answer": 2,
      "explanation": "Limites de habilitação e supervisão são barreiras de segurança.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 13,
      "category": "Ambiente e equipe",
      "question": "Qual comunicação representa escalonamento adequado?",
      "options": [
        "Sempre fizemos assim",
        "Há algo errado, resolvam",
        "Não vou dizer nada",
        "Observei a embalagem aberta; há risco de contaminação e precisamos substituí-la"
      ],
      "answer": 3,
      "explanation": "A mensagem descreve fato, risco e ação necessária de modo objetivo.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 14,
      "category": "Cirurgia segura",
      "question": "Em qual momento são compartilhadas etapas críticas previstas antes da incisão?",
      "options": [
        "Somente após a alta",
        "Apenas na limpeza da sala",
        "Na pausa antes da incisão",
        "Depois do envio de espécimes"
      ],
      "answer": 2,
      "explanation": "A pausa antes da incisão alinha identidade, procedimento, sítio, riscos e necessidades.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 15,
      "category": "Cirurgia segura",
      "question": "Qual exemplo fecha corretamente a alça de comunicação?",
      "options": [
        "Pedido sem destinatário",
        "Repetição da mensagem e confirmação",
        "Silêncio após uma ordem",
        "Duas conversas paralelas"
      ],
      "answer": 1,
      "explanation": "A repetição por quem recebe e a confirmação por quem emitiu completam o ciclo.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 16,
      "category": "Cirurgia segura",
      "question": "Durante a saída, qual item deve ser confirmado?",
      "options": [
        "Preferência musical",
        "Somente o nome do cirurgião",
        "Contagens, espécimes e preocupações para recuperação",
        "Escala do mês seguinte"
      ],
      "answer": 2,
      "explanation": "A saída reconcilia o procedimento e as informações essenciais para continuidade do cuidado.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 17,
      "category": "Prevenção de ISC",
      "question": "A remoção de pelos no pré-operatório deve ser:",
      "options": [
        "Rotineira para todos",
        "Feita com qualquer método",
        "Realizada apenas quando indicada e conforme protocolo",
        "Delegada sem avaliação"
      ],
      "answer": 2,
      "explanation": "Remoção desnecessária e trauma cutâneo devem ser evitados.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 18,
      "category": "Prevenção de ISC",
      "question": "Foi observada quebra de técnica asséptica. A resposta mais adequada é:",
      "options": [
        "Comunicar e corrigir imediatamente",
        "Compensar com outra medida",
        "Ignorar se o procedimento for curto",
        "Registrar apenas no mês seguinte"
      ],
      "answer": 0,
      "explanation": "Barreiras atuam em conjunto, e desvios precisam de correção imediata.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 19,
      "category": "Prevenção de ISC",
      "question": "Qual afirmação sobre profilaxia antimicrobiana é correta?",
      "options": [
        "A equipe deve confirmar prescrição, administração e registro dentro de suas atribuições",
        "Alergias não precisam ser verificadas",
        "Horário não importa",
        "A aula define a dose individual"
      ],
      "answer": 0,
      "explanation": "A profilaxia é processo clínico e de equipe, orientado por prescrição e protocolo.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 20,
      "category": "Contagens",
      "question": "Uma contagem confiável é melhor descrita como:",
      "options": [
        "Silenciosa e individual",
        "Visual, audível e padronizada",
        "Feita somente se houver dúvida",
        "Substituída pela memória"
      ],
      "answer": 1,
      "explanation": "Padronização, participação simultânea, visualização e comunicação audível reduzem falhas.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 21,
      "category": "Contagens",
      "question": "Se um item não for localizado após nova contagem, a equipe deve:",
      "options": [
        "Aguardar o próximo plantão sem comunicar",
        "Declarar a contagem correta",
        "Descartar registros",
        "Seguir busca e escalonamento previstos no protocolo"
      ],
      "answer": 3,
      "explanation": "A divergência exige escalonamento, busca sistemática, decisão clínica e documentação.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 22,
      "category": "Contagens",
      "question": "Qual fator fragiliza a contagem?",
      "options": [
        "Sequência consistente",
        "Interrupções e conversas paralelas",
        "Momento protegido",
        "Registro imediato"
      ],
      "answer": 1,
      "explanation": "Interrupções e ruído elevam o risco de perder a sequência e devem ser controlados.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 23,
      "category": "Espécimes e implantes",
      "question": "Uma amostra para cultura chegou ao ponto de acondicionamento sem informação sobre conservante. O que fazer?",
      "options": [
        "Usar qualquer solução",
        "Descartar",
        "Confirmar o fluxo com laboratório e protocolo antes do envio",
        "Enviar sem identificação"
      ],
      "answer": 2,
      "explanation": "Exames diferentes exigem condições específicas; a dúvida deve ser resolvida antes do envio.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 24,
      "category": "Espécimes e implantes",
      "question": "Qual dado é relevante para rastreabilidade de implante?",
      "options": [
        "Cor da parede",
        "Horário do almoço",
        "Lote ou número de série",
        "Número de pessoas na sala"
      ],
      "answer": 2,
      "explanation": "Lote, série, referência e fabricante ajudam a vincular o produto ao paciente e ao evento.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 25,
      "category": "Espécimes e implantes",
      "question": "Um implante está dentro da validade, mas a embalagem está violada. A conduta é:",
      "options": [
        "Reembalar na sala",
        "Segregar e comunicar a não conformidade",
        "Usar porque não venceu",
        "Limpar externamente"
      ],
      "answer": 1,
      "explanation": "Integridade da embalagem é requisito; validade isolada não torna o produto utilizável.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 26,
      "category": "CME",
      "question": "Qual afirmação sobre limpeza está correta?",
      "options": [
        "É opcional antes da esterilização",
        "É etapa crítica que remove sujidade antes do processamento final",
        "Pode ser substituída por secagem",
        "Não depende do produto"
      ],
      "answer": 1,
      "explanation": "Sujidade interfere no processamento; limpeza validada precede desinfecção ou esterilização.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 27,
      "category": "CME",
      "question": "Após a limpeza, um instrumental ainda apresenta resíduo visível. Ele deve:",
      "options": [
        "Voltar para reprocessamento da limpeza",
        "Ser liberado com aviso",
        "Ser embalado",
        "Receber apenas indicador químico"
      ],
      "answer": 0,
      "explanation": "O item não atende ao critério de limpeza e não deve avançar no fluxo.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 28,
      "category": "CME",
      "question": "Um parâmetro exigido para liberação do ciclo não foi atendido. A resposta correta é:",
      "options": [
        "Liberar se houver urgência administrativa",
        "Ignorar se a embalagem estiver seca",
        "Trocar somente a etiqueta",
        "Reter o lote e investigar"
      ],
      "answer": 3,
      "explanation": "Critério não atendido exige retenção, investigação e conduta do sistema de qualidade.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 29,
      "category": "Energia, fogo e fumaça",
      "question": "Ao usar eletrocirurgia monopolar, qual elemento integra o circuito?",
      "options": [
        "Apenas a iluminação",
        "Somente o pedal",
        "Eletrodo de retorno compatível",
        "Nenhum contato com o paciente"
      ],
      "answer": 2,
      "explanation": "Na configuração monopolar, a corrente retorna ao gerador pelo eletrodo de retorno.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 30,
      "category": "Energia, fogo e fumaça",
      "question": "Oxigênio, unidade de energia e campo inflamável representam, respectivamente:",
      "options": [
        "Combustível, oxidante, ignição",
        "Três combustíveis",
        "Ignição, combustível, oxidante",
        "Oxidante, ignição, combustível"
      ],
      "answer": 3,
      "explanation": "Eles correspondem aos três componentes do triângulo do fogo.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 31,
      "category": "Energia, fogo e fumaça",
      "question": "Qual controle é prioritário para fumaça cirúrgica?",
      "options": [
        "Apenas aromatizante",
        "Captura local próxima à fonte",
        "Abrir a porta",
        "Ignorar pluma pequena"
      ],
      "answer": 1,
      "explanation": "A evacuação local impede que a pluma se disperse na zona respiratória.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 32,
      "category": "Medicamentos",
      "question": "Uma solução foi transferida para uma cuba e não recebeu rótulo. A conduta é:",
      "options": [
        "Usar pela aparência",
        "Não utilizar até identificação segura; se incerta, descartar",
        "Misturar com outra solução",
        "Perguntar depois"
      ],
      "answer": 1,
      "explanation": "Recipiente com conteúdo incerto não deve ser usado.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 33,
      "category": "Medicamentos",
      "question": "Qual prática reduz confusão entre medicamentos semelhantes?",
      "options": [
        "Preparar vários ao mesmo tempo",
        "Separar, ler rótulos e comparar com a prescrição",
        "Confiar apenas na cor",
        "Remover embalagens cedo"
      ],
      "answer": 1,
      "explanation": "Organização e leitura ativa criam barreiras contra troca.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 34,
      "category": "Medicamentos",
      "question": "Em uma dupla checagem independente:",
      "options": [
        "O segundo apenas assina",
        "O cálculo é ignorado",
        "Não é necessário ler a prescrição",
        "Cada profissional verifica os elementos críticos"
      ],
      "answer": 3,
      "explanation": "Independência evita que o segundo verificador apenas confirme a conclusão anterior.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 35,
      "category": "Anestesia e SRPA",
      "question": "Qual informação pertence à transferência para a SRPA?",
      "options": [
        "Somente nome da cirurgia",
        "Apenas o horário",
        "Preferência da equipe",
        "Técnica anestésica, eventos, via aérea, acessos e pendências"
      ],
      "answer": 3,
      "explanation": "A passagem estruturada reúne informações necessárias para continuidade segura.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 36,
      "category": "Anestesia e SRPA",
      "question": "Durante a recuperação, ocorre mudança preocupante da ventilação. A equipe deve:",
      "options": [
        "Comunicar imediatamente e acionar o protocolo",
        "Desconectar a monitorização",
        "Alterar o prontuário",
        "Aguardar a alta"
      ],
      "answer": 0,
      "explanation": "Deterioração exige reconhecimento e escalonamento sem atraso.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 37,
      "category": "Anestesia e SRPA",
      "question": "Qual afirmação sobre alta da SRPA é correta?",
      "options": [
        "Qualquer pessoa pode decidir",
        "Escore substitui avaliação",
        "Pressão de fluxo define a alta",
        "Segue critérios e decisão do médico responsável"
      ],
      "answer": 3,
      "explanation": "Alta exige critérios, avaliação e responsabilidade profissional definida.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 38,
      "category": "Segurança ocupacional",
      "question": "Após usar um perfurocortante, a melhor prática é:",
      "options": [
        "Descartar imediatamente no coletor adequado",
        "Deixá-lo sobre a mesa",
        "Reencapar de rotina",
        "Passar para outro profissional descartar"
      ],
      "answer": 0,
      "explanation": "A NR-32 atribui ao usuário a responsabilidade pelo descarte seguro.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 39,
      "category": "Segurança ocupacional",
      "question": "Após exposição ocupacional, qual ação deve ser evitada?",
      "options": [
        "Comunicar imediatamente",
        "Aplicar substância irritante não indicada",
        "Buscar avaliação ocupacional",
        "Registrar circunstâncias"
      ],
      "answer": 1,
      "explanation": "O cuidado local segue protocolo; substâncias irritantes podem agravar a lesão.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 40,
      "category": "Segurança ocupacional",
      "question": "Qual sequência reflete melhor a hierarquia de controle?",
      "options": [
        "Proteção coletiva e engenharia antes de depender apenas de EPI",
        "Sinalização sem controle",
        "Ignorar manutenção",
        "Somente EPI"
      ],
      "answer": 0,
      "explanation": "Controles na fonte e coletivos são mais robustos que depender apenas do comportamento individual.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 41,
      "category": "Documentação e ética",
      "question": "Qual registro é mais adequado?",
      "options": [
        "Sem novidades",
        "Paciente ruim",
        "Tudo normal",
        "Às 14h20, alteração comunicada ao responsável; orientação recebida e executada"
      ],
      "answer": 3,
      "explanation": "O registro é factual, cronológico e identifica comunicação e resposta.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 42,
      "category": "Documentação e ética",
      "question": "Uma anotação anterior contém erro. A conduta é:",
      "options": [
        "Apagar sem deixar histórico",
        "Pedir a outro para assinar",
        "Usar o mecanismo institucional de correção com autoria e data",
        "Ignorar sempre"
      ],
      "answer": 2,
      "explanation": "Correções precisam preservar integridade, autoria e rastreabilidade.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 43,
      "category": "Documentação e ética",
      "question": "Qual prática protege dados de saúde?",
      "options": [
        "Compartilhar senha",
        "Fotografar prontuário no celular pessoal",
        "Bloquear a tela ao se afastar",
        "Enviar por grupo informal"
      ],
      "answer": 2,
      "explanation": "Acesso individual e proteção da tela reduzem exposição não autorizada.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 44,
      "category": "Eventos críticos",
      "question": "Diante de deterioração súbita, qual ação ajuda a organizar a equipe?",
      "options": [
        "Declarar o evento, chamar ajuda e definir liderança",
        "Aguardar confirmação administrativa",
        "Executar várias tarefas sem comunicação",
        "Manter silêncio"
      ],
      "answer": 0,
      "explanation": "A crise precisa se tornar visível e ter liderança explícita.",
      "competencyId": "C18",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 45,
      "category": "Eventos críticos",
      "question": "Qual é a função de um auxílio cognitivo em uma crise?",
      "options": [
        "Ajudar a recordar e aplicar etapas do protocolo",
        "Substituir treinamento",
        "Criar doses novas",
        "Dispensar liderança"
      ],
      "answer": 0,
      "explanation": "A ferramenta reduz omissões, mas requer treinamento, liderança e adaptação local.",
      "competencyId": "C18",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 46,
      "category": "Eventos críticos",
      "question": "Um debriefing após simulação deve:",
      "options": [
        "Buscar culpado",
        "Ocorrer somente anos depois",
        "Evitar qualquer registro",
        "Identificar falhas do sistema e plano de melhoria"
      ],
      "answer": 3,
      "explanation": "O debriefing transforma observações em melhorias com responsáveis e prazos.",
      "competencyId": "C18",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 47,
      "category": "Instrumentais",
      "question": "Ao receber um instrumental desconhecido, qual abordagem reduz mais o risco de identificação incorreta?",
      "options": [
        "Memorizar apenas a cor",
        "Observar ponta, articulação, serrilha, dentes e função provável",
        "Usar o nome de uma peça parecida",
        "Classificar somente pelo comprimento"
      ],
      "answer": 1,
      "explanation": "A leitura sistemática da construção e da função é mais segura que depender de aparência geral ou nome isolado.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 48,
      "category": "Instrumentais",
      "question": "Para diferenciar hemostáticas semelhantes, a observação mais informativa costuma ser:",
      "options": [
        "A embalagem da caixa",
        "O número de anéis",
        "O brilho do metal",
        "A mandíbula aberta, incluindo dentes e extensão da serrilha"
      ],
      "answer": 3,
      "explanation": "Dentes e padrão de serrilha na mandíbula ajudam a distinguir instrumentos de contorno semelhante.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 49,
      "category": "Instrumentais",
      "question": "Uma pinça apresenta cremalheira que se solta durante o teste funcional. O que fazer?",
      "options": [
        "Retirá-la de uso e comunicar a não conformidade",
        "Usá-la apenas em tecido leve",
        "Colocá-la no fundo da mesa",
        "Apertar com outro instrumento"
      ],
      "answer": 0,
      "explanation": "Falha de travamento compromete função e segurança; o item deve ser segregado e encaminhado pelo fluxo adequado.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 50,
      "category": "Instrumentais",
      "question": "Por que uma tesoura delicada não deve ser usada rotineiramente para cortar materiais resistentes?",
      "options": [
        "Porque muda de cor",
        "Porque deixa de ser esterilizável",
        "Porque fica mais curta",
        "Porque pode perder alinhamento e fio de corte"
      ],
      "answer": 3,
      "explanation": "Uso incompatível pode danificar lâminas e articulação, comprometendo desempenho futuro.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 51,
      "category": "Instrumentais",
      "question": "Na conferência de uma caixa, falta uma peça prevista na lista. A melhor conduta é:",
      "options": [
        "Ocultar para evitar atraso",
        "Registrar e comunicar a discrepância antes do uso",
        "Substituir por qualquer peça",
        "Alterar a lista sem autorização"
      ],
      "answer": 1,
      "explanation": "A discrepância precisa ser reconciliada antes do procedimento para proteger planejamento e rastreabilidade.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 52,
      "category": "Instrumentais",
      "question": "Um instrumental isolado apresenta fissura visível no revestimento. Ele deve:",
      "options": [
        "Ser usado com potência menor",
        "Ser coberto com fita",
        "Ser retirado de uso para avaliação",
        "Ser usado apenas uma vez"
      ],
      "answer": 2,
      "explanation": "Dano no isolamento pode permitir energia em local não intencional e exige segregação e avaliação técnica.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 53,
      "category": "Instrumentais",
      "question": "Durante a passagem, o profissional não tem certeza sobre o instrumento solicitado. A resposta mais segura é:",
      "options": [
        "Passar o mais parecido",
        "Confirmar o nome ou a função antes da entrega",
        "Permanecer em silêncio",
        "Entregar duas peças sem avisar"
      ],
      "answer": 1,
      "explanation": "Antecipação não substitui comunicação; a dúvida deve ser confirmada para evitar erro.",
      "competencyId": "C01",
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 54,
      "category": "Fios e suturas",
      "question": "A perda de resistência tênsil de um fio absorvível ocorre necessariamente no mesmo momento da absorção completa?",
      "options": [
        "Sim, sempre",
        "Somente em fios naturais",
        "Somente em monofilamentos",
        "Não; são eventos distintos"
      ],
      "answer": 3,
      "explanation": "Um material pode perder capacidade de sustentação antes de ser completamente absorvido.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 55,
      "category": "Fios e suturas",
      "question": "A escolha entre agulha cilíndrica e cortante depende principalmente de:",
      "options": [
        "Características do tecido e técnica",
        "Preferência do fornecedor",
        "Cor do envelope",
        "Comprimento do fio apenas"
      ],
      "answer": 0,
      "explanation": "A geometria da ponta deve ser compatível com a resistência e o comportamento do tecido.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 56,
      "category": "Fios e suturas",
      "question": "Um envelope de sutura está dentro da validade, mas apresenta abertura parcial. A conduta é:",
      "options": [
        "Usar porque não venceu",
        "Reesterilizar na sala",
        "Não utilizar e seguir o fluxo de não conformidade",
        "Fechar com fita"
      ],
      "answer": 2,
      "explanation": "Validade não compensa perda de integridade da barreira estéril.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 57,
      "category": "Fios e suturas",
      "question": "Qual afirmação evita uma generalização indevida sobre fios?",
      "options": [
        "Multifilamento é sempre melhor",
        "Monofilamento é sempre mais seguro",
        "A seleção depende de tecido, técnica, risco e propriedades do material",
        "Todo fio absorvível é igual"
      ],
      "answer": 2,
      "explanation": "Não há material universalmente superior; a escolha é contextual e clínica.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 58,
      "category": "Fios e suturas",
      "question": "Uma agulha cai fora do campo e não é imediatamente localizada. O que deve ocorrer?",
      "options": [
        "Ignorar por ser pequena",
        "Adicionar outra sem registro",
        "Comunicar e aplicar o protocolo de contagem e busca",
        "Encerrar a contagem"
      ],
      "answer": 2,
      "explanation": "Perda de agulha é evento de contagem e exige comunicação e busca sistemática.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 59,
      "category": "Fios e suturas",
      "question": "Ao abrir um fio, quais dados devem ser conferidos além do calibre?",
      "options": [
        "Apenas a marca",
        "Somente a cor",
        "Número da sala",
        "Material, estrutura, comprimento, agulha, validade e integridade"
      ],
      "answer": 3,
      "explanation": "A apresentação completa determina compatibilidade com a solicitação e segurança do uso.",
      "competencyId": "C02",
      "sourceIds": [
        "suture-review",
        "nr32"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 60,
      "category": "Posicionamento",
      "question": "Qual conjunto corresponde à varredura de posicionamento ensinada na plataforma?",
      "options": [
        "Cor, peso, altura, idade e sexo",
        "Anestesia, sutura, contagem, amostra e alta",
        "Alinhamento, respiração, circulação, nervos e pele",
        "Mesa, foco, porta, relógio e piso"
      ],
      "answer": 2,
      "explanation": "Os cinco eixos ajudam a revisar riscos sistêmicos e pontos de apoio.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 61,
      "category": "Posicionamento",
      "question": "Após mudar a inclinação da mesa com o paciente já coberto, a equipe deve:",
      "options": [
        "Presumir que tudo permaneceu igual",
        "Reavaliar alinhamento, fixações, acessos e pontos de pressão",
        "Retirar a monitorização",
        "Esperar o fim do caso"
      ],
      "answer": 1,
      "explanation": "Movimentações podem alterar apoios, dispositivos e risco de deslizamento.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 62,
      "category": "Posicionamento",
      "question": "Qual situação aumenta risco de lesão nervosa?",
      "options": [
        "Pressão focal ou estiramento mantido",
        "Alinhamento neutro",
        "Acolchoamento verificado",
        "Reavaliação periódica"
      ],
      "answer": 0,
      "explanation": "Compressão e estiramento prolongados são mecanismos relevantes de dano neural.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 63,
      "category": "Posicionamento",
      "question": "No decúbito lateral, qual checagem é apropriada?",
      "options": [
        "Confirmar alinhamento cervical e proteção de orelha e membros",
        "Apoiar todo o peso no ombro",
        "Deixar a orelha dobrada",
        "Ocultar os pontos de apoio antes de verificar"
      ],
      "answer": 0,
      "explanation": "Cabeça, orelha, plexo braquial, membros e proeminências precisam de proteção.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 64,
      "category": "Posicionamento",
      "question": "Em posição prona, qual risco requer atenção específica?",
      "options": [
        "Pressão sobre olhos e face",
        "Ausência total de pressão",
        "Somente a cor do campo",
        "Apenas o comprimento da mesa"
      ],
      "answer": 0,
      "explanation": "Face, olhos, tórax, genitais e proeminências precisam de avaliação e proteção.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 65,
      "category": "Posicionamento",
      "question": "Um procedimento prolongou-se além do previsto. Qual resposta é mais adequada?",
      "options": [
        "Manter tudo sem revisão",
        "Definir e executar reavaliações de posição e proteção",
        "Remover contenções",
        "Aguardar que o paciente relate dor"
      ],
      "answer": 1,
      "explanation": "Tempo e alterações intraoperatórias justificam reavaliação dos riscos do posicionamento.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 66,
      "category": "Posicionamento",
      "question": "O registro do posicionamento deve incluir, conforme protocolo:",
      "options": [
        "Somente o nome da posição",
        "Posição, dispositivos de proteção, alterações e intercorrências relevantes",
        "Apenas o horário de entrada",
        "Preferência pessoal da equipe"
      ],
      "answer": 1,
      "explanation": "Documentação precisa permitir continuidade, rastreabilidade e análise do cuidado.",
      "competencyId": "C03",
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 67,
      "category": "Assepsia",
      "question": "Uma embalagem esterilizada está úmida ao chegar ao campo. A conduta é:",
      "options": [
        "Secar externamente",
        "Considerar a barreira comprometida e substituir",
        "Abrir rapidamente",
        "Cobrir com outro campo"
      ],
      "answer": 1,
      "explanation": "Umidade pode comprometer a barreira; o item deve seguir o protocolo de não conformidade.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 68,
      "category": "Assepsia",
      "question": "Um campo estéril ficou sem observação em uma sala vazia. Ao retornar, a equipe deve:",
      "options": [
        "Presumir esterilidade",
        "Avaliar conforme protocolo e, se não confirmável, considerá-lo contaminado",
        "Usar apenas o centro",
        "Borrifar antisséptico"
      ],
      "answer": 1,
      "explanation": "Esterilidade precisa ser continuamente protegida e não pode ser presumida quando houve perda de controle.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 69,
      "category": "Assepsia",
      "question": "Por que bordas e áreas abaixo do nível do campo exigem atenção?",
      "options": [
        "Porque são sempre mais claras",
        "Porque podem não integrar a área estéril definida pelo protocolo",
        "Porque não recebem luz",
        "Porque são descartadas em todos os casos"
      ],
      "answer": 1,
      "explanation": "Limites do campo devem ser conhecidos e respeitados conforme a política institucional.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 70,
      "category": "Assepsia",
      "question": "Ao abrir um pacote estéril, qual prática é mais segura?",
      "options": [
        "Cruzar os braços sobre o conteúdo",
        "Tocar a parte interna para estabilizar",
        "Abrir de modo que mãos e vestimenta não passem sobre o campo",
        "Apoiar o pacote no chão"
      ],
      "answer": 2,
      "explanation": "A técnica de abertura deve evitar cruzamento e contato com áreas estéreis.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 71,
      "category": "Assepsia",
      "question": "Um membro observa possível quebra de técnica. O comportamento esperado é:",
      "options": [
        "Silenciar por hierarquia",
        "Comunicar imediatamente para avaliação e correção",
        "Comentar apenas no final",
        "Cobrir o local sem avisar"
      ],
      "answer": 1,
      "explanation": "Qualquer pessoa deve poder verbalizar risco de contaminação sem hesitação.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 72,
      "category": "Assepsia",
      "question": "Um instrumento estéril fica pendente abaixo do nível da mesa. A equipe deve:",
      "options": [
        "Continuar usando sem avaliação",
        "Aplicar a regra institucional para área abaixo do campo e substituir se necessário",
        "Limpar com gaze",
        "Colocar de volta sem comunicar"
      ],
      "answer": 1,
      "explanation": "Áreas fora dos limites reconhecidos podem ser contaminadas e exigem conduta protocolada.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 73,
      "category": "Assepsia",
      "question": "A manga estéril toca superfície não estéril. O que fazer?",
      "options": [
        "Comunicar e substituir ou corrigir a barreira conforme protocolo",
        "Ignorar se o toque foi breve",
        "Aplicar álcool sobre o avental",
        "Cobrir com a mão"
      ],
      "answer": 0,
      "explanation": "Duração curta não elimina contaminação; a barreira comprometida deve ser corrigida.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 74,
      "category": "Assepsia",
      "question": "Quando a esterilidade de um item é incerta, o princípio seguro é:",
      "options": [
        "Usá-lo se for caro",
        "Usá-lo em tecido profundo",
        "Considerá-lo contaminado",
        "Pedir ao paciente decidir"
      ],
      "answer": 2,
      "explanation": "Na dúvida não resolvida, o item não deve entrar no campo.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 75,
      "category": "Assepsia",
      "question": "Qual intervenção ajuda a proteger a técnica asséptica na sala?",
      "options": [
        "Aumentar entradas e saídas",
        "Manter portas abertas",
        "Armazenar caixas no campo",
        "Antecipar materiais e reduzir tráfego desnecessário"
      ],
      "answer": 3,
      "explanation": "Planejamento e controle de circulação reduzem interrupções e dificuldades de controle ambiental.",
      "competencyId": "C04",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 76,
      "category": "Anatomia",
      "question": "Por que a leitura por planos ajuda no estudo de procedimentos?",
      "options": [
        "Porque elimina variações",
        "Porque define a técnica sozinho",
        "Porque organiza relações entre camadas, estruturas e acesso",
        "Porque substitui anatomia específica"
      ],
      "answer": 2,
      "explanation": "Planos oferecem um mapa, mas precisam ser complementados pela anatomia regional e pela técnica.",
      "competencyId": "C05",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 77,
      "category": "Anatomia",
      "question": "Quadrantes abdominais devem ser interpretados como:",
      "options": [
        "Limites rígidos dos órgãos",
        "Referências de localização clínica",
        "Substitutos de exames",
        "Mapas idênticos em todas as posições"
      ],
      "answer": 1,
      "explanation": "Órgãos atravessam regiões e mudam com biotipo, respiração e posicionamento.",
      "competencyId": "C05",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 78,
      "category": "Anatomia",
      "question": "No campo operatório, o que orienta melhor a identificação de uma estrutura?",
      "options": [
        "Apenas a cor",
        "Relações anatômicas, planos e referências do procedimento",
        "Somente o tamanho",
        "Uma ilustração genérica isolada"
      ],
      "answer": 1,
      "explanation": "Relações e contexto são mais confiáveis que um atributo visual isolado.",
      "competencyId": "C05",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 79,
      "category": "Anatomia",
      "question": "Como o conteúdo deve tratar variações anatômicas?",
      "options": [
        "Como possibilidades que exigem reconhecimento por profissional habilitado",
        "Como inexistentes",
        "Como erros do paciente",
        "Como regras universais"
      ],
      "answer": 0,
      "explanation": "Variações são esperadas e reforçam a necessidade de conhecimento e julgamento especializado.",
      "competencyId": "C05",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 80,
      "category": "Anatomia",
      "question": "Antes de estudar uma cirurgia de especialidade, a revisão anatômica deve priorizar:",
      "options": [
        "Acesso, estruturas-alvo, relações, vasos, nervos e riscos do procedimento",
        "Somente o fechamento",
        "Apenas nomes de instrumentos",
        "Somente anatomia de superfície"
      ],
      "answer": 0,
      "explanation": "Anatomia aplicada precisa estar vinculada ao acesso e às estruturas em risco.",
      "competencyId": "C05",
      "sourceIds": [
        "openstax-anatomy"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 81,
      "category": "Fluxo de procedimentos",
      "question": "Os tempos diérese, hemostasia, exérese e síntese devem ser entendidos como:",
      "options": [
        "Regra de duração",
        "Etapas que nunca se repetem",
        "Mapa mental de ações que podem se alternar",
        "Lista de profissionais"
      ],
      "answer": 2,
      "explanation": "Na prática, ações podem se sobrepor e reaparecer ao longo do procedimento.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 82,
      "category": "Fluxo de procedimentos",
      "question": "Antecipação segura significa:",
      "options": [
        "Executar sem solicitação",
        "Acompanhar a etapa, preparar opções e confirmar antes da passagem",
        "Adivinhar em silêncio",
        "Ignorar o campo"
      ],
      "answer": 1,
      "explanation": "Antecipar é estar preparado, sem substituir comunicação ou autorização.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 83,
      "category": "Fluxo de procedimentos",
      "question": "Um espécime foi retirado e o tipo de exame não está claro. A equipe deve:",
      "options": [
        "Escolher qualquer conservante",
        "Confirmar exame e acondicionamento antes do envio",
        "Deixar sem identificação",
        "Enviar ao destino mais próximo"
      ],
      "answer": 1,
      "explanation": "A cadeia segura depende de destino e conservação definidos antes da transferência.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 84,
      "category": "Fluxo de procedimentos",
      "question": "Na desmontagem da sala, instrumentais articulados devem seguir:",
      "options": [
        "Preferência individual",
        "Mistura com resíduos",
        "Orientação do fabricante e protocolo de transporte ao CME",
        "Fechamento máximo de todas as cremalheiras"
      ],
      "answer": 2,
      "explanation": "Preparação para transporte e limpeza depende da construção e da instrução validada.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 85,
      "category": "Fluxo de procedimentos",
      "question": "Um bom estudo prévio de procedimento inclui possibilidade de conversão porque:",
      "options": [
        "Pode alterar acesso, equipamentos, instrumentais e recursos",
        "Conversão é sempre erro",
        "Serve apenas para faturamento",
        "Elimina o checklist"
      ],
      "answer": 0,
      "explanation": "Antecipar alternativas permite preparar recursos e comunicação sem presumir que serão usados.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 86,
      "category": "Fluxo de procedimentos",
      "question": "No encerramento, uma pendência de equipamento deve:",
      "options": [
        "Ser esquecida",
        "Permanecer conectada",
        "Ser comunicada, registrada e encaminhada com responsável definido",
        "Ser atribuída sem evidência"
      ],
      "answer": 2,
      "explanation": "O debriefing precisa transformar pendências em ações rastreáveis.",
      "competencyId": "C06",
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 87,
      "category": "Ambiente e equipe",
      "question": "A classificação de áreas do centro cirúrgico deve orientar:",
      "options": [
        "Somente decoração",
        "Diagnóstico clínico",
        "Escolha do fio",
        "Acesso, vestimenta, circulação e barreiras"
      ],
      "answer": 3,
      "explanation": "Zoneamento organiza comportamento e controle do ambiente conforme a instituição.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 88,
      "category": "Ambiente e equipe",
      "question": "Um carrinho contaminado tenta retornar por fluxo destinado a material processado. O que fazer?",
      "options": [
        "Permitir se estiver coberto",
        "Remover a identificação",
        "Interromper e redirecionar ao fluxo definido",
        "Misturar os materiais"
      ],
      "answer": 2,
      "explanation": "Cruzamento de fluxo pode romper barreiras entre sujo e processado.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 89,
      "category": "Ambiente e equipe",
      "question": "Qual medida reduz circulação desnecessária durante o procedimento?",
      "options": [
        "Solicitar uma pessoa por item",
        "Abrir a porta para facilitar",
        "Guardar itens fora da sala sem plano",
        "Antecipar materiais e controlar entradas"
      ],
      "answer": 3,
      "explanation": "Planejamento diminui interrupções e abertura frequente de portas.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 90,
      "category": "Ambiente e equipe",
      "question": "Uma preocupação de segurança não foi resolvida após a primeira comunicação. O profissional deve:",
      "options": [
        "Desistir",
        "Alterar o registro",
        "Escalar pela cadeia de comando, mantendo relato objetivo",
        "Executar fora de sua competência"
      ],
      "answer": 2,
      "explanation": "Risco persistente exige escalonamento claro dentro da estrutura institucional.",
      "competencyId": "C07",
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 91,
      "category": "Cirurgia segura",
      "question": "Antes da indução anestésica, qual confirmação pertence à entrada do checklist?",
      "options": [
        "Contagem final",
        "Identidade, procedimento, local e riscos relevantes",
        "Envio de espécimes",
        "Limpeza terminal"
      ],
      "answer": 1,
      "explanation": "A entrada reúne verificações essenciais antes do início do ato anestésico.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 92,
      "category": "Cirurgia segura",
      "question": "Na pausa, há divergência entre o procedimento verbalizado e o documento. A equipe deve:",
      "options": [
        "Interromper e resolver a discrepância antes da incisão",
        "Ignorar se o paciente estiver anestesiado",
        "Escolher por maioria",
        "Prosseguir e corrigir depois"
      ],
      "answer": 0,
      "explanation": "A pausa existe para detectar e resolver inconsistências antes de dano.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 93,
      "category": "Cirurgia segura",
      "question": "Qual item pertence à saída do checklist?",
      "options": [
        "Somente o nome da sala",
        "Confirmação do plano de recuperação e de espécimes",
        "Seleção da anestesia futura",
        "Classificação do instrumental novo"
      ],
      "answer": 1,
      "explanation": "A saída reconcilia procedimento, contagens, amostras, equipamentos e continuidade.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 94,
      "category": "Cirurgia segura",
      "question": "Em comunicação em alça fechada, após receber uma solicitação crítica, a pessoa deve:",
      "options": [
        "Apenas acenar",
        "Repetir a mensagem e aguardar confirmação",
        "Perguntar a outra pessoa",
        "Executar sem identificar o paciente"
      ],
      "answer": 1,
      "explanation": "Read-back e confirmação reduzem ambiguidades.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 95,
      "category": "Cirurgia segura",
      "question": "Qual é o objetivo principal do briefing?",
      "options": [
        "Culpar antecipadamente",
        "Substituir a avaliação",
        "Compartilhar plano, riscos, necessidades e alternativas",
        "Eliminar documentação"
      ],
      "answer": 2,
      "explanation": "O briefing cria um modelo mental comum antes do procedimento.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 96,
      "category": "Cirurgia segura",
      "question": "Uma instituição adapta a lista da OMS. Qual princípio deve preservar?",
      "options": [
        "Manter barreiras essenciais e validar a adaptação local",
        "Transformar em assinatura burocrática",
        "Usar apenas em cirurgias longas",
        "Eliminar participação da equipe"
      ],
      "answer": 0,
      "explanation": "A lista pode ser adaptada, mas não deve perder objetivos críticos nem participação.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 97,
      "category": "Cirurgia segura",
      "question": "Na transferência de cuidado, conversas paralelas estão impedindo a escuta. A melhor ação é:",
      "options": [
        "Entregar apenas o prontuário",
        "Falar mais rápido",
        "Omitir pendências",
        "Pausar e restabelecer ambiente de atenção compartilhada"
      ],
      "answer": 3,
      "explanation": "Passagem segura exige escuta, oportunidade de perguntas e confirmação.",
      "competencyId": "C08",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 98,
      "category": "Prevenção de ISC",
      "question": "A remoção de pelos deve ocorrer:",
      "options": [
        "Somente quando indicada e conforme método e momento protocolados",
        "Em todos os pacientes",
        "Com qualquer lâmina",
        "Sempre na véspera em casa"
      ],
      "answer": 0,
      "explanation": "Remoção desnecessária e trauma cutâneo podem aumentar risco.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 99,
      "category": "Prevenção de ISC",
      "question": "A profilaxia antimicrobiana atrasou além do momento definido. O papel da equipe é:",
      "options": [
        "Comunicar e seguir decisão clínica e protocolo",
        "Administrar dose diferente",
        "Ocultar o horário",
        "Cancelar o registro"
      ],
      "answer": 0,
      "explanation": "Divergência de tempo precisa ser reconhecida e gerenciada pela equipe responsável.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 100,
      "category": "Prevenção de ISC",
      "question": "Após preparo da pele com produto inflamável, antes de usar energia deve-se:",
      "options": [
        "Ignorar acúmulo",
        "Cumprir aplicação e secagem conforme fabricante e protocolo",
        "Cobrir área ainda úmida",
        "Aumentar oxigênio sem comunicar"
      ],
      "answer": 1,
      "explanation": "Secagem e prevenção de acúmulo reduzem risco de incêndio e lesão.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 101,
      "category": "Prevenção de ISC",
      "question": "Uma quebra de técnica foi corrigida com substituição do item. O evento deixa de precisar de comunicação?",
      "options": [
        "Apenas após a alta",
        "Sim, sempre",
        "Somente se houver foto",
        "Não; comunicação e registro seguem relevância e protocolo"
      ],
      "answer": 3,
      "explanation": "Correção imediata não elimina necessidade de transparência e aprendizado.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 102,
      "category": "Prevenção de ISC",
      "question": "No pós-operatório, surgem sinais compatíveis com possível complicação da ferida. O estudante deve:",
      "options": [
        "Diagnosticar pela aula",
        "Ignorar até a próxima aula",
        "Recomendar medicamento",
        "Orientar avaliação clínica e seguir o fluxo do serviço"
      ],
      "answer": 3,
      "explanation": "Material educacional não substitui avaliação e diagnóstico clínicos.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 103,
      "category": "Prevenção de ISC",
      "question": "Qual afirmação representa melhor uma estratégia de prevenção de ISC?",
      "options": [
        "Conjunto coordenado de barreiras pré, intra e pós-operatórias",
        "Somente uso de antibiótico",
        "Uma medida isolada resolve tudo",
        "Somente limpeza da sala"
      ],
      "answer": 0,
      "explanation": "Prevenção depende de pacote coerente de medidas e adesão ao sistema.",
      "competencyId": "C09",
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 104,
      "category": "Contagens",
      "question": "Uma contagem é interrompida por chamada urgente e a sequência se perde. O que fazer?",
      "options": [
        "Continuar de memória",
        "Registrar como correta",
        "Estimar o restante",
        "Reiniciar a etapa indicada conforme protocolo"
      ],
      "answer": 3,
      "explanation": "Perda da sequência torna o resultado não confiável.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 105,
      "category": "Contagens",
      "question": "Novas compressas são adicionadas após a linha de base. Elas devem:",
      "options": [
        "Entrar sem registro",
        "Ser anunciadas e incorporadas ao controle",
        "Substituir a contagem anterior",
        "Ficar fora da sala"
      ],
      "answer": 1,
      "explanation": "Itens adicionados precisam integrar a contagem para preservar reconciliação.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 106,
      "category": "Contagens",
      "question": "Após nova contagem, a divergência persiste. Qual sequência é apropriada?",
      "options": [
        "Declarar correta",
        "Descartar recipientes",
        "Encerrar o registro",
        "Comunicar liderança, manter busca sistemática e seguir escalonamento"
      ],
      "answer": 3,
      "explanation": "Divergência persistente exige protocolo, decisão clínica e documentação.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 107,
      "category": "Contagens",
      "question": "Em emergência que impede uma contagem planejada, a equipe deve:",
      "options": [
        "Priorizar o paciente e documentar a exceção e ações subsequentes",
        "Omitir o evento",
        "Falsificar resultado",
        "Eliminar a política"
      ],
      "answer": 0,
      "explanation": "Urgência pode modificar a sequência, mas não elimina comunicação, reconciliação e registro.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 108,
      "category": "Contagens",
      "question": "Qual registro é inadequado quando existe divergência conhecida?",
      "options": [
        "Contagem divergente comunicada",
        "Busca realizada conforme protocolo",
        "Contagem correta sem reconciliação",
        "Liderança notificada"
      ],
      "answer": 2,
      "explanation": "Nunca se deve registrar resultado correto quando a discrepância permanece.",
      "competencyId": "C10",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 109,
      "category": "Espécimes e implantes",
      "question": "Um recipiente com espécime está sem rótulo e há dois pacientes em sequência. A conduta é:",
      "options": [
        "Interromper o fluxo e aplicar o protocolo de identificação de não conformidade",
        "Adivinhar pelo aspecto",
        "Usar o rótulo do primeiro",
        "Enviar sem solicitação"
      ],
      "answer": 0,
      "explanation": "A identidade não pode ser presumida; a discrepância exige resposta formal.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 110,
      "category": "Espécimes e implantes",
      "question": "Uma amostra para cultura foi colocada em conservante de histologia por engano. A primeira ação é:",
      "options": [
        "Enviar silenciosamente",
        "Trocar o rótulo",
        "Comunicar imediatamente e seguir orientação do laboratório e protocolo",
        "Adicionar água"
      ],
      "answer": 2,
      "explanation": "Conservante inadequado pode comprometer exame e exige avaliação rápida, sem improviso.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 111,
      "category": "Espécimes e implantes",
      "question": "Qual conjunto sustenta melhor a rastreabilidade de implante?",
      "options": [
        "Cor e peso",
        "Fabricante, referência, lote ou série, validade e paciente",
        "Nome da sala apenas",
        "Número de profissionais"
      ],
      "answer": 1,
      "explanation": "Esses dados vinculam o produto utilizado ao paciente e ao registro.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 112,
      "category": "Espécimes e implantes",
      "question": "Um implante compatível está com embalagem amassada e selagem duvidosa. O que fazer?",
      "options": [
        "Usar porque é compatível",
        "Reesterilizar sem autorização",
        "Cobrir com campo",
        "Segregar e obter alternativa íntegra"
      ],
      "answer": 3,
      "explanation": "Compatibilidade não substitui integridade da barreira e rastreabilidade.",
      "competencyId": "C11",
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 113,
      "category": "CME",
      "question": "Por que a limpeza é indispensável antes da esterilização?",
      "options": [
        "Porque substitui inspeção",
        "Apenas para melhorar aparência",
        "Porque resíduos interferem no processo e protegem microrganismos",
        "Porque elimina necessidade de secagem"
      ],
      "answer": 2,
      "explanation": "Processamento final não compensa limpeza inadequada.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 114,
      "category": "CME",
      "question": "Um produto que entra em tecido estéril é classificado, em princípio, como:",
      "options": [
        "Crítico",
        "Não crítico",
        "Semicrítico apenas",
        "Doméstico"
      ],
      "answer": 0,
      "explanation": "Produtos críticos requerem esterilização quando aplicável, respeitando norma e fabricante.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 115,
      "category": "CME",
      "question": "Após limpeza, há resíduo em uma articulação. O próximo passo é:",
      "options": [
        "Embalar",
        "Liberar com etiqueta",
        "Aplicar indicador químico",
        "Retornar à etapa de limpeza"
      ],
      "answer": 3,
      "explanation": "Item com sujidade não pode avançar para preparo ou esterilização.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 116,
      "category": "CME",
      "question": "Por que articulações costumam ser preparadas na configuração indicada pelo fabricante?",
      "options": [
        "Para aumentar peso",
        "Para reduzir identificação",
        "Para esconder dano",
        "Para permitir acesso do agente e evitar tensão ou bloqueio"
      ],
      "answer": 3,
      "explanation": "Montagem precisa favorecer limpeza, contato do agente e integridade do produto.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 117,
      "category": "CME",
      "question": "A embalagem de um produto deve ser compatível com:",
      "options": [
        "Método, produto, selagem, transporte e abertura asséptica",
        "Somente a cor institucional",
        "Preferência do turno",
        "Qualquer ciclo disponível"
      ],
      "answer": 0,
      "explanation": "O sistema de barreira integra o processo e precisa ser validado para o método.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 118,
      "category": "CME",
      "question": "Uma embalagem sai úmida do processo. A melhor conduta é:",
      "options": [
        "Secar com pano",
        "Distribuir rapidamente",
        "Reter e investigar conforme protocolo",
        "Colocar outra embalagem por fora"
      ],
      "answer": 2,
      "explanation": "Umidade compromete integridade e pode indicar falha do ciclo, carga ou secagem.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 119,
      "category": "CME",
      "question": "Um indicador previsto não apresentou resultado aceitável. O lote deve:",
      "options": [
        "Ser liberado pela urgência",
        "Receber nova etiqueta",
        "Ser misturado a outro lote",
        "Permanecer retido para investigação"
      ],
      "answer": 3,
      "explanation": "Critério não atendido impede liberação até avaliação do sistema de qualidade.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 120,
      "category": "CME",
      "question": "Uma embalagem armazenada sofre rasgo antes do uso. O produto deve ser considerado:",
      "options": [
        "Estéril porque a data não venceu",
        "Com barreira comprometida",
        "Adequado se o rasgo for pequeno",
        "Liberado após fita"
      ],
      "answer": 1,
      "explanation": "Integridade é condição essencial; evento de dano pode invalidar o estado estéril.",
      "competencyId": "C12",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 121,
      "category": "Energia, fogo e fumaça",
      "question": "Quando o eletrodo ativo não está em uso, ele deve permanecer:",
      "options": [
        "Sob o campo",
        "Sobre o paciente",
        "Em suporte isolante apropriado",
        "Na mão de outro profissional"
      ],
      "answer": 2,
      "explanation": "O suporte reduz ativação acidental e contato com combustível ou tecido.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 122,
      "category": "Energia, fogo e fumaça",
      "question": "Líquido acumulou-se sob o eletrodo de retorno. Qual ação é adequada?",
      "options": [
        "Aumentar potência",
        "Ignorar o alarme",
        "Interromper e avaliar contato e substituição conforme fabricante",
        "Cobrir com gaze"
      ],
      "answer": 2,
      "explanation": "Umidade e contato inadequado podem concentrar corrente e causar lesão.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 123,
      "category": "Energia, fogo e fumaça",
      "question": "Qual combinação exige discussão explícita de risco de incêndio?",
      "options": [
        "Soro, prontuário e cadeira",
        "Oxidante próximo, energia e material combustível",
        "Luz, relógio e mesa",
        "Instrumental, campo seco e porta fechada"
      ],
      "answer": 1,
      "explanation": "A presença conjunta dos três elementos do triângulo do fogo eleva o risco.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 124,
      "category": "Energia, fogo e fumaça",
      "question": "Qual é a estratégia mais robusta para reduzir exposição à fumaça cirúrgica?",
      "options": [
        "Ventilação geral apenas",
        "Evacuação local próxima à fonte com filtração adequada",
        "Perfume ambiental",
        "Abrir embalagens"
      ],
      "answer": 1,
      "explanation": "Captura na fonte evita dispersão na sala e na zona respiratória.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 125,
      "category": "Energia, fogo e fumaça",
      "question": "O gerador emite alarme e o eletrodo de retorno parece parcialmente solto. A equipe deve:",
      "options": [
        "Silenciar e seguir",
        "Interromper a ativação e corrigir o problema",
        "Aumentar potência",
        "Pressionar o eletrodo com objeto"
      ],
      "answer": 1,
      "explanation": "Alarmes precisam ser investigados; prosseguir pode aumentar risco de queimadura.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 126,
      "category": "Energia, fogo e fumaça",
      "question": "Paciente possui dispositivo cardíaco implantável e haverá uso de energia. A equipe deve:",
      "options": [
        "Presumir ausência de interação",
        "Comunicar previamente e seguir plano especializado e fabricante",
        "Desligar o dispositivo sem autorização",
        "Omitir do checklist"
      ],
      "answer": 1,
      "explanation": "Interações dependem do dispositivo e do sistema de energia e exigem avaliação especializada.",
      "competencyId": "C13",
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 127,
      "category": "Medicamentos",
      "question": "Uma seringa no campo não possui rótulo. Quem a preparou não está disponível. A conduta é:",
      "options": [
        "Não utilizar e descartar conforme protocolo",
        "Perguntar ao cirurgião",
        "Usar pela cor",
        "Completar o rótulo por memória"
      ],
      "answer": 0,
      "explanation": "Conteúdo incerto não pode ser administrado.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 128,
      "category": "Medicamentos",
      "question": "Dois medicamentos têm nomes e embalagens semelhantes. Qual barreira é apropriada?",
      "options": [
        "Armazená-los juntos sem alerta",
        "Remover o rótulo",
        "Separação, destaque e leitura ativa do nome e concentração",
        "Usar apelidos"
      ],
      "answer": 2,
      "explanation": "Medicamentos LASA exigem barreiras visuais, armazenamento e confirmação.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 129,
      "category": "Medicamentos",
      "question": "Uma ordem verbal é emitida em situação urgente. A pessoa que recebe deve:",
      "options": [
        "Usar abreviações próprias",
        "Executar sem repetir",
        "Repetir os elementos críticos e registrar conforme protocolo",
        "Aguardar o fim do plantão"
      ],
      "answer": 2,
      "explanation": "Read-back e registro reduzem erro em comunicação verbal.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 130,
      "category": "Medicamentos",
      "question": "Na dupla checagem, o segundo profissional apenas pergunta se o primeiro conferiu. Isso é:",
      "options": [
        "Verificação independente",
        "Confirmação social insuficiente",
        "Cálculo automatizado",
        "Rastreabilidade completa"
      ],
      "answer": 1,
      "explanation": "A segunda pessoa precisa revisar os elementos críticos de modo independente.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 131,
      "category": "Medicamentos",
      "question": "Antes de administrar por um acesso, qual prática reduz erro de conexão?",
      "options": [
        "Confiar na posição da bomba",
        "Usar qualquer porta",
        "Desconectar todas as linhas",
        "Rastrear a linha do recipiente até o paciente"
      ],
      "answer": 3,
      "explanation": "Traçar fisicamente a linha confirma destino e reduz conexão errada.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 132,
      "category": "Medicamentos",
      "question": "Após identificar possível erro de dose já administrada, a prioridade é:",
      "options": [
        "Apagar o registro",
        "Descartar a embalagem sem registro",
        "Esperar sintomas",
        "Comunicar e garantir avaliação clínica imediata"
      ],
      "answer": 3,
      "explanation": "Proteção do paciente e escalonamento vêm antes da análise administrativa.",
      "competencyId": "C14",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 133,
      "category": "Anestesia e SRPA",
      "question": "Antes do ato anestésico, uma fonte de gás apresenta falha. A equipe deve:",
      "options": [
        "Informar e corrigir a inconformidade conforme responsabilidade e urgência",
        "Prosseguir sem comunicar",
        "Desligar alarmes",
        "Usar cilindro não identificado"
      ],
      "answer": 0,
      "explanation": "Condições mínimas de segurança precisam ser verificadas antes do início.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 134,
      "category": "Anestesia e SRPA",
      "question": "Na transferência para SRPA, quem recebe identifica dúvida sobre uma infusão. A melhor ação é:",
      "options": [
        "Assumir a concentração",
        "Registrar depois",
        "Desconectar sem comunicar",
        "Resolver a dúvida antes de encerrar a passagem"
      ],
      "answer": 3,
      "explanation": "Pendências críticas devem ser reconciliadas durante a transferência.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 135,
      "category": "Anestesia e SRPA",
      "question": "Por que tendências são importantes na recuperação?",
      "options": [
        "Porque mudanças sucessivas podem indicar deterioração",
        "Porque eliminam avaliação clínica",
        "Porque um valor isolado sempre é normal",
        "Porque substituem comunicação"
      ],
      "answer": 0,
      "explanation": "Evolução ao longo do tempo pode ser mais informativa que um único número.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 136,
      "category": "Anestesia e SRPA",
      "question": "Pressão por liberar vaga na SRPA deve:",
      "options": [
        "Antecipar alta",
        "Ser aceita sem avaliação",
        "Eliminar registro",
        "Não substituir critérios e decisão responsável"
      ],
      "answer": 3,
      "explanation": "Fluxo não pode prevalecer sobre segurança e critérios clínicos.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 137,
      "category": "Anestesia e SRPA",
      "question": "Como deve ser tratada a Resolução CFM nº 2.471/2026 em outubro de 2026?",
      "options": [
        "Como recomendação de fabricante",
        "Como norma antiga revogada",
        "Como protocolo de enfermagem",
        "Como norma publicada com prazo próprio de entrada em vigor a verificar"
      ],
      "answer": 3,
      "explanation": "A resolução foi publicada em setembro de 2026 e prevê entrada em vigor após prazo definido.",
      "competencyId": "C15",
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 138,
      "category": "Segurança ocupacional",
      "question": "Após utilizar uma agulha, o profissional deve:",
      "options": [
        "Deixá-la no campo",
        "Reencapar com duas mãos",
        "Descartá-la imediatamente no coletor adequado",
        "Entregar a alguém fora da sala"
      ],
      "answer": 2,
      "explanation": "O usuário é responsável pelo descarte seguro, reduzindo manipulação adicional.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 139,
      "category": "Segurança ocupacional",
      "question": "Após exposição a material biológico, qual ação é inadequada?",
      "options": [
        "Cuidado local conforme protocolo",
        "Comunicação imediata",
        "Avaliação ocupacional",
        "Aplicação de produto irritante não indicado"
      ],
      "answer": 3,
      "explanation": "Substâncias irritantes podem lesar o tecido e não substituem o fluxo pós-exposição.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 140,
      "category": "Segurança ocupacional",
      "question": "Foi percebido possível vazamento de gás anestésico. A conduta é:",
      "options": [
        "Ignorar se não houver odor",
        "Aumentar o fluxo",
        "Comunicar, retirar equipamento de uso quando indicado e acionar manutenção",
        "Cobrir o aparelho"
      ],
      "answer": 2,
      "explanation": "Sistemas de gases exigem controle de vazamentos e manutenção segura.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 141,
      "category": "Segurança ocupacional",
      "question": "Qual conjunto ajuda a reduzir exposição ocupacional à radiação?",
      "options": [
        "Somente velocidade",
        "Tempo, distância, blindagem e dosimetria",
        "Apenas máscara",
        "Porta aberta e luz acesa"
      ],
      "answer": 1,
      "explanation": "Esses elementos integram o plano de proteção radiológica.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 142,
      "category": "Segurança ocupacional",
      "question": "Para mover um paciente com segurança, a equipe deve:",
      "options": [
        "Planejar, usar recursos disponíveis e solicitar ajuda",
        "Improvisar com poucas pessoas",
        "Puxar por um membro",
        "Evitar comunicar"
      ],
      "answer": 0,
      "explanation": "Planejamento e recursos reduzem risco ergonômico e de queda.",
      "competencyId": "C16",
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 143,
      "category": "Documentação e ética",
      "question": "Qual anotação é mais objetiva?",
      "options": [
        "Às 10h15, sangramento observado e comunicado ao responsável",
        "Tudo péssimo",
        "Paciente difícil",
        "Parece estranho"
      ],
      "answer": 0,
      "explanation": "O registro descreve fato, horário e comunicação sem julgamento.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 144,
      "category": "Documentação e ética",
      "question": "Uma anotação tardia deve:",
      "options": [
        "Ser identificada com data, hora, autoria e referência ao evento",
        "Ser assinada por outra pessoa",
        "Apagar o registro anterior",
        "Parecer escrita no horário original"
      ],
      "answer": 0,
      "explanation": "Transparência temporal preserva autenticidade e rastreabilidade.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 145,
      "category": "Documentação e ética",
      "question": "Qual situação viola a governança de imagem clínica?",
      "options": [
        "Acesso mínimo necessário",
        "Uso em sistema institucional autorizado",
        "Registro textual no prontuário",
        "Foto do campo em celular pessoal enviada a grupo informal"
      ],
      "answer": 3,
      "explanation": "Dispositivo pessoal e canal informal expõem dados sensíveis e podem identificar o paciente.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 146,
      "category": "Documentação e ética",
      "question": "Um relatório foi enviado ao destinatário errado. O profissional deve:",
      "options": [
        "Conter e comunicar o incidente pelo canal institucional",
        "Apagar da própria caixa e silenciar",
        "Pedir segredo ao destinatário apenas",
        "Alterar o nome do arquivo"
      ],
      "answer": 0,
      "explanation": "Incidente de privacidade exige resposta institucional e preservação das informações do evento.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 147,
      "category": "Documentação e ética",
      "question": "Por que login e senha do prontuário não devem ser compartilhados?",
      "options": [
        "Porque tornam o sistema lento",
        "Porque mudam a cor da tela",
        "Porque identificam autoria e controlam acesso",
        "Porque impedem impressão"
      ],
      "answer": 2,
      "explanation": "Credencial individual sustenta segurança, autoria e auditoria.",
      "competencyId": "C17",
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 148,
      "category": "Eventos críticos",
      "question": "Durante uma crise, quem lidera deve principalmente:",
      "options": [
        "Executar todas as tarefas",
        "Abandonar o auxílio cognitivo",
        "Evitar ouvir a equipe",
        "Manter visão global, priorizar e distribuir funções"
      ],
      "answer": 3,
      "explanation": "Liderança eficaz coordena recursos e protege a atenção, sem concentrar todas as ações.",
      "competencyId": "C18",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 149,
      "category": "Eventos críticos",
      "question": "Um auxílio cognitivo institucional deve ser usado:",
      "options": [
        "Somente depois da crise",
        "Por equipe treinada, com leitor designado quando apropriado",
        "Para substituir decisão profissional",
        "Sem adaptação ou revisão"
      ],
      "answer": 1,
      "explanation": "Treinamento e função de leitor ajudam a integrar o manual à resposta real.",
      "competencyId": "C18",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 150,
      "category": "Eventos críticos",
      "question": "Qual produto esperado de um debriefing após simulação?",
      "options": [
        "Plano de melhoria com responsável e prazo",
        "Lista de culpados",
        "Eliminação do protocolo",
        "Nenhum registro"
      ],
      "answer": 0,
      "explanation": "Debriefing deve transformar observações em correções mensuráveis do sistema.",
      "competencyId": "C18",
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 151,
      "category": "Cirurgia geral",
      "question": "Antes de uma cirurgia abdominal minimamente invasiva, qual preparação reduz risco se houver necessidade de conversão?",
      "options": [
        "Considerar a conversão somente depois da falha",
        "Abrir todos os implantes e grampeadores disponíveis",
        "Posicionar equipamentos na rota de entrada da equipe",
        "Confirmar previamente acesso ao paciente, instrumental aberto essencial e funções da equipe"
      ],
      "answer": 3,
      "explanation": "A conversão é uma alternativa prevista. Acesso, materiais e funções devem ser definidos sem abertura desnecessária.",
      "competencyId": "C19",
      "sourceIds": [
        "eras-colorectal-2025",
        "aorn-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 152,
      "category": "Cirurgia geral",
      "question": "Ao iniciar uma etapa com abertura de víscera, qual comunicação é mais adequada?",
      "options": [
        "Encerrar a contagem e reiniciá-la somente no fechamento",
        "Manter a mesma organização sem informar a equipe",
        "Trocar todos os materiais por regra universal",
        "Verbalizar a mudança de risco e aplicar as barreiras previstas no protocolo"
      ],
      "answer": 3,
      "explanation": "A mudança de etapa pode alterar campo, instrumentais e contagens; deve ser reconhecida pela equipe conforme protocolo.",
      "competencyId": "C19",
      "sourceIds": [
        "anvisa-isc-2025",
        "eras-colorectal-2025"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 153,
      "category": "Cirurgia geral",
      "question": "Uma carga de grampeador parece adequada, mas a compatibilidade com o dispositivo não está confirmada. O que fazer?",
      "options": [
        "Usar porque a cor é semelhante à carga habitual",
        "Não utilizar até conferir modelo, carga e instrução do fabricante",
        "Testar a carga já acoplada dentro do campo",
        "Remover a identificação para evitar confusão"
      ],
      "answer": 1,
      "explanation": "Cor ou aparência não demonstram compatibilidade. A conferência deve ocorrer antes do uso.",
      "competencyId": "C19",
      "sourceIds": [
        "aorn-2026",
        "eras-colorectal-2025"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 154,
      "category": "Cirurgia geral",
      "question": "Um segmento intestinal chega à mesa de espécimes sem orientação anatômica clara. Qual é a melhor ação?",
      "options": [
        "Escolher a orientação pela aparência macroscópica",
        "Pausar o envio e confirmar com o cirurgião nome, orientação e exame solicitado",
        "Enviar sem orientação e explicar depois por telefone",
        "Rotular apenas como tecido abdominal"
      ],
      "answer": 1,
      "explanation": "A equipe não deve inferir origem ou orientação. A confirmação precisa ocorrer antes da saída da sala.",
      "competencyId": "C19",
      "sourceIds": [
        "aorn-specimen",
        "eras-colorectal-2025"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 155,
      "category": "Cirurgia geral",
      "question": "Uma medida isolada de recuperação acelerada conflita com a via institucional aprovada. Qual decisão é mais segura?",
      "options": [
        "Seguir a via multidisciplinar aprovada e discutir formalmente qualquer exceção",
        "Aplicar a medida isolada porque foi publicada recentemente",
        "Combinar elementos de protocolos diferentes sem registrar",
        "Deixar cada profissional aplicar sua preferência"
      ],
      "answer": 0,
      "explanation": "ERAS funciona como programa coordenado. Exceções exigem avaliação, comunicação e documentação.",
      "competencyId": "C19",
      "sourceIds": [
        "eras-colorectal-2025",
        "espen-surgery-2025"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 156,
      "category": "Cirurgia geral",
      "question": "Durante conversão para cirurgia aberta, a sala fica congestionada e a contagem ainda está em andamento. Qual prioridade organiza a transição?",
      "options": [
        "Interromper movimentos não essenciais, manter acesso ao paciente e concluir comunicação e contagem em alça fechada",
        "Continuar a conversão e reconstruir a contagem ao final",
        "Retirar materiais da sala sem registrar para liberar espaço",
        "Abrir todos os conjuntos disponíveis antes de redefinir funções"
      ],
      "answer": 0,
      "explanation": "Conversão segura exige controle do ambiente, acesso ao paciente, funções claras e preservação das barreiras de contagem.",
      "competencyId": "C19",
      "sourceIds": [
        "aorn-2026",
        "br-safe-surgery"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 157,
      "category": "Ortopedia",
      "question": "Na pausa, a imagem exibida indica lado diferente do consentimento. Qual conduta é correta?",
      "options": [
        "Aceitar a indicação verbal do profissional mais experiente",
        "Usar o lado exibido na imagem por ser mais objetivo",
        "Interromper e reconciliar documentação, imagem, marcação e equipe antes da incisão",
        "Prosseguir e corrigir o prontuário depois"
      ],
      "answer": 2,
      "explanation": "Divergência de lateralidade exige interrupção até confirmação formal de todas as fontes.",
      "competencyId": "C20",
      "sourceIds": [
        "aaos-guidelines-current",
        "br-safe-surgery"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 158,
      "category": "Ortopedia",
      "question": "A embalagem externa de um implante apresenta dano que pode comprometer a barreira. O que fazer?",
      "options": [
        "Usar se o implante parecer visualmente limpo",
        "Segregar o item e substituí-lo conforme protocolo e instrução do fabricante",
        "Cobrir a área danificada com material estéril",
        "Abrir o implante e realizar desinfecção rápida"
      ],
      "answer": 1,
      "explanation": "Integridade da embalagem faz parte da garantia de esterilidade; aparência do implante não substitui essa barreira.",
      "competencyId": "C20",
      "sourceIds": [
        "fda-patient-guides-2026",
        "aorn-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 159,
      "category": "Ortopedia",
      "question": "Qual etapa deve ocorrer antes dos campos quando haverá radioscopia?",
      "options": [
        "Retirar a proteção radiológica para ampliar mobilidade",
        "Definir a posição do arco somente após a incisão",
        "Colocar o monitor atrás da equipe para evitar distração",
        "Testar posição, alcance, imagem, proteção e acesso ao paciente"
      ],
      "answer": 3,
      "explanation": "Planejamento prévio reduz cruzamento do campo e exposição desnecessária, mantendo acesso e ergonomia.",
      "competencyId": "C20",
      "sourceIds": [
        "nr32",
        "aaos-guidelines-current"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 160,
      "category": "Ortopedia",
      "question": "Como reduzir confusão entre componente de prova e implante definitivo?",
      "options": [
        "Registrar apenas o componente de prova",
        "Manter ambos no mesmo recipiente para comparação",
        "Retirar rótulos depois da abertura",
        "Segregar, identificar e verbalizar a função de cada componente durante a passagem"
      ],
      "answer": 3,
      "explanation": "Separação visual e comunicação evitam implantação indevida e preservam rastreabilidade.",
      "competencyId": "C20",
      "sourceIds": [
        "fda-patient-guides-2026",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 161,
      "category": "Ortopedia",
      "question": "Um alarme de torniquete ocorre durante o procedimento. Qual ação está dentro de uma resposta segura?",
      "options": [
        "Silenciar o alarme e manter o procedimento",
        "Comunicar imediatamente e seguir o protocolo e a instrução de uso sem alterar parâmetros de forma autônoma",
        "Aumentar a pressão até o alarme cessar",
        "Desconectar o equipamento para reiniciá-lo"
      ],
      "answer": 1,
      "explanation": "Alarmes exigem avaliação coordenada. Pressão e tempo dependem da equipe habilitada, paciente e equipamento.",
      "competencyId": "C20",
      "sourceIds": [
        "aorn-2026",
        "aaos-trauma-ssi-2022"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 162,
      "category": "Ortopedia",
      "question": "Um implante removido precisa de cultura e análise do fabricante. Como organizar o envio?",
      "options": [
        "Enviar o implante sem identificação para evitar contaminação",
        "Colocar tudo em formol e dividir no laboratório",
        "Confirmar solicitações e usar recipientes e cadeias de custódia separados para cada destino",
        "Escolher apenas um destino sem consultar a equipe"
      ],
      "answer": 2,
      "explanation": "Microbiologia, patologia e análise técnica têm requisitos diferentes e precisam de rastreabilidade própria.",
      "competencyId": "C20",
      "sourceIds": [
        "aaos-trauma-ssi-2022",
        "aorn-specimen"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 163,
      "category": "Ginecologia e obstetrícia",
      "question": "Ao elevar as pernas para litotomia, qual prática reduz risco de desalinhamento?",
      "options": [
        "Cobrir os apoios antes da checagem final",
        "Elevar uma perna por vez rapidamente",
        "Apoiar pressão diretamente sobre a cabeça da fíbula",
        "Movimentá-las de modo coordenado, com reavaliação de apoios, acessos e estabilidade"
      ],
      "answer": 3,
      "explanation": "Movimento coordenado e reavaliação diminuem torção e pressão assimétrica.",
      "competencyId": "C21",
      "sourceIds": [
        "eras-gyn-2026",
        "positioning-review"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 164,
      "category": "Ginecologia e obstetrícia",
      "question": "Há várias margens pélvicas para exame intraoperatório. Qual método reduz trocas?",
      "options": [
        "Usar mapa e nomenclatura acordados, com leitura de retorno antes de cada envio",
        "Agrupar todas as margens em um recipiente",
        "Numerar sem registrar a correspondência anatômica",
        "Confiar apenas na ordem de chegada à mesa"
      ],
      "answer": 0,
      "explanation": "Mapa, nome anatômico e read-back preservam origem e orientação.",
      "competencyId": "C21",
      "sourceIds": [
        "eras-gyn-2026",
        "aorn-specimen"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 165,
      "category": "Ginecologia e obstetrícia",
      "question": "Em cesárea urgente, como tratar a lista de verificação?",
      "options": [
        "Adaptar e fracionar a checagem, preservando identidade, indicação, riscos e prontidão neonatal",
        "Omitir toda a checagem porque há urgência",
        "Realizar somente depois do nascimento",
        "Limitar-se à confirmação do nome do cirurgião"
      ],
      "answer": 0,
      "explanation": "Urgência pode mudar momento e formato, mas não elimina barreiras críticas.",
      "competencyId": "C21",
      "sourceIds": [
        "eras-cesarean-2025",
        "br-safe-surgery"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 166,
      "category": "Ginecologia e obstetrícia",
      "question": "Após o nascimento, qual prática protege a identificação materno-neonatal?",
      "options": [
        "Aplicar o protocolo com identificadores inequívocos e handoff explícito entre as equipes",
        "Usar apenas o número da sala",
        "Rotular o recém-nascido antes de confirmar os dados",
        "Transferir a identificação para depois da recuperação"
      ],
      "answer": 0,
      "explanation": "A identificação deve ocorrer no fluxo definido, com conferência e comunicação entre equipes.",
      "competencyId": "C21",
      "sourceIds": [
        "eras-cesarean-2025",
        "anvisa-safety-practices-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 167,
      "category": "Ginecologia e obstetrícia",
      "question": "O destino da placenta não foi definido e a equipe já prepara a saída da sala. O que fazer?",
      "options": [
        "Confirmar descarte ou exame, identificação e recipiente antes do transporte",
        "Enviar automaticamente à anatomia patológica",
        "Descartar por ser um material biológico",
        "Armazenar sem rótulo até alguém decidir"
      ],
      "answer": 0,
      "explanation": "Destino e exame devem ser definidos antes da saída para evitar perda ou envio inadequado.",
      "competencyId": "C21",
      "sourceIds": [
        "aorn-specimen",
        "eras-cesarean-2025"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 168,
      "category": "Ginecologia e obstetrícia",
      "question": "Há aumento rápido do sangramento em uma cesárea. Qual resposta perioperatória é mais adequada?",
      "options": [
        "Reduzir a equipe na sala para evitar ruído",
        "Aguardar uma estimativa final antes de comunicar",
        "Preparar medicamentos escolhidos individualmente sem ordem",
        "Declarar a preocupação, convocar ajuda e ativar o protocolo institucional com funções definidas"
      ],
      "answer": 3,
      "explanation": "Reconhecimento precoce, liderança, ajuda e protocolo estruturam a resposta sem extrapolar atribuições.",
      "competencyId": "C21",
      "sourceIds": [
        "eras-cesarean-2025",
        "rdc36"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 169,
      "category": "Urologia",
      "question": "Durante ureteroscopia, o retorno da irrigação desaparece e a visibilidade piora. Qual ação é segura?",
      "options": [
        "Comunicar e pausar até avaliar entrada, saída, conexões e posição do sistema",
        "Aumentar a pressão de irrigação sem limite",
        "Continuar guiando o instrumento sem visão",
        "Desconectar a drenagem para liberar espaço"
      ],
      "answer": 0,
      "explanation": "Perda de retorno pode indicar obstrução ou pressão inadequada; não se compensa cegamente.",
      "competencyId": "C22",
      "sourceIds": [
        "aua-stones-2026",
        "eau-urolithiasis-current"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 170,
      "category": "Urologia",
      "question": "Um cálculo deve passar por análise de composição e cultura. Como proceder?",
      "options": [
        "Enviar apenas fotografia do cálculo",
        "Colocar todo o material no mesmo conservante",
        "Confirmar e separar amostras conforme os requisitos de cada exame",
        "Escolher cultura ou composição sem consultar a solicitação"
      ],
      "answer": 2,
      "explanation": "Os exames têm recipientes e fluxos distintos; separar preserva validade e rastreabilidade.",
      "competencyId": "C22",
      "sourceIds": [
        "aua-stones-2026",
        "eau-urological-infections-current"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 171,
      "category": "Urologia",
      "question": "Como devem ser definidos os parâmetros de um laser urológico?",
      "options": [
        "Sempre na potência máxima para reduzir tempo",
        "Pela última configuração usada na sala",
        "Pelo operador habilitado, protocolo e instrução de uso do equipamento",
        "Pela cor do cálculo observada no monitor"
      ],
      "answer": 2,
      "explanation": "Não existe configuração universal; seleção depende de sistema, objetivo e julgamento habilitado.",
      "competencyId": "C22",
      "sourceIds": [
        "aua-stones-2026",
        "eau-urolithiasis-current"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 172,
      "category": "Urologia",
      "question": "Qual informação é essencial no handoff após colocação de stent ureteral?",
      "options": [
        "Nenhuma, porque o dispositivo é temporário",
        "Apenas a cor do stent",
        "Somente o nome comercial",
        "Presença, lado, identificação disponível e plano de retirada ou seguimento"
      ],
      "answer": 3,
      "explanation": "Dispositivo temporário também exige rastreabilidade e plano de saída.",
      "competencyId": "C22",
      "sourceIds": [
        "aua-stones-2026",
        "eau-urolithiasis-current"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 173,
      "category": "Urologia",
      "question": "Ao retirar um fio-guia, a ponta parece incompleta. O que fazer?",
      "options": [
        "Supor que a ponta estava ausente de fábrica",
        "Descartar o fio e continuar",
        "Interromper, preservar o item e reconciliar sua integridade com a equipe e o protocolo",
        "Registrar somente se houver sintoma pós-operatório"
      ],
      "answer": 2,
      "explanation": "Suspeita de componente retido exige reconciliação imediata e documentação.",
      "competencyId": "C22",
      "sourceIds": [
        "aorn-safety",
        "aua-stones-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 174,
      "category": "Urologia",
      "question": "Qual princípio orienta o uso de fluoroscopia em endourologia?",
      "options": [
        "Minimizar exposição mantendo a imagem necessária e a proteção definida pelo programa local",
        "Manter emissão contínua durante todo o procedimento",
        "Retirar protetores para facilitar movimento",
        "Aproximar profissionais do tubo sem necessidade"
      ],
      "answer": 0,
      "explanation": "O princípio ALARA orienta reduzir tempo, otimizar distância e usar proteção sem comprometer o cuidado.",
      "competencyId": "C22",
      "sourceIds": [
        "nr32",
        "aua-stones-2026"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 175,
      "category": "Cirurgia vascular",
      "question": "O modelo de uma endoprótese disponível não corresponde ao confirmado pela equipe. Qual ação é correta?",
      "options": [
        "Não abrir nem implantar até reconciliar modelo, medida e plano",
        "Abrir para conferir diretamente no campo",
        "Usar se o diâmetro parecer próximo",
        "Alterar o registro para coincidir com o item"
      ],
      "answer": 0,
      "explanation": "Dispositivo vascular exige correspondência exata e confirmação antes da abertura.",
      "competencyId": "C23",
      "sourceIds": [
        "esvs-vgei-2026",
        "aorn-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 176,
      "category": "Cirurgia vascular",
      "question": "Uma ordem de anticoagulante é dada durante um marco vascular. Qual comunicação reduz erro?",
      "options": [
        "Executar em silêncio para ganhar tempo",
        "Repetir fármaco, dose e momento e receber confirmação do prescritor",
        "Pedir que outro profissional interprete a ordem",
        "Registrar apenas ao final do procedimento"
      ],
      "answer": 1,
      "explanation": "A comunicação em alça fechada é essencial em ordens críticas e não autoriza prescrição autônoma.",
      "competencyId": "C23",
      "sourceIds": [
        "acc-periop-2026",
        "br-med-safety-2013"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 177,
      "category": "Cirurgia vascular",
      "question": "Como registrar tempo de clampeamento e reperfusão?",
      "options": [
        "No momento em que os marcos são verbalizados, usando referência de horário comum",
        "Estimando ao final pela duração total da cirurgia",
        "Registrando apenas se houver complicação",
        "Usando horários diferentes para cada profissional"
      ],
      "answer": 0,
      "explanation": "Registro contemporâneo reduz erro de memória e apoia decisões da equipe.",
      "competencyId": "C23",
      "sourceIds": [
        "esvs-trauma-2025",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 178,
      "category": "Cirurgia vascular",
      "question": "Em sala híbrida, o que torna a conversão para acesso aberto mais segura?",
      "options": [
        "Armazenar o instrumental aberto fora da sala",
        "Plano prévio de acesso ao paciente, instrumental, circulação e funções",
        "Bloquear o lado anestésico com a torre",
        "Definir a conversão somente quando a imagem falhar"
      ],
      "answer": 1,
      "explanation": "Conversão prevista preserva tempo, acesso e coordenação.",
      "competencyId": "C23",
      "sourceIds": [
        "esvs-trauma-2025",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 179,
      "category": "Cirurgia vascular",
      "question": "Um segmento de enxerto explantado precisa de microbiologia e análise. Qual é a melhor organização?",
      "options": [
        "Confirmar os destinos e separar amostras e documentação conforme cada fluxo",
        "Colocar toda a peça em formol",
        "Enviar sem identificação por ser material implantável",
        "Lavar o enxerto antes da cultura"
      ],
      "answer": 0,
      "explanation": "Amostras para microbiologia não devem ser tratadas como histologia; os fluxos precisam ser confirmados.",
      "competencyId": "C23",
      "sourceIds": [
        "esvs-vgei-2026",
        "aorn-specimen"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 180,
      "category": "Cirurgia vascular",
      "question": "Um paciente com dispositivo cardíaco implantável será exposto a possível interferência eletromagnética. O que deve existir antes da cirurgia eletiva?",
      "options": [
        "Uso de magneto por rotina sem identificar o dispositivo",
        "Decisão improvisada somente se ocorrer alarme",
        "Plano documentado que identifique dispositivo, dependência, risco de interferência e restauração pós-operatória",
        "Desativação permanente de todas as terapias"
      ],
      "answer": 2,
      "explanation": "A diretriz perioperatória atual recomenda plano prévio individualizado quando há interferência prevista.",
      "competencyId": "C23",
      "sourceIds": [
        "acc-periop-2026",
        "aorn-energy-2026"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 181,
      "category": "Neurocirurgia e coluna",
      "question": "A navegação aponta um local incompatível com marcos anatômicos após movimentação da cabeça. O que fazer?",
      "options": [
        "Interromper e verificar registro, referência, posição e imagem antes de prosseguir",
        "Confiar na tela porque o sistema foi calibrado no início",
        "Compensar mentalmente o desvio",
        "Reiniciar o monitor sem informar a equipe"
      ],
      "answer": 0,
      "explanation": "Movimento pode degradar a precisão. Inconsistência exige nova verificação.",
      "competencyId": "C24",
      "sourceIds": [
        "cns-spine-risk",
        "aorn-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 182,
      "category": "Neurocirurgia e coluna",
      "question": "Qual barreira confirma o nível vertebral antes de intervenção irreversível?",
      "options": [
        "Marcação cutânea isolada",
        "Correlação intraoperatória de imagem e anatomia com concordância da equipe",
        "Posição do paciente na mesa",
        "Número da caixa de implantes"
      ],
      "answer": 1,
      "explanation": "Nível correto exige confirmação própria; marcação externa não basta.",
      "competencyId": "C24",
      "sourceIds": [
        "cns-spine-risk",
        "br-safe-surgery"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 183,
      "category": "Neurocirurgia e coluna",
      "question": "Após flexionar a mesa com o paciente em prona, qual ação é necessária?",
      "options": [
        "Cobrir imediatamente os pontos de apoio",
        "Assumir que a posição inicial permanece segura",
        "Apertar todos os fixadores sem nova inspeção",
        "Reavaliar olhos, face, alinhamento, apoios, acessos e dispositivos"
      ],
      "answer": 3,
      "explanation": "Toda mudança de posição exige rechecagem sistemática.",
      "competencyId": "C24",
      "sourceIds": [
        "cns-spine-risk",
        "positioning-review"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 184,
      "category": "Neurocirurgia e coluna",
      "question": "Há fragmentos tumorais de locais diferentes para exames distintos. Como preservar a informação?",
      "options": [
        "Enviar todos em um único conservante",
        "Agrupar por semelhança visual",
        "Rotular apenas como tumor cerebral",
        "Usar recipientes separados com local anatômico e exame confirmados por leitura de retorno"
      ],
      "answer": 3,
      "explanation": "Local e exame determinam manejo da amostra; não devem ser inferidos depois.",
      "competencyId": "C24",
      "sourceIds": [
        "cns-pituitary-2025",
        "aorn-specimen"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 185,
      "category": "Neurocirurgia e coluna",
      "question": "O sinal de neuromonitorização muda subitamente. Qual resposta de equipe é adequada?",
      "options": [
        "Aumentar estímulos sem informar anestesia",
        "Ignorar até surgir alteração motora visível",
        "Comunicar imediatamente e revisar causas técnicas, posicionais e fisiológicas de forma coordenada",
        "Atribuir de imediato a falha ao equipamento"
      ],
      "answer": 2,
      "explanation": "Mudança de sinal é um alerta multidisciplinar e precisa de investigação sistemática.",
      "competencyId": "C24",
      "sourceIds": [
        "cns-spine-risk",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 186,
      "category": "Neurocirurgia e coluna",
      "question": "Durante craniotomia, o microscópio não alcança a trajetória sem cruzar cabos sobre o acesso anestésico. Qual decisão é melhor?",
      "options": [
        "Reposicionar de forma controlada antes da etapa crítica, preservando acesso e esterilidade",
        "Passar cabos sobre o circuito e prosseguir",
        "Mover a cabeça sem comunicar",
        "Cobrir a conexão problemática com campo adicional"
      ],
      "answer": 0,
      "explanation": "Fluxo tecnológico deve ser corrigido sem comprometer via aérea, posição ou barreira.",
      "competencyId": "C24",
      "sourceIds": [
        "aorn-2026",
        "br-safe-surgery"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 187,
      "category": "Cabeça e pescoço",
      "question": "Antes de usar energia próxima à via aérea, qual comunicação é essencial?",
      "options": [
        "Ativar sem aviso porque o campo está visível",
        "Confirmar com anestesia o risco de fogo, oxidante e momento de ativação",
        "Aumentar oxigênio para compensar a fumaça",
        "Cobrir o tubo com material não previsto"
      ],
      "answer": 1,
      "explanation": "A via aérea reúne oxidante e combustível; energia exige avaliação e comunicação explícitas.",
      "competencyId": "C25",
      "sourceIds": [
        "anvisa-fire-2014",
        "aorn-energy-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 188,
      "category": "Cabeça e pescoço",
      "question": "Como organizar múltiplas margens cervicais?",
      "options": [
        "Numerar sem legenda",
        "Usar mapa, lado e nível por extenso com confirmação antes de cada envio",
        "Misturar margens da mesma região",
        "Confiar apenas na memória do circulante"
      ],
      "answer": 1,
      "explanation": "Nomenclatura padronizada e read-back preservam a origem.",
      "competencyId": "C25",
      "sourceIds": [
        "eras-head-neck-2017",
        "aorn-specimen"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 189,
      "category": "Cabeça e pescoço",
      "question": "O que o handoff de um retalho livre deve incluir?",
      "options": [
        "Apenas o nome do cirurgião plástico",
        "Somente o horário do fim da cirurgia",
        "Método e local de avaliação, parâmetros prescritos, sítio doador e quem acionar diante de alteração",
        "Uma recomendação genérica para observar a cor"
      ],
      "answer": 2,
      "explanation": "Handoff específico permite continuidade e escalonamento sem manipulação inadequada.",
      "competencyId": "C25",
      "sourceIds": [
        "head-neck-review-2024",
        "eras-head-neck-2017"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 190,
      "category": "Cabeça e pescoço",
      "question": "A equipe de ressecção será substituída pela equipe de reconstrução. Qual barreira é prioritária?",
      "options": [
        "Retirar todo o instrumental sem contar",
        "Realizar transição formal com contagem, espécimes, perdas, implantes e pendências",
        "Manter informações somente com o cirurgião principal",
        "Recomeçar o registro do zero"
      ],
      "answer": 1,
      "explanation": "Mudança de equipe não pode interromper a cadeia de informação e contagem.",
      "competencyId": "C25",
      "sourceIds": [
        "eras-head-neck-2017",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 191,
      "category": "Cabeça e pescoço",
      "question": "Antes da transferência de paciente com traqueostomia recente, o que precisa ser confirmado?",
      "options": [
        "Somente a disponibilidade do leito",
        "Via aérea, fixação, dispositivos, equipamento de resgate, destino e equipe receptora",
        "Apenas a saturação no momento da saída",
        "Retirada do material de emergência para liberar espaço"
      ],
      "answer": 1,
      "explanation": "Transferência segura preserva suporte, plano de resgate e comunicação.",
      "competencyId": "C25",
      "sourceIds": [
        "head-neck-review-2024",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 192,
      "category": "Cabeça e pescoço",
      "question": "Cirurgia solicita manipulação do tubo durante uma etapa crítica. Qual resposta é adequada?",
      "options": [
        "Mover imediatamente sem comunicar",
        "Repetir a solicitação e coordenar a ação com anestesia antes de mover o dispositivo",
        "Soltar a fixação e deixar o tubo livre",
        "Pedir ao profissional não habilitado mais próximo"
      ],
      "answer": 1,
      "explanation": "Via aérea compartilhada exige ação coordenada e responsabilidade definida.",
      "competencyId": "C25",
      "sourceIds": [
        "eras-head-neck-2017",
        "br-safe-surgery"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 193,
      "category": "Torácica e cardíaca",
      "question": "Durante cirurgia pulmonar, o pedido para reinsuflar o pulmão deve ser tratado como?",
      "options": [
        "Sinal para aumentar energia cirúrgica",
        "Rotina que dispensa confirmação",
        "Ação exclusiva da enfermagem",
        "Marco de comunicação em alça fechada entre cirurgia e anestesia"
      ],
      "answer": 3,
      "explanation": "Mudanças ventilatórias afetam campo e fisiologia e precisam de confirmação direta.",
      "competencyId": "C26",
      "sourceIds": [
        "eras-thoracic-2019",
        "aorn-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 194,
      "category": "Torácica e cardíaca",
      "question": "Após inclinar a mesa com paciente em lateral, qual ação é necessária?",
      "options": [
        "Mover o braço dependente para fora da mesa",
        "Apenas observar se o campo permaneceu estéril",
        "Reapertar todos os apoios sem inspecionar",
        "Reavaliar alinhamento, pressão, fixação, circuito e acessos"
      ],
      "answer": 3,
      "explanation": "Inclinação altera forças e pode tracionar dispositivos; a checagem deve ser repetida.",
      "competencyId": "C26",
      "sourceIds": [
        "eras-thoracic-2019",
        "positioning-review"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 195,
      "category": "Torácica e cardíaca",
      "question": "Antes de transferir um paciente com dreno torácico, qual verificação é mais completa?",
      "options": [
        "Desconectar o sistema para facilitar transporte",
        "Somente o volume do coletor",
        "Pinçar todos os drenos por rotina",
        "Conexões, identificação, estado do sistema, posição do coletor e sucção prescrita"
      ],
      "answer": 3,
      "explanation": "Dreno funciona como sistema e não deve ser manipulado fora de indicação e protocolo.",
      "competencyId": "C26",
      "sourceIds": [
        "eras-thoracic-2019",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 196,
      "category": "Torácica e cardíaca",
      "question": "Como tratar início e saída da circulação extracorpórea?",
      "options": [
        "Como estimativas documentadas ao final",
        "Como eventos da perfusão que não exigem resposta da sala",
        "Como marcos de equipe, verbalizados, confirmados e registrados no momento",
        "Como sinais para interromper todas as contagens"
      ],
      "answer": 2,
      "explanation": "Marcos da CEC coordenam cirurgia, perfusão, anestesia e enfermagem.",
      "competencyId": "C26",
      "sourceIds": [
        "eras-cardiac-2024",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 197,
      "category": "Torácica e cardíaca",
      "question": "Antes de abrir uma prótese valvar, qual conjunto de dados deve ser reconciliado?",
      "options": [
        "Apenas o nome comercial",
        "Modelo, tamanho, lote, validade, compatibilidade e decisão da equipe",
        "Somente a cor da embalagem",
        "O registro do paciente depois da implantação"
      ],
      "answer": 1,
      "explanation": "Conferência prévia preserva compatibilidade e rastreabilidade de implante de alto impacto.",
      "competencyId": "C26",
      "sourceIds": [
        "eras-cardiac-2024",
        "aorn-safety"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 198,
      "category": "Torácica e cardíaca",
      "question": "Qual handoff é mais seguro após cirurgia cardíaca?",
      "options": [
        "Resumo apenas do diagnóstico",
        "Estruturado e presencial, incluindo via aérea, hemodinâmica, linhas, drenos, fios, perdas, eventos e pendências",
        "Envio do prontuário sem comunicação verbal",
        "Relato exclusivo do tempo cirúrgico"
      ],
      "answer": 1,
      "explanation": "A transferência reúne múltiplos sistemas e precisa preservar estado, riscos e planos.",
      "competencyId": "C26",
      "sourceIds": [
        "eras-cardiac-2024",
        "br-safe-surgery"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 199,
      "category": "Pediatria e neonatal",
      "question": "O peso no prontuário difere do informado pela unidade de origem. O que fazer antes do procedimento?",
      "options": [
        "Usar a média entre os dois pesos",
        "Escolher o menor valor por segurança",
        "Interromper cálculos e seleção dependentes de peso até reconciliar e documentar o valor correto",
        "Manter ambos os valores sem informar a equipe"
      ],
      "answer": 2,
      "explanation": "Peso divergente pode afetar equipamentos e decisões clínicas; deve ser resolvido formalmente.",
      "competencyId": "C27",
      "sourceIds": [
        "eras-neonatal-2024",
        "br-med-safety-2013"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 200,
      "category": "Pediatria e neonatal",
      "question": "Um dispositivo de aquecimento está em uso sem monitorização adequada da temperatura. Qual ação é segura?",
      "options": [
        "Aumentar o aquecimento até a pele ficar avermelhada",
        "Providenciar monitorização e reavaliar o plano conforme protocolo e instrução do dispositivo",
        "Manter porque neonatos sempre precisam de máxima temperatura",
        "Cobrir o sensor ausente com campo"
      ],
      "answer": 1,
      "explanation": "Aquecimento sem monitorização pode causar hipertermia ou lesão térmica.",
      "competencyId": "C27",
      "sourceIds": [
        "eras-neonatal-2024",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 201,
      "category": "Pediatria e neonatal",
      "question": "Um componente muito pequeno não é encontrado na contagem pediátrica. O que fazer?",
      "options": [
        "Repor outro componente e encerrar",
        "Considerar o item pequeno demais para retenção",
        "Interromper o encerramento e aplicar o protocolo de divergência de contagem",
        "Registrar somente após a alta"
      ],
      "answer": 2,
      "explanation": "Tamanho reduzido aumenta a necessidade de controle visual, não diminui o risco.",
      "competencyId": "C27",
      "sourceIds": [
        "who-retained",
        "eras-neonatal-2024"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 202,
      "category": "Pediatria e neonatal",
      "question": "Qual identificação é inadequada para um recém-nascido?",
      "options": [
        "Envolver responsável quando possível",
        "Conferir pulseira e prontuário",
        "Usar o número do leito como identificador principal",
        "Rotular amostra junto ao paciente"
      ],
      "answer": 2,
      "explanation": "Leito é localização, não identificador inequívoco.",
      "competencyId": "C27",
      "sourceIds": [
        "eras-neonatal-2024",
        "anvisa-safety-practices-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 203,
      "category": "Pediatria e neonatal",
      "question": "Antes do transporte de um neonato para o centro cirúrgico, o que deve ser confirmado?",
      "options": [
        "Retirada de todos os monitores para reduzir peso",
        "Somente a reserva do elevador",
        "Suporte térmico, via aérea, linhas, monitorização, bateria, equipe e destino",
        "Destino depois que o transporte começar"
      ],
      "answer": 2,
      "explanation": "Transporte neonatal é uma transição crítica e requer recursos e responsabilidades definidos.",
      "competencyId": "C27",
      "sourceIds": [
        "eras-neonatal-2024",
        "apsa-eras"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 204,
      "category": "Pediatria e neonatal",
      "question": "Como integrar a família com segurança na jornada cirúrgica pediátrica?",
      "options": [
        "Evitar informações para reduzir ansiedade",
        "Transferir decisões técnicas integralmente à família",
        "Permitir acesso irrestrito a qualquer área",
        "Oferecer comunicação e participação compatíveis com consentimento, política e condição clínica"
      ],
      "answer": 3,
      "explanation": "A família é parceira, mas participação respeita consentimento, privacidade e segurança institucional.",
      "competencyId": "C27",
      "sourceIds": [
        "eras-neonatal-2024",
        "neonatal-pain-2025"
      ],
      "difficulty": "Análise"
    },
    {
      "id": 205,
      "category": "Robótica",
      "question": "O carrinho robótico bloqueia acesso rápido à via aérea antes do docking. Qual decisão é correta?",
      "options": [
        "Reposicionar o sistema antes de acoplar, preservando acesso e rota de emergência",
        "Acoplar e depender de undocking se ocorrer problema",
        "Cobrir o acesso com campos adicionais",
        "Mover o circuito para a zona dos braços robóticos"
      ],
      "answer": 0,
      "explanation": "Acesso de emergência deve ser preservado no planejamento, não recuperado apenas após um evento.",
      "competencyId": "C28",
      "sourceIds": [
        "aorn-robotic-2026",
        "aorn-2026"
      ],
      "difficulty": "Básico"
    },
    {
      "id": 206,
      "category": "Robótica",
      "question": "A equipe deseja movimentar a mesa com o sistema acoplado. O que fazer?",
      "options": [
        "Desligar os alertas de movimento",
        "Mover lentamente sem avisar o console",
        "Desacoplar um braço ao acaso",
        "Seguir somente a compatibilidade, sequência e autorização previstas pelo fabricante e pela equipe treinada"
      ],
      "answer": 3,
      "explanation": "Movimento acoplado depende de recursos específicos e coordenação definida.",
      "competencyId": "C28",
      "sourceIds": [
        "aorn-robotic-2026",
        "fda-rasd-draft-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 207,
      "category": "Robótica",
      "question": "Um instrumento gera alerta e não responde como esperado. Qual é a primeira resposta segura?",
      "options": [
        "Forçar manualmente o braço",
        "Contornar o alerta para terminar a etapa",
        "Parar, comunicar, manter controle visual quando possível e seguir o fluxo autorizado do sistema",
        "Reiniciar sem confirmar a posição do instrumento"
      ],
      "answer": 2,
      "explanation": "Alertas não devem ser burlados; estabilização e procedimento do fabricante reduzem dano adicional.",
      "competencyId": "C28",
      "sourceIds": [
        "aorn-robotic-2026",
        "fda-rasd-draft-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 208,
      "category": "Robótica",
      "question": "Qual elemento deve fazer parte do briefing de uma cirurgia robótica?",
      "options": [
        "Funções para emergência, sequência de undocking, acesso ao paciente e plano de conversão",
        "Somente a preferência de câmera",
        "A decisão de conversão deixada para o final",
        "Abertura prévia de todo o instrumental aberto"
      ],
      "answer": 0,
      "explanation": "Conversão e undocking precisam ser previstos e treinados.",
      "competencyId": "C28",
      "sourceIds": [
        "aorn-robotic-2026",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 209,
      "category": "Robótica",
      "question": "Durante o docking, é percebida ruptura do drape na interface estéril. O que fazer?",
      "options": [
        "Ignorar se a parte interna do braço não tocou o campo",
        "Cobrir a ruptura com qualquer adesivo",
        "Interromper e corrigir a quebra conforme protocolo e instrução do fabricante antes de prosseguir",
        "Continuar e registrar somente no fim"
      ],
      "answer": 2,
      "explanation": "A integridade da interface estéril é uma barreira e precisa ser restaurada por método autorizado.",
      "competencyId": "C28",
      "sourceIds": [
        "aorn-robotic-2026",
        "aorn-2026"
      ],
      "difficulty": "Aplicação"
    },
    {
      "id": 210,
      "category": "Robótica",
      "question": "Um braço aproxima-se de outro e o observador identifica risco de colisão. Qual resposta é adequada?",
      "options": [
        "Silenciar a comunicação para não distrair o console",
        "Aguardar o sistema corrigir sozinho",
        "Empurrar o braço durante o movimento",
        "Dar o comando de parada acordado e coordenar o reposicionamento"
      ],
      "answer": 3,
      "explanation": "Vigilância externa e comando claro permitem interromper uma trajetória insegura.",
      "competencyId": "C28",
      "sourceIds": [
        "aorn-robotic-2026",
        "fda-rasd-draft-2026"
      ],
      "difficulty": "Análise"
    }
  ],
  "checklist": [
    {
      "title": "Antes de estudar um procedimento",
      "items": [
        "Defini o objetivo do procedimento",
        "Revisei acesso e anatomia relacionada",
        "Listei os tempos operatórios prováveis",
        "Identifiquei instrumentais e equipamentos-chave",
        "Revisei fios, agulhas e materiais especiais"
      ]
    },
    {
      "title": "Segurança e fluxo",
      "items": [
        "Revisei posicionamento e pontos de pressão",
        "Mapeei etapas da lista de segurança",
        "Sei os momentos de contagem",
        "Revisei identificação e envio de amostras",
        "Consultei o protocolo da instituição"
      ]
    },
    {
      "title": "Fixação do aprendizado",
      "items": [
        "Concluí a aula",
        "Resumi o tema com minhas palavras",
        "Revisei os flashcards",
        "Respondi ao desafio sem consultar",
        "Registrei as dúvidas para discutir com um preceptor"
      ]
    },
    {
      "title": "Base científica",
      "items": [
        "Consultei as fontes indicadas na aula",
        "Verifiquei a data e a versão da publicação",
        "Distingui norma, diretriz e protocolo local",
        "Confirmei instruções do fabricante quando aplicável",
        "Identifiquei pontos que exigem revisão especializada"
      ]
    },
    {
      "title": "Aplicação segura",
      "items": [
        "Consigo explicar meus limites profissionais",
        "Pratiquei somente em ambiente autorizado e supervisionado",
        "Sei quando interromper e escalar uma preocupação",
        "Comparei o conteúdo com a rotina da instituição",
        "Não tratei vídeo educacional como autorização para executar a técnica"
      ]
    },
    {
      "title": "Cirurgia geral e digestiva — revisão da trilha",
      "items": [
        "Mapeei transições de contaminação previstas",
        "Revisei dispositivos, espécimes e plano de saída",
        "Consigo explicar a lógica do handoff abdominal",
        "Identifiquei pontos dependentes do protocolo local"
      ]
    },
    {
      "title": "Ortopedia e trauma — revisão da trilha",
      "items": [
        "Revisei lateralidade, imagem e posicionamento",
        "Diferenciei prova, implante e componente removido",
        "Mapeei rastreabilidade e resposta a alertas",
        "Confirmei limites para torniquete e parâmetros"
      ]
    },
    {
      "title": "Ginecologia e obstetrícia — revisão da trilha",
      "items": [
        "Revisei litotomia e reavaliação de apoios",
        "Organizei mapa de fluidos e espécimes",
        "Distingui fluxos materno e neonatal",
        "Revisei ativação institucional para deterioração"
      ]
    },
    {
      "title": "Urologia — revisão da trilha",
      "items": [
        "Desenhei o circuito de irrigação completo",
        "Revisei energia, imagem e proteção ocupacional",
        "Mapeei stents, cateteres e planos de saída",
        "Identifiquei quando pausar e escalar discrepâncias"
      ]
    },
    {
      "title": "Cirurgia vascular — revisão da trilha",
      "items": [
        "Revisei zonas e proteção da sala híbrida",
        "Mapeei marcos de clampeamento e reperfusão",
        "Organizei enxertos, implantes e explantes",
        "Planejei comunicação para conversão e transferência"
      ]
    },
    {
      "title": "Neurocirurgia e coluna — revisão da trilha",
      "items": [
        "Revisei posição, olhos, face e acessos",
        "Diferenciei navegação de confirmação anatômica",
        "Mapeei resposta a mudança de neuromonitorização",
        "Expliquei a barreira específica de nível vertebral"
      ]
    },
    {
      "title": "Cabeça e pescoço — revisão da trilha",
      "items": [
        "Revisei comunicação da via aérea compartilhada",
        "Mapeei risco de fogo e comando de pausa",
        "Organizei múltiplas margens e transições de equipe",
        "Estruturei handoff e escalonamento do retalho"
      ]
    },
    {
      "title": "Torácica e cardíaca — revisão da trilha",
      "items": [
        "Revisei marcos de ventilação e posição lateral",
        "Mapeei drenos, linhas, fios e equipamentos",
        "Organizei linha do tempo cardíaca multiprofissional",
        "Estruturei conversão e transferência segura"
      ]
    },
    {
      "title": "Pediatria e neonatal — revisão da trilha",
      "items": [
        "Confirmei identidade, peso e unidade",
        "Revisei microcomponentes e barreiras de medicação",
        "Planejei termorregulação com monitorização",
        "Estruturei transporte, família e equipe receptora"
      ]
    },
    {
      "title": "Robótica e minimamente invasiva — revisão da trilha",
      "items": [
        "Mapeei zonas, docking e acesso de emergência",
        "Revisei posição após inclinação e insuflação",
        "Defini funções para alerta, undocking e conversão",
        "Revisei integridade, rastreabilidade e IFU"
      ]
    },
    {
      "title": "Procedimentos e vias cirúrgicas — revisão",
      "items": [
        "Classifiquei urgência, finalidade e abordagem",
        "Mapeei posição, equipamentos e possibilidade de conversão",
        "Revisei contagens, amostras e dispositivos no encerramento",
        "Estruturei handoff conforme o que mudou",
        "Marquei decisões exclusivas da equipe habilitada"
      ]
    },
    {
      "title": "Acessos vasculares — revisão",
      "items": [
        "Mapeei todos os acessos e funções",
        "Revisei barreiras para periférico, central e arterial",
        "Reconheci sinais que exigem interromper e escalar",
        "Confirmei identificação, curativo e conexões",
        "Incluí necessidade e plano de saída no handoff"
      ]
    },
    {
      "title": "Via aérea, sondas e drenos — revisão",
      "items": [
        "Revisei plano principal, alternativas e resgate de via aérea",
        "Confirmei indicação e sistema fechado do cateter urinário",
        "Mapeei confirmação e função de sondas digestivas",
        "Protegi drenos e coletores para transporte",
        "Diferenciei acessos regionais de vias venosas"
      ]
    },
    {
      "title": "Assepsia e preparo da pele — revisão",
      "items": [
        "Diferenciei limpeza, antissepsia, desinfecção e esterilidade",
        "Revisei mãos, paramentação e quebra de técnica",
        "Avaliei pele, pelos e sujidade antes do produto",
        "Confirmei indicação, contraindicação e IFU do antisséptico",
        "Verifiquei secagem, campos e risco de fogo"
      ]
    },
    {
      "title": "Procedimentos perioperatórios — revisão",
      "items": [
        "Reconciliei identidade, procedimento e documentos",
        "Planejei transferência e proteção de dispositivos",
        "Organizei amostras de punções e biópsias",
        "Registrei curativos, drenos, estomas e condição da pele",
        "Fechei handoff com responsável por pendências"
      ]
    }
  ],
  "videos": [
    {
      "id": "FrRc2zgiJUQ",
      "title": "Aula prática: instrumentação cirúrgica",
      "originalTitle": "#AulaPrática Alunos de Técnico em Enfermagem aprendem sobre instrumentação cirúrgica",
      "channel": "Santa Casa BH",
      "moduleId": "instrumentais",
      "language": "Português",
      "type": "Demonstração educacional",
      "note": "Apresenta uma atividade prática de formação em instrumentação cirúrgica.",
      "url": "https://www.youtube.com/watch?v=FrRc2zgiJUQ",
      "channelUrl": "https://www.youtube.com/@santacasabh",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "t3ODIsIj5x4",
      "title": "Nó quadrado cirúrgico com duas mãos",
      "originalTitle": "How to Tie a Two-Handed Surgical Square Knot",
      "channel": "Stanford Surgery",
      "moduleId": "fios-suturas",
      "language": "Inglês",
      "type": "Demonstração de habilidade",
      "note": "Demonstração de nó cirúrgico produzida pelo Departamento de Cirurgia de Stanford.",
      "url": "https://www.youtube.com/watch?v=t3ODIsIj5x4",
      "channelUrl": "https://www.youtube.com/@StanfordSurgery",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "-lEtr4Jys_4",
      "title": "Sutura simples e nó com instrumental",
      "originalTitle": "Basic Skills Sutures and Knot Tying: Tying Knots with Instruments (Simple Suture)",
      "channel": "Orthopaedic Surgical Videos",
      "moduleId": "fios-suturas",
      "language": "Inglês",
      "type": "Demonstração de habilidade",
      "note": "Demonstração apresentada por médica vinculada ao Hospital for Special Surgery.",
      "url": "https://www.youtube.com/watch?v=-lEtr4Jys_4",
      "channelUrl": "https://www.youtube.com/@orthopaedicsurgicalvideos9653",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "h16JPBcOIGs",
      "title": "Preparo cirúrgico das mãos — técnica OMS",
      "originalTitle": "WHO surgical hand preparation technique",
      "channel": "Hôpitaux Universitaires de Genève",
      "moduleId": "assepsia-seguranca",
      "language": "Demonstração visual",
      "type": "Técnica asséptica",
      "note": "Demonstração institucional do preparo cirúrgico das mãos segundo técnica da OMS.",
      "url": "https://www.youtube.com/watch?v=h16JPBcOIGs",
      "channelUrl": "https://www.youtube.com/@hug_ge",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "3La8r7qRALU",
      "title": "Abertura de embalagens estéreis",
      "originalTitle": "Opening Sterile Packages: Medical Student Microlearning Videos for the Surgery Rotation",
      "channel": "Michigan Medicine",
      "moduleId": "assepsia-seguranca",
      "language": "Inglês",
      "type": "Técnica asséptica",
      "note": "Microaula institucional sobre abertura de materiais e transferência para o campo estéril.",
      "url": "https://www.youtube.com/watch?v=3La8r7qRALU",
      "channelUrl": "https://www.youtube.com/@MichiganMedicine",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "T4OUPVFALZY",
      "title": "Montagem de campo estéril",
      "originalTitle": "Sterile Field Setup",
      "channel": "College of Southern Maryland",
      "moduleId": "assepsia-seguranca",
      "language": "Inglês",
      "type": "Técnica asséptica",
      "note": "Demonstração educacional de montagem de campo estéril.",
      "url": "https://www.youtube.com/watch?v=T4OUPVFALZY",
      "channelUrl": "https://www.youtube.com/@CSMDTube",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "lcrHgzMmGDA",
      "title": "Aplicação do checklist de cirurgia segura",
      "originalTitle": "APLICAÇÃO DO CHECKLIST DE CIRURGIA SEGURA NO HC UFTM",
      "channel": "Educação Permanente em Enfermagem — HC-UFTM",
      "moduleId": "cirurgia-segura",
      "language": "Português",
      "type": "Simulação institucional",
      "note": "Demonstração da aplicação do checklist em hospital universitário brasileiro.",
      "url": "https://www.youtube.com/watch?v=lcrHgzMmGDA",
      "channelUrl": "https://www.youtube.com/@educacaopermanenteemenferm9518",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "DqG_cInBRbo",
      "title": "Cirurgia segura usando o checklist da OMS",
      "originalTitle": "Safe Surgery Using the WHO Checklist",
      "channel": "Medical Aid Films",
      "moduleId": "cirurgia-segura",
      "language": "Inglês",
      "type": "Treinamento profissional",
      "note": "Filme educacional voltado a profissionais sobre o uso do checklist durante uma operação.",
      "url": "https://www.youtube.com/watch?v=DqG_cInBRbo",
      "channelUrl": "https://www.youtube.com/@MedicalAidFilmsFilmsForLife",
      "checkedOn": "2026-10-13"
    },
    {
      "id": "hRnbqk_pRjA",
      "title": "Centro cirúrgico e checklist de cirurgia segura",
      "originalTitle": "Centro Cirúrgico e checklist da cirurgia segura",
      "channel": "SOBECC",
      "moduleId": "cirurgia-segura",
      "language": "Português",
      "type": "Discussão técnico-científica",
      "note": "Discussão da associação brasileira de enfermagem perioperatória sobre checklist e segurança.",
      "url": "https://www.youtube.com/watch?v=hRnbqk_pRjA",
      "channelUrl": "https://www.youtube.com/@SobeccNacional",
      "checkedOn": "2026-10-13"
    }
  ],
  "evidence": [
    {
      "id": "br-safe-surgery",
      "organization": "Ministério da Saúde / Anvisa / Fiocruz",
      "year": "2013",
      "title": "Protocolo para Cirurgia Segura",
      "topic": "Cirurgia segura",
      "access": "Acesso aberto",
      "url": "https://www.gov.br/saude/pt-br/composicao/saes/dahu/pnsp/protocolos-basicos/protocolo-cirurgia-segura.pdf/view"
    },
    {
      "id": "who-safe-surgery",
      "organization": "Organização Mundial da Saúde",
      "year": "2009",
      "title": "Manual de implementação da Lista de Verificação de Segurança Cirúrgica",
      "topic": "Cirurgia segura",
      "access": "Acesso aberto",
      "url": "https://www.who.int/publications/i/item/9789241598590"
    },
    {
      "id": "anvisa-isc-2025",
      "organization": "Anvisa",
      "year": "2025",
      "title": "Protocolo de Prevenção de Infecção de Sítio Cirúrgico",
      "topic": "Prevenção de infecção",
      "access": "Acesso aberto",
      "url": "https://www.gov.br/anvisa/pt-br/centraisdeconteudo/publicacoes/servicosdesaude/publicacoes/Protocolo2PreveodeISCFINAL.pdf",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Protocolo recente; complementado pelas Notas Técnicas Anvisa de 2026"
    },
    {
      "id": "rdc15",
      "organization": "Anvisa",
      "year": "2012",
      "title": "RDC nº 15 — Boas práticas para o processamento de produtos para saúde",
      "topic": "CME e processamento",
      "access": "Norma pública",
      "url": "https://bvsms.saude.gov.br/bvs/saudelegis/anvisa/2012/rdc0015_15_03_2012.html"
    },
    {
      "id": "who-reprocess-2016",
      "organization": "Organização Mundial da Saúde",
      "year": "2016",
      "title": "Decontamination and reprocessing of medical devices for health-care facilities",
      "topic": "CME e processamento",
      "access": "Acesso aberto",
      "url": "https://www.who.int/publications/i/item/9789241549851"
    },
    {
      "id": "who-reprocess-2022",
      "organization": "Organização Mundial da Saúde",
      "year": "2022",
      "title": "Decontamination and reprocessing of medical devices — aide-mémoire",
      "topic": "CME e processamento",
      "access": "Acesso aberto",
      "url": "https://www.who.int/publications/i/item/WHO-UHL-IHS-IPC-2022.4"
    },
    {
      "id": "nr32",
      "organization": "Ministério do Trabalho e Emprego",
      "year": "2023",
      "title": "NR-32 — Segurança e Saúde no Trabalho em Serviços de Saúde",
      "topic": "Segurança ocupacional",
      "access": "Norma pública",
      "url": "https://www.gov.br/trabalho-e-emprego/pt-br/acesso-a-informacao/participacao-social/conselhos-e-orgaos-colegiados/comissao-tripartite-partitaria-permanente/normas-regulamentadora/normas-regulamentadoras-vigentes/nr-32-atualizada-2023-1.pdf",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Versão consolidada no portal oficial; conferir alterações antes do uso local"
    },
    {
      "id": "cofen214",
      "organization": "Cofen",
      "year": "1998",
      "title": "Resolução Cofen nº 214 — Instrumentação Cirúrgica",
      "topic": "Exercício profissional",
      "access": "Norma pública",
      "url": "https://cofen.gov.br/resoluo-cofen-2141998/"
    },
    {
      "id": "cofen609",
      "organization": "Cofen",
      "year": "2019",
      "title": "Resolução Cofen nº 609 — Especialidades de Enfermagem de nível médio",
      "topic": "Exercício profissional",
      "access": "Norma pública",
      "url": "https://www.cofen.gov.br/resolucao-cofen-no-609-2019/"
    },
    {
      "id": "sobecc8",
      "organization": "SOBECC",
      "year": "8ª edição",
      "title": "Diretrizes de Práticas em Enfermagem Perioperatória e Processamento de Produtos para Saúde",
      "topic": "Prática perioperatória",
      "access": "Obra comercial — consultar legalmente",
      "url": "https://sobecc.org.br/store-produto-detalhe.php?produto=3"
    },
    {
      "id": "aorn-safety",
      "organization": "AORN",
      "year": "2022",
      "title": "Position Statement on Patient Safety",
      "topic": "Segurança perioperatória",
      "access": "Resumo público; diretrizes completas protegidas",
      "url": "https://www.aorn.org/docs/default-source/guidelines-resources/position-statements/patient-workplace-safety/posstat-pt-safety-0303.pdf"
    },
    {
      "id": "who-retained",
      "organization": "NCBI Bookshelf / OMS",
      "year": "2009",
      "title": "Prevention of inadvertent retention of instruments and sponges",
      "topic": "Contagem cirúrgica",
      "access": "Acesso aberto",
      "url": "https://www.ncbi.nlm.nih.gov/books/NBK143227/"
    },
    {
      "id": "positioning-review",
      "organization": "Journal of Clinical Nursing",
      "year": "2025",
      "title": "Patient positioning on the operating table and patient safety: systematic review and meta-analysis",
      "topic": "Posicionamento",
      "access": "Artigo aberto no PMC",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12371821/"
    },
    {
      "id": "suture-review",
      "organization": "Tidsskrift for Den norske legeforening",
      "year": "2023",
      "title": "Suture materials",
      "topic": "Fios e suturas",
      "access": "Revisão clínica aberta",
      "url": "https://tidsskriftet.no/en/2023/06/clinical-review/suture-materials"
    },
    {
      "id": "cdc-ssi-2017",
      "organization": "Centers for Disease Control and Prevention",
      "year": "2017",
      "title": "Guideline for the Prevention of Surgical Site Infection",
      "topic": "Prevenção de infecção",
      "access": "Acesso aberto",
      "url": "https://stacks.cdc.gov/view/cdc/79361"
    },
    {
      "id": "shea-ssi-2022",
      "organization": "SHEA / IDSA / APIC",
      "year": "2022",
      "title": "Strategies to prevent surgical site infections in acute-care hospitals: 2022 Update",
      "topic": "Prevenção de infecção",
      "access": "Acesso aberto",
      "url": "https://stacks.cdc.gov/view/cdc/155079/cdc_155079_DS1.pdf"
    },
    {
      "id": "aorn-specimen",
      "organization": "AORN",
      "year": "Atualização contínua",
      "title": "Guideline in Focus: Specimen Management",
      "topic": "Espécimes",
      "access": "Síntese pública; diretriz completa protegida",
      "url": "https://www.aorn.org/article/aorn-guideline-in-focus--specimen-management"
    },
    {
      "id": "niosh-smoke",
      "organization": "NIOSH / CDC",
      "year": "2020",
      "title": "Surgical Smoke Inhalation",
      "topic": "Segurança ocupacional",
      "access": "Acesso aberto",
      "url": "https://www.cdc.gov/niosh/bulletin/2020/surgical-smoke.html"
    },
    {
      "id": "openstax-anatomy",
      "organization": "OpenStax / LibreTexts",
      "year": "1ª edição",
      "title": "Anatomy and Physiology 1e",
      "topic": "Anatomia",
      "access": "Consultar edição e licença do material específico",
      "url": "https://med.libretexts.org/Bookshelves/Anatomy_and_Physiology/Anatomy_and_Physiology_1e_(OpenStax)"
    },
    {
      "id": "aorn-energy-2026",
      "organization": "AORN",
      "year": "2026",
      "title": "Guideline for the Safe Use of Surgical Energy Devices — evidence table",
      "topic": "Energia cirúrgica",
      "access": "Tabela de evidências pública; diretriz completa protegida",
      "url": "https://www.aorn.org/docs/default-source/guidelines-resources/evidence-rating-and-tables/evidence-table-surgical-energy-devices-1218.pdf",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Tabela pública verificada; diretriz integral protegida por licença"
    },
    {
      "id": "anvisa-fire-2014",
      "organization": "Anvisa",
      "year": "2014",
      "title": "Segurança contra Incêndio em Estabelecimentos Assistenciais de Saúde",
      "topic": "Incêndio e emergência",
      "access": "Manual de acesso aberto",
      "url": "https://www.gov.br/anvisa/pt-br/centraisdeconteudo/publicacoes/servicosdesaude/publicacoes/manual-seguranca-contra-incendio-em-estabelecimentos-assistenciais-de-saude.pdf"
    },
    {
      "id": "br-med-safety-2013",
      "organization": "Ministério da Saúde / Anvisa / Fiocruz",
      "year": "2013",
      "title": "Protocolo de Segurança na Prescrição, Uso e Administração de Medicamentos",
      "topic": "Segurança de medicamentos",
      "access": "Acesso aberto",
      "url": "https://www.gov.br/anvisa/pt-br/centraisdeconteudo/publicacoes/servicosdesaude/publicacoes/protocolo-de-seguranca-na-prescricao-uso-e-administracao-de-medicamentos/@@display-file/file"
    },
    {
      "id": "who-med-harm",
      "organization": "Organização Mundial da Saúde",
      "year": "2017–2024",
      "title": "Medication Without Harm",
      "topic": "Segurança de medicamentos",
      "access": "Portal e recursos abertos",
      "url": "https://www.who.int/initiatives/medication-without-harm"
    },
    {
      "id": "coren-sp-med-guide",
      "organization": "Coren-SP",
      "year": "2017",
      "title": "Uso seguro de medicamentos: guia para preparo, administração e monitoramento",
      "topic": "Segurança de medicamentos",
      "access": "Guia de acesso aberto",
      "url": "https://portal.coren-sp.gov.br/wp-content/uploads/2010/01/uso-seguro-medicamentos.pdf"
    },
    {
      "id": "cfm2174-2017",
      "organization": "Conselho Federal de Medicina",
      "year": "2017",
      "title": "Resolução CFM nº 2.174 — prática do ato anestésico",
      "topic": "Anestesia e SRPA",
      "access": "Norma pública",
      "url": "https://sistemas.cfm.org.br/normas/arquivos/resolucoes/BR/2017/2174_2017.pdf"
    },
    {
      "id": "cfm2471-2026",
      "organization": "Conselho Federal de Medicina",
      "year": "2026",
      "title": "Resolução CFM nº 2.471 — segurança da sedação ambulatorial",
      "topic": "Anestesia e SRPA",
      "access": "Norma publicada; observar prazo de vigência",
      "url": "https://sistemas.cfm.org.br/normas/arquivos/resolucoes/BR/2026/2471_2026.pdf"
    },
    {
      "id": "cofen754-2024",
      "organization": "Cofen",
      "year": "2024",
      "title": "Resolução Cofen nº 754 — prontuário eletrônico e plataformas digitais",
      "topic": "Documentação e privacidade",
      "access": "Norma pública",
      "url": "https://www.cofen.gov.br/resolucao-cofen-no-754-de-16-de-maio-de-2024/"
    },
    {
      "id": "cofen736-2024",
      "organization": "Cofen",
      "year": "2024",
      "title": "Resolução Cofen nº 736 — implementação do Processo de Enfermagem",
      "topic": "Documentação e privacidade",
      "access": "Norma pública",
      "url": "https://www.cofen.gov.br/wp-content/uploads/2024/01/Resolucao-Cofen-no-736-2024-Dispoe-sobre-a-implementacao-do-Processo-de-Enfermagem-em-todo-contexto-socioambiental-onde-ocorre-o-cuidado-de-enfermagem.pdf"
    },
    {
      "id": "cofen-records-2023",
      "organization": "Cofen",
      "year": "2023",
      "title": "Recomendações para Registros de Enfermagem no Exercício da Profissão",
      "topic": "Documentação e privacidade",
      "access": "Acesso aberto",
      "url": "https://www.cofen.gov.br/wp-content/uploads/2024/02/Registros-de-Enfermagem-no-Exercicio-da-Profissao.pdf"
    },
    {
      "id": "cofen-ethics-564",
      "organization": "Cofen",
      "year": "2017",
      "title": "Resolução Cofen nº 564 — Código de Ética dos Profissionais de Enfermagem",
      "topic": "Ética profissional",
      "access": "Norma pública",
      "url": "https://biblioteca.cofen.gov.br/wp-content/uploads/2019/11/C%C3%B3digo-de-%C3%89tica-dos-profissionais-de-Enfermagem.pdf"
    },
    {
      "id": "lgpd",
      "organization": "Presidência da República",
      "year": "2018",
      "title": "Lei nº 13.709 — Lei Geral de Proteção de Dados Pessoais",
      "topic": "Documentação e privacidade",
      "access": "Lei pública — texto compilado",
      "url": "https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm"
    },
    {
      "id": "rdc36",
      "organization": "Anvisa",
      "year": "2013",
      "title": "RDC nº 36 — ações para a segurança do paciente em serviços de saúde",
      "topic": "Gestão de risco",
      "access": "Norma pública",
      "url": "https://bvsms.saude.gov.br/bvs/saudelegis/anvisa/2013/rdc0036_25_07_2013.html"
    },
    {
      "id": "stanford-emergency-manual",
      "organization": "Stanford Anesthesia Cognitive Aid Group",
      "year": "Atualização contínua",
      "title": "Emergency Manual — Cognitive Aids for Perioperative Critical Events",
      "topic": "Eventos críticos",
      "access": "Recurso educacional gratuito; adaptar e validar localmente",
      "url": "https://emergencymanual.stanford.edu/"
    },
    {
      "id": "mhaus-crisis",
      "organization": "MHAUS",
      "year": "2025",
      "title": "Malignant Hyperthermia Crisis Resources",
      "topic": "Eventos críticos",
      "access": "Portal institucional; materiais possuem condições próprias",
      "url": "https://www.mhaus.org/site-map/"
    },
    {
      "id": "anvisa-iras-vigilancia-2026",
      "organization": "Anvisa",
      "year": "2026",
      "title": "Nota Técnica GVIMS/GGTES/DIRE3/Anvisa nº 01/2026 — vigilância de IRAS e resistência aos antimicrobianos",
      "topic": "IRAS e vigilância",
      "access": "Acesso aberto",
      "url": "https://www.gov.br/anvisa/pt-br/centraisdeconteudo/publicacoes/servicosdesaude/notas-tecnicas/notas-tecnicas-vigentes/nota-tecnica-01-2026-vigilancia-das-iras-02-01-2026.pdf/@@download/file",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "anvisa-iras-criteria-2026",
      "organization": "Anvisa",
      "year": "2026",
      "title": "Nota Técnica GVIMS/GGTES/DIRE3/Anvisa nº 03/2026 — critérios diagnósticos das IRAS",
      "topic": "IRAS e vigilância",
      "access": "Acesso aberto",
      "url": "https://www.gov.br/anvisa/pt-br/centraisdeconteudo/publicacoes/servicosdesaude/notas-tecnicas/notas-tecnicas-vigentes/nota-tecnica-03-2026-criterios-de-iras-02-01-2026.pdf/@@display-file/file",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "anvisa-safety-practices-2026",
      "organization": "Anvisa",
      "year": "2026",
      "title": "Avaliação Nacional das Práticas de Segurança do Paciente 2026 — orientações para hospitais com UTI",
      "topic": "Segurança do paciente",
      "access": "Acesso aberto",
      "url": "https://www.gov.br/anvisa/pt-br/assuntos/servicosdesaude/seguranca-do-paciente/avaliacao-nacional-das-praticas-de-seguranca-do-paciente/HOSPITAISCOMUTIORIENTAESDEPREENCHIMENTOANSP2026.pdf",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "aorn-2026",
      "organization": "AORN",
      "year": "2026",
      "title": "Guidelines for Perioperative Practice — 2026 edition",
      "topic": "Prática perioperatória",
      "access": "Página pública; conteúdo integral licenciado",
      "url": "https://www.aorn.org/guidelines-resources/guidelines-for-perioperative-practice/book",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Edição corrente na consulta"
    },
    {
      "id": "eras-colorectal-2025",
      "organization": "ERAS Society",
      "year": "2025",
      "title": "Guidelines for perioperative care in elective colorectal surgery: ERAS Society recommendations 2025",
      "topic": "Cirurgia geral e colorretal",
      "access": "Texto completo online",
      "url": "https://www.surgjournal.com/article/S0039-6060(25)00249-1/fulltext",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta; corrigenda de 2026 verificada"
    },
    {
      "id": "espen-surgery-2025",
      "organization": "ESPEN",
      "year": "2025",
      "title": "ESPEN guideline on clinical nutrition in surgery — update 2025",
      "topic": "Cirurgia geral e recuperação",
      "access": "Texto completo online",
      "url": "https://www.clinicalnutritionjournal.com/article/S0261-5614(25)00243-2/fulltext",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "eaes-sages-older-2026",
      "organization": "EAES / SAGES",
      "year": "2026",
      "title": "Evidence-Based Recommendations on Optimization of Perioperative Care in Older Adults",
      "topic": "Cirurgia geral e recuperação",
      "access": "Acesso aberto",
      "url": "https://www.sages.org/publications/guidelines/eaes-sages-guidelines-on-perioperative-care-in-older-adults/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "aaos-trauma-ssi-2022",
      "organization": "AAOS",
      "year": "2022",
      "title": "Prevention of Surgical Site Infections After Major Extremity Trauma",
      "topic": "Ortopedia e trauma",
      "access": "Acesso aberto",
      "url": "https://www.aaos.org/SSItraumacpg",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Diretriz disponível no catálogo corrente da AAOS"
    },
    {
      "id": "aaos-guidelines-current",
      "organization": "AAOS",
      "year": "2026",
      "title": "AAOS Clinical Practice Guidelines — catálogo corrente",
      "topic": "Ortopedia e trauma",
      "access": "Acesso aberto",
      "url": "https://www.aaos.org/quality/quality-programs/clinical-practice-guidelines/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Catálogo corrente na consulta"
    },
    {
      "id": "fda-patient-guides-2026",
      "organization": "U.S. FDA",
      "year": "2026",
      "title": "Patient-Matched Guides for Orthopedic Implants — final guidance",
      "topic": "Ortopedia e dispositivos",
      "access": "Acesso aberto",
      "url": "https://www.fda.gov/media/169792/download",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Guia final de maio de 2026"
    },
    {
      "id": "eras-gyn-2026",
      "organization": "ERAS Society",
      "year": "2026",
      "title": "ERAS Society guidelines for gynecologic oncology — 2026 update",
      "topic": "Ginecologia e obstetrícia",
      "access": "Texto completo online",
      "url": "https://www.gynecologiconcology-online.net/article/S0090-8258(26)01999-2/fulltext",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "eras-cesarean-2025",
      "organization": "ERAS Society",
      "year": "2025",
      "title": "Guidelines for antenatal and preoperative care in cesarean delivery — 2025 update",
      "topic": "Ginecologia e obstetrícia",
      "access": "Texto completo online",
      "url": "https://www.ajog.org/article/S0002-9378(25)00020-1/fulltext",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "aua-stones-2026",
      "organization": "American Urological Association",
      "year": "2026",
      "title": "Surgical Management of Kidney and Ureteral Stones — AUA Guideline 2026",
      "topic": "Urologia",
      "access": "Acesso aberto",
      "url": "https://www.auanet.org/documents/Guidelines/PDF/2025%20Guidelines/Surgical%20Stones%20Unabridged%202026.pdf",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "eau-urolithiasis-current",
      "organization": "European Association of Urology",
      "year": "2026",
      "title": "EAU Guidelines on Urolithiasis — edição online corrente",
      "topic": "Urologia",
      "access": "Acesso aberto",
      "url": "https://uroweb.org/guidelines/urolithiasis/chapter/guidelines",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Edição online corrente na consulta"
    },
    {
      "id": "eau-urological-infections-current",
      "organization": "European Association of Urology",
      "year": "2026",
      "title": "EAU Guidelines on Urological Infections — edição online corrente",
      "topic": "Urologia",
      "access": "Acesso aberto",
      "url": "https://uroweb.org/guidelines/urological-infections/chapter/the-guideline",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Edição online corrente na consulta"
    },
    {
      "id": "esvs-vgei-2026",
      "organization": "European Society for Vascular Surgery",
      "year": "2026",
      "title": "ESVS Guidelines on the Management of Vascular Graft and Endograft Infections",
      "topic": "Cirurgia vascular",
      "access": "Acesso aberto",
      "url": "https://esvs.org/esvs-vgei-guidelines/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "esvs-trauma-2025",
      "organization": "European Society for Vascular Surgery",
      "year": "2025",
      "title": "ESVS Clinical Practice Guidelines on the Management of Vascular Trauma",
      "topic": "Cirurgia vascular",
      "access": "Acesso aberto pelo catálogo",
      "url": "https://esvs.org/guidelines/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "esvs-pad-2024",
      "organization": "European Society for Vascular Surgery",
      "year": "2024",
      "title": "ESVS Clinical Practice Guidelines on Asymptomatic Lower Limb PAD and Intermittent Claudication",
      "topic": "Cirurgia vascular",
      "access": "Acesso aberto",
      "url": "https://esvs.org/wp-content/uploads/2024/01/PAD-2024-Guidelines.pdf",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Disponível no catálogo corrente"
    },
    {
      "id": "acc-periop-2026",
      "organization": "ACC / AHA e sociedades parceiras",
      "year": "2026",
      "title": "Guideline for Perioperative Cardiovascular Management for Noncardiac Surgery",
      "topic": "Risco cardiovascular perioperatório",
      "access": "Acesso aberto",
      "url": "https://www.jacc.org/doi/10.1016/j.jacc.2026.06.017",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Reafirma e substitui formalmente a publicação de 2024"
    },
    {
      "id": "cns-spine-risk",
      "organization": "Congress of Neurological Surgeons",
      "year": "2021",
      "title": "Evidence-Based Guidelines for Perioperative Spine: Preoperative Surgical Risk Assessment",
      "topic": "Neurocirurgia e coluna",
      "access": "Acesso aberto",
      "url": "https://www.cns.org/guidelines/browse-guidelines-detail/2-preoperative-surgical-risk-assessement",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Página oficial disponível; atualização futura deve ser monitorada"
    },
    {
      "id": "cns-pituitary-2025",
      "organization": "Congress of Neurological Surgeons",
      "year": "2025",
      "title": "Guideline for Medical Management of Functioning Pituitary Adenomas — perioperative topics",
      "topic": "Neurocirurgia",
      "access": "Acesso aberto",
      "url": "https://www.cns.org/guidelines/management-of-patients-with-functioning-pituitary-adenomas/role-of-medical-management-patients-with-functioni",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "eras-head-neck-2017",
      "organization": "ERAS Society",
      "year": "2017",
      "title": "Optimal Perioperative Care in Major Head and Neck Cancer Surgery With Free Flap Reconstruction",
      "topic": "Cabeça e pescoço",
      "access": "Resumo PubMed",
      "url": "https://pubmed.ncbi.nlm.nih.gov/27737447/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Consenso de base; complementar com literatura recente"
    },
    {
      "id": "head-neck-review-2024",
      "organization": "Auris Nasus Larynx",
      "year": "2024",
      "title": "Enhanced recovery pathways for head and neck surgery with free tissue transfer reconstruction",
      "topic": "Cabeça e pescoço",
      "access": "Resumo PubMed",
      "url": "https://pubmed.ncbi.nlm.nih.gov/37558602",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Revisão recente de suporte"
    },
    {
      "id": "eras-cardiac-2024",
      "organization": "ERAS Cardiac Society / ERAS International / STS",
      "year": "2024",
      "title": "Perioperative Care in Cardiac Surgery — Joint Consensus Statement",
      "topic": "Cirurgia cardíaca",
      "access": "Texto completo online",
      "url": "https://www.jcvaonline.com/article/S1053-0770(24)00307-0/fulltext",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Consenso corrente identificado"
    },
    {
      "id": "eras-thoracic-2019",
      "organization": "ERAS Society / ESTS",
      "year": "2019",
      "title": "Guidelines for enhanced recovery after lung surgery",
      "topic": "Cirurgia torácica",
      "access": "Acesso aberto pela EACTS",
      "url": "https://www.eacts.org/clinical-practice-guideline/eras-ests-guidelines-for-eras-after-lung-surgery/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Diretriz oficial ainda listada pela ERAS Society"
    },
    {
      "id": "asa-pain-2026",
      "organization": "American Society of Anesthesiologists",
      "year": "2026",
      "title": "Practice Guideline on Perioperative Pain Management Using Local and Regional Analgesia",
      "topic": "Anestesia e analgesia",
      "access": "Resumo PubMed",
      "url": "https://pubmed.ncbi.nlm.nih.gov/41363869/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "eras-neonatal-2024",
      "organization": "ERAS Society",
      "year": "2024",
      "title": "ERAS Society Recommendations for Neonatal Perioperative Care",
      "topic": "Cirurgia neonatal e pediátrica",
      "access": "Resumo e metadados",
      "url": "https://jamanetwork.com/journals/jamasurgery/article-abstract/2821818",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Recomendação corrente identificada"
    },
    {
      "id": "neonatal-pain-2025",
      "organization": "BMJ Paediatrics Open / ERAS",
      "year": "2025",
      "title": "Consensus recommendations for non-pharmacological perioperative neonatal pain management",
      "topic": "Cirurgia neonatal e pediátrica",
      "access": "Acesso aberto",
      "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC12060878",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "apsa-eras",
      "organization": "American Pediatric Surgical Association",
      "year": "2023",
      "title": "Enhanced Recovery After Surgery — Pediatric Surgery NaT",
      "topic": "Cirurgia pediátrica",
      "access": "Página educacional",
      "url": "https://www.pedsurglibrary.com/apsa/view/PedSurg%20Resource/1884016/all/Enhanced_Recovery_After_Surgery__ERAS_",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Recurso educacional institucional"
    },
    {
      "id": "aorn-robotic-2026",
      "organization": "AORN Journal",
      "year": "2026",
      "title": "Enhancing Patient Care During Robotic-Assisted Surgery",
      "topic": "Cirurgia robótica",
      "access": "Registro bibliográfico",
      "url": "https://aornjournal.onlinelibrary.wiley.com/doi/10.1002/aorn.70032",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Atual na consulta"
    },
    {
      "id": "fda-rasd-draft-2026",
      "organization": "U.S. FDA",
      "year": "2026",
      "title": "Robotically-Assisted Surgical Devices — Premarket Submissions",
      "topic": "Cirurgia robótica",
      "access": "Acesso aberto",
      "url": "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/robotically-assisted-surgical-devices-premarket-submissions",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Rascunho não vinculante; não usar como norma final"
    },
    {
      "id": "who-catheter-peripheral-2024",
      "organization": "OMS",
      "year": "2024",
      "title": "Guidelines for the prevention of bloodstream infections and other infections associated with the use of intravascular catheters — Part 1: peripheral catheters",
      "topic": "Cateteres periféricos e prevenção de infecção",
      "access": "Acesso aberto; licença CC BY-NC-SA 3.0 IGO",
      "url": "https://www.who.int/publications/i/item/9789240093829",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Diretriz oficial; atual na consulta"
    },
    {
      "id": "who-catheter-central-2026",
      "organization": "OMS",
      "year": "2026",
      "title": "Guidelines for the prevention of bloodstream infections and other infections associated with the use of intravascular catheters — Part 2: central venous catheters",
      "topic": "Cateteres venosos centrais e prevenção de infecção",
      "access": "Acesso aberto; licença CC BY-NC-SA 3.0 IGO",
      "url": "https://www.who.int/publications/i/item/9789240121805",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Diretriz oficial publicada em 28/05/2026; atual na consulta"
    },
    {
      "id": "ins-infusion-2024",
      "organization": "Infusion Nurses Society",
      "year": "2024",
      "title": "Infusion Therapy Standards of Practice — 9th edition",
      "topic": "Terapia infusional e dispositivos de acesso vascular",
      "access": "Página pública; conteúdo integral licenciado",
      "url": "https://www.ins1.org/publications/infusion-therapy-standards-of-practice/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "9ª edição identificada como versão corrente; texto integral sujeito a licença"
    },
    {
      "id": "asa-central-venous-2020",
      "organization": "American Society of Anesthesiologists",
      "year": "2020",
      "title": "Practice Guidelines for Central Venous Access 2020",
      "topic": "Acesso venoso central",
      "access": "Artigo e resumo público",
      "url": "https://pubmed.ncbi.nlm.nih.gov/31821240/",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Diretriz oficial ainda listada pela ASA; complementar à OMS 2026"
    },
    {
      "id": "asa-difficult-airway-2022",
      "organization": "American Society of Anesthesiologists",
      "year": "2022",
      "title": "Practice Guidelines for Management of the Difficult Airway",
      "topic": "Via aérea e planejamento de contingência",
      "access": "Texto completo online",
      "url": "https://pubs.asahq.org/anesthesiology/article/136/1/31/117915/2022-American-Society-of-Anesthesiologists",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Diretriz oficial listada como vigente na consulta"
    },
    {
      "id": "cdc-cauti-2025",
      "organization": "CDC",
      "year": "2025",
      "title": "Clinical Safety: Preventing Catheter-associated Urinary Tract Infections",
      "topic": "Cateter urinário e prevenção de ITU associada",
      "access": "Acesso aberto",
      "url": "https://www.cdc.gov/uti/hcp/clinical-safety/index.html",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Página oficial atualizada em 27/06/2025; remete à diretriz CDC de 2009"
    },
    {
      "id": "aorn-skin-antisepsis-2026",
      "organization": "AORN",
      "year": "2026",
      "title": "Skin Preparation for Surgery: Techniques, Solutions, and Standards",
      "topic": "Antissepsia pré-operatória da pele",
      "access": "Resumo público; diretriz integral licenciada",
      "url": "https://www.aorn.org/outpatient-surgery/article/the-essentials-peerless-skin-prep-here-s-how",
      "verifiedOn": "2026-10-13",
      "referenceStatus": "Resumo público corrente; conteúdo integral da diretriz sujeito a licença"
    }
  ],
  "mediaSources": [
    {
      "name": "NIH BioArt Source",
      "license": "Domínio público ou licença indicada por item",
      "use": "Vetores médicos e científicos; verificar a página de cada arquivo.",
      "url": "https://bioart.niaid.nih.gov/"
    },
    {
      "name": "Servier Medical Art",
      "license": "CC BY 4.0",
      "use": "Ilustrações médicas reutilizáveis inclusive comercialmente, com atribuição.",
      "url": "https://smart.servier.com/"
    },
    {
      "name": "Wikimedia Commons",
      "license": "Varia por arquivo",
      "use": "Usar somente após registrar autor, URL e licença do item individual.",
      "url": "https://commons.wikimedia.org/wiki/Category:Surgical_instruments"
    },
    {
      "name": "OpenStax Anatomy & Physiology 1e — cópias históricas",
      "license": "CC BY 4.0 em repositórios identificados",
      "use": "Confirmar edição e licença do arquivo específico; a edição 2e atual é CC BY-NC-SA e não serve automaticamente para produto comercial.",
      "url": "https://med.libretexts.org/Bookshelves/Anatomy_and_Physiology/Anatomy_and_Physiology_1e_(OpenStax)"
    }
  ],
  "roadmap": {
    "updatedOn": "2026-10-14",
    "northStar": "Evoluir do MVP perioperatório para uma plataforma médica de procedimentos e materiais integrada, rastreável e segura, sem confundir estudo digital com habilitação prática.",
    "phases": [
      {
        "id": "produto-mvp",
        "order": "00",
        "title": "Produto-base",
        "status": "Concluído",
        "progress": 100,
        "horizon": "Entregue",
        "description": "SPA responsiva com biblioteca, matriz técnica corrigida, Atlas de Materiais, planos, avaliações, remediação, progresso, videoteca e fontes.",
        "deliverables": [
          "Navegação e persistência local",
          "Experiência responsiva",
          "Matriz técnica de 28 módulos — MB01",
          "Modelo editorial de 14 campos",
          "Atlas de Materiais — MB02",
          "Planos de estudo progressivos",
          "Remediação formativa por competência",
          "Videoteca por links externos",
          "Biblioteca científica"
        ]
      },
      {
        "id": "conteudo-p0",
        "order": "01",
        "title": "Fundamentos P0",
        "status": "Auditoria adiada",
        "progress": 80,
        "horizon": "Após conclusão editorial completa",
        "description": "Fundamentos atuais preservados e mapeados à nova matriz. Próxima expansão prioriza acessos, administração, feridas, suturas, imobilizações e diagnóstico à beira-leito.",
        "deliverables": [
          "14 trilhas de fundamentos organizadas",
          "40 aulas na etapa Fundamentos seguros",
          "Bibliografia contextual",
          "Revisão clínica formal pendente"
        ]
      },
      {
        "id": "conteudo-p1",
        "order": "02",
        "title": "Prática ampliada P1",
        "status": "Auditoria adiada",
        "progress": 76,
        "horizon": "Após conclusão editorial completa",
        "description": "Prática ampliada inclui agora procedimentos, vias cirúrgicas, acessos vasculares, via aérea, sondas, drenos e assistência multiprofissional.",
        "deliverables": [
          "9 trilhas de prática ampliada",
          "35 aulas na etapa Prática perioperatória ampliada",
          "Procedimentos, acessos, vias, sondas e drenos",
          "Revisão multiprofissional pendente"
        ]
      },
      {
        "id": "casos-avaliacao",
        "order": "03",
        "title": "Casos e avaliação robusta",
        "status": "Auditoria adiada",
        "progress": 86,
        "horizon": "Após conclusão editorial completa",
        "description": "Blueprint com 28 competências, 210 questões e 30 casos, relatório por competência e remediação com aulas recomendadas. Revisão clínica e piloto adiados.",
        "deliverables": [
          "Blueprint com 28 competências",
          "30 casos situacionais",
          "210 questões estruturadas",
          "Relatório formativo por competência",
          "Remediação com 84 vínculos de aula",
          "Auditoria clínica consolidada ao final"
        ]
      },
      {
        "id": "especialidades-p2",
        "order": "04",
        "title": "Anatomia e especialidades P2",
        "status": "Em desenvolvimento",
        "progress": 78,
        "horizon": "Após validação do núcleo",
        "description": "Dez trilhas, 40 aulas, 40 flashcards, 10 competências, 60 questões, 10 casos e checklists P2 incorporados; anatomia visual licenciada e aprofundamento editorial ainda pendentes.",
        "deliverables": [
          "10 trilhas de especialidade incorporadas",
          "40 aulas e 40 flashcards P2",
          "Competências C19–C28 com 60 questões e 10 casos",
          "Checklists de estudo por especialidade",
          "Anatomia visual com ativos licenciados — pendente",
          "Revisão clínica consolidada ao final da produção"
        ]
      },
      {
        "id": "governanca-validacao",
        "order": "05",
        "title": "Governança e validação",
        "status": "Parcial",
        "progress": 32,
        "horizon": "Transversal",
        "description": "Rastreabilidade de fontes e direitos em andamento; revisão clínica formal e piloto adiados até a conclusão editorial.",
        "deliverables": [
          "Revisores nomeados",
          "Termos de aprovação",
          "Registro de ativos e licenças",
          "Calendário de revisão e errata"
        ]
      },
      {
        "id": "produto-producao",
        "order": "06",
        "title": "Plataforma de produção",
        "status": "Planejado",
        "progress": 15,
        "horizon": "Após gates clínicos",
        "description": "Backend, autenticação, painel editorial, analytics de aprendizagem e controle de versões.",
        "deliverables": [
          "Banco e API",
          "Perfis e permissões",
          "Workflow editorial",
          "Telemetria com privacidade e acessibilidade"
        ]
      }
    ]
  },
  "references": [
    "Organização Mundial da Saúde — Lista de Verificação de Segurança Cirúrgica",
    "Anvisa — Protocolo de Prevenção de Infecção de Sítio Cirúrgico, 2025",
    "SOBECC — Diretrizes de Práticas em Enfermagem Perioperatória e Processamento de Produtos para Saúde, 8ª edição",
    "AORN — Guidelines for Perioperative Practice",
    "Protocolos e padronizações da instituição de ensino ou serviço de saúde"
  ],
  "competencies": [
    {
      "id": "C01",
      "title": "Instrumentais cirúrgicos",
      "description": "Identificar função, integridade e uso seguro dos instrumentais.",
      "moduleId": "instrumentais",
      "targetQuestions": 9,
      "sourceIds": [
        "sobecc8",
        "aorn-safety"
      ]
    },
    {
      "id": "C02",
      "title": "Fios e suturas",
      "description": "Relacionar propriedades de fios e agulhas ao contexto, embalagem e segurança.",
      "moduleId": "fios-suturas",
      "targetQuestions": 8,
      "sourceIds": [
        "suture-review",
        "nr32"
      ]
    },
    {
      "id": "C03",
      "title": "Posicionamento",
      "description": "Prevenir lesões por pressão, estiramento, compressão e deslocamento.",
      "moduleId": "posicionamento",
      "targetQuestions": 8,
      "sourceIds": [
        "positioning-review",
        "aorn-safety"
      ]
    },
    {
      "id": "C04",
      "title": "Técnica asséptica",
      "description": "Reconhecer limites do campo e corrigir quebras de técnica.",
      "moduleId": "assepsia-seguranca",
      "targetQuestions": 10,
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8"
      ]
    },
    {
      "id": "C05",
      "title": "Anatomia aplicada",
      "description": "Usar planos e relações anatômicas sem extrapolar o escopo profissional.",
      "moduleId": "anatomia",
      "targetQuestions": 6,
      "sourceIds": [
        "openstax-anatomy"
      ]
    },
    {
      "id": "C06",
      "title": "Fluxo do procedimento",
      "description": "Antecipar etapas, recursos e encerramento com comunicação e rastreabilidade.",
      "moduleId": "fluxo-procedimentos",
      "targetQuestions": 7,
      "sourceIds": [
        "br-safe-surgery",
        "aorn-specimen",
        "rdc15"
      ]
    },
    {
      "id": "C07",
      "title": "Ambiente e equipe",
      "description": "Aplicar zoneamento, fluxo, responsabilidades e escalonamento.",
      "moduleId": "ambiente-equipe",
      "targetQuestions": 7,
      "sourceIds": [
        "sobecc8",
        "nr32",
        "cofen214",
        "cofen609"
      ]
    },
    {
      "id": "C08",
      "title": "Cirurgia segura",
      "description": "Executar checagens e comunicação efetiva nos três momentos.",
      "moduleId": "cirurgia-segura",
      "targetQuestions": 10,
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ]
    },
    {
      "id": "C09",
      "title": "Prevenção de ISC",
      "description": "Integrar barreiras pré, intra e pós-operatórias contra infecção.",
      "moduleId": "prevencao-isc",
      "targetQuestions": 9,
      "sourceIds": [
        "anvisa-isc-2025",
        "cdc-ssi-2017",
        "shea-ssi-2022"
      ]
    },
    {
      "id": "C10",
      "title": "Contagens",
      "description": "Manter controle confiável e responder corretamente à divergência.",
      "moduleId": "contagens-itens",
      "targetQuestions": 9,
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ]
    },
    {
      "id": "C11",
      "title": "Espécimes e implantes",
      "description": "Preservar identidade, integridade e rastreabilidade.",
      "moduleId": "especimes-implantes",
      "targetQuestions": 8,
      "sourceIds": [
        "aorn-specimen",
        "rdc36",
        "sobecc8"
      ]
    },
    {
      "id": "C12",
      "title": "CME e processamento",
      "description": "Relacionar limpeza, inspeção, preparo, monitoramento e liberação.",
      "moduleId": "cme-processamento",
      "targetQuestions": 11,
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ]
    },
    {
      "id": "C13",
      "title": "Energia, fogo e fumaça",
      "description": "Prevenir queimadura, incêndio e exposição à fumaça cirúrgica.",
      "moduleId": "energia-fogo-fumaca",
      "targetQuestions": 9,
      "sourceIds": [
        "aorn-energy-2026",
        "anvisa-fire-2014",
        "niosh-smoke"
      ]
    },
    {
      "id": "C14",
      "title": "Medicamentos",
      "description": "Aplicar rotulagem, checagem e resposta a erro de medicamento.",
      "moduleId": "medicamentos-rotulagem",
      "targetQuestions": 9,
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ]
    },
    {
      "id": "C15",
      "title": "Anestesia e SRPA",
      "description": "Apoiar ambiente, transferência e vigilância dentro do escopo.",
      "moduleId": "anestesia-srpa",
      "targetQuestions": 8,
      "sourceIds": [
        "cfm2174-2017",
        "cfm2471-2026",
        "sobecc8"
      ]
    },
    {
      "id": "C16",
      "title": "Segurança ocupacional",
      "description": "Controlar exposições biológicas, químicas, físicas e ergonômicas.",
      "moduleId": "seguranca-ocupacional",
      "targetQuestions": 8,
      "sourceIds": [
        "nr32",
        "niosh-smoke",
        "anvisa-fire-2014"
      ]
    },
    {
      "id": "C17",
      "title": "Documentação e privacidade",
      "description": "Registrar com precisão e proteger dados sensíveis.",
      "moduleId": "documentacao-etica-privacidade",
      "targetQuestions": 8,
      "sourceIds": [
        "cofen754-2024",
        "cofen736-2024",
        "cofen-records-2023",
        "cofen-ethics-564",
        "lgpd"
      ]
    },
    {
      "id": "C18",
      "title": "Eventos críticos",
      "description": "Organizar liderança, comunicação, auxílio cognitivo e simulação.",
      "moduleId": "eventos-criticos",
      "targetQuestions": 6,
      "sourceIds": [
        "rdc36",
        "stanford-emergency-manual",
        "mhaus-crisis"
      ]
    },
    {
      "id": "C19",
      "title": "Cirurgia geral e digestiva",
      "description": "Organizar acesso, transições de contaminação, dispositivos, espécimes e recuperação na cirurgia abdominal.",
      "moduleId": "cirurgia-geral-digestiva",
      "targetQuestions": 6,
      "sourceIds": [
        "eras-colorectal-2025",
        "espen-surgery-2025",
        "anvisa-isc-2025"
      ]
    },
    {
      "id": "C20",
      "title": "Ortopedia e trauma",
      "description": "Aplicar barreiras de lateralidade, imagem, implantes, torniquete, amostras e rastreabilidade.",
      "moduleId": "ortopedia-trauma",
      "targetQuestions": 6,
      "sourceIds": [
        "aaos-trauma-ssi-2022",
        "aaos-guidelines-current",
        "fda-patient-guides-2026"
      ]
    },
    {
      "id": "C21",
      "title": "Ginecologia e obstetrícia",
      "description": "Integrar segurança pélvica, posicionamento, espécimes e coordenação materno-neonatal.",
      "moduleId": "ginecologia-obstetricia",
      "targetQuestions": 6,
      "sourceIds": [
        "eras-gyn-2026",
        "eras-cesarean-2025",
        "anvisa-iras-criteria-2026"
      ]
    },
    {
      "id": "C22",
      "title": "Urologia",
      "description": "Preparar endourologia, irrigação, energia, amostras e dispositivos com segurança.",
      "moduleId": "urologia",
      "targetQuestions": 6,
      "sourceIds": [
        "aua-stones-2026",
        "eau-urolithiasis-current",
        "eau-urological-infections-current"
      ]
    },
    {
      "id": "C23",
      "title": "Cirurgia vascular",
      "description": "Coordenar sala aberta ou híbrida, marcos vasculares, imagem, enxertos e documentação.",
      "moduleId": "cirurgia-vascular",
      "targetQuestions": 6,
      "sourceIds": [
        "esvs-vgei-2026",
        "esvs-trauma-2025",
        "acc-periop-2026"
      ]
    },
    {
      "id": "C24",
      "title": "Neurocirurgia e coluna",
      "description": "Aplicar barreiras para nível, posicionamento, tecnologia, neuromonitorização, implantes e espécimes.",
      "moduleId": "neurocirurgia-coluna",
      "targetQuestions": 6,
      "sourceIds": [
        "cns-spine-risk",
        "cns-pituitary-2025",
        "anvisa-isc-2025"
      ]
    },
    {
      "id": "C25",
      "title": "Cabeça e pescoço",
      "description": "Coordenar via aérea compartilhada, energia, espécimes, reconstrução e handoff especializado.",
      "moduleId": "cabeca-pescoco",
      "targetQuestions": 6,
      "sourceIds": [
        "eras-head-neck-2017",
        "head-neck-review-2024",
        "asa-pain-2026"
      ]
    },
    {
      "id": "C26",
      "title": "Cirurgia torácica e cardíaca",
      "description": "Integrar ventilação, posição lateral, drenos, circulação extracorpórea, implantes e transferência.",
      "moduleId": "toracica-cardiaca",
      "targetQuestions": 6,
      "sourceIds": [
        "eras-cardiac-2024",
        "eras-thoracic-2019",
        "acc-periop-2026"
      ]
    },
    {
      "id": "C27",
      "title": "Cirurgia pediátrica e neonatal",
      "description": "Adaptar identificação, termorregulação, equipamentos, transferência e participação familiar à pediatria.",
      "moduleId": "cirurgia-pediatrica-neonatal",
      "targetQuestions": 6,
      "sourceIds": [
        "eras-neonatal-2024",
        "neonatal-pain-2025",
        "apsa-eras"
      ]
    },
    {
      "id": "C28",
      "title": "Cirurgia minimamente invasiva e robótica",
      "description": "Planejar docking, interface estéril, instrumentos, alertas, undocking e conversão segura.",
      "moduleId": "minimamente-invasiva-robotica",
      "targetQuestions": 6,
      "sourceIds": [
        "aorn-2026",
        "aorn-robotic-2026",
        "fda-rasd-draft-2026"
      ]
    }
  ],
  "assessmentBlueprint": {
    "version": "1.2",
    "updatedOn": "2026-10-13",
    "targetCompetencies": 28,
    "targetQuestions": 210,
    "targetCases": 30,
    "cognitiveDistribution": [
      {
        "level": "Básico",
        "target": 25,
        "description": "Reconhecer conceitos, riscos e elementos essenciais."
      },
      {
        "level": "Aplicação",
        "target": 55,
        "description": "Escolher a conduta segura em contexto típico."
      },
      {
        "level": "Análise",
        "target": 20,
        "description": "Priorizar, reconciliar e escalonar em cenários ambíguos."
      }
    ],
    "rules": [
      "Uma única melhor resposta, sem pistas gramaticais.",
      "Distratores plausíveis, mas claramente inadequados à luz da fonte.",
      "Justificativa explica a decisão e o risco controlado.",
      "Cada item vinculado a competência, dificuldade e fontes.",
      "Questões clínicas não prescrevem dose ou conduta individual fora de protocolo.",
      "Itens passam por revisão técnica independente antes do gate clínico.",
      "Posições de gabarito balanceadas sem padrão previsível.",
      "Resultados por competência são formativos até validação e piloto.",
      "Itens P2 avaliam processo e decisão segura, não técnica operatória autônoma.",
      "Parâmetros de dispositivos dependem de IFU, protocolo e profissional habilitado."
    ]
  },
  "cases": [
    {
      "id": "caso-01",
      "number": "01",
      "title": "Lateralidade divergente na pausa",
      "category": "Cirurgia segura",
      "moduleId": "cirurgia-segura",
      "competencyId": "C08",
      "difficulty": "Aplicação",
      "context": "Durante a pausa antes da incisão, a equipe verbaliza o lado direito, mas o documento disponível na sala indica lado esquerdo. O paciente já está anestesiado e a marcação não está claramente visível.",
      "prompt": "Qual é a decisão mais segura?",
      "options": [
        "Registrar a divergência somente depois",
        "Prosseguir pelo lado verbalizado pelo cirurgião",
        "Escolher o lado descrito no documento mais recente",
        "Interromper e reconciliar todas as fontes antes da incisão"
      ],
      "answer": 3,
      "rationale": "A pausa existe para revelar e resolver discrepâncias. Nenhuma fonte isolada deve ser presumida correta quando identidade, procedimento ou local divergem.",
      "consequence": "Prosseguir sem reconciliação pode resultar em procedimento em local incorreto. A equipe deve manter a barreira até confirmação formal.",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery"
      ]
    },
    {
      "id": "caso-02",
      "number": "02",
      "title": "Risco crítico não compartilhado",
      "category": "Cirurgia segura",
      "moduleId": "cirurgia-segura",
      "competencyId": "C08",
      "difficulty": "Análise",
      "context": "A equipe inicia a pausa, mas há conversas paralelas. O anestesiologista tenta informar risco relevante de via aérea e o cirurgião discute outro caso ao telefone.",
      "prompt": "Como reorganizar a comunicação?",
      "options": [
        "Registrar que a pausa foi realizada",
        "Prosseguir e discutir o risco se ocorrer problema",
        "Pedir ao anestesiologista para escrever a informação",
        "Pausar as conversas, obter atenção compartilhada e reiniciar os itens críticos"
      ],
      "answer": 3,
      "rationale": "Checklist efetivo requer atenção da equipe. Informação crítica sem escuta e confirmação não constitui barreira confiável.",
      "consequence": "Reiniciar a comunicação protege o modelo mental compartilhado e permite preparar recursos antes da incisão.",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery",
        "aorn-safety"
      ]
    },
    {
      "id": "caso-03",
      "number": "03",
      "title": "Transferência com pendências",
      "category": "Cirurgia segura",
      "moduleId": "cirurgia-segura",
      "competencyId": "C08",
      "difficulty": "Aplicação",
      "context": "Na saída da sala, espécimes foram confirmados, mas uma falha de equipamento e uma preocupação para recuperação não receberam responsável definido.",
      "prompt": "O que falta para encerrar com segurança?",
      "options": [
        "Somente assinar a lista",
        "Definir responsáveis, destino e comunicação das pendências",
        "Aguardar o próximo plantão descobrir",
        "Excluir a falha do registro"
      ],
      "answer": 1,
      "rationale": "A saída precisa transformar preocupações em plano de continuidade. Pendência sem responsável pode se perder na transição.",
      "consequence": "Atribuir destino e responsabilidade reduz falha de equipamento recorrente e deterioração não reconhecida na recuperação.",
      "sourceIds": [
        "br-safe-surgery",
        "who-safe-surgery"
      ]
    },
    {
      "id": "caso-04",
      "number": "04",
      "title": "Pacote úmido no momento da abertura",
      "category": "Assepsia e ISC",
      "moduleId": "assepsia-seguranca",
      "competencyId": "C04",
      "difficulty": "Aplicação",
      "context": "Um conjunto esterilizado chega à sala dentro da validade, com indicadores externos compatíveis, mas a embalagem apresenta área úmida.",
      "prompt": "Qual é a conduta adequada?",
      "options": [
        "Secar e abrir",
        "Considerar a barreira comprometida, substituir e comunicar",
        "Usar apenas os itens do centro da caixa",
        "Cobrir a área úmida com campo"
      ],
      "answer": 1,
      "rationale": "Umidade pode comprometer a barreira estéril. Validade e indicador externo não anulam a não conformidade de integridade.",
      "consequence": "A substituição evita introduzir material de esterilidade não confirmada e permite investigar transporte, secagem ou armazenamento.",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "sobecc8"
      ]
    },
    {
      "id": "caso-05",
      "number": "05",
      "title": "Preparo da pele e risco combinado",
      "category": "Assepsia e ISC",
      "moduleId": "prevencao-isc",
      "competencyId": "C09",
      "difficulty": "Análise",
      "context": "Após preparo da pele, observa-se solução acumulada sob o paciente. O procedimento prevê uso de energia e presença de oxidante próximo ao campo.",
      "prompt": "Qual prioridade deve orientar a equipe?",
      "options": [
        "Interromper o início, remover o risco conforme protocolo e confirmar secagem",
        "Cobrir rapidamente a área",
        "Reduzir a luz da sala",
        "Aumentar a potência para compensar"
      ],
      "answer": 0,
      "rationale": "Solução acumulada pode lesar a pele e funcionar como combustível. A combinação com ignição e oxidante exige correção antes do uso de energia.",
      "consequence": "Resolver o acúmulo e confirmar condições seguras reduz risco simultâneo de lesão química e incêndio.",
      "sourceIds": [
        "anvisa-isc-2025",
        "anvisa-fire-2014",
        "aorn-energy-2026"
      ]
    },
    {
      "id": "caso-06",
      "number": "06",
      "title": "Quebra de técnica verbalizada",
      "category": "Assepsia e ISC",
      "moduleId": "assepsia-seguranca",
      "competencyId": "C04",
      "difficulty": "Aplicação",
      "context": "Um integrante percebe contato da manga estéril com superfície não estéril. O procedimento está em etapa de grande concentração e ninguém mais parece ter notado.",
      "prompt": "Qual comportamento demonstra cultura de segurança?",
      "options": [
        "Silenciar para não interromper",
        "Esperar o debriefing",
        "Cobrir a manga sem avisar",
        "Verbalizar imediatamente e executar a correção definida"
      ],
      "answer": 3,
      "rationale": "Quebra de técnica precisa ser comunicada quando ocorre. Hierarquia ou concentração não eliminam o risco.",
      "consequence": "A comunicação permite substituir ou corrigir a barreira antes de novo contato com o campo.",
      "sourceIds": [
        "anvisa-isc-2025",
        "sobecc8",
        "rdc36"
      ]
    },
    {
      "id": "caso-07",
      "number": "07",
      "title": "Mudança de posição após cobertura",
      "category": "Posicionamento",
      "moduleId": "posicionamento",
      "competencyId": "C03",
      "difficulty": "Análise",
      "context": "Com o paciente em posição prona e campos colocados, a mesa é inclinada. Um acesso e um apoio facial ficam parcialmente ocultos.",
      "prompt": "Qual resposta é mais segura?",
      "options": [
        "Presumir que os apoios permaneceram adequados",
        "Retirar a monitorização",
        "Coordenar reavaliação de alinhamento, face, acessos e fixações",
        "Aguardar o fim para inspecionar"
      ],
      "answer": 2,
      "rationale": "Movimentação pode alterar pressão, alinhamento, via aérea, acessos e contenção. O fato de os pontos estarem cobertos aumenta a necessidade de verificação coordenada.",
      "consequence": "A reavaliação reduz risco de pressão ocular/facial, deslocamento e comprometimento de dispositivos.",
      "sourceIds": [
        "positioning-review",
        "aorn-safety",
        "sobecc8"
      ]
    },
    {
      "id": "caso-08",
      "number": "08",
      "title": "Procedimento prolongado em litotomia",
      "category": "Posicionamento",
      "moduleId": "posicionamento",
      "competencyId": "C03",
      "difficulty": "Aplicação",
      "context": "Um procedimento em litotomia excede o tempo previsto. Os apoios não foram reavaliados desde o início e a equipe prepara nova inclinação da mesa.",
      "prompt": "O que deve acontecer antes de prosseguir?",
      "options": [
        "Reavaliar apoios, pressão, alinhamento e fixações em equipe",
        "Apertar todas as contenções",
        "Retirar uma perna por vez sem coordenação",
        "Nada, porque a posição inicial foi conferida"
      ],
      "answer": 0,
      "rationale": "Tempo e mudança da mesa alteram risco de pressão, estiramento e deslocamento.",
      "consequence": "Reavaliação estruturada permite corrigir pressão focal e coordenar movimentação dos membros.",
      "sourceIds": [
        "positioning-review",
        "sobecc8"
      ]
    },
    {
      "id": "caso-09",
      "number": "09",
      "title": "Agulha ausente na contagem",
      "category": "Contagens",
      "moduleId": "contagens-itens",
      "competencyId": "C10",
      "difficulty": "Análise",
      "context": "Na contagem antes do fechamento, falta uma agulha. Uma nova contagem confirma a divergência e a busca inicial não localiza o item.",
      "prompt": "Qual é a próxima resposta do sistema?",
      "options": [
        "Abrir outro fio para equilibrar a quantidade",
        "Registrar como correta porque a agulha é pequena",
        "Comunicar a liderança e seguir o escalonamento clínico e de busca",
        "Descartar o registro anterior"
      ],
      "answer": 2,
      "rationale": "Divergência confirmada exige liderança, busca sistemática, decisão clínica e documentação conforme protocolo.",
      "consequence": "Normalizar a divergência elimina uma barreira contra item retido e compromete o registro assistencial.",
      "sourceIds": [
        "who-retained",
        "sobecc8",
        "aorn-safety"
      ]
    },
    {
      "id": "caso-10",
      "number": "10",
      "title": "Contagem interrompida por emergência",
      "category": "Contagens",
      "moduleId": "contagens-itens",
      "competencyId": "C10",
      "difficulty": "Análise",
      "context": "Uma deterioração súbita interrompe a contagem. Após estabilização, a equipe não sabe até qual grupo de itens havia chegado.",
      "prompt": "Como recuperar a confiabilidade?",
      "options": [
        "Continuar do número provável",
        "Marcar como correta pela urgência",
        "Somar apenas itens novos",
        "Reiniciar a etapa indicada e documentar a interrupção"
      ],
      "answer": 3,
      "rationale": "Sem sequência conhecida, o resultado não é confiável. A urgência justifica a interrupção, não a falsificação da reconciliação.",
      "consequence": "Reinício protegido e registro da exceção preservam segurança sem ignorar a prioridade clínica anterior.",
      "sourceIds": [
        "who-retained",
        "sobecc8"
      ]
    },
    {
      "id": "caso-11",
      "number": "11",
      "title": "Espécime sem identificação",
      "category": "Espécimes e implantes",
      "moduleId": "especimes-implantes",
      "competencyId": "C11",
      "difficulty": "Análise",
      "context": "Ao final de dois procedimentos consecutivos, um recipiente com tecido é encontrado sem rótulo. Há duas solicitações abertas, mas ninguém consegue confirmar de imediato a origem.",
      "prompt": "Qual decisão preserva a cadeia de identidade?",
      "options": [
        "Interromper o fluxo e aplicar o protocolo de espécime não identificado",
        "Usar o horário aproximado",
        "Escolher o caso mais provável",
        "Descartar sem notificação"
      ],
      "answer": 0,
      "rationale": "Identidade de amostra não pode ser reconstruída por suposição. A instituição precisa conduzir investigação e decisão formal.",
      "consequence": "Rotular por probabilidade pode produzir diagnóstico atribuído ao paciente errado.",
      "sourceIds": [
        "aorn-specimen",
        "br-safe-surgery",
        "rdc36"
      ]
    },
    {
      "id": "caso-12",
      "number": "12",
      "title": "Implante sem rastreabilidade completa",
      "category": "Espécimes e implantes",
      "moduleId": "especimes-implantes",
      "competencyId": "C11",
      "difficulty": "Aplicação",
      "context": "O implante solicitado está disponível e íntegro, mas a etiqueta de lote não corresponde ao cadastro do sistema. Existe outro produto rastreável em estoque.",
      "prompt": "Qual é a conduta mais segura?",
      "options": [
        "Usar e corrigir o lote depois",
        "Segregar a divergência e usar alternativa rastreável após confirmação",
        "Copiar o lote de produto semelhante",
        "Omitir o lote do prontuário"
      ],
      "answer": 1,
      "rationale": "Compatibilidade e integridade não substituem rastreabilidade. A divergência deve ser resolvida antes do uso.",
      "consequence": "Registro incorreto impede recall, investigação de falha e vínculo seguro entre produto e paciente.",
      "sourceIds": [
        "rdc36",
        "sobecc8"
      ]
    },
    {
      "id": "caso-13",
      "number": "13",
      "title": "Resíduo após a limpeza",
      "category": "CME",
      "moduleId": "cme-processamento",
      "competencyId": "C12",
      "difficulty": "Aplicação",
      "context": "Durante inspeção com iluminação e magnificação, observa-se resíduo na articulação de um instrumental já enviado para preparo da caixa.",
      "prompt": "Qual etapa deve seguir?",
      "options": [
        "Aplicar apenas indicador químico",
        "Embalar e aumentar o ciclo",
        "Remover superficialmente e liberar",
        "Retornar o item ao fluxo de limpeza"
      ],
      "answer": 3,
      "rationale": "Item com sujidade não atende ao critério de limpeza e não pode avançar para processamento final.",
      "consequence": "Esterilização não corrige matéria orgânica remanescente e a caixa precisa ser reconciliada.",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016",
        "who-reprocess-2022"
      ]
    },
    {
      "id": "caso-14",
      "number": "14",
      "title": "Carga com critério de liberação não atendido",
      "category": "CME",
      "moduleId": "cme-processamento",
      "competencyId": "C12",
      "difficulty": "Análise",
      "context": "Uma carga é necessária para a primeira cirurgia do dia. Um parâmetro previsto está fora do critério e algumas embalagens apresentam umidade.",
      "prompt": "Como o sistema de qualidade deve responder?",
      "options": [
        "Liberar somente os pacotes secos",
        "Reetiquetar a carga",
        "Reter a carga e investigar antes de qualquer liberação",
        "Secar externamente e distribuir"
      ],
      "answer": 2,
      "rationale": "Parâmetro não atendido e umidade impedem liberação. Pressão operacional não substitui critérios validados.",
      "consequence": "A retenção protege pacientes e permite avaliar ciclo, carga, equipamento, embalagem e secagem.",
      "sourceIds": [
        "rdc15",
        "who-reprocess-2016"
      ]
    },
    {
      "id": "caso-15",
      "number": "15",
      "title": "Seringa sem rótulo no campo",
      "category": "Medicamentos",
      "moduleId": "medicamentos-rotulagem",
      "competencyId": "C14",
      "difficulty": "Aplicação",
      "context": "Uma seringa transparente está no campo sem identificação. Dois medicamentos incolores foram preparados recentemente e os profissionais não concordam sobre o conteúdo.",
      "prompt": "Qual é a única decisão aceitável?",
      "options": [
        "Não administrar e descartar conforme protocolo",
        "Comparar o cheiro",
        "Usar a opção mais provável",
        "Completar o rótulo pelo horário"
      ],
      "answer": 0,
      "rationale": "Aspecto, memória e contexto não confirmam conteúdo. Medicamento não identificado não deve ser administrado.",
      "consequence": "O descarte controlado evita troca de medicamento e deve gerar revisão do processo de rotulagem imediata.",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm",
        "coren-sp-med-guide"
      ]
    },
    {
      "id": "caso-16",
      "number": "16",
      "title": "Ordem verbal e medicamento de alta vigilância",
      "category": "Medicamentos",
      "moduleId": "medicamentos-rotulagem",
      "competencyId": "C14",
      "difficulty": "Análise",
      "context": "Durante uma intercorrência, é emitida ordem verbal para medicamento de alta vigilância. O ruído impede ouvir claramente a concentração e duas apresentações estão disponíveis.",
      "prompt": "Qual barreira deve ser aplicada antes da administração?",
      "options": [
        "Escolher a apresentação mais comum",
        "Esperar o fim para registrar",
        "Solicitar repetição, fazer read-back e confirmar apresentação e dose",
        "Administrar metade de cada apresentação"
      ],
      "answer": 2,
      "rationale": "Ambiguidade em medicamento de alto risco precisa ser resolvida por comunicação fechada e checagem protocolada.",
      "consequence": "Prosseguir com informação incompleta pode produzir erro grave de dose ou concentração.",
      "sourceIds": [
        "br-med-safety-2013",
        "who-med-harm"
      ]
    },
    {
      "id": "caso-17",
      "number": "17",
      "title": "Triângulo do fogo no campo",
      "category": "Energia, fogo e fumaça",
      "moduleId": "energia-fogo-fumaca",
      "competencyId": "C13",
      "difficulty": "Análise",
      "context": "O procedimento é próximo à face, há oxidante suplementar, preparo alcoólico ainda úmido e uso imediato de unidade de energia planejado.",
      "prompt": "Qual ação vem antes da ativação?",
      "options": [
        "Cobrir a umidade com gaze",
        "Aumentar potência para reduzir tempo",
        "Interromper e alinhar redução dos riscos de oxidante, combustível e ignição",
        "Ativar fora do campo para testar"
      ],
      "answer": 2,
      "rationale": "Os três elementos do fogo estão presentes. A equipe deve corrigir as condições e compartilhar o plano antes da fonte de ignição.",
      "consequence": "A intervenção coordenada previne fogo no campo e possível lesão de via aérea ou face.",
      "sourceIds": [
        "anvisa-fire-2014",
        "aorn-energy-2026"
      ]
    },
    {
      "id": "caso-18",
      "number": "18",
      "title": "Evacuação de fumaça indisponível",
      "category": "Energia, fogo e fumaça",
      "moduleId": "energia-fogo-fumaca",
      "competencyId": "C13",
      "difficulty": "Aplicação",
      "context": "O caso produzirá pluma cirúrgica, mas o evacuador local não inicia. A ventilação geral está funcionando e há pressão para começar.",
      "prompt": "Qual resposta respeita a hierarquia de controles?",
      "options": [
        "Começar porque a ventilação geral basta",
        "Comunicar a falha e restabelecer controle de captura adequado antes do uso",
        "Abrir a porta",
        "Usar perfume ambiental"
      ],
      "answer": 1,
      "rationale": "Captura na fonte é controle de engenharia prioritário. Ventilação geral não substitui automaticamente o sistema previsto.",
      "consequence": "Corrigir antes do início evita exposição ocupacional planejável e documenta a falha de equipamento.",
      "sourceIds": [
        "niosh-smoke",
        "aorn-energy-2026",
        "nr32"
      ]
    },
    {
      "id": "caso-19",
      "number": "19",
      "title": "Padrão inesperado durante anestesia",
      "category": "Eventos críticos",
      "moduleId": "eventos-criticos",
      "competencyId": "C18",
      "difficulty": "Análise",
      "context": "Durante anestesia, surgem alterações rápidas e inesperadas de ventilação e temperatura. O anestesiologista declara suspeita de evento crítico específico e solicita o protocolo institucional.",
      "prompt": "Qual contribuição organizacional é mais adequada à equipe perioperatória?",
      "options": [
        "Debater o diagnóstico antes de agir",
        "Acionar ajuda, trazer o auxílio cognitivo e distribuir funções",
        "Pesquisar doses em fonte informal",
        "Aguardar confirmação laboratorial"
      ],
      "answer": 1,
      "rationale": "Em eventos de evolução rápida, a equipe deve apoiar liderança, recursos, comunicação e protocolo sem executar atos fora de competência.",
      "consequence": "Auxílio cognitivo e funções explícitas reduzem omissões e atraso na resposta especializada.",
      "sourceIds": [
        "cfm2174-2017",
        "mhaus-crisis",
        "stanford-emergency-manual"
      ]
    },
    {
      "id": "caso-20",
      "number": "20",
      "title": "Deterioração na transferência para SRPA",
      "category": "Emergência e transferência",
      "moduleId": "anestesia-srpa",
      "competencyId": "C15",
      "difficulty": "Análise",
      "context": "Durante a passagem para SRPA, a saturação começa a cair e o padrão respiratório se altera. A equipe ainda discute detalhes administrativos e ninguém assumiu formalmente o cuidado.",
      "prompt": "Qual prioridade organiza a resposta?",
      "options": [
        "Declarar a alteração, garantir atenção imediata e definir liderança e responsabilidade",
        "Ocultar o monitor para reduzir ansiedade",
        "Transferir para outro leito",
        "Concluir toda a documentação primeiro"
      ],
      "answer": 0,
      "rationale": "Deterioração interrompe a rotina de passagem. O paciente precisa de resposta clínica e responsabilidade explícita imediatamente.",
      "consequence": "Depois da estabilização, a transferência e os registros são reconciliados, incluindo o evento e as condutas.",
      "sourceIds": [
        "cfm2174-2017",
        "sobecc8",
        "stanford-emergency-manual"
      ]
    },
    {
      "id": "caso-21",
      "number": "21",
      "title": "Conversão organizada na cirurgia abdominal",
      "category": "Cirurgia geral",
      "moduleId": "cirurgia-geral-digestiva",
      "competencyId": "C19",
      "difficulty": "Análise",
      "context": "Durante uma colectomia laparoscópica, a equipe decide converter para acesso aberto. A torre e uma mesa auxiliar bloqueiam o lado de acesso, e a contagem está em andamento.",
      "prompt": "Qual é a melhor decisão imediata?",
      "options": [
        "Abrir todos os conjuntos disponíveis para evitar nova espera",
        "Iniciar a incisão aberta enquanto a sala é reorganizada",
        "Retirar materiais sem registro para abrir espaço",
        "Interromper movimentos não essenciais, liberar acesso, definir funções e reconciliar a contagem antes de avançar"
      ],
      "answer": 3,
      "rationale": "Conversão segura exige controle do ambiente, acesso ao paciente, comunicação e preservação da contagem.",
      "consequence": "Avançar sem coordenação aumenta risco de quebra de técnica, item retido e atraso em emergência.",
      "sourceIds": [
        "eras-colorectal-2025",
        "br-safe-surgery"
      ]
    },
    {
      "id": "caso-22",
      "number": "22",
      "title": "Implante com identificação divergente",
      "category": "Ortopedia",
      "moduleId": "ortopedia-trauma",
      "competencyId": "C20",
      "difficulty": "Análise",
      "context": "Em uma artroplastia, a embalagem externa mostra o tamanho planejado, mas o rótulo interno visível indica outro tamanho. O campo aguarda a abertura do componente.",
      "prompt": "Qual é a decisão mais segura?",
      "options": [
        "Abrir e comparar o implante diretamente com o osso",
        "Usar o rótulo externo como referência principal",
        "Não abrir para uso e reconciliar fabricante, modelo, tamanho e lote com a equipe e o fornecedor",
        "Alterar o registro para o tamanho que estiver disponível"
      ],
      "answer": 2,
      "rationale": "Divergência de identificação invalida a confirmação do implante. O item deve ser segregado até reconciliação.",
      "consequence": "Implantar componente incorreto pode causar dano e perda de rastreabilidade.",
      "sourceIds": [
        "fda-patient-guides-2026",
        "aaos-guidelines-current"
      ]
    },
    {
      "id": "caso-23",
      "number": "23",
      "title": "Cesárea urgente com identificação incompleta",
      "category": "Ginecologia e obstetrícia",
      "moduleId": "ginecologia-obstetricia",
      "competencyId": "C21",
      "difficulty": "Aplicação",
      "context": "Uma gestante chega para cesárea urgente com pulseira legível, mas o prontuário eletrônico ainda exibe sobrenome divergente após atualização cadastral. As equipes materna e neonatal estão prontas.",
      "prompt": "Como proceder?",
      "options": [
        "Prosseguir e corrigir os dados após o nascimento",
        "Ignorar o prontuário porque a pulseira parece correta",
        "Criar uma nova identificação provisória sem vinculação",
        "Adaptar a checagem à urgência, reconciliar os identificadores e só então avançar para a etapa irreversível"
      ],
      "answer": 3,
      "rationale": "Urgência não elimina identificação inequívoca. A discrepância deve ser resolvida pelo fluxo institucional.",
      "consequence": "Erro de identificação pode afetar cirurgia, amostras e vínculo materno-neonatal.",
      "sourceIds": [
        "eras-cesarean-2025",
        "anvisa-safety-practices-2026"
      ]
    },
    {
      "id": "caso-24",
      "number": "24",
      "title": "Irrigação sem retorno na endourologia",
      "category": "Urologia",
      "moduleId": "urologia",
      "competencyId": "C22",
      "difficulty": "Aplicação",
      "context": "Durante ureteroscopia, a visão piora, o retorno de irrigação praticamente cessa e a bolsa continua sendo pressurizada. A causa ainda não foi identificada.",
      "prompt": "Qual é a resposta inicial mais segura?",
      "options": [
        "Pausar, comunicar e avaliar entrada, saída, conexões e posição antes de retomar",
        "Aumentar a pressão até recuperar a visão",
        "Continuar a progressão guiando-se pela imagem anterior",
        "Desconectar a saída e manter a entrada aberta"
      ],
      "answer": 0,
      "rationale": "Perda de retorno pode elevar pressão e ocultar problema do sistema. A resposta deve ser coordenada.",
      "consequence": "Aumentar pressão sem diagnóstico pode agravar risco de extravasamento e complicação.",
      "sourceIds": [
        "aua-stones-2026",
        "eau-urolithiasis-current"
      ]
    },
    {
      "id": "caso-25",
      "number": "25",
      "title": "Endoprótese incompatível na sala híbrida",
      "category": "Cirurgia vascular",
      "moduleId": "cirurgia-vascular",
      "competencyId": "C23",
      "difficulty": "Análise",
      "context": "Na sala híbrida, a endoprótese traz o modelo solicitado, mas a medida impressa não coincide com a confirmação verbal registrada no briefing. O dispositivo ainda está fechado.",
      "prompt": "Qual é a melhor decisão?",
      "options": [
        "Abrir para medir manualmente no campo",
        "Manter fechado e interromper até reconciliar medida, imagem, plano e disponibilidade de alternativa",
        "Implantar porque o modelo está correto",
        "Escolher a medida pela memória do profissional mais experiente"
      ],
      "answer": 1,
      "rationale": "Dispositivo de alto impacto exige concordância de todas as informações antes da abertura.",
      "consequence": "Abertura ou implantação sem reconciliação pode eliminar alternativas e causar dano grave.",
      "sourceIds": [
        "esvs-vgei-2026",
        "esvs-trauma-2025"
      ]
    },
    {
      "id": "caso-26",
      "number": "26",
      "title": "Navegação divergente após movimento",
      "category": "Neurocirurgia e coluna",
      "moduleId": "neurocirurgia-coluna",
      "competencyId": "C24",
      "difficulty": "Aplicação",
      "context": "Após ajuste não planejado da fixação da cabeça, a neuronavegação passa a apontar trajetória incompatível com os marcos anatômicos visíveis.",
      "prompt": "Qual ação é mais segura?",
      "options": [
        "Interromper e verificar referência, registro, posição e imagem antes de continuar",
        "Compensar mentalmente o desvio e prosseguir",
        "Confiar na navegação porque a calibração inicial foi aceita",
        "Reiniciar somente o monitor sem informar a equipe"
      ],
      "answer": 0,
      "rationale": "Movimento pode comprometer precisão; inconsistência precisa de nova validação.",
      "consequence": "Prosseguir com referência degradada pode direcionar a intervenção ao local errado.",
      "sourceIds": [
        "cns-pituitary-2025",
        "aorn-2026"
      ]
    },
    {
      "id": "caso-27",
      "number": "27",
      "title": "Energia próxima à via aérea",
      "category": "Cabeça e pescoço",
      "moduleId": "cabeca-pescoco",
      "competencyId": "C25",
      "difficulty": "Aplicação",
      "context": "Em procedimento próximo à via aérea, o cirurgião solicita ativação de energia. Houve mudança recente na estratégia ventilatória, ainda não comunicada ao restante da equipe.",
      "prompt": "Qual é a melhor resposta?",
      "options": [
        "Aumentar a potência para reduzir o tempo de uso",
        "Ativar imediatamente porque a ponta está visível",
        "Pausar e confirmar com anestesia oxidante, risco de fogo e momento de ativação",
        "Cobrir o tubo e prosseguir sem comunicar"
      ],
      "answer": 2,
      "rationale": "Mudança ventilatória altera o risco do triângulo do fogo. A ativação precisa de coordenação explícita.",
      "consequence": "Energia sem alinhamento sobre oxidante e combustível pode produzir incêndio de via aérea.",
      "sourceIds": [
        "anvisa-fire-2014",
        "aorn-energy-2026"
      ]
    },
    {
      "id": "caso-28",
      "number": "28",
      "title": "Dreno torácico desconectado na transferência",
      "category": "Torácica e cardíaca",
      "moduleId": "toracica-cardiaca",
      "competencyId": "C26",
      "difficulty": "Aplicação",
      "context": "Durante a preparação para transferir um paciente após ressecção pulmonar, a conexão do dreno se solta e o estado do sistema fica incerto.",
      "prompt": "Qual é a prioridade?",
      "options": [
        "Reconectar silenciosamente e continuar o transporte",
        "Interromper a transferência, estabilizar o sistema conforme protocolo, avaliar o paciente e comunicar a equipe",
        "Pinçar o dreno por rotina",
        "Cobrir a conexão e conferir apenas na unidade de destino"
      ],
      "answer": 1,
      "rationale": "Falha do sistema de drenagem exige resposta antes do deslocamento, com avaliação e comunicação.",
      "consequence": "Transportar com sistema incerto pode ocultar perda de função e deterioração clínica.",
      "sourceIds": [
        "eras-thoracic-2019",
        "aorn-2026"
      ]
    },
    {
      "id": "caso-29",
      "number": "29",
      "title": "Aquecimento neonatal sem monitorização",
      "category": "Cirurgia pediátrica e neonatal",
      "moduleId": "cirurgia-pediatrica-neonatal",
      "competencyId": "C27",
      "difficulty": "Aplicação",
      "context": "Um neonato está sob aquecimento ativo, mas o sensor de temperatura se desprendeu e a leitura deixou de ser confiável. A equipe está concentrada em outra etapa.",
      "prompt": "Qual ação é mais segura?",
      "options": [
        "Aumentar o aquecimento para prevenir hipotermia",
        "Comunicar, restabelecer monitorização confiável e reavaliar o aquecimento antes de prosseguir",
        "Manter sem alteração até o fim da cirurgia",
        "Estimar a temperatura tocando a pele"
      ],
      "answer": 1,
      "rationale": "Aquecimento precisa de monitorização para equilibrar prevenção de hipotermia e risco térmico.",
      "consequence": "Sem leitura confiável, podem ocorrer hipotermia, hipertermia ou lesão térmica sem detecção.",
      "sourceIds": [
        "eras-neonatal-2024",
        "aorn-2026"
      ]
    },
    {
      "id": "caso-30",
      "number": "30",
      "title": "Alerta e perda de resposta no robô",
      "category": "Cirurgia robótica",
      "moduleId": "minimamente-invasiva-robotica",
      "competencyId": "C28",
      "difficulty": "Análise",
      "context": "Durante dissecção robótica, um instrumento gera alerta, deixa de responder e permanece dentro do paciente. A posição exata ainda aparece na câmera.",
      "prompt": "Qual é a melhor decisão inicial?",
      "options": [
        "Parar movimentos, comunicar, manter visualização e seguir o fluxo de recuperação ou undocking autorizado",
        "Contornar o alerta para concluir a dissecção",
        "Puxar manualmente o braço robótico",
        "Reiniciar o sistema sem confirmar instrumentos e posição"
      ],
      "answer": 0,
      "rationale": "A resposta começa por estabilizar e preservar conhecimento da posição, seguindo treinamento e instrução do fabricante.",
      "consequence": "Forçar, burlar ou reiniciar sem controle pode mover o instrumento de forma imprevisível e ampliar dano.",
      "sourceIds": [
        "aorn-robotic-2026",
        "fda-rasd-draft-2026"
      ]
    }
  ],
  "studyPlans": [
    {
      "id": "fundamentos-seguros",
      "order": "01",
      "title": "Fundamentos seguros",
      "short": "Construa a base antes de avançar para dispositivos e especialidades.",
      "description": "Sequência de segurança, ambiente, instrumentais, anatomia, processamento, assepsia e procedimentos perioperatórios essenciais.",
      "audience": "Início da formação e revisão de base",
      "level": "Essencial",
      "color": "teal",
      "prerequisite": "Nenhum",
      "moduleIds": [
        "instrumentais",
        "fios-suturas",
        "posicionamento",
        "assepsia-seguranca",
        "anatomia",
        "fluxo-procedimentos",
        "ambiente-equipe",
        "cirurgia-segura",
        "prevencao-isc",
        "contagens-itens",
        "especimes-implantes",
        "cme-processamento",
        "assepsia-antissepsia-pele",
        "procedimentos-perioperatorios"
      ],
      "competencyIds": [
        "C01",
        "C02",
        "C03",
        "C04",
        "C05",
        "C06",
        "C07",
        "C08",
        "C09",
        "C10",
        "C11",
        "C12"
      ],
      "outcomes": [
        "Reconhecer barreiras essenciais de segurança",
        "Organizar ambiente, materiais e equipe",
        "Aplicar assepsia, contagens e rastreabilidade",
        "Executar estudo perioperatório dentro dos limites profissionais"
      ],
      "gate": "Concluir as aulas e conseguir explicar as barreiras sem consultar antes de iniciar a prática ampliada."
    },
    {
      "id": "pratica-ampliada",
      "order": "02",
      "title": "Prática perioperatória ampliada",
      "short": "Integre tecnologia, medicamentos, anestesia, acessos e resposta a eventos.",
      "description": "Sequência intermediária para energia, medicação, SRPA, documentação, crises, vias cirúrgicas, acessos vasculares, via aérea, sondas e drenos.",
      "audience": "Após os fundamentos",
      "level": "Intermediário",
      "color": "blue",
      "prerequisite": "Fundamentos seguros",
      "moduleIds": [
        "energia-fogo-fumaca",
        "medicamentos-rotulagem",
        "anestesia-srpa",
        "seguranca-ocupacional",
        "documentacao-etica-privacidade",
        "eventos-criticos",
        "procedimentos-vias-cirurgicas",
        "acessos-vasculares-infusao",
        "via-aerea-sondas-drenos"
      ],
      "competencyIds": [
        "C13",
        "C14",
        "C15",
        "C16",
        "C17",
        "C18"
      ],
      "outcomes": [
        "Apoiar procedimentos e acessos sem extrapolar habilitação",
        "Reconhecer falhas, complicações e critérios de escalonamento",
        "Estruturar transferências e registros de dispositivos",
        "Integrar segurança ocupacional, energia, medicamentos e anestesia"
      ],
      "gate": "Concluir os módulos e demonstrar raciocínio de pausa, comunicação e escalonamento em cenários simulados."
    },
    {
      "id": "especialidades-p2",
      "order": "03",
      "title": "Especialidades cirúrgicas P2",
      "short": "Aplique a base perioperatória a dez contextos especializados.",
      "description": "Sequência avançada para cirurgia geral, ortopedia, ginecologia/obstetrícia, urologia, vascular, neuro, cabeça e pescoço, torácica/cardíaca, pediatria e robótica.",
      "audience": "Após fundamentos e prática ampliada",
      "level": "Aprofundamento",
      "color": "violet",
      "prerequisite": "Prática perioperatória ampliada",
      "moduleIds": [
        "cirurgia-geral-digestiva",
        "ortopedia-trauma",
        "ginecologia-obstetricia",
        "urologia",
        "cirurgia-vascular",
        "neurocirurgia-coluna",
        "cabeca-pescoco",
        "toracica-cardiaca",
        "cirurgia-pediatrica-neonatal",
        "minimamente-invasiva-robotica"
      ],
      "competencyIds": [
        "C19",
        "C20",
        "C21",
        "C22",
        "C23",
        "C24",
        "C25",
        "C26",
        "C27",
        "C28"
      ],
      "outcomes": [
        "Adaptar barreiras ao contexto da especialidade",
        "Preparar equipamentos, implantes, espécimes e dispositivos",
        "Reconhecer transições e planos de conversão",
        "Realizar handoff especializado e rastreável"
      ],
      "gate": "Concluir as trilhas e revisar desempenho formativo por competência; prática real continua supervisionada."
    }
  ],
  "remediationMap": [
    {
      "competencyId": "C01",
      "focus": "Revisar função, integridade e escolha segura de instrumentais.",
      "lessonIds": [
        "instrumentais-logica",
        "instrumentais-diferencas",
        "procedimentos-acesso-aberto"
      ]
    },
    {
      "competencyId": "C02",
      "focus": "Reforçar leitura de embalagem, função e rastreabilidade de fios e agulhas.",
      "lessonIds": [
        "fios-classificacao",
        "agulhas-principios",
        "procedimentos-conversao-encerramento"
      ]
    },
    {
      "competencyId": "C03",
      "focus": "Reavaliar alinhamento, pressão, dispositivos e mudanças de posição.",
      "lessonIds": [
        "posicoes-base",
        "posicionamento-seguranca",
        "perioperatorio-transferencia-monitorizacao"
      ]
    },
    {
      "competencyId": "C04",
      "focus": "Distinguir técnica asséptica, antissepsia e resposta à quebra de barreira.",
      "lessonIds": [
        "campo-esteril",
        "contagem-comunicacao",
        "assepsia-conceitos"
      ]
    },
    {
      "competencyId": "C05",
      "focus": "Usar orientação anatômica para comunicação sem extrapolar a decisão operatória.",
      "lessonIds": [
        "planos-teciduais",
        "abdome-referencias",
        "procedimentos-acesso-aberto"
      ]
    },
    {
      "competencyId": "C06",
      "focus": "Reconstruir a jornada, as transições e o encerramento do procedimento.",
      "lessonIds": [
        "tempos-operatorios",
        "encerramento-seguro",
        "procedimentos-classificacao-jornada"
      ]
    },
    {
      "competencyId": "C07",
      "focus": "Clarificar papéis, ambiente, circulação e limites profissionais.",
      "lessonIds": [
        "ambiente-areas-fluxo",
        "equipe-papeis-limites",
        "perioperatorio-admissao-verificacao"
      ]
    },
    {
      "competencyId": "C08",
      "focus": "Praticar verificação, comunicação em alça fechada e interrupção segura.",
      "lessonIds": [
        "checklist-tres-momentos",
        "comunicacao-fatores-humanos",
        "perioperatorio-admissao-verificacao"
      ]
    },
    {
      "competencyId": "C09",
      "focus": "Integrar preparo da pele, barreiras e vigilância de prevenção de ISC.",
      "lessonIds": [
        "isc-preparo-preoperatorio",
        "isc-intra-posoperatorio",
        "assepsia-avaliacao-pele-pelos"
      ]
    },
    {
      "competencyId": "C10",
      "focus": "Revisar momentos, método e resposta à divergência de contagem.",
      "lessonIds": [
        "contagem-sistema-confiavel",
        "contagem-divergencia",
        "procedimentos-conversao-encerramento"
      ]
    },
    {
      "competencyId": "C11",
      "focus": "Reforçar identificação, orientação, destino e rastreabilidade.",
      "lessonIds": [
        "especimes-cadeia-segura",
        "implantes-rastreabilidade",
        "perioperatorio-feridas-curativos-estomas"
      ]
    },
    {
      "competencyId": "C12",
      "focus": "Revisar fluxo unidirecional, limpeza, inspeção, barreira e liberação.",
      "lessonIds": [
        "cme-fluxo-limpeza",
        "cme-inspecao-preparo",
        "cme-barreira-eventos"
      ]
    },
    {
      "competencyId": "C13",
      "focus": "Reconhecer riscos de energia, fogo, fumaça e falhas de equipamento.",
      "lessonIds": [
        "energia-cirurgica-principios",
        "fogo-cirurgico-prevencao",
        "procedimentos-video-robotico"
      ]
    },
    {
      "competencyId": "C14",
      "focus": "Praticar rotulagem, reconciliação e comunicação segura de medicamentos.",
      "lessonIds": [
        "medicamentos-campo-rotulagem",
        "medicamentos-alta-vigilancia",
        "vascular-mapa-dispositivos"
      ]
    },
    {
      "competencyId": "C15",
      "focus": "Reforçar interface com anestesia, alarmes, transferência e vigilância na SRPA.",
      "lessonIds": [
        "anestesia-fases-seguranca",
        "srpa-transferencia-vigilancia",
        "via-aerea-dispositivos"
      ]
    },
    {
      "competencyId": "C16",
      "focus": "Aplicar NR-32, prevenção de exposição e ergonomia nas transições.",
      "lessonIds": [
        "nr32-biologico-perfurocortante",
        "nr32-quimico-fisico-ergonomia",
        "perioperatorio-transferencia-monitorizacao"
      ]
    },
    {
      "competencyId": "C17",
      "focus": "Melhorar linha do tempo, autoria, privacidade e rastreabilidade do registro.",
      "lessonIds": [
        "registro-perioperatorio-qualidade",
        "privacidade-dados-saude",
        "perioperatorio-transporte-handoff"
      ]
    },
    {
      "competencyId": "C18",
      "focus": "Praticar liderança, auxílio cognitivo, escalonamento e debriefing de crises.",
      "lessonIds": [
        "crise-lideranca-comunicacao",
        "crise-preparo-simulacao",
        "via-aerea-assistencia-crise"
      ]
    },
    {
      "competencyId": "C19",
      "focus": "Revisar transições de contaminação, dispositivos e handoff abdominal.",
      "lessonIds": [
        "geral-mapa-abdominal",
        "geral-recuperacao-integrada",
        "procedimentos-conversao-encerramento"
      ]
    },
    {
      "competencyId": "C20",
      "focus": "Reforçar lateralidade, imagem, implantes, torniquete e rastreabilidade.",
      "lessonIds": [
        "ortopedia-implantes-imagem",
        "ortopedia-trauma-seguranca",
        "procedimentos-acesso-aberto"
      ]
    },
    {
      "competencyId": "C21",
      "focus": "Integrar posição, fluidos, espécimes e coordenação materno-neonatal.",
      "lessonIds": [
        "ginecologia-pelve-vias",
        "obstetricia-duas-equipes",
        "assepsia-selecao-antisseptico"
      ]
    },
    {
      "competencyId": "C22",
      "focus": "Revisar irrigação, energia, amostras, stents e cadeia de saída.",
      "lessonIds": [
        "urologia-endourologia",
        "urologia-posicao-dispositivos",
        "sonda-vesical-perioperatoria"
      ]
    },
    {
      "competencyId": "C23",
      "focus": "Reforçar sala híbrida, marcos vasculares, enxertos e explantes.",
      "lessonIds": [
        "vascular-aberta-endovascular",
        "vascular-enxertos-seguranca",
        "vascular-central"
      ]
    },
    {
      "competencyId": "C24",
      "focus": "Revisar posição, nível, navegação, neuromonitorização e tecnologia.",
      "lessonIds": [
        "neuro-cranio-micro",
        "coluna-posicao-implantes",
        "perioperatorio-transferencia-monitorizacao"
      ]
    },
    {
      "competencyId": "C25",
      "focus": "Integrar via aérea compartilhada, fogo, margens, reconstrução e handoff.",
      "lessonIds": [
        "cabeca-via-aerea-especimes",
        "cabeca-reconstrucao-handoff",
        "via-aerea-dispositivos"
      ]
    },
    {
      "competencyId": "C26",
      "focus": "Reforçar ventilação, posição lateral, drenos, CEC e transferência.",
      "lessonIds": [
        "toracica-pulmao-drenos",
        "cardiaca-cec-handoff",
        "drenos-toracicos-cirurgicos"
      ]
    },
    {
      "competencyId": "C27",
      "focus": "Adaptar identidade, peso, termorregulação, dispositivos e transporte.",
      "lessonIds": [
        "pediatria-escala-fisiologia",
        "neonatal-equipe-familia",
        "vascular-periferico"
      ]
    },
    {
      "competencyId": "C28",
      "focus": "Revisar docking, acesso ao paciente, alertas, undocking e conversão.",
      "lessonIds": [
        "robotica-docking-equipe",
        "robotica-interface-falha",
        "procedimentos-video-robotico"
      ]
    }
  ],
  "technicalCurriculum": {
    "version": "1.1",
    "phase": "MB01 — Arquitetura curricular",
    "status": "MB01 corrigido; MB02 implementado como núcleo inicial, revisão clínica pendente",
    "primaryAudience": "Estudantes de Medicina e médicos em treinamento supervisionado",
    "scopeStatement": "A plataforma prepara para estudo e simulação. Procedimentos invasivos exigem supervisão, autorização institucional, equipe habilitada, protocolo local e instruções do fabricante.",
    "metadataFields": [
      {
        "id": "population",
        "title": "População",
        "values": [
          "Adulto",
          "Pediátrico",
          "Neonatal",
          "Gestante",
          "Necessidades específicas"
        ]
      },
      {
        "id": "prerequisites",
        "title": "Pré-requisitos"
      },
      {
        "id": "supervision",
        "title": "Nível de supervisão"
      },
      {
        "id": "professionalScope",
        "title": "Escopo profissional"
      },
      {
        "id": "setting",
        "title": "Ambiente assistencial"
      },
      {
        "id": "revision",
        "title": "Versão e revisão clínica"
      }
    ],
    "lessonSchema": [
      {
        "order": 1,
        "id": "definition",
        "title": "Definição e finalidade",
        "description": "Delimitar o procedimento, seu objetivo e os resultados esperados."
      },
      {
        "order": 2,
        "id": "indications",
        "title": "Indicações clínicas",
        "description": "Explicar quando considerar a técnica e quais decisões antecedem sua indicação."
      },
      {
        "order": 3,
        "id": "contraindications",
        "title": "Contraindicações e alternativas",
        "description": "Registrar contraindicações absolutas e relativas, alternativas e critérios de escalonamento."
      },
      {
        "order": 4,
        "id": "anatomy",
        "title": "Anatomia e referências",
        "description": "Apresentar referências anatômicas e variações relevantes sem substituir treinamento prático."
      },
      {
        "order": 5,
        "id": "materials",
        "title": "Materiais e calibres",
        "description": "Identificar materiais, escalas, compatibilidades, tamanhos e instruções do fabricante."
      },
      {
        "order": 6,
        "id": "environment",
        "title": "Preparação do ambiente",
        "description": "Organizar equipe, equipamentos, barreiras, monitorização e plano de contingência."
      },
      {
        "order": 7,
        "id": "patient",
        "title": "Preparação do paciente",
        "description": "Cobrir identificação, consentimento, avaliação, posicionamento e comunicação."
      },
      {
        "order": 8,
        "id": "analgesia",
        "title": "Anestesia e analgesia",
        "description": "Explicar opções e monitorização conforme população, procedimento e protocolo validado."
      },
      {
        "order": 9,
        "id": "sequence",
        "title": "Sequência técnica ilustrada",
        "description": "Organizar etapas verificáveis para simulação e execução exclusivamente supervisionada."
      },
      {
        "order": 10,
        "id": "confirmation",
        "title": "Confirmação do resultado",
        "description": "Definir como confirmar funcionamento, posicionamento ou objetivo alcançado."
      },
      {
        "order": 11,
        "id": "complications",
        "title": "Complicações e manejo inicial",
        "description": "Reconhecer falhas, sinais de alarme, interrupção segura e escalonamento."
      },
      {
        "order": 12,
        "id": "aftercare",
        "title": "Cuidados posteriores",
        "description": "Descrever vigilância, manutenção, retirada, documentação e orientações."
      },
      {
        "order": 13,
        "id": "skills-checklist",
        "title": "Checklist de habilidades",
        "description": "Avaliar preparação, sequência, comunicação, segurança e erros críticos em simulação."
      },
      {
        "order": 14,
        "id": "media-references",
        "title": "Vídeo, referências e revisão",
        "description": "Vincular fontes, vídeo externo creditado, data de revisão e conformidade editorial."
      }
    ],
    "categories": [
      {
        "id": "fundamentos",
        "title": "Fundamentos, segurança e materiais",
        "description": "Base transversal para reconhecer materiais, preparar ambiente e paciente e atuar com barreiras de segurança."
      },
      {
        "id": "terapeutica-dispositivos",
        "title": "Terapêutica, acessos e dispositivos",
        "description": "Administração, acessos, suporte de via aérea, anestesia e manejo seguro de dispositivos."
      },
      {
        "id": "procedimentos-fundamentais",
        "title": "Procedimentos fundamentais",
        "description": "Feridas, fechamento, imobilização, atendimento ambulatorial, diagnóstico à beira-leito e seguimento."
      },
      {
        "id": "urgencia-criticos",
        "title": "Urgência e cuidados críticos",
        "description": "Resposta inicial, ressuscitação, monitorização e suporte em eventos de alto risco."
      },
      {
        "id": "cirurgia",
        "title": "Cirurgia e fluxo operatório",
        "description": "Princípios técnicos e assistenciais da cirurgia aberta, minimamente invasiva e recuperação."
      },
      {
        "id": "especialidades",
        "title": "Especialidades clínicas e cirúrgicas",
        "description": "Aplicação contextual dos fundamentos em populações, órgãos e especialidades."
      }
    ],
    "modules": [
      {
        "id": "M01",
        "order": 1,
        "title": "Biossegurança",
        "priority": "P0",
        "categoryId": "fundamentos",
        "coverage": "Base existente",
        "existingModuleIds": [
          "assepsia-seguranca",
          "prevencao-isc",
          "seguranca-ocupacional",
          "assepsia-antissepsia-pele"
        ],
        "existingLessonIds": [
          "campo-esteril",
          "contagem-comunicacao",
          "isc-preparo-preoperatorio",
          "isc-intra-posoperatorio",
          "nr32-biologico-perfurocortante",
          "nr32-quimico-fisico-ergonomia",
          "assepsia-conceitos",
          "assepsia-maos-paramentacao",
          "assepsia-avaliacao-pele-pelos",
          "assepsia-selecao-antisseptico",
          "assepsia-aplicacao-campos-fogo"
        ],
        "topics": [
          {
            "id": "PT-M01-01",
            "title": "Higienização das mãos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-HIGIENIZACAO-DAS-MAOS",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-02",
            "title": "Equipamentos de proteção individual",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EQUIPAMENTOS-DE-PROTECAO-INDIVIDUAL",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-03",
            "title": "Paramentação cirúrgica",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PARAMENTACAO-CIRURGICA",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-04",
            "title": "Calçamento de luvas estéreis",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CALCAMENTO-DE-LUVAS-ESTEREIS",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-05",
            "title": "Campos estéreis",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CAMPOS-ESTEREIS",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-06",
            "title": "Assepsia e antissepsia",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSEPSIA-E-ANTISSEPSIA",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-07",
            "title": "Segurança com perfurocortantes",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SEGURANCA-COM-PERFUROCORTANTES",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M01-08",
            "title": "Descarte de resíduos assistenciais",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DESCARTE-DE-RESIDUOS-ASSISTENCIAIS",
            "context": {
              "moduleId": "M01",
              "moduleTitle": "Biossegurança"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M01-campo-esteril",
            "lessonId": "campo-esteril",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M01-contagem-comunicacao",
            "lessonId": "contagem-comunicacao",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M01-isc-preparo-preoperatorio",
            "lessonId": "isc-preparo-preoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M01-isc-intra-posoperatorio",
            "lessonId": "isc-intra-posoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M01-nr32-biologico-perfurocortante",
            "lessonId": "nr32-biologico-perfurocortante",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M01-02",
              "PT-M01-07",
              "PT-M01-08"
            ]
          },
          {
            "id": "REL-M01-nr32-quimico-fisico-ergonomia",
            "lessonId": "nr32-quimico-fisico-ergonomia",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M01-assepsia-conceitos",
            "lessonId": "assepsia-conceitos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M01-06"
            ]
          },
          {
            "id": "REL-M01-assepsia-maos-paramentacao",
            "lessonId": "assepsia-maos-paramentacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M01-01",
              "PT-M01-03",
              "PT-M01-04"
            ]
          },
          {
            "id": "REL-M01-assepsia-avaliacao-pele-pelos",
            "lessonId": "assepsia-avaliacao-pele-pelos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M01-06"
            ]
          },
          {
            "id": "REL-M01-assepsia-selecao-antisseptico",
            "lessonId": "assepsia-selecao-antisseptico",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M01-06"
            ]
          },
          {
            "id": "REL-M01-assepsia-aplicacao-campos-fogo",
            "lessonId": "assepsia-aplicacao-campos-fogo",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M01-05",
              "PT-M01-06"
            ]
          }
        ]
      },
      {
        "id": "M02",
        "order": 2,
        "title": "Instrumentação cirúrgica",
        "priority": "P0",
        "categoryId": "fundamentos",
        "coverage": "Base existente",
        "existingModuleIds": [
          "instrumentais",
          "fios-suturas"
        ],
        "existingLessonIds": [
          "instrumentais-logica",
          "instrumentais-diferencas",
          "instrumentais-integridade-funcional",
          "fios-classificacao",
          "agulhas-principios",
          "fios-selecao-rastreabilidade"
        ],
        "topics": [
          {
            "id": "PT-M02-01",
            "title": "Pinças de preensão",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PINCAS-DE-PREENSAO",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-02",
            "title": "Pinças hemostáticas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PINCAS-HEMOSTATICAS",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-03",
            "title": "Pinças de dissecção",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PINCAS-DE-DISSECCAO",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-04",
            "title": "Afastadores",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AFASTADORES",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-05",
            "title": "Tesouras cirúrgicas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TESOURAS-CIRURGICAS",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-06",
            "title": "Bisturis, cabos e lâminas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [
              "bisturi",
              "lâmina 15",
              "lamina 15",
              "scalpel"
            ],
            "canonicalProcedureId": "PROC-BISTURIS-CABOS-E-LAMINAS",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-07",
            "title": "Porta-agulhas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PORTA-AGULHAS",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-08",
            "title": "Montagem da mesa cirúrgica",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MONTAGEM-DA-MESA-CIRURGICA",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-09",
            "title": "Passagem de instrumentais",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PASSAGEM-DE-INSTRUMENTAIS",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M02-10",
            "title": "Integridade e teste funcional",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-INTEGRIDADE-E-TESTE-FUNCIONAL",
            "context": {
              "moduleId": "M02",
              "moduleTitle": "Instrumentação cirúrgica"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M02-instrumentais-logica",
            "lessonId": "instrumentais-logica",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M02-01",
              "PT-M02-02",
              "PT-M02-03",
              "PT-M02-04",
              "PT-M02-05",
              "PT-M02-06",
              "PT-M02-07"
            ]
          },
          {
            "id": "REL-M02-instrumentais-diferencas",
            "lessonId": "instrumentais-diferencas",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M02-01",
              "PT-M02-02",
              "PT-M02-03",
              "PT-M02-04",
              "PT-M02-05",
              "PT-M02-07"
            ]
          },
          {
            "id": "REL-M02-instrumentais-integridade-funcional",
            "lessonId": "instrumentais-integridade-funcional",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M02-10"
            ]
          },
          {
            "id": "REL-M02-fios-classificacao",
            "lessonId": "fios-classificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M02-agulhas-principios",
            "lessonId": "agulhas-principios",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M02-07"
            ]
          },
          {
            "id": "REL-M02-fios-selecao-rastreabilidade",
            "lessonId": "fios-selecao-rastreabilidade",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M03",
        "order": 3,
        "title": "Agulhas, seringas e dispositivos",
        "priority": "P0",
        "categoryId": "fundamentos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "fios-suturas",
          "acessos-vasculares-infusao",
          "via-aerea-sondas-drenos"
        ],
        "existingLessonIds": [
          "fios-classificacao",
          "agulhas-principios",
          "fios-selecao-rastreabilidade",
          "vascular-mapa-dispositivos",
          "vascular-periferico",
          "vascular-central",
          "vascular-arterial",
          "vascular-intraosseo-emergencia",
          "vascular-manutencao-complicacoes",
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais"
        ],
        "topics": [
          {
            "id": "PT-M03-01",
            "title": "Escalas Gauge, French, USP e milímetros",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [
              "Gauge",
              "G",
              "French",
              "Fr",
              "Charrière",
              "Ch",
              "USP",
              "calibre"
            ],
            "canonicalProcedureId": "PROC-ESCALAS-GAUGE-FRENCH-USP-E-MILIMETROS",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-02",
            "title": "Agulhas hipodérmicas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AGULHAS-HIPODERMICAS",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-03",
            "title": "Dispositivo alado tipo scalp",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [
              "scalp",
              "butterfly needle",
              "agulha borboleta"
            ],
            "canonicalProcedureId": "PROC-DISPOSITIVO-ALADO-TIPO-SCALP",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-04",
            "title": "Cateter intravenoso periférico",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CATETER-INTRAVENOSO-PERIFERICO",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-05",
            "title": "Seringas e graduações",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SERINGAS-E-GRADUACOES",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-06",
            "title": "Conectores sem agulha",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CONECTORES-SEM-AGULHA",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-07",
            "title": "Equipos de infusão",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EQUIPOS-DE-INFUSAO",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-08",
            "title": "Extensores",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EXTENSORES",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-09",
            "title": "Torneiras de três vias",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TORNEIRAS-DE-TRES-VIAS",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M03-10",
            "title": "Compatibilidade entre dispositivos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COMPATIBILIDADE-ENTRE-DISPOSITIVOS",
            "context": {
              "moduleId": "M03",
              "moduleTitle": "Agulhas, seringas e dispositivos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M03-fios-classificacao",
            "lessonId": "fios-classificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-agulhas-principios",
            "lessonId": "agulhas-principios",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M03-02"
            ]
          },
          {
            "id": "REL-M03-fios-selecao-rastreabilidade",
            "lessonId": "fios-selecao-rastreabilidade",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-vascular-mapa-dispositivos",
            "lessonId": "vascular-mapa-dispositivos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M03-01",
              "PT-M03-03",
              "PT-M03-04",
              "PT-M03-06",
              "PT-M03-07",
              "PT-M03-08",
              "PT-M03-09"
            ]
          },
          {
            "id": "REL-M03-vascular-periferico",
            "lessonId": "vascular-periferico",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M03-04"
            ]
          },
          {
            "id": "REL-M03-vascular-central",
            "lessonId": "vascular-central",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-vascular-arterial",
            "lessonId": "vascular-arterial",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-vascular-intraosseo-emergencia",
            "lessonId": "vascular-intraosseo-emergencia",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-vascular-manutencao-complicacoes",
            "lessonId": "vascular-manutencao-complicacoes",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M03-10"
            ]
          },
          {
            "id": "REL-M03-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M03-04"
            ]
          },
          {
            "id": "REL-M03-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M03-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M04",
        "order": 4,
        "title": "Administração de medicamentos",
        "priority": "P0",
        "categoryId": "terapeutica-dispositivos",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "medicamentos-rotulagem",
          "acessos-vasculares-infusao"
        ],
        "existingLessonIds": [
          "medicamentos-campo-rotulagem",
          "medicamentos-alta-vigilancia",
          "medicamentos-reconciliacao-campo",
          "vascular-mapa-dispositivos",
          "vascular-periferico",
          "vascular-central",
          "vascular-arterial",
          "vascular-intraosseo-emergencia",
          "vascular-manutencao-complicacoes"
        ],
        "topics": [
          {
            "id": "PT-M04-01",
            "title": "Via oral",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-ORAL",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M04-02",
            "title": "Via sublingual",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-SUBLINGUAL",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M04-03",
            "title": "Via intradérmica",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-INTRADERMICA",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M04-04",
            "title": "Via subcutânea",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-SUBCUTANEA",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M04-05",
            "title": "Via intramuscular",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-INTRAMUSCULAR",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M04-06",
            "title": "Via intravenosa",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-INTRAVENOSA",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M04-07",
            "title": "Infusão intermitente e contínua",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-INFUSAO-INTERMITENTE-E-CONTINUA",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M04-08",
            "title": "Reconstituição e diluição",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RECONSTITUICAO-E-DILUICAO",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M04-09",
            "title": "Bombas de infusão",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [
              "bomba infusora",
              "infusion pump"
            ],
            "canonicalProcedureId": "PROC-BOMBAS-DE-INFUSAO",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M04-10",
            "title": "Barreiras para medicamentos de alta vigilância",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BARREIRAS-PARA-MEDICAMENTOS-DE-ALTA-VIGILANCIA",
            "context": {
              "moduleId": "M04",
              "moduleTitle": "Administração de medicamentos"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M04-medicamentos-campo-rotulagem",
            "lessonId": "medicamentos-campo-rotulagem",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M04-10"
            ]
          },
          {
            "id": "REL-M04-medicamentos-alta-vigilancia",
            "lessonId": "medicamentos-alta-vigilancia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M04-10"
            ]
          },
          {
            "id": "REL-M04-medicamentos-reconciliacao-campo",
            "lessonId": "medicamentos-reconciliacao-campo",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M04-10"
            ]
          },
          {
            "id": "REL-M04-vascular-mapa-dispositivos",
            "lessonId": "vascular-mapa-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M04-vascular-periferico",
            "lessonId": "vascular-periferico",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M04-10"
            ]
          },
          {
            "id": "REL-M04-vascular-central",
            "lessonId": "vascular-central",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M04-vascular-arterial",
            "lessonId": "vascular-arterial",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M04-vascular-intraosseo-emergencia",
            "lessonId": "vascular-intraosseo-emergencia",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M04-vascular-manutencao-complicacoes",
            "lessonId": "vascular-manutencao-complicacoes",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M05",
        "order": 5,
        "title": "Acessos vasculares",
        "priority": "P0–P2",
        "categoryId": "terapeutica-dispositivos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "acessos-vasculares-infusao"
        ],
        "existingLessonIds": [
          "vascular-mapa-dispositivos",
          "vascular-periferico",
          "vascular-central",
          "vascular-arterial",
          "vascular-intraosseo-emergencia",
          "vascular-manutencao-complicacoes"
        ],
        "topics": [
          {
            "id": "PT-M05-01",
            "title": "Acesso venoso periférico",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "cateter periférico",
              "cateter intravenoso periférico",
              "cateter IV",
              "IV",
              "PIVC",
              "CIVP",
              "jelco",
              "abocath",
              "cânula intravenosa",
              "venopunção",
              "venopunción"
            ],
            "canonicalProcedureId": "PROC-ACESSO-VENOSO-PERIFERICO",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M05-02",
            "title": "Coleta de sangue venoso",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLETA-DE-SANGUE-VENOSO",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M05-03",
            "title": "Coleta para hemocultura",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLETA-PARA-HEMOCULTURA",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M05-04",
            "title": "Cateter venoso central",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CATETER-VENOSO-CENTRAL",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M05-05",
            "title": "Cateter central de inserção periférica — PICC",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "PICC",
              "cateter PICC",
              "cateter central de inserção periférica",
              "peripherally inserted central catheter"
            ],
            "canonicalProcedureId": "PROC-CATETER-CENTRAL-DE-INSERCAO-PERIFERICA-PICC",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M05-06",
            "title": "Linha arterial",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-LINHA-ARTERIAL",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M05-07",
            "title": "Acesso intraósseo",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ACESSO-INTRAOSSEO",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M05-08",
            "title": "Manutenção e complicações de acessos",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MANUTENCAO-E-COMPLICACOES-DE-ACESSOS",
            "context": {
              "moduleId": "M05",
              "moduleTitle": "Acessos vasculares"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M05-vascular-mapa-dispositivos",
            "lessonId": "vascular-mapa-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M05-vascular-periferico",
            "lessonId": "vascular-periferico",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M05-01"
            ]
          },
          {
            "id": "REL-M05-vascular-central",
            "lessonId": "vascular-central",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M05-04"
            ]
          },
          {
            "id": "REL-M05-vascular-arterial",
            "lessonId": "vascular-arterial",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M05-06"
            ]
          },
          {
            "id": "REL-M05-vascular-intraosseo-emergencia",
            "lessonId": "vascular-intraosseo-emergencia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M05-07"
            ]
          },
          {
            "id": "REL-M05-vascular-manutencao-complicacoes",
            "lessonId": "vascular-manutencao-complicacoes",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M05-08"
            ]
          }
        ]
      },
      {
        "id": "M06",
        "order": 6,
        "title": "Feridas e lesões",
        "priority": "P0",
        "categoryId": "procedimentos-fundamentais",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "prevencao-isc",
          "procedimentos-perioperatorios"
        ],
        "existingLessonIds": [
          "isc-preparo-preoperatorio",
          "isc-intra-posoperatorio",
          "perioperatorio-admissao-verificacao",
          "perioperatorio-transferencia-monitorizacao",
          "perioperatorio-puncoes-biopsias",
          "perioperatorio-feridas-curativos-estomas",
          "perioperatorio-transporte-handoff"
        ],
        "topics": [
          {
            "id": "PT-M06-01",
            "title": "Avaliação estruturada da ferida",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AVALIACAO-ESTRUTURADA-DA-FERIDA",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M06-02",
            "title": "Hemostasia inicial",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-HEMOSTASIA-INICIAL",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M06-03",
            "title": "Irrigação de ferida",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-IRRIGACAO-DE-FERIDA",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M06-04",
            "title": "Limpeza e remoção de contaminantes",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-LIMPEZA-E-REMOCAO-DE-CONTAMINANTES",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M06-05",
            "title": "Desbridamento em ambiente habilitado",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DESBRIDAMENTO-EM-AMBIENTE-HABILITADO",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M06-06",
            "title": "Classificação de feridas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CLASSIFICACAO-DE-FERIDAS",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M06-07",
            "title": "Seleção e troca de curativos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SELECAO-E-TROCA-DE-CURATIVOS",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M06-08",
            "title": "Reconhecimento de infecção",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RECONHECIMENTO-DE-INFECCAO",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M06-09",
            "title": "Mordeduras de animais e humanas",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MORDEDURAS-DE-ANIMAIS-E-HUMANAS",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M06-10",
            "title": "Cuidados posteriores e retorno",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CUIDADOS-POSTERIORES-E-RETORNO",
            "context": {
              "moduleId": "M06",
              "moduleTitle": "Feridas e lesões"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M06-isc-preparo-preoperatorio",
            "lessonId": "isc-preparo-preoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M06-isc-intra-posoperatorio",
            "lessonId": "isc-intra-posoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M06-perioperatorio-admissao-verificacao",
            "lessonId": "perioperatorio-admissao-verificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M06-perioperatorio-transferencia-monitorizacao",
            "lessonId": "perioperatorio-transferencia-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M06-perioperatorio-puncoes-biopsias",
            "lessonId": "perioperatorio-puncoes-biopsias",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M06-perioperatorio-feridas-curativos-estomas",
            "lessonId": "perioperatorio-feridas-curativos-estomas",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M06-07",
              "PT-M06-10"
            ]
          },
          {
            "id": "REL-M06-perioperatorio-transporte-handoff",
            "lessonId": "perioperatorio-transporte-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M07",
        "order": 7,
        "title": "Suturas e fechamento",
        "priority": "P0",
        "categoryId": "procedimentos-fundamentais",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "fios-suturas",
          "fluxo-procedimentos"
        ],
        "existingLessonIds": [
          "fios-classificacao",
          "agulhas-principios",
          "fios-selecao-rastreabilidade",
          "tempos-operatorios",
          "encerramento-seguro"
        ],
        "topics": [
          {
            "id": "PT-M07-01",
            "title": "Fios absorvíveis e não absorvíveis",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [
              "fio de sutura",
              "suture",
              "nylon",
              "poliglactina",
              "vicryl"
            ],
            "canonicalProcedureId": "PROC-FIOS-ABSORVIVEIS-E-NAO-ABSORVIVEIS",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M07-02",
            "title": "Agulhas cilíndricas e cortantes",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AGULHAS-CILINDRICAS-E-CORTANTES",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M07-03",
            "title": "Sutura simples interrompida",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [
              "sutura simples",
              "ponto simples",
              "ponto interrompido",
              "simple interrupted suture"
            ],
            "canonicalProcedureId": "PROC-SUTURA-SIMPLES-INTERROMPIDA",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M07-04",
            "title": "Sutura contínua",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SUTURA-CONTINUA",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-05",
            "title": "Colchoeiro vertical",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLCHOEIRO-VERTICAL",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-06",
            "title": "Colchoeiro horizontal",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLCHOEIRO-HORIZONTAL",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-07",
            "title": "Sutura intradérmica",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SUTURA-INTRADERMICA",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-08",
            "title": "Fechamento dérmico profundo",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-FECHAMENTO-DERMICO-PROFUNDO",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-09",
            "title": "Adesivos cutâneos",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ADESIVOS-CUTANEOS",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-10",
            "title": "Grampos cutâneos",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-GRAMPOS-CUTANEOS",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M07-11",
            "title": "Retirada de pontos e grampos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RETIRADA-DE-PONTOS-E-GRAMPOS",
            "context": {
              "moduleId": "M07",
              "moduleTitle": "Suturas e fechamento"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M07-fios-classificacao",
            "lessonId": "fios-classificacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M07-01"
            ]
          },
          {
            "id": "REL-M07-agulhas-principios",
            "lessonId": "agulhas-principios",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M07-02"
            ]
          },
          {
            "id": "REL-M07-fios-selecao-rastreabilidade",
            "lessonId": "fios-selecao-rastreabilidade",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M07-01"
            ]
          },
          {
            "id": "REL-M07-tempos-operatorios",
            "lessonId": "tempos-operatorios",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M07-encerramento-seguro",
            "lessonId": "encerramento-seguro",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M08",
        "order": 8,
        "title": "Anestesia e analgesia",
        "priority": "P0–P2",
        "categoryId": "terapeutica-dispositivos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "anestesia-srpa",
          "via-aerea-sondas-drenos"
        ],
        "existingLessonIds": [
          "anestesia-fases-seguranca",
          "srpa-transferencia-vigilancia",
          "anestesia-alarmes-interface",
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais"
        ],
        "topics": [
          {
            "id": "PT-M08-01",
            "title": "Anestesia tópica",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ANESTESIA-TOPICA",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-02",
            "title": "Anestesia infiltrativa",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ANESTESIA-INFILTRATIVA",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-03",
            "title": "Bloqueios periféricos",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BLOQUEIOS-PERIFERICOS",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-04",
            "title": "Sedação procedimental",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SEDACAO-PROCEDIMENTAL",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-05",
            "title": "Raquianestesia",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RAQUIANESTESIA",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-06",
            "title": "Anestesia peridural",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ANESTESIA-PERIDURAL",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-07",
            "title": "Anestesia geral",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ANESTESIA-GERAL",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-08",
            "title": "Equipamento e circuitos de anestesia",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EQUIPAMENTO-E-CIRCUITOS-DE-ANESTESIA",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-09",
            "title": "Toxicidade sistêmica por anestésicos locais",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TOXICIDADE-SISTEMICA-POR-ANESTESICOS-LOCAIS",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M08-10",
            "title": "Recuperação pós-anestésica",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RECUPERACAO-POS-ANESTESICA",
            "context": {
              "moduleId": "M08",
              "moduleTitle": "Anestesia e analgesia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M08-anestesia-fases-seguranca",
            "lessonId": "anestesia-fases-seguranca",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M08-07",
              "PT-M08-08"
            ]
          },
          {
            "id": "REL-M08-srpa-transferencia-vigilancia",
            "lessonId": "srpa-transferencia-vigilancia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M08-10"
            ]
          },
          {
            "id": "REL-M08-anestesia-alarmes-interface",
            "lessonId": "anestesia-alarmes-interface",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M08-01",
              "PT-M08-02",
              "PT-M08-06",
              "PT-M08-07",
              "PT-M08-08"
            ]
          },
          {
            "id": "REL-M08-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M08-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M08-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M08-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M08-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M08-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M08-03",
              "PT-M08-05",
              "PT-M08-06"
            ]
          }
        ]
      },
      {
        "id": "M09",
        "order": 9,
        "title": "Preparo cirúrgico",
        "priority": "P0",
        "categoryId": "fundamentos",
        "coverage": "Base existente",
        "existingModuleIds": [
          "posicionamento",
          "cirurgia-segura",
          "prevencao-isc",
          "assepsia-antissepsia-pele",
          "procedimentos-perioperatorios"
        ],
        "existingLessonIds": [
          "posicoes-base",
          "posicionamento-seguranca",
          "posicionamento-reavaliacao",
          "checklist-tres-momentos",
          "comunicacao-fatores-humanos",
          "isc-preparo-preoperatorio",
          "isc-intra-posoperatorio",
          "assepsia-conceitos",
          "assepsia-maos-paramentacao",
          "assepsia-avaliacao-pele-pelos",
          "assepsia-selecao-antisseptico",
          "assepsia-aplicacao-campos-fogo",
          "perioperatorio-admissao-verificacao",
          "perioperatorio-transferencia-monitorizacao",
          "perioperatorio-puncoes-biopsias",
          "perioperatorio-feridas-curativos-estomas",
          "perioperatorio-transporte-handoff"
        ],
        "topics": [
          {
            "id": "PT-M09-01",
            "title": "Avaliação pré-operatória",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AVALIACAO-PRE-OPERATORIA",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-02",
            "title": "Jejum individualizado",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-JEJUM-INDIVIDUALIZADO",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-03",
            "title": "Exames pré-operatórios indicados",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EXAMES-PRE-OPERATORIOS-INDICADOS",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-04",
            "title": "Consentimento e lateralidade",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CONSENTIMENTO-E-LATERALIDADE",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-05",
            "title": "Profilaxia antimicrobiana",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PROFILAXIA-ANTIMICROBIANA",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-06",
            "title": "Prevenção tromboembólica",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PREVENCAO-TROMBOEMBOLICA",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-07",
            "title": "Banho e manejo de pelos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BANHO-E-MANEJO-DE-PELOS",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-08",
            "title": "Preparo antisséptico da pele",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PREPARO-ANTISSEPTICO-DA-PELE",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-09",
            "title": "Marcação do sítio",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MARCACAO-DO-SITIO",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-10",
            "title": "Posicionamento seguro",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-POSICIONAMENTO-SEGURO",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M09-11",
            "title": "Lista de verificação de cirurgia segura",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-LISTA-DE-VERIFICACAO-DE-CIRURGIA-SEGURA",
            "context": {
              "moduleId": "M09",
              "moduleTitle": "Preparo cirúrgico"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M09-posicoes-base",
            "lessonId": "posicoes-base",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-posicionamento-seguranca",
            "lessonId": "posicionamento-seguranca",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-10"
            ]
          },
          {
            "id": "REL-M09-posicionamento-reavaliacao",
            "lessonId": "posicionamento-reavaliacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-10"
            ]
          },
          {
            "id": "REL-M09-checklist-tres-momentos",
            "lessonId": "checklist-tres-momentos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-11"
            ]
          },
          {
            "id": "REL-M09-comunicacao-fatores-humanos",
            "lessonId": "comunicacao-fatores-humanos",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-isc-preparo-preoperatorio",
            "lessonId": "isc-preparo-preoperatorio",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-01",
              "PT-M09-05",
              "PT-M09-07"
            ]
          },
          {
            "id": "REL-M09-isc-intra-posoperatorio",
            "lessonId": "isc-intra-posoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-assepsia-conceitos",
            "lessonId": "assepsia-conceitos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-assepsia-maos-paramentacao",
            "lessonId": "assepsia-maos-paramentacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-assepsia-avaliacao-pele-pelos",
            "lessonId": "assepsia-avaliacao-pele-pelos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-07"
            ]
          },
          {
            "id": "REL-M09-assepsia-selecao-antisseptico",
            "lessonId": "assepsia-selecao-antisseptico",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-08"
            ]
          },
          {
            "id": "REL-M09-assepsia-aplicacao-campos-fogo",
            "lessonId": "assepsia-aplicacao-campos-fogo",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-perioperatorio-admissao-verificacao",
            "lessonId": "perioperatorio-admissao-verificacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M09-11"
            ]
          },
          {
            "id": "REL-M09-perioperatorio-transferencia-monitorizacao",
            "lessonId": "perioperatorio-transferencia-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-perioperatorio-puncoes-biopsias",
            "lessonId": "perioperatorio-puncoes-biopsias",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-perioperatorio-feridas-curativos-estomas",
            "lessonId": "perioperatorio-feridas-curativos-estomas",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M09-perioperatorio-transporte-handoff",
            "lessonId": "perioperatorio-transporte-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M10",
        "order": 10,
        "title": "Via aérea e oxigenoterapia",
        "priority": "P0–P2",
        "categoryId": "terapeutica-dispositivos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "via-aerea-sondas-drenos",
          "cabeca-pescoco",
          "anestesia-srpa"
        ],
        "existingLessonIds": [
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais",
          "cabeca-via-aerea-especimes",
          "cabeca-reconstrucao-handoff",
          "cabeca-via-aerea-fogo",
          "cabeca-retalho-monitorizacao",
          "anestesia-fases-seguranca",
          "srpa-transferencia-vigilancia",
          "anestesia-alarmes-interface"
        ],
        "topics": [
          {
            "id": "PT-M10-01",
            "title": "Cânula nasal",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CANULA-NASAL",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-02",
            "title": "Máscaras simples, Venturi e com reservatório",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MASCARAS-SIMPLES-VENTURI-E-COM-RESERVATORIO",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-03",
            "title": "Ventilação com bolsa-válvula-máscara",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "BVM",
              "ambu",
              "bolsa autoinflável"
            ],
            "canonicalProcedureId": "PROC-VENTILACAO-COM-BOLSA-VALVULA-MASCARA",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-04",
            "title": "Dispositivos supraglóticos",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DISPOSITIVOS-SUPRAGLOTICOS",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-05",
            "title": "Assistência à intubação traqueal",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "intubação",
              "IOT",
              "tubo endotraqueal",
              "ETT",
              "intubacion"
            ],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-INTUBACAO-TRAQUEAL",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-06",
            "title": "Ventilação mecânica",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VENTILACAO-MECANICA",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-07",
            "title": "Via aérea difícil",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-AEREA-DIFICIL",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-08",
            "title": "Cricotireoidostomia em contexto de emergência",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CRICOTIREOIDOSTOMIA-EM-CONTEXTO-DE-EMERGENCIA",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M10-09",
            "title": "Extubação e vigilância",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EXTUBACAO-E-VIGILANCIA",
            "context": {
              "moduleId": "M10",
              "moduleTitle": "Via aérea e oxigenoterapia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M10-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M10-01",
              "PT-M10-02",
              "PT-M10-03",
              "PT-M10-04",
              "PT-M10-05"
            ]
          },
          {
            "id": "REL-M10-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M10-07",
              "PT-M10-08"
            ]
          },
          {
            "id": "REL-M10-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-cabeca-via-aerea-especimes",
            "lessonId": "cabeca-via-aerea-especimes",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M10-07"
            ]
          },
          {
            "id": "REL-M10-cabeca-reconstrucao-handoff",
            "lessonId": "cabeca-reconstrucao-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-cabeca-via-aerea-fogo",
            "lessonId": "cabeca-via-aerea-fogo",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M10-07"
            ]
          },
          {
            "id": "REL-M10-cabeca-retalho-monitorizacao",
            "lessonId": "cabeca-retalho-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-anestesia-fases-seguranca",
            "lessonId": "anestesia-fases-seguranca",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M10-srpa-transferencia-vigilancia",
            "lessonId": "srpa-transferencia-vigilancia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M10-09"
            ]
          },
          {
            "id": "REL-M10-anestesia-alarmes-interface",
            "lessonId": "anestesia-alarmes-interface",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M11",
        "order": 11,
        "title": "Procedimentos respiratórios",
        "priority": "P1–P2",
        "categoryId": "terapeutica-dispositivos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "via-aerea-sondas-drenos",
          "toracica-cardiaca"
        ],
        "existingLessonIds": [
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais",
          "toracica-pulmao-drenos",
          "cardiaca-cec-handoff",
          "toracica-ventilacao-conversao",
          "cardiaca-marcos-transferencia"
        ],
        "topics": [
          {
            "id": "PT-M11-01",
            "title": "Aspiração de vias aéreas",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASPIRACAO-DE-VIAS-AEREAS",
            "context": {
              "moduleId": "M11",
              "moduleTitle": "Procedimentos respiratórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M11-02",
            "title": "Nebulização",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-NEBULIZACAO",
            "context": {
              "moduleId": "M11",
              "moduleTitle": "Procedimentos respiratórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M11-03",
            "title": "Gasometria arterial",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-GASOMETRIA-ARTERIAL",
            "context": {
              "moduleId": "M11",
              "moduleTitle": "Procedimentos respiratórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M11-04",
            "title": "Toracocentese",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TORACOCENTESE",
            "context": {
              "moduleId": "M11",
              "moduleTitle": "Procedimentos respiratórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M11-05",
            "title": "Drenagem torácica",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DRENAGEM-TORACICA",
            "context": {
              "moduleId": "M11",
              "moduleTitle": "Procedimentos respiratórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M11-06",
            "title": "Assistência à traqueostomia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-TRAQUEOSTOMIA",
            "context": {
              "moduleId": "M11",
              "moduleTitle": "Procedimentos respiratórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M11-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M11-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M11-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M11-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M11-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M11-05"
            ]
          },
          {
            "id": "REL-M11-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M11-toracica-pulmao-drenos",
            "lessonId": "toracica-pulmao-drenos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M11-05"
            ]
          },
          {
            "id": "REL-M11-cardiaca-cec-handoff",
            "lessonId": "cardiaca-cec-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M11-toracica-ventilacao-conversao",
            "lessonId": "toracica-ventilacao-conversao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M11-05"
            ]
          },
          {
            "id": "REL-M11-cardiaca-marcos-transferencia",
            "lessonId": "cardiaca-marcos-transferencia",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M12",
        "order": 12,
        "title": "Emergências",
        "priority": "P0–P2",
        "categoryId": "urgencia-criticos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "eventos-criticos",
          "acessos-vasculares-infusao",
          "via-aerea-sondas-drenos"
        ],
        "existingLessonIds": [
          "crise-lideranca-comunicacao",
          "crise-preparo-simulacao",
          "eventos-debriefing-aprendizado",
          "vascular-mapa-dispositivos",
          "vascular-periferico",
          "vascular-central",
          "vascular-arterial",
          "vascular-intraosseo-emergencia",
          "vascular-manutencao-complicacoes",
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais"
        ],
        "topics": [
          {
            "id": "PT-M12-01",
            "title": "Ressuscitação cardiopulmonar",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RESSUSCITACAO-CARDIOPULMONAR",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-02",
            "title": "Uso do desfibrilador externo automático",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-USO-DO-DESFIBRILADOR-EXTERNO-AUTOMATICO",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-03",
            "title": "Desfibrilação manual",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DESFIBRILACAO-MANUAL",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-04",
            "title": "Cardioversão sincronizada",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "cardioversao",
              "choque sincronizado",
              "synchronized cardioversion"
            ],
            "canonicalProcedureId": "PROC-CARDIOVERSAO-SINCRONIZADA",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-05",
            "title": "Acesso vascular de emergência",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ACESSO-VASCULAR-DE-EMERGENCIA",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-06",
            "title": "Controle de hemorragias",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CONTROLE-DE-HEMORRAGIAS",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-07",
            "title": "Aplicação e vigilância de torniquete",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-APLICACAO-E-VIGILANCIA-DE-TORNIQUETE",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-08",
            "title": "Estabilização inicial no trauma",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ESTABILIZACAO-INICIAL-NO-TRAUMA",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M12-09",
            "title": "Comunicação e liderança em crise",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COMUNICACAO-E-LIDERANCA-EM-CRISE",
            "context": {
              "moduleId": "M12",
              "moduleTitle": "Emergências"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M12-crise-lideranca-comunicacao",
            "lessonId": "crise-lideranca-comunicacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-09"
            ]
          },
          {
            "id": "REL-M12-crise-preparo-simulacao",
            "lessonId": "crise-preparo-simulacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-09"
            ]
          },
          {
            "id": "REL-M12-eventos-debriefing-aprendizado",
            "lessonId": "eventos-debriefing-aprendizado",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M12-vascular-mapa-dispositivos",
            "lessonId": "vascular-mapa-dispositivos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-05"
            ]
          },
          {
            "id": "REL-M12-vascular-periferico",
            "lessonId": "vascular-periferico",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-05",
              "PT-M12-07"
            ]
          },
          {
            "id": "REL-M12-vascular-central",
            "lessonId": "vascular-central",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-05"
            ]
          },
          {
            "id": "REL-M12-vascular-arterial",
            "lessonId": "vascular-arterial",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-05"
            ]
          },
          {
            "id": "REL-M12-vascular-intraosseo-emergencia",
            "lessonId": "vascular-intraosseo-emergencia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-05"
            ]
          },
          {
            "id": "REL-M12-vascular-manutencao-complicacoes",
            "lessonId": "vascular-manutencao-complicacoes",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-05"
            ]
          },
          {
            "id": "REL-M12-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M12-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M12-09"
            ]
          },
          {
            "id": "REL-M12-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M12-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M12-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M12-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M13",
        "order": 13,
        "title": "Ortopedia e imobilização",
        "priority": "P0–P2",
        "categoryId": "procedimentos-fundamentais",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "ortopedia-trauma"
        ],
        "existingLessonIds": [
          "ortopedia-implantes-imagem",
          "ortopedia-trauma-seguranca",
          "ortopedia-torniquete-interface",
          "ortopedia-componentes-cimento"
        ],
        "topics": [
          {
            "id": "PT-M13-01",
            "title": "Tipóia",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TIPOIA",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-02",
            "title": "Tala antebraquiopalmar",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TALA-ANTEBRAQUIOPALMAR",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-03",
            "title": "Tala tipo sugar-tong",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TALA-TIPO-SUGAR-TONG",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M13-04",
            "title": "Tala tipo U",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TALA-TIPO-U",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-05",
            "title": "Tala posterior de membro inferior",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TALA-POSTERIOR-DE-MEMBRO-INFERIOR",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M13-06",
            "title": "Gesso circular",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-GESSO-CIRCULAR",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          },
          {
            "id": "PT-M13-07",
            "title": "Imobilização do polegar — thumb spica",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-IMOBILIZACAO-DO-POLEGAR-THUMB-SPICA",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-08",
            "title": "Imobilização de dedos e buddy taping",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-IMOBILIZACAO-DE-DEDOS-E-BUDDY-TAPING",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-09",
            "title": "Colar cervical em indicações selecionadas",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLAR-CERVICAL-EM-INDICACOES-SELECIONADAS",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-10",
            "title": "Avaliação neurovascular antes e depois",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AVALIACAO-NEUROVASCULAR-ANTES-E-DEPOIS",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M13-11",
            "title": "Reconhecimento de síndrome compartimental",
            "status": "revisao-tecnica",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RECONHECIMENTO-DE-SINDROME-COMPARTIMENTAL",
            "context": {
              "moduleId": "M13",
              "moduleTitle": "Ortopedia e imobilização"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            },
            "review": {
              "status": "revisao-tecnica",
              "clinicalReviewer": null,
              "reviewedOn": null,
              "version": "0.2"
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M13-ortopedia-implantes-imagem",
            "lessonId": "ortopedia-implantes-imagem",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M13-ortopedia-trauma-seguranca",
            "lessonId": "ortopedia-trauma-seguranca",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M13-ortopedia-torniquete-interface",
            "lessonId": "ortopedia-torniquete-interface",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M13-ortopedia-componentes-cimento",
            "lessonId": "ortopedia-componentes-cimento",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M14",
        "order": 14,
        "title": "Sondas e cateteres",
        "priority": "P0–P1",
        "categoryId": "terapeutica-dispositivos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "via-aerea-sondas-drenos",
          "urologia"
        ],
        "existingLessonIds": [
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais",
          "urologia-endourologia",
          "urologia-posicao-dispositivos",
          "urologia-irrigacao-balanco",
          "urologia-stents-cadeia-saida"
        ],
        "topics": [
          {
            "id": "PT-M14-01",
            "title": "Cateterismo vesical de alívio",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "sonda Nelaton",
              "Nelaton",
              "cateter urinário intermitente"
            ],
            "canonicalProcedureId": "PROC-CATETERISMO-VESICAL-DE-ALIVIO",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M14-02",
            "title": "Cateterismo vesical de demora",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "sonda Foley",
              "Foley",
              "SVD",
              "cateter urinário de demora"
            ],
            "canonicalProcedureId": "PROC-CATETERISMO-VESICAL-DE-DEMORA",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M14-03",
            "title": "Irrigação vesical",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "lavagem vesical",
              "irrigacao da bexiga",
              "bladder irrigation"
            ],
            "canonicalProcedureId": "PROC-IRRIGACAO-VESICAL",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M14-04",
            "title": "Sonda nasogástrica",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "SNG",
              "NG tube",
              "sonda gástrica"
            ],
            "canonicalProcedureId": "PROC-SONDA-NASOGASTRICA",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M14-05",
            "title": "Sonda nasoenteral",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "SNE",
              "enteral tube",
              "sonda enteral"
            ],
            "canonicalProcedureId": "PROC-SONDA-NASOENTERAL",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M14-06",
            "title": "Gastrostomia",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-GASTROSTOMIA",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M14-07",
            "title": "Cuidados com ostomias",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CUIDADOS-COM-OSTOMIAS",
            "context": {
              "moduleId": "M14",
              "moduleTitle": "Sondas e cateteres"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1"
        ],
        "lessonRelations": [
          {
            "id": "REL-M14-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M14-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M14-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M14-01",
              "PT-M14-02",
              "PT-M14-03"
            ]
          },
          {
            "id": "REL-M14-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M14-04",
              "PT-M14-05"
            ]
          },
          {
            "id": "REL-M14-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M14-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M14-urologia-endourologia",
            "lessonId": "urologia-endourologia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M14-03"
            ]
          },
          {
            "id": "REL-M14-urologia-posicao-dispositivos",
            "lessonId": "urologia-posicao-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M14-urologia-irrigacao-balanco",
            "lessonId": "urologia-irrigacao-balanco",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M14-03"
            ]
          },
          {
            "id": "REL-M14-urologia-stents-cadeia-saida",
            "lessonId": "urologia-stents-cadeia-saida",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M15",
        "order": 15,
        "title": "Procedimentos ambulatoriais",
        "priority": "P1",
        "categoryId": "procedimentos-fundamentais",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "procedimentos-perioperatorios"
        ],
        "existingLessonIds": [
          "perioperatorio-admissao-verificacao",
          "perioperatorio-transferencia-monitorizacao",
          "perioperatorio-puncoes-biopsias",
          "perioperatorio-feridas-curativos-estomas",
          "perioperatorio-transporte-handoff"
        ],
        "topics": [
          {
            "id": "PT-M15-01",
            "title": "Drenagem de abscesso em ambiente habilitado",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DRENAGEM-DE-ABSCESSO-EM-AMBIENTE-HABILITADO",
            "context": {
              "moduleId": "M15",
              "moduleTitle": "Procedimentos ambulatoriais"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M15-02",
            "title": "Retirada de corpo estranho superficial",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RETIRADA-DE-CORPO-ESTRANHO-SUPERFICIAL",
            "context": {
              "moduleId": "M15",
              "moduleTitle": "Procedimentos ambulatoriais"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M15-03",
            "title": "Biópsias ambulatoriais",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BIOPSIAS-AMBULATORIAIS",
            "context": {
              "moduleId": "M15",
              "moduleTitle": "Procedimentos ambulatoriais"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M15-04",
            "title": "Procedimentos ungueais",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PROCEDIMENTOS-UNGUEAIS",
            "context": {
              "moduleId": "M15",
              "moduleTitle": "Procedimentos ambulatoriais"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M15-05",
            "title": "Tratamento inicial de queimaduras",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TRATAMENTO-INICIAL-DE-QUEIMADURAS",
            "context": {
              "moduleId": "M15",
              "moduleTitle": "Procedimentos ambulatoriais"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1"
        ],
        "lessonRelations": [
          {
            "id": "REL-M15-perioperatorio-admissao-verificacao",
            "lessonId": "perioperatorio-admissao-verificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M15-perioperatorio-transferencia-monitorizacao",
            "lessonId": "perioperatorio-transferencia-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M15-perioperatorio-puncoes-biopsias",
            "lessonId": "perioperatorio-puncoes-biopsias",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M15-03"
            ]
          },
          {
            "id": "REL-M15-perioperatorio-feridas-curativos-estomas",
            "lessonId": "perioperatorio-feridas-curativos-estomas",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M15-perioperatorio-transporte-handoff",
            "lessonId": "perioperatorio-transporte-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M16",
        "order": 16,
        "title": "Cirurgia geral",
        "priority": "P1–P2",
        "categoryId": "cirurgia",
        "coverage": "Base existente",
        "existingModuleIds": [
          "cirurgia-geral-digestiva",
          "procedimentos-vias-cirurgicas",
          "fluxo-procedimentos",
          "minimamente-invasiva-robotica"
        ],
        "existingLessonIds": [
          "geral-mapa-abdominal",
          "geral-recuperacao-integrada",
          "geral-transicoes-contaminacao",
          "geral-dispositivos-handoff",
          "procedimentos-classificacao-jornada",
          "procedimentos-acesso-aberto",
          "procedimentos-video-robotico",
          "procedimentos-endoscopico-percutaneo",
          "procedimentos-conversao-encerramento",
          "tempos-operatorios",
          "encerramento-seguro",
          "robotica-docking-equipe",
          "robotica-interface-falha",
          "robotica-posicionamento-acesso",
          "robotica-conversao-rastreabilidade"
        ],
        "topics": [
          {
            "id": "PT-M16-01",
            "title": "Incisões e vias de acesso",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-INCISOES-E-VIAS-DE-ACESSO",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-02",
            "title": "Dissecção por planos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DISSECCAO-POR-PLANOS",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-03",
            "title": "Hemostasia e ligaduras",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-HEMOSTASIA-E-LIGADURAS",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-04",
            "title": "Laparotomia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-LAPAROTOMIA",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-05",
            "title": "Laparoscopia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-LAPAROSCOPIA",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-06",
            "title": "Fechamento por planos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-FECHAMENTO-POR-PLANOS",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-07",
            "title": "Drenos cirúrgicos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DRENOS-CIRURGICOS",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M16-08",
            "title": "Conversão e encerramento seguro",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CONVERSAO-E-ENCERRAMENTO-SEGURO",
            "context": {
              "moduleId": "M16",
              "moduleTitle": "Cirurgia geral"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M16-geral-mapa-abdominal",
            "lessonId": "geral-mapa-abdominal",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-geral-recuperacao-integrada",
            "lessonId": "geral-recuperacao-integrada",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-geral-transicoes-contaminacao",
            "lessonId": "geral-transicoes-contaminacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-geral-dispositivos-handoff",
            "lessonId": "geral-dispositivos-handoff",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M16-07"
            ]
          },
          {
            "id": "REL-M16-procedimentos-classificacao-jornada",
            "lessonId": "procedimentos-classificacao-jornada",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-procedimentos-acesso-aberto",
            "lessonId": "procedimentos-acesso-aberto",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M16-01"
            ]
          },
          {
            "id": "REL-M16-procedimentos-video-robotico",
            "lessonId": "procedimentos-video-robotico",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-procedimentos-endoscopico-percutaneo",
            "lessonId": "procedimentos-endoscopico-percutaneo",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-procedimentos-conversao-encerramento",
            "lessonId": "procedimentos-conversao-encerramento",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M16-08"
            ]
          },
          {
            "id": "REL-M16-tempos-operatorios",
            "lessonId": "tempos-operatorios",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-encerramento-seguro",
            "lessonId": "encerramento-seguro",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M16-08"
            ]
          },
          {
            "id": "REL-M16-robotica-docking-equipe",
            "lessonId": "robotica-docking-equipe",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-robotica-interface-falha",
            "lessonId": "robotica-interface-falha",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M16-08"
            ]
          },
          {
            "id": "REL-M16-robotica-posicionamento-acesso",
            "lessonId": "robotica-posicionamento-acesso",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M16-robotica-conversao-rastreabilidade",
            "lessonId": "robotica-conversao-rastreabilidade",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M16-08"
            ]
          }
        ]
      },
      {
        "id": "M17",
        "order": 17,
        "title": "Ginecologia e obstetrícia",
        "priority": "P1–P2",
        "categoryId": "especialidades",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "ginecologia-obstetricia"
        ],
        "existingLessonIds": [
          "ginecologia-pelve-vias",
          "obstetricia-duas-equipes",
          "ginecologia-fluidos-especimes",
          "obstetricia-hemorragia-fluxo"
        ],
        "topics": [
          {
            "id": "PT-M17-01",
            "title": "Exame especular",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EXAME-ESPECULAR",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-02",
            "title": "Coleta cervical",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLETA-CERVICAL",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-03",
            "title": "Procedimentos uterinos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PROCEDIMENTOS-UTERINOS",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-04",
            "title": "Dispositivo intrauterino",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DISPOSITIVO-INTRAUTERINO",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-05",
            "title": "Assistência ao parto",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-AO-PARTO",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-06",
            "title": "Episiotomia e episiorrafia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EPISIOTOMIA-E-EPISIORRAFIA",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-07",
            "title": "Urgências obstétricas",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-URGENCIAS-OBSTETRICAS",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M17-08",
            "title": "Fluxo seguro na cesariana",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-FLUXO-SEGURO-NA-CESARIANA",
            "context": {
              "moduleId": "M17",
              "moduleTitle": "Ginecologia e obstetrícia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M17-ginecologia-pelve-vias",
            "lessonId": "ginecologia-pelve-vias",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M17-obstetricia-duas-equipes",
            "lessonId": "obstetricia-duas-equipes",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M17-ginecologia-fluidos-especimes",
            "lessonId": "ginecologia-fluidos-especimes",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M17-obstetricia-hemorragia-fluxo",
            "lessonId": "obstetricia-hemorragia-fluxo",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M17-08"
            ]
          }
        ]
      },
      {
        "id": "M18",
        "order": 18,
        "title": "Pediatria e neonatologia",
        "priority": "P1–P2",
        "categoryId": "especialidades",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "cirurgia-pediatrica-neonatal",
          "acessos-vasculares-infusao"
        ],
        "existingLessonIds": [
          "pediatria-escala-fisiologia",
          "neonatal-equipe-familia",
          "pediatria-microcomponentes-medicamentos",
          "neonatal-termica-transporte",
          "vascular-mapa-dispositivos",
          "vascular-periferico",
          "vascular-central",
          "vascular-arterial",
          "vascular-intraosseo-emergencia",
          "vascular-manutencao-complicacoes"
        ],
        "topics": [
          {
            "id": "PT-M18-01",
            "title": "Acessos vasculares pediátricos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ACESSOS-VASCULARES-PEDIATRICOS",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M18-02",
            "title": "Punção capilar",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [
              "puncao capilar",
              "glicemia ponta de dedo",
              "fingerstick",
              "punción capilar"
            ],
            "canonicalProcedureId": "PROC-PUNCAO-CAPILAR",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M18-03",
            "title": "Dispositivos neonatais",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DISPOSITIVOS-NEONATAIS",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M18-04",
            "title": "Vias de administração pediátrica",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIAS-DE-ADMINISTRACAO-PEDIATRICA",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M18-05",
            "title": "Reanimação neonatal",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-REANIMACAO-NEONATAL",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M18-06",
            "title": "Dispositivos pediátricos de oxigênio",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DISPOSITIVOS-PEDIATRICOS-DE-OXIGENIO",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M18-07",
            "title": "Termorregulação e transporte neonatal",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TERMORREGULACAO-E-TRANSPORTE-NEONATAL",
            "context": {
              "moduleId": "M18",
              "moduleTitle": "Pediatria e neonatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M18-pediatria-escala-fisiologia",
            "lessonId": "pediatria-escala-fisiologia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M18-07"
            ]
          },
          {
            "id": "REL-M18-neonatal-equipe-familia",
            "lessonId": "neonatal-equipe-familia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M18-05",
              "PT-M18-07"
            ]
          },
          {
            "id": "REL-M18-pediatria-microcomponentes-medicamentos",
            "lessonId": "pediatria-microcomponentes-medicamentos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M18-04"
            ]
          },
          {
            "id": "REL-M18-neonatal-termica-transporte",
            "lessonId": "neonatal-termica-transporte",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M18-05",
              "PT-M18-07"
            ]
          },
          {
            "id": "REL-M18-vascular-mapa-dispositivos",
            "lessonId": "vascular-mapa-dispositivos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M18-01",
              "PT-M18-03",
              "PT-M18-06"
            ]
          },
          {
            "id": "REL-M18-vascular-periferico",
            "lessonId": "vascular-periferico",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M18-vascular-central",
            "lessonId": "vascular-central",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M18-vascular-arterial",
            "lessonId": "vascular-arterial",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M18-vascular-intraosseo-emergencia",
            "lessonId": "vascular-intraosseo-emergencia",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M18-vascular-manutencao-complicacoes",
            "lessonId": "vascular-manutencao-complicacoes",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M19",
        "order": 19,
        "title": "Neurologia",
        "priority": "P1–P2",
        "categoryId": "especialidades",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "neurocirurgia-coluna",
          "via-aerea-sondas-drenos"
        ],
        "existingLessonIds": [
          "neuro-cranio-micro",
          "coluna-posicao-implantes",
          "neuro-navegacao-monitorizacao",
          "coluna-nivel-tecnologia",
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais"
        ],
        "topics": [
          {
            "id": "PT-M19-01",
            "title": "Punção lombar em ambiente supervisionado",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PUNCAO-LOMBAR-EM-AMBIENTE-SUPERVISIONADO",
            "context": {
              "moduleId": "M19",
              "moduleTitle": "Neurologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M19-02",
            "title": "Coleta e avaliação inicial do líquor",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLETA-E-AVALIACAO-INICIAL-DO-LIQUOR",
            "context": {
              "moduleId": "M19",
              "moduleTitle": "Neurologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M19-03",
            "title": "Monitorização da pressão intracraniana",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MONITORIZACAO-DA-PRESSAO-INTRACRANIANA",
            "context": {
              "moduleId": "M19",
              "moduleTitle": "Neurologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M19-04",
            "title": "Assistência a procedimentos neurocirúrgicos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-PROCEDIMENTOS-NEUROCIRURGICOS",
            "context": {
              "moduleId": "M19",
              "moduleTitle": "Neurologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M19-05",
            "title": "Navegação e neuromonitorização",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-NAVEGACAO-E-NEUROMONITORIZACAO",
            "context": {
              "moduleId": "M19",
              "moduleTitle": "Neurologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M19-neuro-cranio-micro",
            "lessonId": "neuro-cranio-micro",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M19-05"
            ]
          },
          {
            "id": "REL-M19-coluna-posicao-implantes",
            "lessonId": "coluna-posicao-implantes",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-neuro-navegacao-monitorizacao",
            "lessonId": "neuro-navegacao-monitorizacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M19-03",
              "PT-M19-05"
            ]
          },
          {
            "id": "REL-M19-coluna-nivel-tecnologia",
            "lessonId": "coluna-nivel-tecnologia",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M19-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M20",
        "order": 20,
        "title": "Cardiologia",
        "priority": "P0–P2",
        "categoryId": "urgencia-criticos",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "toracica-cardiaca",
          "eventos-criticos"
        ],
        "existingLessonIds": [
          "toracica-pulmao-drenos",
          "cardiaca-cec-handoff",
          "toracica-ventilacao-conversao",
          "cardiaca-marcos-transferencia",
          "crise-lideranca-comunicacao",
          "crise-preparo-simulacao",
          "eventos-debriefing-aprendizado"
        ],
        "topics": [
          {
            "id": "PT-M20-01",
            "title": "Eletrocardiograma de 12 derivações",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "ECG",
              "ECG 12 derivações",
              "eletrocardiografia"
            ],
            "canonicalProcedureId": "PROC-ELETROCARDIOGRAMA-DE-12-DERIVACOES",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M20-02",
            "title": "Monitorização cardíaca",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MONITORIZACAO-CARDIACA",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M20-03",
            "title": "Cardioversão sincronizada",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [
              "cardioversao",
              "choque sincronizado",
              "synchronized cardioversion"
            ],
            "canonicalProcedureId": "PROC-CARDIOVERSAO-SINCRONIZADA",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M20-04",
            "title": "Desfibrilação",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DESFIBRILACAO",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M20-05",
            "title": "Marcapasso transcutâneo",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MARCAPASSO-TRANSCUTANEO",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M20-06",
            "title": "Assistência a procedimentos cardiovasculares invasivos",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-PROCEDIMENTOS-CARDIOVASCULARES-INVASIVOS",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M20-07",
            "title": "Transições em circulação extracorpórea",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TRANSICOES-EM-CIRCULACAO-EXTRACORPOREA",
            "context": {
              "moduleId": "M20",
              "moduleTitle": "Cardiologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M20-toracica-pulmao-drenos",
            "lessonId": "toracica-pulmao-drenos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M20-cardiaca-cec-handoff",
            "lessonId": "cardiaca-cec-handoff",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M20-02",
              "PT-M20-07"
            ]
          },
          {
            "id": "REL-M20-toracica-ventilacao-conversao",
            "lessonId": "toracica-ventilacao-conversao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M20-cardiaca-marcos-transferencia",
            "lessonId": "cardiaca-marcos-transferencia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M20-02"
            ]
          },
          {
            "id": "REL-M20-crise-lideranca-comunicacao",
            "lessonId": "crise-lideranca-comunicacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M20-crise-preparo-simulacao",
            "lessonId": "crise-preparo-simulacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M20-eventos-debriefing-aprendizado",
            "lessonId": "eventos-debriefing-aprendizado",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M21",
        "order": 21,
        "title": "Gastroenterologia",
        "priority": "P1–P2",
        "categoryId": "especialidades",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "cirurgia-geral-digestiva",
          "procedimentos-vias-cirurgicas",
          "via-aerea-sondas-drenos"
        ],
        "existingLessonIds": [
          "geral-mapa-abdominal",
          "geral-recuperacao-integrada",
          "geral-transicoes-contaminacao",
          "geral-dispositivos-handoff",
          "procedimentos-classificacao-jornada",
          "procedimentos-acesso-aberto",
          "procedimentos-video-robotico",
          "procedimentos-endoscopico-percutaneo",
          "procedimentos-conversao-encerramento",
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais"
        ],
        "topics": [
          {
            "id": "PT-M21-01",
            "title": "Paracentese",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PARACENTESE",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M21-02",
            "title": "Sondas digestivas",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-SONDAS-DIGESTIVAS",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M21-03",
            "title": "Assistência à endoscopia digestiva alta",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-ENDOSCOPIA-DIGESTIVA-ALTA",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M21-04",
            "title": "Assistência à colonoscopia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-COLONOSCOPIA",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M21-05",
            "title": "Biópsias digestivas",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BIOPSIAS-DIGESTIVAS",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M21-06",
            "title": "Assistência a drenagens",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-DRENAGENS",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M21-07",
            "title": "Cuidados com ostomias digestivas",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CUIDADOS-COM-OSTOMIAS-DIGESTIVAS",
            "context": {
              "moduleId": "M21",
              "moduleTitle": "Gastroenterologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M21-geral-mapa-abdominal",
            "lessonId": "geral-mapa-abdominal",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-geral-recuperacao-integrada",
            "lessonId": "geral-recuperacao-integrada",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-geral-transicoes-contaminacao",
            "lessonId": "geral-transicoes-contaminacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-geral-dispositivos-handoff",
            "lessonId": "geral-dispositivos-handoff",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M21-07"
            ]
          },
          {
            "id": "REL-M21-procedimentos-classificacao-jornada",
            "lessonId": "procedimentos-classificacao-jornada",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-procedimentos-acesso-aberto",
            "lessonId": "procedimentos-acesso-aberto",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-procedimentos-video-robotico",
            "lessonId": "procedimentos-video-robotico",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-procedimentos-endoscopico-percutaneo",
            "lessonId": "procedimentos-endoscopico-percutaneo",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-procedimentos-conversao-encerramento",
            "lessonId": "procedimentos-conversao-encerramento",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M21-02"
            ]
          },
          {
            "id": "REL-M21-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M21-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M22",
        "order": 22,
        "title": "Urologia",
        "priority": "P1–P2",
        "categoryId": "especialidades",
        "coverage": "Cobertura parcial",
        "existingModuleIds": [
          "urologia",
          "via-aerea-sondas-drenos"
        ],
        "existingLessonIds": [
          "urologia-endourologia",
          "urologia-posicao-dispositivos",
          "urologia-irrigacao-balanco",
          "urologia-stents-cadeia-saida",
          "via-aerea-dispositivos",
          "via-aerea-assistencia-crise",
          "sonda-vesical-perioperatoria",
          "sondas-gastricas-enterais",
          "drenos-toracicos-cirurgicos",
          "acessos-neuroeixo-regionais"
        ],
        "topics": [
          {
            "id": "PT-M22-01",
            "title": "Cateterismo urinário",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CATETERISMO-URINARIO",
            "context": {
              "moduleId": "M22",
              "moduleTitle": "Urologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M22-02",
            "title": "Irrigação vesical",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [
              "lavagem vesical",
              "irrigacao da bexiga",
              "bladder irrigation"
            ],
            "canonicalProcedureId": "PROC-IRRIGACAO-VESICAL",
            "context": {
              "moduleId": "M22",
              "moduleTitle": "Urologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M22-03",
            "title": "Cistostomia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CISTOSTOMIA",
            "context": {
              "moduleId": "M22",
              "moduleTitle": "Urologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M22-04",
            "title": "Assistência à cistoscopia",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ASSISTENCIA-A-CISTOSCOPIA",
            "context": {
              "moduleId": "M22",
              "moduleTitle": "Urologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M22-05",
            "title": "Procedimentos uretrais",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PROCEDIMENTOS-URETRAIS",
            "context": {
              "moduleId": "M22",
              "moduleTitle": "Urologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M22-06",
            "title": "Stents e cateteres urológicos",
            "status": "catalogado",
            "priorityLevels": [
              "P1",
              "P2"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-STENTS-E-CATETERES-UROLOGICOS",
            "context": {
              "moduleId": "M22",
              "moduleTitle": "Urologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1",
          "P2"
        ],
        "lessonRelations": [
          {
            "id": "REL-M22-urologia-endourologia",
            "lessonId": "urologia-endourologia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M22-02"
            ]
          },
          {
            "id": "REL-M22-urologia-posicao-dispositivos",
            "lessonId": "urologia-posicao-dispositivos",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M22-06"
            ]
          },
          {
            "id": "REL-M22-urologia-irrigacao-balanco",
            "lessonId": "urologia-irrigacao-balanco",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M22-02"
            ]
          },
          {
            "id": "REL-M22-urologia-stents-cadeia-saida",
            "lessonId": "urologia-stents-cadeia-saida",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M22-06"
            ]
          },
          {
            "id": "REL-M22-via-aerea-dispositivos",
            "lessonId": "via-aerea-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M22-via-aerea-assistencia-crise",
            "lessonId": "via-aerea-assistencia-crise",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M22-sonda-vesical-perioperatoria",
            "lessonId": "sonda-vesical-perioperatoria",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M22-01",
              "PT-M22-02"
            ]
          },
          {
            "id": "REL-M22-sondas-gastricas-enterais",
            "lessonId": "sondas-gastricas-enterais",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M22-drenos-toracicos-cirurgicos",
            "lessonId": "drenos-toracicos-cirurgicos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M22-acessos-neuroeixo-regionais",
            "lessonId": "acessos-neuroeixo-regionais",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M22-06"
            ]
          }
        ]
      },
      {
        "id": "M23",
        "order": 23,
        "title": "Oftalmologia",
        "priority": "P1",
        "categoryId": "especialidades",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [],
        "existingLessonIds": [],
        "topics": [
          {
            "id": "PT-M23-01",
            "title": "Avaliação da acuidade visual",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AVALIACAO-DA-ACUIDADE-VISUAL",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M23-02",
            "title": "Teste com fluoresceína",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TESTE-COM-FLUORESCEINA",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M23-03",
            "title": "Eversão palpebral",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EVERSAO-PALPEBRAL",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M23-04",
            "title": "Irrigação ocular",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-IRRIGACAO-OCULAR",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M23-05",
            "title": "Tonometria",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TONOMETRIA",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M23-06",
            "title": "Curativos oculares",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CURATIVOS-OCULARES",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M23-07",
            "title": "Remoção de corpo estranho superficial em contexto habilitado",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-REMOCAO-DE-CORPO-ESTRANHO-SUPERFICIAL-EM-CONTEXTO-HABILITADO",
            "context": {
              "moduleId": "M23",
              "moduleTitle": "Oftalmologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1"
        ],
        "lessonRelations": []
      },
      {
        "id": "M24",
        "order": 24,
        "title": "Otorrinolaringologia",
        "priority": "P1",
        "categoryId": "especialidades",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "cabeca-pescoco"
        ],
        "existingLessonIds": [
          "cabeca-via-aerea-especimes",
          "cabeca-reconstrucao-handoff",
          "cabeca-via-aerea-fogo",
          "cabeca-retalho-monitorizacao"
        ],
        "topics": [
          {
            "id": "PT-M24-01",
            "title": "Otoscopia",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-OTOSCOPIA",
            "context": {
              "moduleId": "M24",
              "moduleTitle": "Otorrinolaringologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M24-02",
            "title": "Lavagem auricular quando indicada",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-LAVAGEM-AURICULAR-QUANDO-INDICADA",
            "context": {
              "moduleId": "M24",
              "moduleTitle": "Otorrinolaringologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M24-03",
            "title": "Controle inicial de epistaxe",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CONTROLE-INICIAL-DE-EPISTAXE",
            "context": {
              "moduleId": "M24",
              "moduleTitle": "Otorrinolaringologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M24-04",
            "title": "Tamponamento nasal",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TAMPONAMENTO-NASAL",
            "context": {
              "moduleId": "M24",
              "moduleTitle": "Otorrinolaringologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M24-05",
            "title": "Remoção de corpo estranho em ouvido ou nariz",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-REMOCAO-DE-CORPO-ESTRANHO-EM-OUVIDO-OU-NARIZ",
            "context": {
              "moduleId": "M24",
              "moduleTitle": "Otorrinolaringologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M24-06",
            "title": "Via aérea compartilhada",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIA-AEREA-COMPARTILHADA",
            "context": {
              "moduleId": "M24",
              "moduleTitle": "Otorrinolaringologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1"
        ],
        "lessonRelations": [
          {
            "id": "REL-M24-cabeca-via-aerea-especimes",
            "lessonId": "cabeca-via-aerea-especimes",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M24-06"
            ]
          },
          {
            "id": "REL-M24-cabeca-reconstrucao-handoff",
            "lessonId": "cabeca-reconstrucao-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M24-cabeca-via-aerea-fogo",
            "lessonId": "cabeca-via-aerea-fogo",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M24-06"
            ]
          },
          {
            "id": "REL-M24-cabeca-retalho-monitorizacao",
            "lessonId": "cabeca-retalho-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M25",
        "order": 25,
        "title": "Dermatologia",
        "priority": "P1",
        "categoryId": "especialidades",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "procedimentos-perioperatorios"
        ],
        "existingLessonIds": [
          "perioperatorio-admissao-verificacao",
          "perioperatorio-transferencia-monitorizacao",
          "perioperatorio-puncoes-biopsias",
          "perioperatorio-feridas-curativos-estomas",
          "perioperatorio-transporte-handoff"
        ],
        "topics": [
          {
            "id": "PT-M25-01",
            "title": "Biópsia punch",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BIOPSIA-PUNCH",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M25-02",
            "title": "Biópsia shave",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BIOPSIA-SHAVE",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M25-03",
            "title": "Biópsia excisional",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-BIOPSIA-EXCISIONAL",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M25-04",
            "title": "Crioterapia",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CRIOTERAPIA",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M25-05",
            "title": "Cauterização",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CAUTERIZACAO",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M25-06",
            "title": "Exérese de lesões",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EXERESE-DE-LESOES",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M25-07",
            "title": "Curativos e acondicionamento de espécimes",
            "status": "catalogado",
            "priorityLevels": [
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CURATIVOS-E-ACONDICIONAMENTO-DE-ESPECIMES",
            "context": {
              "moduleId": "M25",
              "moduleTitle": "Dermatologia"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P1"
        ],
        "lessonRelations": [
          {
            "id": "REL-M25-perioperatorio-admissao-verificacao",
            "lessonId": "perioperatorio-admissao-verificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M25-perioperatorio-transferencia-monitorizacao",
            "lessonId": "perioperatorio-transferencia-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M25-perioperatorio-puncoes-biopsias",
            "lessonId": "perioperatorio-puncoes-biopsias",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M25-perioperatorio-feridas-curativos-estomas",
            "lessonId": "perioperatorio-feridas-curativos-estomas",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M25-07"
            ]
          },
          {
            "id": "REL-M25-perioperatorio-transporte-handoff",
            "lessonId": "perioperatorio-transporte-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M26",
        "order": 26,
        "title": "Cuidados pós-operatórios",
        "priority": "P0",
        "categoryId": "procedimentos-fundamentais",
        "coverage": "Base existente",
        "existingModuleIds": [
          "anestesia-srpa",
          "prevencao-isc",
          "cirurgia-geral-digestiva",
          "procedimentos-perioperatorios"
        ],
        "existingLessonIds": [
          "anestesia-fases-seguranca",
          "srpa-transferencia-vigilancia",
          "anestesia-alarmes-interface",
          "isc-preparo-preoperatorio",
          "isc-intra-posoperatorio",
          "geral-mapa-abdominal",
          "geral-recuperacao-integrada",
          "geral-transicoes-contaminacao",
          "geral-dispositivos-handoff",
          "perioperatorio-admissao-verificacao",
          "perioperatorio-transferencia-monitorizacao",
          "perioperatorio-puncoes-biopsias",
          "perioperatorio-feridas-curativos-estomas",
          "perioperatorio-transporte-handoff"
        ],
        "topics": [
          {
            "id": "PT-M26-01",
            "title": "Vigilância na SRPA",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIGILANCIA-NA-SRPA",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-02",
            "title": "Avaliação e controle da dor",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-AVALIACAO-E-CONTROLE-DA-DOR",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-03",
            "title": "Náuseas e vômitos pós-operatórios",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-NAUSEAS-E-VOMITOS-POS-OPERATORIOS",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-04",
            "title": "Reconhecimento de hemorragia",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RECONHECIMENTO-DE-HEMORRAGIA",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-05",
            "title": "Vigilância de infecção",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-VIGILANCIA-DE-INFECCAO",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-06",
            "title": "Tromboprofilaxia",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TROMBOPROFILAXIA",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-07",
            "title": "Curativos pós-operatórios",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CURATIVOS-POS-OPERATORIOS",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-08",
            "title": "Manejo de drenos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-MANEJO-DE-DRENOS",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-09",
            "title": "Retirada planejada de dispositivos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RETIRADA-PLANEJADA-DE-DISPOSITIVOS",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M26-10",
            "title": "Critérios e orientações de alta",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CRITERIOS-E-ORIENTACOES-DE-ALTA",
            "context": {
              "moduleId": "M26",
              "moduleTitle": "Cuidados pós-operatórios"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M26-anestesia-fases-seguranca",
            "lessonId": "anestesia-fases-seguranca",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-srpa-transferencia-vigilancia",
            "lessonId": "srpa-transferencia-vigilancia",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M26-01",
              "PT-M26-05"
            ]
          },
          {
            "id": "REL-M26-anestesia-alarmes-interface",
            "lessonId": "anestesia-alarmes-interface",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-isc-preparo-preoperatorio",
            "lessonId": "isc-preparo-preoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-isc-intra-posoperatorio",
            "lessonId": "isc-intra-posoperatorio",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-geral-mapa-abdominal",
            "lessonId": "geral-mapa-abdominal",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-geral-recuperacao-integrada",
            "lessonId": "geral-recuperacao-integrada",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-geral-transicoes-contaminacao",
            "lessonId": "geral-transicoes-contaminacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-geral-dispositivos-handoff",
            "lessonId": "geral-dispositivos-handoff",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M26-08",
              "PT-M26-09"
            ]
          },
          {
            "id": "REL-M26-perioperatorio-admissao-verificacao",
            "lessonId": "perioperatorio-admissao-verificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-perioperatorio-transferencia-monitorizacao",
            "lessonId": "perioperatorio-transferencia-monitorizacao",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M26-09"
            ]
          },
          {
            "id": "REL-M26-perioperatorio-puncoes-biopsias",
            "lessonId": "perioperatorio-puncoes-biopsias",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M26-perioperatorio-feridas-curativos-estomas",
            "lessonId": "perioperatorio-feridas-curativos-estomas",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M26-07"
            ]
          },
          {
            "id": "REL-M26-perioperatorio-transporte-handoff",
            "lessonId": "perioperatorio-transporte-handoff",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M26-09"
            ]
          }
        ]
      },
      {
        "id": "M27",
        "order": 27,
        "title": "Diagnóstico à beira-leito",
        "priority": "P0–P1",
        "categoryId": "procedimentos-fundamentais",
        "coverage": "Lacuna prioritária",
        "existingModuleIds": [
          "procedimentos-perioperatorios",
          "acessos-vasculares-infusao"
        ],
        "existingLessonIds": [
          "perioperatorio-admissao-verificacao",
          "perioperatorio-transferencia-monitorizacao",
          "perioperatorio-puncoes-biopsias",
          "perioperatorio-feridas-curativos-estomas",
          "perioperatorio-transporte-handoff",
          "vascular-mapa-dispositivos",
          "vascular-periferico",
          "vascular-central",
          "vascular-arterial",
          "vascular-intraosseo-emergencia",
          "vascular-manutencao-complicacoes"
        ],
        "topics": [
          {
            "id": "PT-M27-01",
            "title": "Glicemia capilar",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-GLICEMIA-CAPILAR",
            "context": {
              "moduleId": "M27",
              "moduleTitle": "Diagnóstico à beira-leito"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M27-02",
            "title": "Eletrocardiograma à beira-leito",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "ECG",
              "eletrocardiograma bedside",
              "ECG bedside"
            ],
            "canonicalProcedureId": "PROC-ELETROCARDIOGRAMA-A-BEIRA-LEITO",
            "context": {
              "moduleId": "M27",
              "moduleTitle": "Diagnóstico à beira-leito"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M27-03",
            "title": "Ultrassom point-of-care",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-ULTRASSOM-POINT-OF-CARE",
            "context": {
              "moduleId": "M27",
              "moduleTitle": "Diagnóstico à beira-leito"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M27-04",
            "title": "Coleta de amostras biológicas",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-COLETA-DE-AMOSTRAS-BIOLOGICAS",
            "context": {
              "moduleId": "M27",
              "moduleTitle": "Diagnóstico à beira-leito"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M27-05",
            "title": "Punções diagnósticas supervisionadas",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PUNCOES-DIAGNOSTICAS-SUPERVISIONADAS",
            "context": {
              "moduleId": "M27",
              "moduleTitle": "Diagnóstico à beira-leito"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M27-06",
            "title": "Punção capilar",
            "status": "catalogado",
            "priorityLevels": [
              "P0",
              "P1"
            ],
            "aliases": [
              "puncao capilar",
              "glicemia ponta de dedo",
              "fingerstick",
              "punción capilar"
            ],
            "canonicalProcedureId": "PROC-PUNCAO-CAPILAR",
            "context": {
              "moduleId": "M27",
              "moduleTitle": "Diagnóstico à beira-leito"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0",
          "P1"
        ],
        "lessonRelations": [
          {
            "id": "REL-M27-perioperatorio-admissao-verificacao",
            "lessonId": "perioperatorio-admissao-verificacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-perioperatorio-transferencia-monitorizacao",
            "lessonId": "perioperatorio-transferencia-monitorizacao",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-perioperatorio-puncoes-biopsias",
            "lessonId": "perioperatorio-puncoes-biopsias",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M27-05"
            ]
          },
          {
            "id": "REL-M27-perioperatorio-feridas-curativos-estomas",
            "lessonId": "perioperatorio-feridas-curativos-estomas",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-perioperatorio-transporte-handoff",
            "lessonId": "perioperatorio-transporte-handoff",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-vascular-mapa-dispositivos",
            "lessonId": "vascular-mapa-dispositivos",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-vascular-periferico",
            "lessonId": "vascular-periferico",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-vascular-central",
            "lessonId": "vascular-central",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-vascular-arterial",
            "lessonId": "vascular-arterial",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-vascular-intraosseo-emergencia",
            "lessonId": "vascular-intraosseo-emergencia",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M27-vascular-manutencao-complicacoes",
            "lessonId": "vascular-manutencao-complicacoes",
            "relationType": "fundamento",
            "targetTopicIds": []
          }
        ]
      },
      {
        "id": "M28",
        "order": 28,
        "title": "Documentação e comunicação",
        "priority": "P0",
        "categoryId": "fundamentos",
        "coverage": "Base existente",
        "existingModuleIds": [
          "documentacao-etica-privacidade",
          "cirurgia-segura",
          "fluxo-procedimentos"
        ],
        "existingLessonIds": [
          "registro-perioperatorio-qualidade",
          "privacidade-dados-saude",
          "documentacao-linha-tempo",
          "checklist-tres-momentos",
          "comunicacao-fatores-humanos",
          "tempos-operatorios",
          "encerramento-seguro"
        ],
        "topics": [
          {
            "id": "PT-M28-01",
            "title": "Consentimento informado",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-CONSENTIMENTO-INFORMADO",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-02",
            "title": "Evolução clínica",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-EVOLUCAO-CLINICA",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-03",
            "title": "Descrição de procedimentos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-DESCRICAO-DE-PROCEDIMENTOS",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-04",
            "title": "Rastreabilidade de materiais",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-RASTREABILIDADE-DE-MATERIAIS",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-05",
            "title": "Identificação de amostras e dispositivos",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-IDENTIFICACAO-DE-AMOSTRAS-E-DISPOSITIVOS",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-06",
            "title": "Transferência do cuidado",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-TRANSFERENCIA-DO-CUIDADO",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-07",
            "title": "Passagem de plantão estruturada",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PASSAGEM-DE-PLANTAO-ESTRUTURADA",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          },
          {
            "id": "PT-M28-08",
            "title": "Privacidade e proteção de dados",
            "status": "catalogado",
            "priorityLevels": [
              "P0"
            ],
            "aliases": [],
            "canonicalProcedureId": "PROC-PRIVACIDADE-E-PROTECAO-DE-DADOS",
            "context": {
              "moduleId": "M28",
              "moduleTitle": "Documentação e comunicação"
            },
            "revision": {
              "version": "0.1",
              "state": "pendente",
              "reviewedOn": null,
              "reviewer": null
            }
          }
        ],
        "priorityLevels": [
          "P0"
        ],
        "lessonRelations": [
          {
            "id": "REL-M28-registro-perioperatorio-qualidade",
            "lessonId": "registro-perioperatorio-qualidade",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M28-privacidade-dados-saude",
            "lessonId": "privacidade-dados-saude",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M28-08"
            ]
          },
          {
            "id": "REL-M28-documentacao-linha-tempo",
            "lessonId": "documentacao-linha-tempo",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M28-04"
            ]
          },
          {
            "id": "REL-M28-checklist-tres-momentos",
            "lessonId": "checklist-tres-momentos",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M28-comunicacao-fatores-humanos",
            "lessonId": "comunicacao-fatores-humanos",
            "relationType": "pre-requisito",
            "targetTopicIds": []
          },
          {
            "id": "REL-M28-tempos-operatorios",
            "lessonId": "tempos-operatorios",
            "relationType": "fundamento",
            "targetTopicIds": []
          },
          {
            "id": "REL-M28-encerramento-seguro",
            "lessonId": "encerramento-seguro",
            "relationType": "cobertura-direta",
            "targetTopicIds": [
              "PT-M28-05"
            ]
          }
        ]
      }
    ],
    "macroblocks": [
      {
        "id": "MB01",
        "title": "Arquitetura curricular",
        "status": "Entregue",
        "description": "Arquitetura corrigida com status por tópico, prioridades inclusivas, relações tipadas, aliases e procedimentos canônicos."
      },
      {
        "id": "MB02",
        "title": "Atlas de materiais",
        "status": "Entregue",
        "description": "Atlas extensível com materiais, variantes, escalas, procedimentos, fontes, compatibilidades e visuais próprios."
      },
      {
        "id": "MB03",
        "title": "Procedimentos fundamentais",
        "status": "Próximo",
        "description": "Acessos, coletas, administração, feridas, curativos, suturas e imobilizações."
      },
      {
        "id": "MB04",
        "title": "Cirurgia e anestesia",
        "status": "Planejado",
        "description": "Fluxos completos do pré-operatório à recuperação pós-anestésica."
      },
      {
        "id": "MB05",
        "title": "Urgência e especialidades",
        "status": "Planejado",
        "description": "Via aérea, emergências, sondagens, drenagens, pediatria e especialidades."
      },
      {
        "id": "MB06",
        "title": "Videoteca vinculada",
        "status": "Planejado",
        "description": "Vídeos por procedimento com autoria, revisão, finalidade e conformidade."
      },
      {
        "id": "MB07",
        "title": "Avaliação prática",
        "status": "Planejado",
        "description": "Checklists de simulação, sequenciamento de etapas e erros críticos."
      },
      {
        "id": "MB08",
        "title": "Revisão e publicação",
        "status": "Planejado",
        "description": "Revisão clínica, acessibilidade, testes, piloto, versão e aprovação."
      }
    ],
    "canonicalProcedures": [
      {
        "id": "PROC-HIGIENIZACAO-DAS-MAOS",
        "preferredTitle": "Higienização das mãos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-01",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-EQUIPAMENTOS-DE-PROTECAO-INDIVIDUAL",
        "preferredTitle": "Equipamentos de proteção individual",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-02",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-PARAMENTACAO-CIRURGICA",
        "preferredTitle": "Paramentação cirúrgica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-03",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-CALCAMENTO-DE-LUVAS-ESTEREIS",
        "preferredTitle": "Calçamento de luvas estéreis",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-04",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-CAMPOS-ESTEREIS",
        "preferredTitle": "Campos estéreis",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-05",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-ASSEPSIA-E-ANTISSEPSIA",
        "preferredTitle": "Assepsia e antissepsia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-06",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-SEGURANCA-COM-PERFUROCORTANTES",
        "preferredTitle": "Segurança com perfurocortantes",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-07",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-DESCARTE-DE-RESIDUOS-ASSISTENCIAIS",
        "preferredTitle": "Descarte de resíduos assistenciais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M01-08",
            "moduleId": "M01",
            "label": "Biossegurança"
          }
        ]
      },
      {
        "id": "PROC-PINCAS-DE-PREENSAO",
        "preferredTitle": "Pinças de preensão",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-01",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-PINCAS-HEMOSTATICAS",
        "preferredTitle": "Pinças hemostáticas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-02",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-PINCAS-DE-DISSECCAO",
        "preferredTitle": "Pinças de dissecção",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-03",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-AFASTADORES",
        "preferredTitle": "Afastadores",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-04",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-TESOURAS-CIRURGICAS",
        "preferredTitle": "Tesouras cirúrgicas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-05",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-BISTURIS-CABOS-E-LAMINAS",
        "preferredTitle": "Bisturis, cabos e lâminas",
        "aliases": [
          "bisturi",
          "lamina 15",
          "lâmina 15",
          "scalpel"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-06",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-PORTA-AGULHAS",
        "preferredTitle": "Porta-agulhas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-07",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-MONTAGEM-DA-MESA-CIRURGICA",
        "preferredTitle": "Montagem da mesa cirúrgica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-08",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-PASSAGEM-DE-INSTRUMENTAIS",
        "preferredTitle": "Passagem de instrumentais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-09",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-INTEGRIDADE-E-TESTE-FUNCIONAL",
        "preferredTitle": "Integridade e teste funcional",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M02-10",
            "moduleId": "M02",
            "label": "Instrumentação cirúrgica"
          }
        ]
      },
      {
        "id": "PROC-ESCALAS-GAUGE-FRENCH-USP-E-MILIMETROS",
        "preferredTitle": "Escalas Gauge, French, USP e milímetros",
        "aliases": [
          "Ch",
          "Charrière",
          "Fr",
          "French",
          "G",
          "Gauge",
          "USP",
          "calibre"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-01",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-AGULHAS-HIPODERMICAS",
        "preferredTitle": "Agulhas hipodérmicas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-02",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-DISPOSITIVO-ALADO-TIPO-SCALP",
        "preferredTitle": "Dispositivo alado tipo scalp",
        "aliases": [
          "agulha borboleta",
          "butterfly needle",
          "scalp"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-03",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-CATETER-INTRAVENOSO-PERIFERICO",
        "preferredTitle": "Cateter intravenoso periférico",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-04",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-SERINGAS-E-GRADUACOES",
        "preferredTitle": "Seringas e graduações",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-05",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-CONECTORES-SEM-AGULHA",
        "preferredTitle": "Conectores sem agulha",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-06",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-EQUIPOS-DE-INFUSAO",
        "preferredTitle": "Equipos de infusão",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-07",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-EXTENSORES",
        "preferredTitle": "Extensores",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-08",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-TORNEIRAS-DE-TRES-VIAS",
        "preferredTitle": "Torneiras de três vias",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-09",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-COMPATIBILIDADE-ENTRE-DISPOSITIVOS",
        "preferredTitle": "Compatibilidade entre dispositivos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M03-10",
            "moduleId": "M03",
            "label": "Agulhas, seringas e dispositivos"
          }
        ]
      },
      {
        "id": "PROC-VIA-ORAL",
        "preferredTitle": "Via oral",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-01",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-VIA-SUBLINGUAL",
        "preferredTitle": "Via sublingual",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-02",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-VIA-INTRADERMICA",
        "preferredTitle": "Via intradérmica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-03",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-VIA-SUBCUTANEA",
        "preferredTitle": "Via subcutânea",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-04",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-VIA-INTRAMUSCULAR",
        "preferredTitle": "Via intramuscular",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-05",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-VIA-INTRAVENOSA",
        "preferredTitle": "Via intravenosa",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-06",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-INFUSAO-INTERMITENTE-E-CONTINUA",
        "preferredTitle": "Infusão intermitente e contínua",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-07",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-RECONSTITUICAO-E-DILUICAO",
        "preferredTitle": "Reconstituição e diluição",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-08",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-BOMBAS-DE-INFUSAO",
        "preferredTitle": "Bombas de infusão",
        "aliases": [
          "bomba infusora",
          "infusion pump"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-09",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-BARREIRAS-PARA-MEDICAMENTOS-DE-ALTA-VIGILANCIA",
        "preferredTitle": "Barreiras para medicamentos de alta vigilância",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M04-10",
            "moduleId": "M04",
            "label": "Administração de medicamentos"
          }
        ]
      },
      {
        "id": "PROC-ACESSO-VENOSO-PERIFERICO",
        "preferredTitle": "Acesso venoso periférico",
        "aliases": [
          "CIVP",
          "IV",
          "PIVC",
          "abocath",
          "cateter IV",
          "cateter intravenoso periférico",
          "cateter periférico",
          "cânula intravenosa",
          "jelco",
          "venopunción",
          "venopunção"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-01",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-COLETA-DE-SANGUE-VENOSO",
        "preferredTitle": "Coleta de sangue venoso",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-02",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-COLETA-PARA-HEMOCULTURA",
        "preferredTitle": "Coleta para hemocultura",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-03",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-CATETER-VENOSO-CENTRAL",
        "preferredTitle": "Cateter venoso central",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-04",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-CATETER-CENTRAL-DE-INSERCAO-PERIFERICA-PICC",
        "preferredTitle": "Cateter central de inserção periférica — PICC",
        "aliases": [
          "PICC",
          "cateter PICC",
          "cateter central de inserção periférica",
          "peripherally inserted central catheter"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-05",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-LINHA-ARTERIAL",
        "preferredTitle": "Linha arterial",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-06",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-ACESSO-INTRAOSSEO",
        "preferredTitle": "Acesso intraósseo",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-07",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-MANUTENCAO-E-COMPLICACOES-DE-ACESSOS",
        "preferredTitle": "Manutenção e complicações de acessos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M05-08",
            "moduleId": "M05",
            "label": "Acessos vasculares"
          }
        ]
      },
      {
        "id": "PROC-AVALIACAO-ESTRUTURADA-DA-FERIDA",
        "preferredTitle": "Avaliação estruturada da ferida",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-01",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-HEMOSTASIA-INICIAL",
        "preferredTitle": "Hemostasia inicial",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-02",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-IRRIGACAO-DE-FERIDA",
        "preferredTitle": "Irrigação de ferida",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-03",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-LIMPEZA-E-REMOCAO-DE-CONTAMINANTES",
        "preferredTitle": "Limpeza e remoção de contaminantes",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-04",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-DESBRIDAMENTO-EM-AMBIENTE-HABILITADO",
        "preferredTitle": "Desbridamento em ambiente habilitado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-05",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-CLASSIFICACAO-DE-FERIDAS",
        "preferredTitle": "Classificação de feridas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-06",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-SELECAO-E-TROCA-DE-CURATIVOS",
        "preferredTitle": "Seleção e troca de curativos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-07",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-RECONHECIMENTO-DE-INFECCAO",
        "preferredTitle": "Reconhecimento de infecção",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-08",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-MORDEDURAS-DE-ANIMAIS-E-HUMANAS",
        "preferredTitle": "Mordeduras de animais e humanas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-09",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-CUIDADOS-POSTERIORES-E-RETORNO",
        "preferredTitle": "Cuidados posteriores e retorno",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M06-10",
            "moduleId": "M06",
            "label": "Feridas e lesões"
          }
        ]
      },
      {
        "id": "PROC-FIOS-ABSORVIVEIS-E-NAO-ABSORVIVEIS",
        "preferredTitle": "Fios absorvíveis e não absorvíveis",
        "aliases": [
          "fio de sutura",
          "nylon",
          "poliglactina",
          "suture",
          "vicryl"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-01",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-AGULHAS-CILINDRICAS-E-CORTANTES",
        "preferredTitle": "Agulhas cilíndricas e cortantes",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-02",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-SUTURA-SIMPLES-INTERROMPIDA",
        "preferredTitle": "Sutura simples interrompida",
        "aliases": [
          "ponto interrompido",
          "ponto simples",
          "simple interrupted suture",
          "sutura simples"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-03",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-SUTURA-CONTINUA",
        "preferredTitle": "Sutura contínua",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-04",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-COLCHOEIRO-VERTICAL",
        "preferredTitle": "Colchoeiro vertical",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-05",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-COLCHOEIRO-HORIZONTAL",
        "preferredTitle": "Colchoeiro horizontal",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-06",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-SUTURA-INTRADERMICA",
        "preferredTitle": "Sutura intradérmica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-07",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-FECHAMENTO-DERMICO-PROFUNDO",
        "preferredTitle": "Fechamento dérmico profundo",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-08",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-ADESIVOS-CUTANEOS",
        "preferredTitle": "Adesivos cutâneos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-09",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-GRAMPOS-CUTANEOS",
        "preferredTitle": "Grampos cutâneos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-10",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-RETIRADA-DE-PONTOS-E-GRAMPOS",
        "preferredTitle": "Retirada de pontos e grampos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M07-11",
            "moduleId": "M07",
            "label": "Suturas e fechamento"
          }
        ]
      },
      {
        "id": "PROC-ANESTESIA-TOPICA",
        "preferredTitle": "Anestesia tópica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-01",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-ANESTESIA-INFILTRATIVA",
        "preferredTitle": "Anestesia infiltrativa",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-02",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-BLOQUEIOS-PERIFERICOS",
        "preferredTitle": "Bloqueios periféricos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-03",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-SEDACAO-PROCEDIMENTAL",
        "preferredTitle": "Sedação procedimental",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-04",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-RAQUIANESTESIA",
        "preferredTitle": "Raquianestesia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-05",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-ANESTESIA-PERIDURAL",
        "preferredTitle": "Anestesia peridural",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-06",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-ANESTESIA-GERAL",
        "preferredTitle": "Anestesia geral",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-07",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-EQUIPAMENTO-E-CIRCUITOS-DE-ANESTESIA",
        "preferredTitle": "Equipamento e circuitos de anestesia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-08",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-TOXICIDADE-SISTEMICA-POR-ANESTESICOS-LOCAIS",
        "preferredTitle": "Toxicidade sistêmica por anestésicos locais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-09",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-RECUPERACAO-POS-ANESTESICA",
        "preferredTitle": "Recuperação pós-anestésica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M08-10",
            "moduleId": "M08",
            "label": "Anestesia e analgesia"
          }
        ]
      },
      {
        "id": "PROC-AVALIACAO-PRE-OPERATORIA",
        "preferredTitle": "Avaliação pré-operatória",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-01",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-JEJUM-INDIVIDUALIZADO",
        "preferredTitle": "Jejum individualizado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-02",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-EXAMES-PRE-OPERATORIOS-INDICADOS",
        "preferredTitle": "Exames pré-operatórios indicados",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-03",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-CONSENTIMENTO-E-LATERALIDADE",
        "preferredTitle": "Consentimento e lateralidade",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-04",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-PROFILAXIA-ANTIMICROBIANA",
        "preferredTitle": "Profilaxia antimicrobiana",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-05",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-PREVENCAO-TROMBOEMBOLICA",
        "preferredTitle": "Prevenção tromboembólica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-06",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-BANHO-E-MANEJO-DE-PELOS",
        "preferredTitle": "Banho e manejo de pelos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-07",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-PREPARO-ANTISSEPTICO-DA-PELE",
        "preferredTitle": "Preparo antisséptico da pele",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-08",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-MARCACAO-DO-SITIO",
        "preferredTitle": "Marcação do sítio",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-09",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-POSICIONAMENTO-SEGURO",
        "preferredTitle": "Posicionamento seguro",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-10",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-LISTA-DE-VERIFICACAO-DE-CIRURGIA-SEGURA",
        "preferredTitle": "Lista de verificação de cirurgia segura",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M09-11",
            "moduleId": "M09",
            "label": "Preparo cirúrgico"
          }
        ]
      },
      {
        "id": "PROC-CANULA-NASAL",
        "preferredTitle": "Cânula nasal",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-01",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-MASCARAS-SIMPLES-VENTURI-E-COM-RESERVATORIO",
        "preferredTitle": "Máscaras simples, Venturi e com reservatório",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-02",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-VENTILACAO-COM-BOLSA-VALVULA-MASCARA",
        "preferredTitle": "Ventilação com bolsa-válvula-máscara",
        "aliases": [
          "BVM",
          "ambu",
          "bolsa autoinflável"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-03",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-DISPOSITIVOS-SUPRAGLOTICOS",
        "preferredTitle": "Dispositivos supraglóticos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-04",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-INTUBACAO-TRAQUEAL",
        "preferredTitle": "Assistência à intubação traqueal",
        "aliases": [
          "ETT",
          "IOT",
          "intubacion",
          "intubação",
          "tubo endotraqueal"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-05",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-VENTILACAO-MECANICA",
        "preferredTitle": "Ventilação mecânica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-06",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-VIA-AEREA-DIFICIL",
        "preferredTitle": "Via aérea difícil",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-07",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-CRICOTIREOIDOSTOMIA-EM-CONTEXTO-DE-EMERGENCIA",
        "preferredTitle": "Cricotireoidostomia em contexto de emergência",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-08",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-EXTUBACAO-E-VIGILANCIA",
        "preferredTitle": "Extubação e vigilância",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M10-09",
            "moduleId": "M10",
            "label": "Via aérea e oxigenoterapia"
          }
        ]
      },
      {
        "id": "PROC-ASPIRACAO-DE-VIAS-AEREAS",
        "preferredTitle": "Aspiração de vias aéreas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M11-01",
            "moduleId": "M11",
            "label": "Procedimentos respiratórios"
          }
        ]
      },
      {
        "id": "PROC-NEBULIZACAO",
        "preferredTitle": "Nebulização",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M11-02",
            "moduleId": "M11",
            "label": "Procedimentos respiratórios"
          }
        ]
      },
      {
        "id": "PROC-GASOMETRIA-ARTERIAL",
        "preferredTitle": "Gasometria arterial",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M11-03",
            "moduleId": "M11",
            "label": "Procedimentos respiratórios"
          }
        ]
      },
      {
        "id": "PROC-TORACOCENTESE",
        "preferredTitle": "Toracocentese",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M11-04",
            "moduleId": "M11",
            "label": "Procedimentos respiratórios"
          }
        ]
      },
      {
        "id": "PROC-DRENAGEM-TORACICA",
        "preferredTitle": "Drenagem torácica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M11-05",
            "moduleId": "M11",
            "label": "Procedimentos respiratórios"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-TRAQUEOSTOMIA",
        "preferredTitle": "Assistência à traqueostomia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M11-06",
            "moduleId": "M11",
            "label": "Procedimentos respiratórios"
          }
        ]
      },
      {
        "id": "PROC-RESSUSCITACAO-CARDIOPULMONAR",
        "preferredTitle": "Ressuscitação cardiopulmonar",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-01",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-USO-DO-DESFIBRILADOR-EXTERNO-AUTOMATICO",
        "preferredTitle": "Uso do desfibrilador externo automático",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-02",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-DESFIBRILACAO-MANUAL",
        "preferredTitle": "Desfibrilação manual",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-03",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-CARDIOVERSAO-SINCRONIZADA",
        "preferredTitle": "Cardioversão sincronizada",
        "aliases": [
          "cardioversao",
          "choque sincronizado",
          "synchronized cardioversion"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-04",
            "moduleId": "M12",
            "label": "Emergências"
          },
          {
            "topicId": "PT-M20-03",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-ACESSO-VASCULAR-DE-EMERGENCIA",
        "preferredTitle": "Acesso vascular de emergência",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-05",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-CONTROLE-DE-HEMORRAGIAS",
        "preferredTitle": "Controle de hemorragias",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-06",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-APLICACAO-E-VIGILANCIA-DE-TORNIQUETE",
        "preferredTitle": "Aplicação e vigilância de torniquete",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-07",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-ESTABILIZACAO-INICIAL-NO-TRAUMA",
        "preferredTitle": "Estabilização inicial no trauma",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-08",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-COMUNICACAO-E-LIDERANCA-EM-CRISE",
        "preferredTitle": "Comunicação e liderança em crise",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M12-09",
            "moduleId": "M12",
            "label": "Emergências"
          }
        ]
      },
      {
        "id": "PROC-TIPOIA",
        "preferredTitle": "Tipóia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-01",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-TALA-ANTEBRAQUIOPALMAR",
        "preferredTitle": "Tala antebraquiopalmar",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-02",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-TALA-TIPO-SUGAR-TONG",
        "preferredTitle": "Tala tipo sugar-tong",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-03",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-TALA-TIPO-U",
        "preferredTitle": "Tala tipo U",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-04",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-TALA-POSTERIOR-DE-MEMBRO-INFERIOR",
        "preferredTitle": "Tala posterior de membro inferior",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-05",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-GESSO-CIRCULAR",
        "preferredTitle": "Gesso circular",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-06",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-IMOBILIZACAO-DO-POLEGAR-THUMB-SPICA",
        "preferredTitle": "Imobilização do polegar — thumb spica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-07",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-IMOBILIZACAO-DE-DEDOS-E-BUDDY-TAPING",
        "preferredTitle": "Imobilização de dedos e buddy taping",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-08",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-COLAR-CERVICAL-EM-INDICACOES-SELECIONADAS",
        "preferredTitle": "Colar cervical em indicações selecionadas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-09",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-AVALIACAO-NEUROVASCULAR-ANTES-E-DEPOIS",
        "preferredTitle": "Avaliação neurovascular antes e depois",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-10",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-RECONHECIMENTO-DE-SINDROME-COMPARTIMENTAL",
        "preferredTitle": "Reconhecimento de síndrome compartimental",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M13-11",
            "moduleId": "M13",
            "label": "Ortopedia e imobilização"
          }
        ]
      },
      {
        "id": "PROC-CATETERISMO-VESICAL-DE-ALIVIO",
        "preferredTitle": "Cateterismo vesical de alívio",
        "aliases": [
          "Nelaton",
          "cateter urinário intermitente",
          "sonda Nelaton"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-01",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          }
        ]
      },
      {
        "id": "PROC-CATETERISMO-VESICAL-DE-DEMORA",
        "preferredTitle": "Cateterismo vesical de demora",
        "aliases": [
          "Foley",
          "SVD",
          "cateter urinário de demora",
          "sonda Foley"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-02",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          }
        ]
      },
      {
        "id": "PROC-IRRIGACAO-VESICAL",
        "preferredTitle": "Irrigação vesical",
        "aliases": [
          "bladder irrigation",
          "irrigacao da bexiga",
          "lavagem vesical"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-03",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          },
          {
            "topicId": "PT-M22-02",
            "moduleId": "M22",
            "label": "Urologia"
          }
        ]
      },
      {
        "id": "PROC-SONDA-NASOGASTRICA",
        "preferredTitle": "Sonda nasogástrica",
        "aliases": [
          "NG tube",
          "SNG",
          "sonda gástrica"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-04",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          }
        ]
      },
      {
        "id": "PROC-SONDA-NASOENTERAL",
        "preferredTitle": "Sonda nasoenteral",
        "aliases": [
          "SNE",
          "enteral tube",
          "sonda enteral"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-05",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          }
        ]
      },
      {
        "id": "PROC-GASTROSTOMIA",
        "preferredTitle": "Gastrostomia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-06",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          }
        ]
      },
      {
        "id": "PROC-CUIDADOS-COM-OSTOMIAS",
        "preferredTitle": "Cuidados com ostomias",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M14-07",
            "moduleId": "M14",
            "label": "Sondas e cateteres"
          }
        ]
      },
      {
        "id": "PROC-DRENAGEM-DE-ABSCESSO-EM-AMBIENTE-HABILITADO",
        "preferredTitle": "Drenagem de abscesso em ambiente habilitado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M15-01",
            "moduleId": "M15",
            "label": "Procedimentos ambulatoriais"
          }
        ]
      },
      {
        "id": "PROC-RETIRADA-DE-CORPO-ESTRANHO-SUPERFICIAL",
        "preferredTitle": "Retirada de corpo estranho superficial",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M15-02",
            "moduleId": "M15",
            "label": "Procedimentos ambulatoriais"
          }
        ]
      },
      {
        "id": "PROC-BIOPSIAS-AMBULATORIAIS",
        "preferredTitle": "Biópsias ambulatoriais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M15-03",
            "moduleId": "M15",
            "label": "Procedimentos ambulatoriais"
          }
        ]
      },
      {
        "id": "PROC-PROCEDIMENTOS-UNGUEAIS",
        "preferredTitle": "Procedimentos ungueais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M15-04",
            "moduleId": "M15",
            "label": "Procedimentos ambulatoriais"
          }
        ]
      },
      {
        "id": "PROC-TRATAMENTO-INICIAL-DE-QUEIMADURAS",
        "preferredTitle": "Tratamento inicial de queimaduras",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M15-05",
            "moduleId": "M15",
            "label": "Procedimentos ambulatoriais"
          }
        ]
      },
      {
        "id": "PROC-INCISOES-E-VIAS-DE-ACESSO",
        "preferredTitle": "Incisões e vias de acesso",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-01",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-DISSECCAO-POR-PLANOS",
        "preferredTitle": "Dissecção por planos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-02",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-HEMOSTASIA-E-LIGADURAS",
        "preferredTitle": "Hemostasia e ligaduras",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-03",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-LAPAROTOMIA",
        "preferredTitle": "Laparotomia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-04",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-LAPAROSCOPIA",
        "preferredTitle": "Laparoscopia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-05",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-FECHAMENTO-POR-PLANOS",
        "preferredTitle": "Fechamento por planos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-06",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-DRENOS-CIRURGICOS",
        "preferredTitle": "Drenos cirúrgicos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-07",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-CONVERSAO-E-ENCERRAMENTO-SEGURO",
        "preferredTitle": "Conversão e encerramento seguro",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M16-08",
            "moduleId": "M16",
            "label": "Cirurgia geral"
          }
        ]
      },
      {
        "id": "PROC-EXAME-ESPECULAR",
        "preferredTitle": "Exame especular",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-01",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-COLETA-CERVICAL",
        "preferredTitle": "Coleta cervical",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-02",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-PROCEDIMENTOS-UTERINOS",
        "preferredTitle": "Procedimentos uterinos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-03",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-DISPOSITIVO-INTRAUTERINO",
        "preferredTitle": "Dispositivo intrauterino",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-04",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-AO-PARTO",
        "preferredTitle": "Assistência ao parto",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-05",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-EPISIOTOMIA-E-EPISIORRAFIA",
        "preferredTitle": "Episiotomia e episiorrafia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-06",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-URGENCIAS-OBSTETRICAS",
        "preferredTitle": "Urgências obstétricas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-07",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-FLUXO-SEGURO-NA-CESARIANA",
        "preferredTitle": "Fluxo seguro na cesariana",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M17-08",
            "moduleId": "M17",
            "label": "Ginecologia e obstetrícia"
          }
        ]
      },
      {
        "id": "PROC-ACESSOS-VASCULARES-PEDIATRICOS",
        "preferredTitle": "Acessos vasculares pediátricos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-01",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          }
        ]
      },
      {
        "id": "PROC-PUNCAO-CAPILAR",
        "preferredTitle": "Punção capilar",
        "aliases": [
          "fingerstick",
          "glicemia ponta de dedo",
          "puncao capilar",
          "punción capilar"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-02",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          },
          {
            "topicId": "PT-M27-06",
            "moduleId": "M27",
            "label": "Diagnóstico à beira-leito"
          }
        ]
      },
      {
        "id": "PROC-DISPOSITIVOS-NEONATAIS",
        "preferredTitle": "Dispositivos neonatais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-03",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          }
        ]
      },
      {
        "id": "PROC-VIAS-DE-ADMINISTRACAO-PEDIATRICA",
        "preferredTitle": "Vias de administração pediátrica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-04",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          }
        ]
      },
      {
        "id": "PROC-REANIMACAO-NEONATAL",
        "preferredTitle": "Reanimação neonatal",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-05",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          }
        ]
      },
      {
        "id": "PROC-DISPOSITIVOS-PEDIATRICOS-DE-OXIGENIO",
        "preferredTitle": "Dispositivos pediátricos de oxigênio",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-06",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          }
        ]
      },
      {
        "id": "PROC-TERMORREGULACAO-E-TRANSPORTE-NEONATAL",
        "preferredTitle": "Termorregulação e transporte neonatal",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M18-07",
            "moduleId": "M18",
            "label": "Pediatria e neonatologia"
          }
        ]
      },
      {
        "id": "PROC-PUNCAO-LOMBAR-EM-AMBIENTE-SUPERVISIONADO",
        "preferredTitle": "Punção lombar em ambiente supervisionado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M19-01",
            "moduleId": "M19",
            "label": "Neurologia"
          }
        ]
      },
      {
        "id": "PROC-COLETA-E-AVALIACAO-INICIAL-DO-LIQUOR",
        "preferredTitle": "Coleta e avaliação inicial do líquor",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M19-02",
            "moduleId": "M19",
            "label": "Neurologia"
          }
        ]
      },
      {
        "id": "PROC-MONITORIZACAO-DA-PRESSAO-INTRACRANIANA",
        "preferredTitle": "Monitorização da pressão intracraniana",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M19-03",
            "moduleId": "M19",
            "label": "Neurologia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-PROCEDIMENTOS-NEUROCIRURGICOS",
        "preferredTitle": "Assistência a procedimentos neurocirúrgicos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M19-04",
            "moduleId": "M19",
            "label": "Neurologia"
          }
        ]
      },
      {
        "id": "PROC-NAVEGACAO-E-NEUROMONITORIZACAO",
        "preferredTitle": "Navegação e neuromonitorização",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M19-05",
            "moduleId": "M19",
            "label": "Neurologia"
          }
        ]
      },
      {
        "id": "PROC-ELETROCARDIOGRAMA-DE-12-DERIVACOES",
        "preferredTitle": "Eletrocardiograma de 12 derivações",
        "aliases": [
          "ECG",
          "ECG 12 derivações",
          "eletrocardiografia"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M20-01",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-MONITORIZACAO-CARDIACA",
        "preferredTitle": "Monitorização cardíaca",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M20-02",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-DESFIBRILACAO",
        "preferredTitle": "Desfibrilação",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M20-04",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-MARCAPASSO-TRANSCUTANEO",
        "preferredTitle": "Marcapasso transcutâneo",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M20-05",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-PROCEDIMENTOS-CARDIOVASCULARES-INVASIVOS",
        "preferredTitle": "Assistência a procedimentos cardiovasculares invasivos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M20-06",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-TRANSICOES-EM-CIRCULACAO-EXTRACORPOREA",
        "preferredTitle": "Transições em circulação extracorpórea",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M20-07",
            "moduleId": "M20",
            "label": "Cardiologia"
          }
        ]
      },
      {
        "id": "PROC-PARACENTESE",
        "preferredTitle": "Paracentese",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-01",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-SONDAS-DIGESTIVAS",
        "preferredTitle": "Sondas digestivas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-02",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-ENDOSCOPIA-DIGESTIVA-ALTA",
        "preferredTitle": "Assistência à endoscopia digestiva alta",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-03",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-COLONOSCOPIA",
        "preferredTitle": "Assistência à colonoscopia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-04",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-BIOPSIAS-DIGESTIVAS",
        "preferredTitle": "Biópsias digestivas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-05",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-DRENAGENS",
        "preferredTitle": "Assistência a drenagens",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-06",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-CUIDADOS-COM-OSTOMIAS-DIGESTIVAS",
        "preferredTitle": "Cuidados com ostomias digestivas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M21-07",
            "moduleId": "M21",
            "label": "Gastroenterologia"
          }
        ]
      },
      {
        "id": "PROC-CATETERISMO-URINARIO",
        "preferredTitle": "Cateterismo urinário",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M22-01",
            "moduleId": "M22",
            "label": "Urologia"
          }
        ]
      },
      {
        "id": "PROC-CISTOSTOMIA",
        "preferredTitle": "Cistostomia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M22-03",
            "moduleId": "M22",
            "label": "Urologia"
          }
        ]
      },
      {
        "id": "PROC-ASSISTENCIA-A-CISTOSCOPIA",
        "preferredTitle": "Assistência à cistoscopia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M22-04",
            "moduleId": "M22",
            "label": "Urologia"
          }
        ]
      },
      {
        "id": "PROC-PROCEDIMENTOS-URETRAIS",
        "preferredTitle": "Procedimentos uretrais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M22-05",
            "moduleId": "M22",
            "label": "Urologia"
          }
        ]
      },
      {
        "id": "PROC-STENTS-E-CATETERES-UROLOGICOS",
        "preferredTitle": "Stents e cateteres urológicos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M22-06",
            "moduleId": "M22",
            "label": "Urologia"
          }
        ]
      },
      {
        "id": "PROC-AVALIACAO-DA-ACUIDADE-VISUAL",
        "preferredTitle": "Avaliação da acuidade visual",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-01",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-TESTE-COM-FLUORESCEINA",
        "preferredTitle": "Teste com fluoresceína",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-02",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-EVERSAO-PALPEBRAL",
        "preferredTitle": "Eversão palpebral",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-03",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-IRRIGACAO-OCULAR",
        "preferredTitle": "Irrigação ocular",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-04",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-TONOMETRIA",
        "preferredTitle": "Tonometria",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-05",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-CURATIVOS-OCULARES",
        "preferredTitle": "Curativos oculares",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-06",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-REMOCAO-DE-CORPO-ESTRANHO-SUPERFICIAL-EM-CONTEXTO-HABILITADO",
        "preferredTitle": "Remoção de corpo estranho superficial em contexto habilitado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M23-07",
            "moduleId": "M23",
            "label": "Oftalmologia"
          }
        ]
      },
      {
        "id": "PROC-OTOSCOPIA",
        "preferredTitle": "Otoscopia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M24-01",
            "moduleId": "M24",
            "label": "Otorrinolaringologia"
          }
        ]
      },
      {
        "id": "PROC-LAVAGEM-AURICULAR-QUANDO-INDICADA",
        "preferredTitle": "Lavagem auricular quando indicada",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M24-02",
            "moduleId": "M24",
            "label": "Otorrinolaringologia"
          }
        ]
      },
      {
        "id": "PROC-CONTROLE-INICIAL-DE-EPISTAXE",
        "preferredTitle": "Controle inicial de epistaxe",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M24-03",
            "moduleId": "M24",
            "label": "Otorrinolaringologia"
          }
        ]
      },
      {
        "id": "PROC-TAMPONAMENTO-NASAL",
        "preferredTitle": "Tamponamento nasal",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M24-04",
            "moduleId": "M24",
            "label": "Otorrinolaringologia"
          }
        ]
      },
      {
        "id": "PROC-REMOCAO-DE-CORPO-ESTRANHO-EM-OUVIDO-OU-NARIZ",
        "preferredTitle": "Remoção de corpo estranho em ouvido ou nariz",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M24-05",
            "moduleId": "M24",
            "label": "Otorrinolaringologia"
          }
        ]
      },
      {
        "id": "PROC-VIA-AEREA-COMPARTILHADA",
        "preferredTitle": "Via aérea compartilhada",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M24-06",
            "moduleId": "M24",
            "label": "Otorrinolaringologia"
          }
        ]
      },
      {
        "id": "PROC-BIOPSIA-PUNCH",
        "preferredTitle": "Biópsia punch",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-01",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-BIOPSIA-SHAVE",
        "preferredTitle": "Biópsia shave",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-02",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-BIOPSIA-EXCISIONAL",
        "preferredTitle": "Biópsia excisional",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-03",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-CRIOTERAPIA",
        "preferredTitle": "Crioterapia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-04",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-CAUTERIZACAO",
        "preferredTitle": "Cauterização",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-05",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-EXERESE-DE-LESOES",
        "preferredTitle": "Exérese de lesões",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-06",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-CURATIVOS-E-ACONDICIONAMENTO-DE-ESPECIMES",
        "preferredTitle": "Curativos e acondicionamento de espécimes",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M25-07",
            "moduleId": "M25",
            "label": "Dermatologia"
          }
        ]
      },
      {
        "id": "PROC-VIGILANCIA-NA-SRPA",
        "preferredTitle": "Vigilância na SRPA",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-01",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-AVALIACAO-E-CONTROLE-DA-DOR",
        "preferredTitle": "Avaliação e controle da dor",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-02",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-NAUSEAS-E-VOMITOS-POS-OPERATORIOS",
        "preferredTitle": "Náuseas e vômitos pós-operatórios",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-03",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-RECONHECIMENTO-DE-HEMORRAGIA",
        "preferredTitle": "Reconhecimento de hemorragia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-04",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-VIGILANCIA-DE-INFECCAO",
        "preferredTitle": "Vigilância de infecção",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-05",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-TROMBOPROFILAXIA",
        "preferredTitle": "Tromboprofilaxia",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-06",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-CURATIVOS-POS-OPERATORIOS",
        "preferredTitle": "Curativos pós-operatórios",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-07",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-MANEJO-DE-DRENOS",
        "preferredTitle": "Manejo de drenos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-08",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-RETIRADA-PLANEJADA-DE-DISPOSITIVOS",
        "preferredTitle": "Retirada planejada de dispositivos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-09",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-CRITERIOS-E-ORIENTACOES-DE-ALTA",
        "preferredTitle": "Critérios e orientações de alta",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M26-10",
            "moduleId": "M26",
            "label": "Cuidados pós-operatórios"
          }
        ]
      },
      {
        "id": "PROC-GLICEMIA-CAPILAR",
        "preferredTitle": "Glicemia capilar",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M27-01",
            "moduleId": "M27",
            "label": "Diagnóstico à beira-leito"
          }
        ]
      },
      {
        "id": "PROC-ELETROCARDIOGRAMA-A-BEIRA-LEITO",
        "preferredTitle": "Eletrocardiograma à beira-leito",
        "aliases": [
          "ECG",
          "ECG bedside",
          "eletrocardiograma bedside"
        ],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M27-02",
            "moduleId": "M27",
            "label": "Diagnóstico à beira-leito"
          }
        ]
      },
      {
        "id": "PROC-ULTRASSOM-POINT-OF-CARE",
        "preferredTitle": "Ultrassom point-of-care",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M27-03",
            "moduleId": "M27",
            "label": "Diagnóstico à beira-leito"
          }
        ]
      },
      {
        "id": "PROC-COLETA-DE-AMOSTRAS-BIOLOGICAS",
        "preferredTitle": "Coleta de amostras biológicas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M27-04",
            "moduleId": "M27",
            "label": "Diagnóstico à beira-leito"
          }
        ]
      },
      {
        "id": "PROC-PUNCOES-DIAGNOSTICAS-SUPERVISIONADAS",
        "preferredTitle": "Punções diagnósticas supervisionadas",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M27-05",
            "moduleId": "M27",
            "label": "Diagnóstico à beira-leito"
          }
        ]
      },
      {
        "id": "PROC-CONSENTIMENTO-INFORMADO",
        "preferredTitle": "Consentimento informado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-01",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-EVOLUCAO-CLINICA",
        "preferredTitle": "Evolução clínica",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-02",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-DESCRICAO-DE-PROCEDIMENTOS",
        "preferredTitle": "Descrição de procedimentos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-03",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-RASTREABILIDADE-DE-MATERIAIS",
        "preferredTitle": "Rastreabilidade de materiais",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-04",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-IDENTIFICACAO-DE-AMOSTRAS-E-DISPOSITIVOS",
        "preferredTitle": "Identificação de amostras e dispositivos",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-05",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-TRANSFERENCIA-DO-CUIDADO",
        "preferredTitle": "Transferência do cuidado",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-06",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-PASSAGEM-DE-PLANTAO-ESTRUTURADA",
        "preferredTitle": "Passagem de plantão estruturada",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-07",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      },
      {
        "id": "PROC-PRIVACIDADE-E-PROTECAO-DE-DADOS",
        "preferredTitle": "Privacidade e proteção de dados",
        "aliases": [],
        "status": "catalogado",
        "version": "0.1",
        "contexts": [
          {
            "topicId": "PT-M28-08",
            "moduleId": "M28",
            "label": "Documentação e comunicação"
          }
        ]
      }
    ],
    "topicStatusWorkflow": [
      {
        "id": "catalogado",
        "title": "Catalogado",
        "order": 1
      },
      {
        "id": "em-desenvolvimento",
        "title": "Em desenvolvimento",
        "order": 2
      },
      {
        "id": "revisao-tecnica",
        "title": "Revisão técnica",
        "order": 3
      },
      {
        "id": "validado",
        "title": "Validado",
        "order": 4
      },
      {
        "id": "publicado",
        "title": "Publicado",
        "order": 5
      }
    ]
  },
  "materialAtlas": {
    "version": "1.0",
    "status": "Núcleo inicial implementado; fichas em revisão editorial, não validadas clinicamente",
    "primaryAudience": "Estudantes de Medicina e médicos em treinamento supervisionado",
    "scopeStatement": "A plataforma prepara para estudo e simulação. Procedimentos invasivos exigem supervisão, autorização institucional, equipe habilitada, protocolo local e instruções do fabricante.",
    "scaleSystems": [
      {
        "id": "G",
        "title": "Gauge",
        "direction": "inversa",
        "definition": "Número legado associado ao diâmetro externo; números menores representam diâmetros maiores dentro da mesma família.",
        "warning": "Agulhas hipodérmicas e cateteres intravenosos usam códigos de cor distintos. Verifique família, marcação e IFU; não use somente a cor."
      },
      {
        "id": "Fr",
        "title": "French / Charrière",
        "direction": "direta",
        "definition": "Escala de diâmetro externo: 1 Fr corresponde a aproximadamente 0,33 mm; diâmetro externo em mm = Fr ÷ 3.",
        "warning": "O diâmetro interno e o fluxo variam com material, parede, lúmens e fabricante."
      },
      {
        "id": "USP",
        "title": "Numeração USP de suturas",
        "direction": "mista",
        "definition": "Classificação nominal de diâmetro e desempenho; mais zeros indicam fios mais finos, enquanto números inteiros crescentes indicam fios mais grossos.",
        "warning": "Faixas de diâmetro podem variar por classe/material. Não converter para milímetros sem monografia e produto específicos."
      },
      {
        "id": "mm-ID",
        "title": "Milímetros — diâmetro interno",
        "direction": "direta",
        "definition": "Dimensão interna nominal usada, entre outros exemplos, em tubos endotraqueais.",
        "warning": "Diâmetro interno, diâmetro externo, comprimento e conectores são dimensões diferentes."
      },
      {
        "id": "mL",
        "title": "Mililitros",
        "direction": "direta",
        "definition": "Capacidade nominal de seringas e reservatórios; não representa calibre.",
        "warning": "Precisão, graduação, espaço morto e conector dependem do produto."
      },
      {
        "id": "blade",
        "title": "Número de lâmina",
        "direction": "categorica",
        "definition": "Identificador de formato de lâmina e compatibilidade de cabo, não uma escala linear de tamanho.",
        "warning": "Confirmar encaixe com o cabo e instruções do fabricante."
      },
      {
        "id": "pattern",
        "title": "Padrão ou modelo",
        "direction": "categorica",
        "definition": "Nome de desenho, forma ou função do instrumental; não equivale a tamanho universal.",
        "warning": "Comprimento, ponta, serrilha, cremalheira e fabricante devem constar na especificação."
      }
    ],
    "categories": [
      {
        "id": "vascular",
        "title": "Dispositivos vasculares",
        "layer": "A"
      },
      {
        "id": "infusao",
        "title": "Infusão e conexões",
        "layer": "A"
      },
      {
        "id": "medicacao",
        "title": "Seringas e acesso medicamentoso",
        "layer": "B"
      },
      {
        "id": "sondas",
        "title": "Sondas e drenagem",
        "layer": "C"
      },
      {
        "id": "via-aerea",
        "title": "Via aérea e oxigenação",
        "layer": "C"
      },
      {
        "id": "fechamento",
        "title": "Fechamento e suturas",
        "layer": "D"
      },
      {
        "id": "instrumentais",
        "title": "Instrumentais cirúrgicos",
        "layer": "D"
      }
    ],
    "sources": [
      {
        "id": "SRC-MAT-WHO-PIV-2024",
        "title": "Guidelines for the prevention of bloodstream infections associated with peripheral catheters",
        "organization": "World Health Organization",
        "edition": "Part I",
        "year": "2024",
        "url": "https://www.who.int/publications/i/item/9789240093829",
        "verifiedOn": "14/10/2026",
        "status": "verificada"
      },
      {
        "id": "SRC-MAT-WHO-CVC-2026",
        "title": "Guidelines for the prevention of bloodstream infections associated with central venous catheters",
        "organization": "World Health Organization",
        "edition": "Part II",
        "year": "2026",
        "url": "https://www.who.int/publications/i/item/9789240121805",
        "verifiedOn": "14/10/2026",
        "status": "verificada"
      },
      {
        "id": "SRC-MAT-ISO-10555-5",
        "title": "ISO 10555-5:2013 — Over-needle peripheral catheters",
        "organization": "ISO",
        "edition": "2nd edition; confirmed 2023, revision in development",
        "year": "2013",
        "url": "https://www.iso.org/standard/54885.html",
        "verifiedOn": "14/10/2026",
        "status": "vigente-em-revisao"
      },
      {
        "id": "SRC-MAT-ISO-6009",
        "title": "ISO 6009:2016 — Hypodermic needles colour coding",
        "organization": "ISO",
        "edition": "4th edition; confirmed 2021",
        "year": "2016",
        "url": "https://www.iso.org/standard/63277.html",
        "verifiedOn": "14/10/2026",
        "status": "vigente"
      },
      {
        "id": "SRC-MAT-FDA-FOLEY",
        "title": "Conventional Foley Catheters — Safety and Performance Based Pathway",
        "organization": "U.S. Food and Drug Administration",
        "edition": "Guidance",
        "year": "2019",
        "url": "https://www.fda.gov/media/130865/download",
        "verifiedOn": "14/10/2026",
        "status": "verificada"
      },
      {
        "id": "SRC-MAT-FDA-SUTURE",
        "title": "Surgical Sutures — Safety and Performance Based Pathway",
        "organization": "U.S. Food and Drug Administration",
        "edition": "Guidance",
        "year": "2022",
        "url": "https://www.fda.gov/media/157490/download",
        "verifiedOn": "14/10/2026",
        "status": "verificada"
      },
      {
        "id": "SRC-MAT-ISO-80369-3",
        "title": "ISO 80369-3:2016 — Connectors for enteral applications",
        "organization": "ISO",
        "edition": "1st edition; confirmed 2023",
        "year": "2016",
        "url": "https://www.iso.org/standard/50731.html",
        "verifiedOn": "14/10/2026",
        "status": "vigente"
      },
      {
        "id": "SRC-MAT-CDC-INJECTION",
        "title": "Preventing Unsafe Injection Practices",
        "organization": "Centers for Disease Control and Prevention",
        "edition": "Clinical safety resource",
        "year": "2025",
        "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/",
        "verifiedOn": "14/10/2026",
        "status": "verificada"
      },
      {
        "id": "SRC-MAT-IFU",
        "title": "Instruções de uso do fabricante do item selecionado",
        "organization": "Fabricante e registro sanitário aplicáveis",
        "edition": "Modelo, lote e versão devem ser registrados",
        "year": "Vigente",
        "url": "",
        "verifiedOn": null,
        "status": "obrigatoria-antes-validacao",
        "manufacturerRequirement": true
      }
    ],
    "materials": [
      {
        "id": "MAT-VAS-001",
        "preferredName": "Cateter intravenoso periférico",
        "aliases": [
          "jelco",
          "abocath",
          "cateter IV",
          "cânula IV",
          "PIVC",
          "CIVP",
          "cateter periférico 24G"
        ],
        "categoryId": "vascular",
        "description": "Cateter curto sobre agulha para acesso ao sistema vascular periférico. Gauge, diâmetro, comprimento, material e mecanismo de segurança precisam ser conferidos no produto.",
        "generalIndications": [
          "Terapia intravenosa periférica quando indicada"
        ],
        "risks": [
          "Infiltração, extravasamento, flebite, oclusão, infecção e lesão por perfurocortante"
        ],
        "alternatives": [
          "Dispositivo alado em usos selecionados",
          "Acesso central quando clinicamente indicado"
        ],
        "precautions": [
          "Selecionar o menor diâmetro e comprimento adequados ao objetivo e vaso conforme avaliação; confirmar marcação, integridade, validade e mecanismo de segurança"
        ],
        "scaleSystem": "G",
        "variants": [
          {
            "id": "PIV-14G",
            "label": "14G — Laranja",
            "scaleType": "G",
            "scaleValue": "14G",
            "dimensions": {
              "nominalOuterDiameterMm": 2.1,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Laranja",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-16G",
            "label": "16G — Cinza médio",
            "scaleType": "G",
            "scaleValue": "16G",
            "dimensions": {
              "nominalOuterDiameterMm": 1.7,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Cinza médio",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-17G",
            "label": "17G — Branco",
            "scaleType": "G",
            "scaleValue": "17G",
            "dimensions": {
              "nominalOuterDiameterMm": 1.5,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Branco",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-18G",
            "label": "18G — Verde escuro",
            "scaleType": "G",
            "scaleValue": "18G",
            "dimensions": {
              "nominalOuterDiameterMm": 1.3,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Verde escuro",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-20G",
            "label": "20G — Rosa",
            "scaleType": "G",
            "scaleValue": "20G",
            "dimensions": {
              "nominalOuterDiameterMm": 1.1,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Rosa",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-22G",
            "label": "22G — Azul escuro",
            "scaleType": "G",
            "scaleValue": "22G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.9,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Azul escuro",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-24G",
            "label": "24G — Amarelo",
            "scaleType": "G",
            "scaleValue": "24G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.7,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Amarelo",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PIV-26G",
            "label": "26G — Violeta",
            "scaleType": "G",
            "scaleValue": "26G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.6,
              "length": "depende do fabricante"
            },
            "color": {
              "value": "Violeta",
              "context": "ISO 10555-5 para cateter periférico sobre agulha; conferir embalagem e IFU"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M05-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M03-04",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-WHO-PIV-2024",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-ISO-10555-5",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cateter intravenoso periférico"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-VAS-002",
        "preferredName": "Dispositivo alado para acesso vascular",
        "aliases": [
          "scalp",
          "butterfly needle",
          "agulha borboleta"
        ],
        "categoryId": "vascular",
        "description": "Agulha metálica curta com asas e extensão flexível; finalidade e permanência dependem do modelo e protocolo.",
        "generalIndications": [
          "Coleta ou acesso de curta duração em situações selecionadas"
        ],
        "risks": [
          "Perfurocortante, deslocamento, infiltração e uso inadequado para permanência"
        ],
        "alternatives": [
          "Cateter intravenoso periférico"
        ],
        "precautions": [
          "Distinguir agulha metálica de cateter flexível e seguir protocolo local"
        ],
        "scaleSystem": "G",
        "variants": [
          {
            "id": "SCALP-19G",
            "label": "19G",
            "scaleType": "G",
            "scaleValue": "19G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "variável",
              "context": "Não inferir Gauge apenas pela cor; conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SCALP-21G",
            "label": "21G",
            "scaleType": "G",
            "scaleValue": "21G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "variável",
              "context": "Não inferir Gauge apenas pela cor; conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SCALP-23G",
            "label": "23G",
            "scaleType": "G",
            "scaleValue": "23G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "variável",
              "context": "Não inferir Gauge apenas pela cor; conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SCALP-25G",
            "label": "25G",
            "scaleType": "G",
            "scaleValue": "25G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "variável",
              "context": "Não inferir Gauge apenas pela cor; conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-03",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M05-02",
            "role": "alternativa",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-ISO-6009",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de dispositivo alado para acesso vascular"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-VAS-003",
        "preferredName": "Cateter central de inserção periférica",
        "aliases": [
          "PICC",
          "cateter PICC",
          "peripherally inserted central catheter"
        ],
        "categoryId": "vascular",
        "description": "Cateter venoso central introduzido por veia periférica; lúmens, calibre, comprimento e material variam.",
        "generalIndications": [
          "Acesso central quando indicado pelo plano terapêutico"
        ],
        "risks": [
          "Infecção, trombose, malposição, oclusão, embolia e complicações de inserção"
        ],
        "alternatives": [
          "Cateter venoso central por outra via",
          "Acesso periférico"
        ],
        "precautions": [
          "Inserção e confirmação por equipe habilitada; registrar comprimento, lúmens e método de confirmação"
        ],
        "scaleSystem": "Fr",
        "variants": [
          {
            "id": "PICC-2FR",
            "label": "2 Fr",
            "scaleType": "Fr",
            "scaleValue": "2 Fr",
            "dimensions": {
              "outerDiameterMm": 0.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PICC-3FR",
            "label": "3 Fr",
            "scaleType": "Fr",
            "scaleValue": "3 Fr",
            "dimensions": {
              "outerDiameterMm": 1.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PICC-4FR",
            "label": "4 Fr",
            "scaleType": "Fr",
            "scaleValue": "4 Fr",
            "dimensions": {
              "outerDiameterMm": 1.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PICC-5FR",
            "label": "5 Fr",
            "scaleType": "Fr",
            "scaleValue": "5 Fr",
            "dimensions": {
              "outerDiameterMm": 1.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PICC-6FR",
            "label": "6 Fr",
            "scaleType": "Fr",
            "scaleValue": "6 Fr",
            "dimensions": {
              "outerDiameterMm": 2.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M05-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-WHO-PIV-2024",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-WHO-CVC-2026",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cateter central de inserção periférica"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-VAS-004",
        "preferredName": "Cateter venoso central não tunelizado",
        "aliases": [
          "CVC",
          "cateter central",
          "central line"
        ],
        "categoryId": "vascular",
        "description": "Cateter de acesso venoso central com configurações de lúmen, calibre e comprimento específicas.",
        "generalIndications": [
          "Acesso venoso central quando indicado"
        ],
        "risks": [
          "Complicações mecânicas, infecciosas, trombóticas e relacionadas à posição"
        ],
        "alternatives": [
          "PICC",
          "Dispositivo implantável ou tunelizado",
          "Acesso periférico"
        ],
        "precautions": [
          "Barreira máxima, técnica estéril, confirmação e manutenção conforme protocolo"
        ],
        "scaleSystem": "Fr",
        "variants": [
          {
            "id": "CVC-4FR",
            "label": "4 Fr",
            "scaleType": "Fr",
            "scaleValue": "4 Fr",
            "dimensions": {
              "outerDiameterMm": 1.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "CVC-5FR",
            "label": "5 Fr",
            "scaleType": "Fr",
            "scaleValue": "5 Fr",
            "dimensions": {
              "outerDiameterMm": 1.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "CVC-6FR",
            "label": "6 Fr",
            "scaleType": "Fr",
            "scaleValue": "6 Fr",
            "dimensions": {
              "outerDiameterMm": 2.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "CVC-7FR",
            "label": "7 Fr",
            "scaleType": "Fr",
            "scaleValue": "7 Fr",
            "dimensions": {
              "outerDiameterMm": 2.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "CVC-8FR",
            "label": "8 Fr",
            "scaleType": "Fr",
            "scaleValue": "8 Fr",
            "dimensions": {
              "outerDiameterMm": 2.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M05-04",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-WHO-CVC-2026",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cateter venoso central não tunelizado"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-VAS-005",
        "preferredName": "Cateter arterial",
        "aliases": [
          "linha arterial",
          "arterial line",
          "cateter para pressão invasiva"
        ],
        "categoryId": "vascular",
        "description": "Cateter para acesso arterial e conexão a sistema de monitorização ou coleta conforme indicação.",
        "generalIndications": [
          "Monitorização invasiva e coleta arterial em contextos indicados"
        ],
        "risks": [
          "Isquemia, sangramento, hematoma, infecção, trombose e desconexão"
        ],
        "alternatives": [
          "Punção arterial única para gasometria"
        ],
        "precautions": [
          "Avaliar perfusão, sistema pressurizado, zero, nivelamento, identificação e retirada"
        ],
        "scaleSystem": "G",
        "variants": [
          {
            "id": "ART-18G",
            "label": "18G",
            "scaleType": "G",
            "scaleValue": "18G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "conferir produto",
              "context": "Não assumir padrão sem embalagem/IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ART-20G",
            "label": "20G",
            "scaleType": "G",
            "scaleValue": "20G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "conferir produto",
              "context": "Não assumir padrão sem embalagem/IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ART-22G",
            "label": "22G",
            "scaleType": "G",
            "scaleValue": "22G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "conferir produto",
              "context": "Não assumir padrão sem embalagem/IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ART-24G",
            "label": "24G",
            "scaleType": "G",
            "scaleValue": "24G",
            "dimensions": {
              "length": "variável"
            },
            "color": {
              "value": "conferir produto",
              "context": "Não assumir padrão sem embalagem/IFU"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M05-06",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M11-03",
            "role": "alternativa",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-ISO-10555-5",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cateter arterial"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INF-001",
        "preferredName": "Conector sem agulha",
        "aliases": [
          "needleless connector",
          "conector valvulado",
          "hub sem agulha"
        ],
        "categoryId": "infusao",
        "description": "Componente de acesso a linhas de infusão cuja mecânica interna e desinfecção dependem do modelo.",
        "generalIndications": [
          "Acesso a sistema de infusão compatível"
        ],
        "risks": [
          "Contaminação, desconexão, oclusão e incompatibilidade"
        ],
        "alternatives": [
          "Tampa/conector especificado pelo sistema"
        ],
        "precautions": [
          "Conhecer mecanismo, técnica de desinfecção, sequência de clampeamento e troca da instituição"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "NC-NEUTRAL",
            "label": "Deslocamento neutro",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NC-POSITIVE",
            "label": "Deslocamento positivo",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NC-NEGATIVE",
            "label": "Deslocamento negativo",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-06",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M05-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-WHO-PIV-2024",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-WHO-CVC-2026",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de conector sem agulha"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INF-002",
        "preferredName": "Extensor de infusão",
        "aliases": [
          "extensão IV",
          "prolongador",
          "extension set"
        ],
        "categoryId": "infusao",
        "description": "Tubulação intermediária com comprimento, volume de preenchimento, conectores e número de vias variáveis.",
        "generalIndications": [
          "Conexão e organização de linhas quando compatível"
        ],
        "risks": [
          "Espaço morto, volume residual, desconexão, tração e mistura incompatível"
        ],
        "alternatives": [
          "Conexão direta quando prevista"
        ],
        "precautions": [
          "Calcular volume de preenchimento quando clinicamente relevante; rastrear cada via"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "EXT-SHORT",
            "label": "Extensor curto",
            "scaleType": null,
            "scaleValue": null,
            "dimensions": {
              "primingVolume": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "EXT-MULTI",
            "label": "Extensor multivias",
            "scaleType": null,
            "scaleValue": null,
            "dimensions": {
              "primingVolume": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M05-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-WHO-PIV-2024",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de extensor de infusão"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INF-003",
        "preferredName": "Equipo de infusão",
        "aliases": [
          "equipo macrogotas",
          "equipo microgotas",
          "IV set",
          "administration set"
        ],
        "categoryId": "infusao",
        "description": "Conjunto para administração de soluções; câmara, fator de gotejamento, filtro, ventilação e material variam.",
        "generalIndications": [
          "Administração de soluções conforme sistema e prescrição"
        ],
        "risks": [
          "Fluxo incorreto, ar, contaminação, incompatibilidade e conexão errada"
        ],
        "alternatives": [
          "Seringa/bomba em sistemas apropriados"
        ],
        "precautions": [
          "Confirmar fator de gotejamento, uso com bomba, filtro, fotoproteção e compatibilidade química"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "SET-MACRO",
            "label": "Equipo de macrogotas",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SET-MICRO",
            "label": "Equipo de microgotas",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SET-PUMP",
            "label": "Equipo específico para bomba",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-07",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M04-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-CDC-INJECTION",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de equipo de infusão"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-MED-001",
        "preferredName": "Seringa descartável",
        "aliases": [
          "seringa Luer",
          "syringe",
          "seringa 10 mL",
          "seringa 20 mL"
        ],
        "categoryId": "medicacao",
        "description": "Dispositivo graduado para aspirar ou administrar fluidos; volume, graduação, espaço morto e conector variam.",
        "generalIndications": [
          "Preparo e administração conforme via, fármaco e protocolo"
        ],
        "risks": [
          "Erro de graduação, conexão errada, contaminação, reutilização e espaço morto"
        ],
        "alternatives": [
          "Seringa oral/enteral específica",
          "Sistema fechado específico"
        ],
        "precautions": [
          "Conferir volume nominal, graduação, conector, esterilidade, uso único e compatibilidade"
        ],
        "scaleSystem": "mL",
        "variants": [
          {
            "id": "SYR-1ML",
            "label": "1 mL",
            "scaleType": "mL",
            "scaleValue": "1 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SYR-3ML",
            "label": "3 mL",
            "scaleType": "mL",
            "scaleValue": "3 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SYR-5ML",
            "label": "5 mL",
            "scaleType": "mL",
            "scaleValue": "5 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SYR-10ML",
            "label": "10 mL",
            "scaleType": "mL",
            "scaleValue": "10 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SYR-20ML",
            "label": "20 mL",
            "scaleType": "mL",
            "scaleValue": "20 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SYR-50ML",
            "label": "50 mL",
            "scaleType": "mL",
            "scaleValue": "50 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SYR-60ML",
            "label": "60 mL",
            "scaleType": "mL",
            "scaleValue": "60 mL",
            "connector": "Luer slip ou Luer lock conforme modelo",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M04-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [
          {
            "withMaterialId": "MAT-MED-002",
            "relationship": "compativel-condicional",
            "condition": "Conectores e finalidade compatíveis; confirmar IFU",
            "note": "Gauge não define o conector"
          }
        ],
        "provenance": [
          {
            "sourceId": "SRC-MAT-CDC-INJECTION",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de seringa descartável"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-MED-002",
        "preferredName": "Agulha hipodérmica descartável",
        "aliases": [
          "agulha de injeção",
          "hypodermic needle",
          "agulha 25G"
        ],
        "categoryId": "medicacao",
        "description": "Agulha de uso único cuja seleção envolve diâmetro externo, comprimento, parede, bisel e conector.",
        "generalIndications": [
          "Aspiração ou administração por via compatível quando indicada"
        ],
        "risks": [
          "Perfurocortante, lesão, aplicação em plano inadequado, reutilização e contaminação"
        ],
        "alternatives": [
          "Dispositivo de segurança ou sistema sem agulha conforme finalidade"
        ],
        "precautions": [
          "Confirmar Gauge e comprimento escritos; cor ISO 6009 não é a mesma sequência de cateter IV"
        ],
        "scaleSystem": "G",
        "variants": [
          {
            "id": "NDL-18G",
            "label": "18G — Rosa",
            "scaleType": "G",
            "scaleValue": "18G",
            "dimensions": {
              "nominalOuterDiameterMm": 1.2,
              "length": "variável"
            },
            "color": {
              "value": "Rosa",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-20G",
            "label": "20G — Amarelo",
            "scaleType": "G",
            "scaleValue": "20G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.9,
              "length": "variável"
            },
            "color": {
              "value": "Amarelo",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-21G",
            "label": "21G — Verde escuro",
            "scaleType": "G",
            "scaleValue": "21G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.8,
              "length": "variável"
            },
            "color": {
              "value": "Verde escuro",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-22G",
            "label": "22G — Preto",
            "scaleType": "G",
            "scaleValue": "22G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.7,
              "length": "variável"
            },
            "color": {
              "value": "Preto",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-23G",
            "label": "23G — Azul escuro",
            "scaleType": "G",
            "scaleValue": "23G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.6,
              "length": "variável"
            },
            "color": {
              "value": "Azul escuro",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-25G",
            "label": "25G — Laranja",
            "scaleType": "G",
            "scaleValue": "25G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.5,
              "length": "variável"
            },
            "color": {
              "value": "Laranja",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-26G",
            "label": "26G — Marrom",
            "scaleType": "G",
            "scaleValue": "26G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.45,
              "length": "variável"
            },
            "color": {
              "value": "Marrom",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-27G",
            "label": "27G — Cinza médio",
            "scaleType": "G",
            "scaleValue": "27G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.4,
              "length": "variável"
            },
            "color": {
              "value": "Cinza médio",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NDL-30G",
            "label": "30G — Amarelo",
            "scaleType": "G",
            "scaleValue": "30G",
            "dimensions": {
              "nominalOuterDiameterMm": 0.3,
              "length": "variável"
            },
            "color": {
              "value": "Amarelo",
              "context": "ISO 6009 para agulha hipodérmica; não confundir com cor de cateter IV"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-02",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M04-03",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M04-04",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M04-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-ISO-6009",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-CDC-INJECTION",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de agulha hipodérmica descartável"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-MED-003",
        "preferredName": "Bomba de infusão",
        "aliases": [
          "bomba infusora",
          "infusion pump",
          "bomba volumétrica"
        ],
        "categoryId": "medicacao",
        "description": "Equipamento ativo que controla administração conforme modelo, biblioteca de fármacos e equipo compatível.",
        "generalIndications": [
          "Infusão controlada conforme indicação e prescrição"
        ],
        "risks": [
          "Programação incorreta, oclusão, fluxo livre, atraso, alarme ignorado e equipo incompatível"
        ],
        "alternatives": [
          "Controle gravitacional em situações permitidas",
          "Outro equipamento validado"
        ],
        "precautions": [
          "Treinamento específico, dupla checagem quando indicada, biblioteca vigente e resposta a alarmes"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "PUMP-VOLUMETRIC",
            "label": "Volumétrica",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PUMP-SYRINGE",
            "label": "Bomba de seringa",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M04-09",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de bomba de infusão"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INF-004",
        "preferredName": "Torneira de três vias",
        "aliases": [
          "three-way stopcock",
          "torneirinha 3 vias",
          "3-way"
        ],
        "categoryId": "infusao",
        "description": "Componente com três portas e seletor de fluxo; pressão, material e tampas variam.",
        "generalIndications": [
          "Organização de conexões compatíveis quando indicada"
        ],
        "risks": [
          "Posição incorreta, entrada de ar, contaminação, desconexão e espaço morto"
        ],
        "alternatives": [
          "Manifold ou conector multivias específico"
        ],
        "precautions": [
          "Traçar linha, identificar vias e confirmar posição do seletor antes de manipular"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "3WAY-BASIC",
            "label": "Três vias padrão",
            "scaleType": null,
            "scaleValue": null,
            "connector": "Luer compatível conforme produto",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "3WAY-EXT",
            "label": "Três vias com extensor",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-09",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M05-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de torneira de três vias"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SON-001",
        "preferredName": "Cateter urinário de demora tipo Foley",
        "aliases": [
          "sonda Foley",
          "Foley",
          "SVD",
          "cateter vesical de demora"
        ],
        "categoryId": "sondas",
        "description": "Cateter com balão de retenção; diâmetro externo é indicado em French, enquanto lúmens, material, comprimento e balão variam.",
        "generalIndications": [
          "Drenagem vesical de demora quando houver indicação clínica"
        ],
        "risks": [
          "Trauma, infecção, obstrução, falso trajeto, lesão por balão e desconexão"
        ],
        "alternatives": [
          "Cateter intermitente",
          "Método externo quando indicado"
        ],
        "precautions": [
          "Usar menor calibre adequado à drenagem conforme protocolo; confirmar volume do balão no produto e nunca inferi-lo pelo Fr"
        ],
        "scaleSystem": "Fr",
        "variants": [
          {
            "id": "FOL-12FR",
            "label": "12 Fr",
            "scaleType": "Fr",
            "scaleValue": "12 Fr",
            "dimensions": {
              "outerDiameterMm": 4.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FOL-14FR",
            "label": "14 Fr",
            "scaleType": "Fr",
            "scaleValue": "14 Fr",
            "dimensions": {
              "outerDiameterMm": 4.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FOL-16FR",
            "label": "16 Fr",
            "scaleType": "Fr",
            "scaleValue": "16 Fr",
            "dimensions": {
              "outerDiameterMm": 5.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FOL-18FR",
            "label": "18 Fr",
            "scaleType": "Fr",
            "scaleValue": "18 Fr",
            "dimensions": {
              "outerDiameterMm": 6.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FOL-20FR",
            "label": "20 Fr",
            "scaleType": "Fr",
            "scaleValue": "20 Fr",
            "dimensions": {
              "outerDiameterMm": 6.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FOL-22FR",
            "label": "22 Fr",
            "scaleType": "Fr",
            "scaleValue": "22 Fr",
            "dimensions": {
              "outerDiameterMm": 7.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FOL-24FR",
            "label": "24 Fr",
            "scaleType": "Fr",
            "scaleValue": "24 Fr",
            "dimensions": {
              "outerDiameterMm": 8.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M14-02",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M22-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-FDA-FOLEY",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cateter urinário de demora tipo foley"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SON-002",
        "preferredName": "Cateter urinário intermitente tipo Nelaton",
        "aliases": [
          "sonda Nelaton",
          "Nelaton",
          "cateter de alívio"
        ],
        "categoryId": "sondas",
        "description": "Cateter sem balão para cateterismo intermitente; calibre, comprimento, ponta e material variam.",
        "generalIndications": [
          "Cateterismo vesical intermitente quando indicado"
        ],
        "risks": [
          "Trauma, infecção, resistência, falso trajeto e seleção inadequada"
        ],
        "alternatives": [
          "Foley quando indicada permanência",
          "Dispositivo externo selecionado"
        ],
        "precautions": [
          "Não forçar resistência; confirmar tamanho, comprimento, lubrificação e protocolo"
        ],
        "scaleSystem": "Fr",
        "variants": [
          {
            "id": "NEL-6FR",
            "label": "6 Fr",
            "scaleType": "Fr",
            "scaleValue": "6 Fr",
            "dimensions": {
              "outerDiameterMm": 2.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NEL-8FR",
            "label": "8 Fr",
            "scaleType": "Fr",
            "scaleValue": "8 Fr",
            "dimensions": {
              "outerDiameterMm": 2.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NEL-10FR",
            "label": "10 Fr",
            "scaleType": "Fr",
            "scaleValue": "10 Fr",
            "dimensions": {
              "outerDiameterMm": 3.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NEL-12FR",
            "label": "12 Fr",
            "scaleType": "Fr",
            "scaleValue": "12 Fr",
            "dimensions": {
              "outerDiameterMm": 4.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NEL-14FR",
            "label": "14 Fr",
            "scaleType": "Fr",
            "scaleValue": "14 Fr",
            "dimensions": {
              "outerDiameterMm": 4.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NEL-16FR",
            "label": "16 Fr",
            "scaleType": "Fr",
            "scaleValue": "16 Fr",
            "dimensions": {
              "outerDiameterMm": 5.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NEL-18FR",
            "label": "18 Fr",
            "scaleType": "Fr",
            "scaleValue": "18 Fr",
            "dimensions": {
              "outerDiameterMm": 6.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M14-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M22-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cateter urinário intermitente tipo nelaton"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SON-003",
        "preferredName": "Sonda gástrica ou enteral",
        "aliases": [
          "SNG",
          "SNE",
          "sonda nasogástrica",
          "sonda nasoenteral",
          "feeding tube",
          "NG tube"
        ],
        "categoryId": "sondas",
        "description": "Tubo para acesso gastrointestinal; finalidade, material, ponta, marca radiopaca, comprimento e conector variam.",
        "generalIndications": [
          "Descompressão, alimentação ou medicação conforme tipo e indicação"
        ],
        "risks": [
          "Malposição, aspiração, lesão, obstrução e conexão incorreta"
        ],
        "alternatives": [
          "Gastrostomia ou outro acesso enteral"
        ],
        "precautions": [
          "Distinguir finalidade e método institucional de confirmação antes do uso; registrar marca externa"
        ],
        "scaleSystem": "Fr",
        "variants": [
          {
            "id": "ENT-6FR",
            "label": "6 Fr",
            "scaleType": "Fr",
            "scaleValue": "6 Fr",
            "dimensions": {
              "outerDiameterMm": 2.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENT-8FR",
            "label": "8 Fr",
            "scaleType": "Fr",
            "scaleValue": "8 Fr",
            "dimensions": {
              "outerDiameterMm": 2.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENT-10FR",
            "label": "10 Fr",
            "scaleType": "Fr",
            "scaleValue": "10 Fr",
            "dimensions": {
              "outerDiameterMm": 3.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENT-12FR",
            "label": "12 Fr",
            "scaleType": "Fr",
            "scaleValue": "12 Fr",
            "dimensions": {
              "outerDiameterMm": 4.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENT-14FR",
            "label": "14 Fr",
            "scaleType": "Fr",
            "scaleValue": "14 Fr",
            "dimensions": {
              "outerDiameterMm": 4.67,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENT-16FR",
            "label": "16 Fr",
            "scaleType": "Fr",
            "scaleValue": "16 Fr",
            "dimensions": {
              "outerDiameterMm": 5.33,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENT-18FR",
            "label": "18 Fr",
            "scaleType": "Fr",
            "scaleValue": "18 Fr",
            "dimensions": {
              "outerDiameterMm": 6.0,
              "length": "depende do modelo"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M14-04",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M14-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M21-02",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-ISO-80369-3",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de sonda gástrica ou enteral"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SON-004",
        "preferredName": "Conector enteral ENFit",
        "aliases": [
          "ENFit",
          "ISO 80369-3",
          "conector enteral"
        ],
        "categoryId": "sondas",
        "description": "Conector de pequeno calibre específico para aplicações enterais, concebido para reduzir conexões erradas com sistemas não enterais.",
        "generalIndications": [
          "Conexão de dispositivos enterais compatíveis"
        ],
        "risks": [
          "Uso de adaptador inadequado, conexão forçada, resíduos e dosagem imprecisa"
        ],
        "alternatives": [
          "Conector enteral legado somente em transição institucional controlada"
        ],
        "precautions": [
          "Não conectar a Luer vascular; confirmar compatibilidade de todo o sistema"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "ENFIT-STD",
            "label": "ENFit padrão",
            "scaleType": null,
            "scaleValue": null,
            "connector": "ISO 80369-3",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ENFIT-LDT",
            "label": "ENFit de baixa dose",
            "scaleType": null,
            "scaleValue": null,
            "connector": "ISO 80369-3",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M03-10",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M14-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [
          {
            "withMaterialId": "MAT-MED-001",
            "relationship": "incompativel-por-design",
            "condition": "ENFit e Luer destinam-se a vias diferentes",
            "note": "Não improvisar adaptadores"
          }
        ],
        "provenance": [
          {
            "sourceId": "SRC-MAT-ISO-80369-3",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de conector enteral enfit"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-AIR-001",
        "preferredName": "Tubo endotraqueal",
        "aliases": [
          "TET",
          "ETT",
          "tubo traqueal",
          "endotracheal tube"
        ],
        "categoryId": "via-aerea",
        "description": "Tubo para via aérea traqueal; diâmetro interno em milímetros não define sozinho diâmetro externo, comprimento, cuff ou conector.",
        "generalIndications": [
          "Via aérea avançada por profissional habilitado quando indicada"
        ],
        "risks": [
          "Hipoxemia, trauma, malposição, pressão de cuff inadequada e desconexão"
        ],
        "alternatives": [
          "Dispositivo supraglótico",
          "Via aérea cirúrgica em resgate"
        ],
        "precautions": [
          "Seleção e confirmação dependem de paciente, técnica, monitorização e protocolo; verificar todas as marcações"
        ],
        "scaleSystem": "mm-ID",
        "variants": [
          {
            "id": "ETT-25",
            "label": "2.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "2.5",
            "dimensions": {
              "internalDiameterMm": 2.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-3",
            "label": "3.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "3.0",
            "dimensions": {
              "internalDiameterMm": 3,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-35",
            "label": "3.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "3.5",
            "dimensions": {
              "internalDiameterMm": 3.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-4",
            "label": "4.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "4.0",
            "dimensions": {
              "internalDiameterMm": 4,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-45",
            "label": "4.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "4.5",
            "dimensions": {
              "internalDiameterMm": 4.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-5",
            "label": "5.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "5.0",
            "dimensions": {
              "internalDiameterMm": 5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-55",
            "label": "5.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "5.5",
            "dimensions": {
              "internalDiameterMm": 5.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-6",
            "label": "6.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "6.0",
            "dimensions": {
              "internalDiameterMm": 6,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-65",
            "label": "6.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "6.5",
            "dimensions": {
              "internalDiameterMm": 6.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-7",
            "label": "7.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "7.0",
            "dimensions": {
              "internalDiameterMm": 7,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-75",
            "label": "7.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "7.5",
            "dimensions": {
              "internalDiameterMm": 7.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-8",
            "label": "8.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "8.0",
            "dimensions": {
              "internalDiameterMm": 8,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-85",
            "label": "8.5 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "8.5",
            "dimensions": {
              "internalDiameterMm": 8.5,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ETT-9",
            "label": "9.0 mm ID",
            "scaleType": "mm-ID",
            "scaleValue": "9.0",
            "dimensions": {
              "internalDiameterMm": 9,
              "outerDiameterMm": "conferir fabricante",
              "length": "conferir fabricante"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M10-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de tubo endotraqueal"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-AIR-002",
        "preferredName": "Bolsa-válvula-máscara",
        "aliases": [
          "BVM",
          "Ambu",
          "bolsa autoinflável",
          "bag valve mask"
        ],
        "categoryId": "via-aerea",
        "description": "Sistema manual de ventilação composto por bolsa, válvulas, reservatório e interfaces compatíveis.",
        "generalIndications": [
          "Ventilação manual quando indicada"
        ],
        "risks": [
          "Ventilação inadequada, pressão excessiva, vazamento, conexão incorreta e ausência de oxigênio"
        ],
        "alternatives": [
          "Ventilador ou outro dispositivo conforme contexto"
        ],
        "precautions": [
          "Treinamento, tamanho de máscara, técnica a duas mãos quando necessária, válvulas e reservatório conferidos"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "BVM-ADULT",
            "label": "Conjunto adulto",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BVM-PED",
            "label": "Conjunto pediátrico",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BVM-NEO",
            "label": "Conjunto neonatal",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M10-03",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M12-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de bolsa-válvula-máscara"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-AIR-003",
        "preferredName": "Cânula nasal de oxigênio",
        "aliases": [
          "cateter nasal",
          "óculos nasal",
          "nasal cannula"
        ],
        "categoryId": "via-aerea",
        "description": "Interface de oxigenoterapia de baixo fluxo; desenho, tamanho e limites de fluxo são específicos do produto.",
        "generalIndications": [
          "Oxigenoterapia conforme avaliação e prescrição"
        ],
        "risks": [
          "Ressecamento, lesão de pele, desconexão e oferta inadequada"
        ],
        "alternatives": [
          "Máscara de oxigênio",
          "Sistema de alto fluxo específico"
        ],
        "precautions": [
          "Monitorar resposta; confirmar fluxo permitido e umidificação conforme protocolo"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "NC-ADULT",
            "label": "Adulto",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NC-PED",
            "label": "Pediátrica",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NC-NEO",
            "label": "Neonatal",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M10-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cânula nasal de oxigênio"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SUT-001",
        "preferredName": "Fio de sutura de nylon",
        "aliases": [
          "nylon",
          "náilon",
          "mononylon",
          "fio monofilamentar não absorvível",
          "nylon 4-0"
        ],
        "categoryId": "fechamento",
        "description": "Fio sintético não absorvível geralmente monofilamentar; memória, calibre, agulha, cor e apresentação variam.",
        "generalIndications": [
          "Aproximação de tecidos quando material e calibre forem adequados"
        ],
        "risks": [
          "Reação tecidual, infecção, deiscência, marca de ponto e seleção inadequada"
        ],
        "alternatives": [
          "Polipropileno",
          "Fio absorvível quando indicado"
        ],
        "precautions": [
          "Selecionar pelo tecido, tensão, contaminação, plano e IFU; USP não é conversão universal para mm"
        ],
        "scaleSystem": "USP",
        "variants": [
          {
            "id": "NYL-2O0",
            "label": "USP 2-0",
            "scaleType": "USP",
            "scaleValue": "2-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NYL-3O0",
            "label": "USP 3-0",
            "scaleType": "USP",
            "scaleValue": "3-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NYL-4O0",
            "label": "USP 4-0",
            "scaleType": "USP",
            "scaleValue": "4-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NYL-5O0",
            "label": "USP 5-0",
            "scaleType": "USP",
            "scaleValue": "5-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "NYL-6O0",
            "label": "USP 6-0",
            "scaleType": "USP",
            "scaleValue": "6-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M07-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M07-03",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M07-04",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-FDA-SUTURE",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de fio de sutura de nylon"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SUT-002",
        "preferredName": "Fio de sutura de poliglactina",
        "aliases": [
          "poliglactina",
          "polyglactin",
          "fio absorvível trançado",
          "vicryl"
        ],
        "categoryId": "fechamento",
        "description": "Fio sintético absorvível trançado; perfil de absorção, revestimento, resistência e apresentação dependem do produto.",
        "generalIndications": [
          "Aproximação de tecidos quando absorção e desempenho forem adequados"
        ],
        "risks": [
          "Reação, infecção, perda de resistência incompatível com cicatrização e seleção inadequada"
        ],
        "alternatives": [
          "Outro absorvível sintético",
          "Não absorvível quando indicado"
        ],
        "precautions": [
          "Conferir monografia/IFU, tecido, tempo de suporte e condição da ferida"
        ],
        "scaleSystem": "USP",
        "variants": [
          {
            "id": "PGL-0",
            "label": "USP 0",
            "scaleType": "USP",
            "scaleValue": "0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PGL-2O0",
            "label": "USP 2-0",
            "scaleType": "USP",
            "scaleValue": "2-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PGL-3O0",
            "label": "USP 3-0",
            "scaleType": "USP",
            "scaleValue": "3-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PGL-4O0",
            "label": "USP 4-0",
            "scaleType": "USP",
            "scaleValue": "4-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "PGL-5O0",
            "label": "USP 5-0",
            "scaleType": "USP",
            "scaleValue": "5-0",
            "dimensions": {
              "diameterRange": "consultar monografia aplicável e IFU"
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M07-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M07-08",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-FDA-SUTURE",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de fio de sutura de poliglactina"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-SUT-003",
        "preferredName": "Agulha cirúrgica",
        "aliases": [
          "agulha de sutura",
          "agulha cortante",
          "agulha cilíndrica",
          "taper needle"
        ],
        "categoryId": "fechamento",
        "description": "Agulha acoplada ou avulsa caracterizada por ponta, corpo, curvatura, comprimento e relação com o fio.",
        "generalIndications": [
          "Passagem do fio por tecido compatível com o desenho"
        ],
        "risks": [
          "Trauma, perfurocortante, deformação, quebra e ponta inadequada"
        ],
        "alternatives": [
          "Agulha atraumática integrada ao fio"
        ],
        "precautions": [
          "Confirmar desenho, curvatura e tecido; manipular com porta-agulhas apropriado"
        ],
        "scaleSystem": null,
        "variants": [
          {
            "id": "SNEED-CUT",
            "label": "Cortante convencional",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SNEED-RCUT",
            "label": "Cortante reversa",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          },
          {
            "id": "SNEED-TAPER",
            "label": "Cilíndrica",
            "scaleType": null,
            "scaleValue": null,
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M07-02",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-FDA-SUTURE",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": "14/10/2026",
            "status": "revisao-editorial"
          },
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de agulha cirúrgica"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-001",
        "preferredName": "Cabo de bisturi",
        "aliases": [
          "cabo nº 3",
          "cabo nº 4",
          "scalpel handle"
        ],
        "categoryId": "instrumentais",
        "description": "Suporte reutilizável ou descartável para lâmina compatível; número do cabo indica família de encaixe.",
        "generalIndications": [
          "Suporte de lâmina compatível em incisão ou dissecção"
        ],
        "risks": [
          "Corte acidental, encaixe incompleto, lâmina incompatível e reprocessamento inadequado"
        ],
        "alternatives": [
          "Bisturi descartável integrado"
        ],
        "precautions": [
          "Montagem e retirada com técnica segura e dispositivo apropriado"
        ],
        "scaleSystem": "blade",
        "variants": [
          {
            "id": "HANDLE-3",
            "label": "Cabo nº 3",
            "scaleType": "blade",
            "scaleValue": "3",
            "compatibility": "Lâminas 10, 11, 12 e 15 em padrões usuais; confirmar fabricante",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "HANDLE-4",
            "label": "Cabo nº 4",
            "scaleType": "blade",
            "scaleValue": "4",
            "compatibility": "Lâminas 20 a 24 em padrões usuais; confirmar fabricante",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-06",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M16-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [
          {
            "withMaterialId": "MAT-INS-002",
            "relationship": "compativel-condicional",
            "condition": "Família de encaixe cabo/lâmina e fabricante compatíveis",
            "note": "Não forçar encaixe"
          }
        ],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de cabo de bisturi"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-002",
        "preferredName": "Lâmina de bisturi",
        "aliases": [
          "lâmina 10",
          "lâmina 11",
          "lâmina 12",
          "lâmina 15",
          "lâmina 20",
          "lâmina 21",
          "lâmina 22",
          "lâmina 23",
          "lâmina 24"
        ],
        "categoryId": "instrumentais",
        "description": "Componente cortante identificado por número de formato; o número não é uma escala linear de tamanho.",
        "generalIndications": [
          "Incisão ou dissecção conforme formato e indicação"
        ],
        "risks": [
          "Perfurocortante, quebra, encaixe inadequado e descarte incorreto"
        ],
        "alternatives": [
          "Bisturi descartável",
          "Energia cirúrgica quando indicada"
        ],
        "precautions": [
          "Confirmar integridade, número, cabo e técnica de descarte"
        ],
        "scaleSystem": "blade",
        "variants": [
          {
            "id": "BLADE-10",
            "label": "Lâmina nº 10",
            "scaleType": "blade",
            "scaleValue": "10",
            "compatibility": "Cabo nº 3",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-11",
            "label": "Lâmina nº 11",
            "scaleType": "blade",
            "scaleValue": "11",
            "compatibility": "Cabo nº 3",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-12",
            "label": "Lâmina nº 12",
            "scaleType": "blade",
            "scaleValue": "12",
            "compatibility": "Cabo nº 3",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-15",
            "label": "Lâmina nº 15",
            "scaleType": "blade",
            "scaleValue": "15",
            "compatibility": "Cabo nº 3",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-20",
            "label": "Lâmina nº 20",
            "scaleType": "blade",
            "scaleValue": "20",
            "compatibility": "Cabo nº 4",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-21",
            "label": "Lâmina nº 21",
            "scaleType": "blade",
            "scaleValue": "21",
            "compatibility": "Cabo nº 4",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-22",
            "label": "Lâmina nº 22",
            "scaleType": "blade",
            "scaleValue": "22",
            "compatibility": "Cabo nº 4",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-23",
            "label": "Lâmina nº 23",
            "scaleType": "blade",
            "scaleValue": "23",
            "compatibility": "Cabo nº 4",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "BLADE-24",
            "label": "Lâmina nº 24",
            "scaleType": "blade",
            "scaleValue": "24",
            "compatibility": "Cabo nº 4",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-06",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          },
          {
            "topicId": "PT-M16-01",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de lâmina de bisturi"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-003",
        "preferredName": "Porta-agulhas Mayo-Hegar",
        "aliases": [
          "Mayo Hegar",
          "porta agulha",
          "needle holder"
        ],
        "categoryId": "instrumentais",
        "description": "Instrumental com cremalheira e mandíbulas para controlar agulhas de sutura; comprimento e inserto variam.",
        "generalIndications": [
          "Manipulação de agulha compatível em fechamento"
        ],
        "risks": [
          "Dano à agulha, perda de controle, cremalheira defeituosa e uso como pinça"
        ],
        "alternatives": [
          "Outro porta-agulhas apropriado"
        ],
        "precautions": [
          "Inspecionar alinhamento, serrilha e trava; combinar tamanho com agulha"
        ],
        "scaleSystem": "pattern",
        "variants": [
          {
            "id": "MH-14",
            "label": "Mayo-Hegar 14 cm",
            "scaleType": "pattern",
            "scaleValue": "Mayo-Hegar",
            "dimensions": {
              "lengthMm": 140
            },
            "manufacturerVerificationRequired": true
          },
          {
            "id": "MH-16",
            "label": "Mayo-Hegar 16 cm",
            "scaleType": "pattern",
            "scaleValue": "Mayo-Hegar",
            "dimensions": {
              "lengthMm": 160
            },
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-07",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de porta-agulhas mayo-hegar"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-004",
        "preferredName": "Pinça Adson",
        "aliases": [
          "Adson anatômica",
          "Adson com dente",
          "pinça dente de rato"
        ],
        "categoryId": "instrumentais",
        "description": "Pinça de dissecção manual com versões lisas ou dentadas; ponta e comprimento definem aplicação.",
        "generalIndications": [
          "Preensão ou manipulação de tecido conforme versão"
        ],
        "risks": [
          "Trauma por pressão ou dente, ponta desalinhada e uso em tecido inadequado"
        ],
        "alternatives": [
          "Outra pinça de dissecção"
        ],
        "precautions": [
          "Distinguir versão lisa/dentada e inspecionar ponta"
        ],
        "scaleSystem": "pattern",
        "variants": [
          {
            "id": "ADSON-PLAIN",
            "label": "Adson anatômica",
            "scaleType": "pattern",
            "scaleValue": "Adson lisa",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "ADSON-TOOTH",
            "label": "Adson com dente",
            "scaleType": "pattern",
            "scaleValue": "Adson 1x2",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-03",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de pinça adson"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-005",
        "preferredName": "Pinça hemostática Kelly",
        "aliases": [
          "Kelly reta",
          "Kelly curva",
          "hemostat Kelly"
        ],
        "categoryId": "instrumentais",
        "description": "Pinça com anéis e cremalheira, reta ou curva, com padrão de serrilha próprio.",
        "generalIndications": [
          "Hemostasia ou dissecção conforme técnica e tamanho"
        ],
        "risks": [
          "Esmagamento de tecido, trava defeituosa, desalinhamento e identificação incorreta"
        ],
        "alternatives": [
          "Mosquito",
          "Crile",
          "outra hemostática"
        ],
        "precautions": [
          "Inspecionar serrilha, articulação e cremalheira; diferenciar de outros padrões"
        ],
        "scaleSystem": "pattern",
        "variants": [
          {
            "id": "KELLY-STRAIGHT",
            "label": "Kelly reta",
            "scaleType": "pattern",
            "scaleValue": "Kelly",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "KELLY-CURVED",
            "label": "Kelly curva",
            "scaleType": "pattern",
            "scaleValue": "Kelly",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-02",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de pinça hemostática kelly"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-006",
        "preferredName": "Tesoura Metzenbaum",
        "aliases": [
          "Metzenbaum reta",
          "Metzenbaum curva",
          "tesoura de dissecção"
        ],
        "categoryId": "instrumentais",
        "description": "Tesoura delicada de dissecção, disponível em comprimentos e curvaturas diferentes.",
        "generalIndications": [
          "Dissecção de tecidos delicados conforme indicação"
        ],
        "risks": [
          "Dano ao corte, uso em material inadequado, ponta defeituosa e perda de fio"
        ],
        "alternatives": [
          "Tesoura Mayo para tecidos/materiais compatíveis"
        ],
        "precautions": [
          "Não usar para cortar fios ou materiais quando não previsto; testar alinhamento"
        ],
        "scaleSystem": "pattern",
        "variants": [
          {
            "id": "METZ-STRAIGHT",
            "label": "Metzenbaum reta",
            "scaleType": "pattern",
            "scaleValue": "Metzenbaum",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "METZ-CURVED",
            "label": "Metzenbaum curva",
            "scaleType": "pattern",
            "scaleValue": "Metzenbaum",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de tesoura metzenbaum"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-007",
        "preferredName": "Tesoura Mayo",
        "aliases": [
          "Mayo reta",
          "Mayo curva",
          "tesoura robusta"
        ],
        "categoryId": "instrumentais",
        "description": "Tesoura robusta com versões reta e curva; dimensões e aplicação dependem do padrão.",
        "generalIndications": [
          "Corte de tecido ou material conforme versão e protocolo"
        ],
        "risks": [
          "Uso em estrutura inadequada, perda de fio, ponta danificada e identificação incorreta"
        ],
        "alternatives": [
          "Metzenbaum em dissecção delicada"
        ],
        "precautions": [
          "Diferenciar versões e finalidade local; inspecionar corte"
        ],
        "scaleSystem": "pattern",
        "variants": [
          {
            "id": "MAYO-STRAIGHT",
            "label": "Mayo reta",
            "scaleType": "pattern",
            "scaleValue": "Mayo",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "MAYO-CURVED",
            "label": "Mayo curva",
            "scaleType": "pattern",
            "scaleValue": "Mayo",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-05",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de tesoura mayo"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      },
      {
        "id": "MAT-INS-008",
        "preferredName": "Afastador Farabeuf",
        "aliases": [
          "Farabeuf",
          "afastador manual"
        ],
        "categoryId": "instrumentais",
        "description": "Afastador manual de duas extremidades, disponível em tamanhos e desenhos diferentes.",
        "generalIndications": [
          "Afastamento manual quando apropriado ao acesso"
        ],
        "risks": [
          "Pressão excessiva, lesão de tecidos, escorregamento e tamanho inadequado"
        ],
        "alternatives": [
          "Outro afastador manual ou autoestático"
        ],
        "precautions": [
          "Aplicar sob visão e comunicação da equipe; conferir bordas e integridade"
        ],
        "scaleSystem": "pattern",
        "variants": [
          {
            "id": "FAR-SMALL",
            "label": "Farabeuf pequeno",
            "scaleType": "pattern",
            "scaleValue": "Farabeuf",
            "manufacturerVerificationRequired": true
          },
          {
            "id": "FAR-LARGE",
            "label": "Farabeuf grande",
            "scaleType": "pattern",
            "scaleValue": "Farabeuf",
            "manufacturerVerificationRequired": true
          }
        ],
        "procedureLinks": [
          {
            "topicId": "PT-M02-04",
            "role": "dependente-indicacao",
            "note": "Seleção depende do procedimento, paciente e protocolo local"
          }
        ],
        "compatibility": [],
        "provenance": [
          {
            "sourceId": "SRC-MAT-IFU",
            "claimScope": "Identificação, escala, segurança ou compatibilidade conforme aplicável",
            "reviewedOn": null,
            "status": "pendente-fabricante"
          }
        ],
        "visual": {
          "kind": "original-schematic",
          "assetId": "atlas-inline-svg",
          "author": "Nexo Cirúrgico",
          "license": "Original do projeto",
          "sourceUrl": null,
          "alt": "Esquema vetorial original de afastador farabeuf"
        },
        "review": {
          "status": "revisao-editorial",
          "version": "0.1",
          "clinicalReviewer": null,
          "reviewedOn": null
        }
      }
    ],
    "relationRoles": [
      {
        "id": "obrigatorio",
        "title": "Obrigatório na configuração descrita"
      },
      {
        "id": "alternativa",
        "title": "Alternativa"
      },
      {
        "id": "dependente-indicacao",
        "title": "Dependente de indicação"
      }
    ],
    "reviewWorkflow": [
      "rascunho",
      "revisao-editorial",
      "revisao-tecnica",
      "validado",
      "publicado"
    ],
    "visualPolicy": "Somente esquemas originais ou ativos com autor, URL e licença verificável. Ausência de licença exige placeholder próprio."
  }
};
