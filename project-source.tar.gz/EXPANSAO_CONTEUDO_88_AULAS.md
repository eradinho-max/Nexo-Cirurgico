# Nexo Cirúrgico — expansão para 88 aulas

**Data:** 13 de outubro de 2026  
**Motivo:** reequilibrar conteúdo didático e avaliação  
**Estado:** expansão incorporada; revisão clínica consolidada permanece adiada

> **Nota histórica:** este documento registra o lote que elevou a plataforma a 88 aulas. O lote seguinte acrescentou procedimentos e acessos, levando o estado atual a 33 trilhas e 115 aulas; consulte `MATRIZ_PROCEDIMENTOS_E_ACESSOS.md`.

## 1. Resultado

| Indicador | Antes | Depois |
|---|---:|---:|
| Trilhas | 28 | 28 |
| Aulas | 58 | 88 |
| Minutos | 1.008 | 1.567 |
| Flashcards | 80 | 110 |
| Itens de checklist | 25 | 65 |
| Questões | 210 | 210 |
| Casos | 30 | 30 |
| Questões por aula | 3,62 | 2,39 |

Nenhuma questão ou caso novo foi criado neste lote. As 210 questões permanecem como banco interno, e o simulado continua sorteando apenas 20 itens por tentativa.

## 2. Dez aulas adicionadas ao núcleo

1. Instrumentais — integridade, teste funcional e resposta a falhas;
2. Fios e suturas — seleção contextual e rastreabilidade;
3. Posicionamento — reavaliação após mudanças de posição e mesa;
4. Anatomia — orientação anatômica e comunicação espacial;
5. CME — barreira estéril, armazenamento e eventos de pacote;
6. Anestesia/SRPA — alarmes e interface multiprofissional;
7. Energia — falhas e contingência segura;
8. Medicamentos — reconciliação no campo estéril;
9. Documentação — linha do tempo perioperatória;
10. Eventos críticos — debriefing e aprendizagem do sistema.

## 3. Vinte aulas adicionadas às especialidades P2

Cada especialidade passou de duas para quatro aulas:

- cirurgia geral: transições de contaminação; dispositivos e handoff;
- ortopedia: torniquete e alertas; componentes, prova e cimento;
- ginecologia/obstetrícia: fluidos e espécimes; hemorragia e coordenação;
- urologia: circuito de irrigação; stents e cadeia de saída;
- vascular: sala híbrida; marcos e explantes;
- neurocirurgia/coluna: navegação e neuromonitorização; nível e tecnologia;
- cabeça e pescoço: via aérea e fogo; retalho e monitorização;
- torácica/cardíaca: ventilação e conversão; marcos e transferência;
- pediátrica/neonatal: microcomponentes e medicamentos; cadeia térmica e transporte;
- robótica: posicionamento e acesso; conversão e rastreabilidade.

## 4. Apoios de estudo

- 30 flashcards novos, um para cada aula adicionada;
- dez roteiros de checklist por especialidade, com quatro itens cada;
- manutenção dos limites profissionais e do condicionamento a protocolo, equipe habilitada e instrução do fabricante;
- conteúdo textual original, sem copiar tabelas, imagens ou trechos de publicações.

## 5. Auditoria estrutural

Execute:

```bash
node qa_content.js
node qa_assessment.js
```

Resultado atual do conteúdo:

- 28 módulos;
- 88 aulas;
- 1.567 minutos;
- 110 flashcards;
- 65 itens de checklist;
- 2,39 questões por aula;
- zero erros e zero sinais automáticos de revisão estrutural.

A auditoria de avaliação permanece aprovada com 210 questões, 30 casos, 28 competências e zero erros estruturais.

## 6. Limites e próximo gate

Esta expansão melhora volume e progressão, mas não comprova validação clínica. Continuam pendentes:

- revisão da sequência didática entre aulas e competências;
- anatomia visual somente com ativos próprios ou licenciados;
- revisão clínica independente;
- auditoria contextual dos itens;
- teste de acessibilidade e piloto com público-alvo.
