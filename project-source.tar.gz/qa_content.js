/* Auditoria estrutural reproduzível do conteúdo didático Nexo Cirúrgico.
   Execute com: node qa_content.js */
const path = require('path');
global.window = {};
require(path.join(__dirname, 'data.js'));
const data = window.NEXO_DATA;
const errors = [];
const flags = [];
const normalize = value => String(value).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const duplicates = values => [...new Set(values.filter((value, index) => values.indexOf(value) !== index))];
const sourceIds = new Set(data.evidence.map(item => item.id));
const evidenceById = new Map(data.evidence.map(item => [item.id, item]));
const lessons = data.modules.flatMap(module => module.lessons.map(lesson => ({...lesson, moduleId:module.id})));
const checklistItems = data.checklist.flatMap(section => section.items);

const targets = {modules:33, lessons:115, flashcards:137, checklistItems:90};
if (data.modules.length !== targets.modules) errors.push(`Módulos: ${data.modules.length}; meta ${targets.modules}.`);
if (lessons.length !== targets.lessons) errors.push(`Aulas: ${lessons.length}; meta ${targets.lessons}.`);
if (data.flashcards.length !== targets.flashcards) errors.push(`Flashcards: ${data.flashcards.length}; meta ${targets.flashcards}.`);
if (checklistItems.length !== targets.checklistItems) errors.push(`Itens de checklist: ${checklistItems.length}; meta ${targets.checklistItems}.`);

for (const [label, values] of [
  ['módulo', data.modules.map(item => item.id)],
  ['aula', lessons.map(item => item.id)],
  ['flashcard', data.flashcards.map(item => item.id)],
  ['título de checklist', data.checklist.map(item => normalize(item.title))],
]) {
  const found = duplicates(values);
  if (found.length) errors.push(`${label}: duplicados ${found.join(', ')}.`);
}

for (const module of data.modules) {
  if (module.lessons.length < 2) errors.push(`${module.id}: menos de duas aulas.`);
  if (!module.sourceIds?.length) errors.push(`${module.id}: sem fontes vinculadas.`);
  for (const sourceId of module.sourceIds || []) if (!sourceIds.has(sourceId)) errors.push(`${module.id}: fonte inexistente ${sourceId}.`);
  for (const lesson of module.lessons) {
    if (!lesson.title?.trim() || !lesson.summary?.trim()) errors.push(`${lesson.id}: título ou resumo ausente.`);
    if (!Number.isFinite(lesson.duration) || lesson.duration < 8) errors.push(`${lesson.id}: duração inválida.`);
    if (!Array.isArray(lesson.objectives) || lesson.objectives.length < 3) errors.push(`${lesson.id}: menos de três objetivos.`);
    if (!Array.isArray(lesson.sections) || lesson.sections.length < 3) errors.push(`${lesson.id}: menos de três tópicos.`);
    for (const [index, section] of (lesson.sections || []).entries()) {
      if (!section.title?.trim() || !section.body?.trim()) errors.push(`${lesson.id}: tópico ${index + 1} incompleto.`);
      if ((section.body || '').trim().length < 90) flags.push(`${lesson.id}: tópico ${index + 1} com texto curto.`);
    }
  }
}

for (const card of data.flashcards) {
  if (!card.deck?.trim() || !card.front?.trim() || !card.back?.trim()) errors.push(`Flashcard ${card.id}: campo vazio.`);
  if ((card.back || '').trim().length < 25) flags.push(`Flashcard ${card.id}: resposta curta.`);
}
const repeatedFronts = duplicates(data.flashcards.map(card => normalize(card.front)));
if (repeatedFronts.length) errors.push(`Flashcards com frente duplicada: ${repeatedFronts.join(' | ')}.`);

for (const section of data.checklist) {
  if (!Array.isArray(section.items) || section.items.length < 4) errors.push(`Checklist ${section.title}: menos de quatro itens.`);
  if (new Set(section.items.map(normalize)).size !== section.items.length) errors.push(`Checklist ${section.title}: itens duplicados.`);
}

const p2 = [
  ['cirurgia-geral-digestiva','Cirurgia geral'],
  ['ortopedia-trauma','Ortopedia'],
  ['ginecologia-obstetricia','Ginecologia e obstetrícia'],
  ['urologia','Urologia'],
  ['cirurgia-vascular','Vascular'],
  ['neurocirurgia-coluna','Neurocirurgia'],
  ['cabeca-pescoco','Cabeça e pescoço'],
  ['toracica-cardiaca','Torácica e cardíaca'],
  ['cirurgia-pediatrica-neonatal','Pediatria'],
  ['minimamente-invasiva-robotica','Robótica'],
];
for (const [moduleId, deck] of p2) {
  const module = data.modules.find(item => item.id === moduleId);
  if (!module || module.lessons.length !== 4) errors.push(`${moduleId}: deve ter quatro aulas P2.`);
  const cards = data.flashcards.filter(item => item.deck === deck).length;
  if (cards !== 4) errors.push(`${moduleId}: ${cards} flashcards; meta 4.`);
  const competency = data.competencies.find(item => item.moduleId === moduleId);
  if (!competency) errors.push(`${moduleId}: sem competência.`);
  else {
    const questions = data.quiz.filter(item => item.competencyId === competency.id).length;
    const cases = data.cases.filter(item => item.competencyId === competency.id).length;
    if (questions !== 6 || cases !== 1) errors.push(`${moduleId}: relação avaliação incompatível (${questions} questões, ${cases} casos).`);
  }
}

const proceduresExpansion = [
  ['procedimentos-vias-cirurgicas','Procedimentos e acessos',5,'Procedimentos e vias cirúrgicas — revisão'],
  ['acessos-vasculares-infusao','Acessos vasculares',6,'Acessos vasculares — revisão'],
  ['via-aerea-sondas-drenos','Vias, sondas e drenos',6,'Via aérea, sondas e drenos — revisão'],
  ['assepsia-antissepsia-pele','Assepsia e antissepsia',5,'Assepsia e preparo da pele — revisão'],
  ['procedimentos-perioperatorios','Procedimentos perioperatórios',5,'Procedimentos perioperatórios — revisão'],
];
for (const [moduleId, deck, expectedLessons, checklistTitle] of proceduresExpansion) {
  const module = data.modules.find(item => item.id === moduleId);
  if (!module || module.lessons.length !== expectedLessons) errors.push(`${moduleId}: deve ter ${expectedLessons} aulas.`);
  const cards = data.flashcards.filter(item => item.deck === deck).length;
  if (cards !== expectedLessons) errors.push(`${moduleId}: ${cards} flashcards; meta ${expectedLessons}.`);
  if (!data.checklist.some(item => item.title === checklistTitle)) errors.push(`${moduleId}: checklist de revisão ausente.`);
  const hasVerifiedSource = (module?.sourceIds || []).some(sourceId => evidenceById.get(sourceId)?.verifiedOn && evidenceById.get(sourceId)?.referenceStatus);
  if (!hasVerifiedSource) errors.push(`${moduleId}: nenhuma fonte documentalmente verificada.`);
}

const plans = data.studyPlans || [];
if (plans.length !== 3) errors.push(`Planos de estudo: ${plans.length}; meta 3.`);
const plannedModuleIds = plans.flatMap(plan => plan.moduleIds || []);
const plannedCompetencyIds = plans.flatMap(plan => plan.competencyIds || []);
const duplicatedPlanModules = duplicates(plannedModuleIds);
const duplicatedPlanCompetencies = duplicates(plannedCompetencyIds);
if (duplicatedPlanModules.length) errors.push(`Módulos repetidos nos planos: ${duplicatedPlanModules.join(', ')}.`);
if (duplicatedPlanCompetencies.length) errors.push(`Competências repetidas nos planos: ${duplicatedPlanCompetencies.join(', ')}.`);
if (new Set(plannedModuleIds).size !== data.modules.length || data.modules.some(module => !plannedModuleIds.includes(module.id))) errors.push('Planos de estudo não cobrem todos os módulos exatamente uma vez.');
if (new Set(plannedCompetencyIds).size !== data.competencies.length || data.competencies.some(item => !plannedCompetencyIds.includes(item.id))) errors.push('Planos de estudo não cobrem todas as competências exatamente uma vez.');
for (const plan of plans) {
  if (!plan.title?.trim() || !plan.description?.trim() || !plan.gate?.trim()) errors.push(`Plano ${plan.id}: metadados incompletos.`);
  if (!Array.isArray(plan.outcomes) || plan.outcomes.length < 3) errors.push(`Plano ${plan.id}: resultados esperados insuficientes.`);
  for (const moduleId of plan.moduleIds || []) if (!data.modules.some(module => module.id === moduleId)) errors.push(`Plano ${plan.id}: módulo inexistente ${moduleId}.`);
}

const remediationMap = data.remediationMap || [];
if (remediationMap.length !== data.competencies.length) errors.push(`Mapa de remediação: ${remediationMap.length} entradas; meta ${data.competencies.length}.`);
const remediationCompetencies = remediationMap.map(item => item.competencyId);
if (duplicates(remediationCompetencies).length) errors.push('Mapa de remediação contém competências duplicadas.');
for (const competency of data.competencies) if (!remediationCompetencies.includes(competency.id)) errors.push(`${competency.id}: sem remediação.`);
for (const item of remediationMap) {
  const competency = data.competencies.find(entry => entry.id === item.competencyId);
  if (!competency) errors.push(`Mapa de remediação referencia competência inexistente ${item.competencyId}.`);
  if (!item.focus?.trim()) errors.push(`${item.competencyId}: foco de remediação ausente.`);
  if (!Array.isArray(item.lessonIds) || item.lessonIds.length !== 3) errors.push(`${item.competencyId}: esperado exatamente três vínculos de aula.`);
  if (duplicates(item.lessonIds || []).length) errors.push(`${item.competencyId}: aula de remediação duplicada.`);
  for (const lessonId of item.lessonIds || []) if (!lessons.some(lesson => lesson.id === lessonId)) errors.push(`${item.competencyId}: aula de remediação inexistente ${lessonId}.`);
  const primaryModule = data.modules.find(module => module.id === competency?.moduleId);
  if (primaryModule && !(item.lessonIds || []).some(lessonId => primaryModule.lessons.some(lesson => lesson.id === lessonId))) errors.push(`${item.competencyId}: remediação não inclui aula da trilha principal.`);
}

const technical = data.technicalCurriculum;
if (!technical) errors.push('Matriz técnica ausente.');
else {
  const expectedTechnicalIds = Array.from({length:28}, (_,index) => `M${String(index+1).padStart(2,'0')}`);
  const technicalIds = technical.modules?.map(item => item.id) || [];
  if (technicalIds.length !== 28 || expectedTechnicalIds.some(id => !technicalIds.includes(id))) errors.push('Matriz técnica deve conter M01–M28 exatamente uma vez.');
  if (duplicates(technicalIds).length) errors.push('Matriz técnica contém módulos duplicados.');
  const categoryIds = (technical.categories || []).map(item => item.id);
  if (duplicates(categoryIds).length) errors.push('Matriz técnica contém categorias duplicadas.');
  const topics = (technical.modules || []).flatMap(module => (module.topics || []).map(topic => ({...topic,moduleId:module.id})));
  const topicIds = topics.map(topic => topic.id);
  if (topicIds.length !== 227) errors.push(`Matriz técnica: ${topicIds.length} tópicos; esperado 227.`);
  if (duplicates(topicIds).length) errors.push('Matriz técnica contém IDs de tópico duplicados.');
  if (!Array.isArray(technical.lessonSchema) || technical.lessonSchema.length !== 14) errors.push('Ficha técnica deve conter exatamente 14 campos.');
  if (duplicates((technical.lessonSchema || []).map(item => item.id)).length) errors.push('Ficha técnica contém campos duplicados.');
  if (!technical.primaryAudience?.includes('Medicina')) errors.push('Público principal da matriz técnica não está definido para formação médica.');
  if (!technical.scopeStatement?.trim()) errors.push('Limite profissional da matriz técnica ausente.');
  if (!Array.isArray(technical.macroblocks) || technical.macroblocks.length !== 8) errors.push('Programa de expansão deve conter oito macroblocos.');
  if (duplicates((technical.macroblocks || []).map(item => item.id)).length) errors.push('Programa de expansão contém macroblocos duplicados.');
  const deliveredMacroblocks=(technical.macroblocks || []).filter(item => item.status === 'Entregue').map(item=>item.id);
  if (deliveredMacroblocks.join(',') !== 'MB01,MB02') errors.push(`Macroblocos entregues inesperados: ${deliveredMacroblocks.join(',')}.`);
  const workflowIds=(technical.topicStatusWorkflow || []).map(item=>item.id);
  const expectedWorkflow=['catalogado','em-desenvolvimento','revisao-tecnica','validado','publicado'];
  if (workflowIds.join(',') !== expectedWorkflow.join(',')) errors.push('Fluxo editorial por tópico inválido.');
  const canonicalIds=(technical.canonicalProcedures || []).map(item=>item.id);
  if (canonicalIds.length !== 224 || duplicates(canonicalIds).length) errors.push(`Procedimentos canônicos: ${canonicalIds.length}; esperado 224 IDs únicos.`);
  const canonicalSet=new Set(canonicalIds);
  const relationIds=[];
  for (const item of technical.modules || []) {
    if (!categoryIds.includes(item.categoryId)) errors.push(`${item.id}: categoria técnica inexistente.`);
    if (!['Base existente','Cobertura parcial','Lacuna prioritária'].includes(item.coverage)) errors.push(`${item.id}: estado de cobertura inválido.`);
    if (!item.priority?.trim() || !item.title?.trim() || !(item.topics || []).length) errors.push(`${item.id}: metadados ou tópicos incompletos.`);
    const bounds=(item.priority.match(/P[0-2]/g)||[]).map(value=>Number(value[1]));
    const expectedLevels=bounds.length ? Array.from({length:Math.max(...bounds)-Math.min(...bounds)+1},(_,i)=>`P${Math.min(...bounds)+i}`) : [];
    if ((item.priorityLevels || []).join(',') !== expectedLevels.join(',')) errors.push(`${item.id}: níveis de prioridade inconsistentes com ${item.priority}.`);
    for (const moduleId of item.existingModuleIds || []) if (!data.modules.some(module => module.id === moduleId)) errors.push(`${item.id}: trilha atual inexistente ${moduleId}.`);
    for (const lessonId of item.existingLessonIds || []) if (!lessons.some(lesson => lesson.id === lessonId)) errors.push(`${item.id}: aula atual inexistente ${lessonId}.`);
    if ((item.lessonRelations || []).length !== (item.existingLessonIds || []).length) errors.push(`${item.id}: migração não preservou todos os vínculos antigos.`);
    for (const relation of item.lessonRelations || []) {
      relationIds.push(relation.id);
      if (!['cobertura-direta','fundamento','pre-requisito'].includes(relation.relationType)) errors.push(`${relation.id}: tipo de relação inválido.`);
      if (!item.existingLessonIds.includes(relation.lessonId)) errors.push(`${relation.id}: relação não corresponde ao vínculo legado.`);
      if (relation.relationType === 'cobertura-direta' && !(relation.targetTopicIds || []).length) errors.push(`${relation.id}: cobertura direta sem tópico-alvo.`);
      for (const topicId of relation.targetTopicIds || []) if (!item.topics.some(topic=>topic.id===topicId)) errors.push(`${relation.id}: tópico-alvo fora do módulo ${topicId}.`);
    }
    for (const topic of item.topics || []) {
      if (!topic.title?.trim() || !topic.id.startsWith(`PT-${item.id}-`)) errors.push(`${item.id}: tópico técnico inválido ${topic.id}.`);
      if (!workflowIds.includes(topic.status)) errors.push(`${topic.id}: status editorial inválido.`);
      if (!Array.isArray(topic.priorityLevels) || !topic.priorityLevels.length || topic.priorityLevels.some(value=>!['P0','P1','P2'].includes(value))) errors.push(`${topic.id}: prioridade por tópico inválida.`);
      if (!Array.isArray(topic.aliases)) errors.push(`${topic.id}: aliases ausentes.`);
      if (!canonicalSet.has(topic.canonicalProcedureId)) errors.push(`${topic.id}: procedimento canônico inexistente.`);
      if (!topic.revision?.version || !topic.revision?.state) errors.push(`${topic.id}: revisão editorial ausente.`);
    }
  }
  if (relationIds.length !== 254 || duplicates(relationIds).length) errors.push(`Relações de aula: ${relationIds.length}; esperado 254 IDs únicos.`);
  const titleGroups=new Map();
  for (const topic of topics) { const key=normalize(topic.title); if(!titleGroups.has(key))titleGroups.set(key,[]); titleGroups.get(key).push(topic); }
  for (const group of titleGroups.values()) if (group.length>1 && new Set(group.map(topic=>topic.canonicalProcedureId)).size!==1) errors.push(`Duplicidade sem ficha canônica compartilhada: ${group[0].title}.`);
  for (const canonical of technical.canonicalProcedures || []) {
    if (!canonical.preferredTitle?.trim() || !canonical.contexts?.length) errors.push(`${canonical.id}: ficha canônica incompleta.`);
    for (const context of canonical.contexts || []) if (!topicIds.includes(context.topicId) || !technicalIds.includes(context.moduleId)) errors.push(`${canonical.id}: contexto inválido.`);
  }
  const topicSearch = topics.map(topic=>normalize(`${topic.title} ${(topic.aliases||[]).join(' ')}`));
  for (const [term,label] of [['ecg','ECG'],['puncao','punção'],['cateter periferico','cateter periférico'],['picc','PICC'],['sutura simples','sutura simples']]) if (!topicSearch.some(value=>value.includes(normalize(term)))) errors.push(`Busca técnica sem alias para ${label}.`);
}

const atlas=data.materialAtlas;
if (!atlas) errors.push('Atlas de materiais ausente.');
else {
  const materialIds=atlas.materials.map(item=>item.id);
  const atlasCategoryIds=atlas.categories.map(item=>item.id);
  const scaleIds=atlas.scaleSystems.map(item=>item.id);
  const atlasSourceIds=atlas.sources.map(item=>item.id);
  const atlasTopicIds=new Set((technical?.modules||[]).flatMap(module=>module.topics.map(topic=>topic.id)));
  const variantIds=atlas.materials.flatMap(item=>item.variants.map(variant=>variant.id));
  if (atlas.materials.length !== 41 || duplicates(materialIds).length) errors.push(`Atlas: ${atlas.materials.length} materiais; esperado 41 IDs únicos.`);
  if (atlas.categories.length !== 8 || duplicates(atlasCategoryIds).length) errors.push('Atlas deve conter oito categorias únicas.');
  if (atlas.scaleSystems.length !== 7 || duplicates(scaleIds).length) errors.push('Atlas deve conter sete sistemas de escala únicos.');
  if (atlas.sources.length !== 10 || duplicates(atlasSourceIds).length) errors.push('Atlas deve conter dez fontes/requisitos únicos.');
  if (variantIds.length !== 158 || duplicates(variantIds).length) errors.push(`Atlas: ${variantIds.length} variantes; esperado 158 IDs únicos.`);
  for (const source of atlas.sources) if (!source.url && !source.manufacturerRequirement) errors.push(`${source.id}: fonte sem URL ou requisito de fabricante.`);
  for (const item of atlas.materials) {
    if (!item.preferredName?.trim() || !Array.isArray(item.aliases) || !item.aliases.length || !item.description?.trim()) errors.push(`${item.id}: identificação incompleta.`);
    if (!atlasCategoryIds.includes(item.categoryId)) errors.push(`${item.id}: categoria inexistente.`);
    if (item.scaleSystem && !scaleIds.includes(item.scaleSystem)) errors.push(`${item.id}: escala inexistente.`);
    if (!item.variants?.length || !item.procedureLinks?.length || !item.provenance?.length) errors.push(`${item.id}: variantes, procedimentos ou proveniência ausentes.`);
    if (!item.visual?.author || !item.visual?.license || !item.visual?.alt) errors.push(`${item.id}: atribuição visual incompleta.`);
    if (!item.review?.status || !item.review?.version) errors.push(`${item.id}: estado de revisão ausente.`);
    for (const variant of item.variants || []) if (!variant.manufacturerVerificationRequired) errors.push(`${variant.id}: verificação de fabricante não exigida.`);
    for (const link of item.procedureLinks || []) {
      if (!atlasTopicIds.has(link.topicId)) errors.push(`${item.id}: tópico relacionado inexistente ${link.topicId}.`);
      if (!['obrigatorio','alternativa','dependente-indicacao'].includes(link.role)) errors.push(`${item.id}: papel de material inválido.`);
    }
    for (const relation of item.compatibility || []) if (!materialIds.includes(relation.withMaterialId) || !relation.condition?.trim()) errors.push(`${item.id}: compatibilidade inválida.`);
    for (const provenance of item.provenance || []) if (!atlasSourceIds.includes(provenance.sourceId)) errors.push(`${item.id}: fonte inexistente ${provenance.sourceId}.`);
  }
  const materialSearch=atlas.materials.map(item=>normalize(`${item.preferredName} ${item.aliases.join(' ')} ${item.variants.map(v=>`${v.label} ${v.scaleValue||''}`).join(' ')}`));
  for (const term of ['jelco','cateter intravenoso','iv','24g','sonda foley','14 fr','nylon 4 0','lamina 15']) {
    const found=materialSearch.some(value=>term.length<=2 ? value.split(' ').includes(term) : value.includes(term));
    if (!found) errors.push(`Atlas sem termo de demonstração: ${term}.`);
  }
}

const minutes = lessons.reduce((sum, lesson) => sum + lesson.duration, 0);
const ratio = data.quiz.length / lessons.length;
const summary = {
  status: errors.length ? 'FALHOU' : 'APROVADO NA AUDITORIA ESTRUTURAL DE CONTEÚDO',
  modules:data.modules.length,
  lessons:lessons.length,
  minutes,
  flashcards:data.flashcards.length,
  checklistSections:data.checklist.length,
  checklistItems:checklistItems.length,
  sources:data.evidence.length,
  questions:data.quiz.length,
  questionsPerLesson:Number(ratio.toFixed(2)),
  p2Lessons:p2.reduce((sum, [moduleId]) => sum + data.modules.find(item => item.id === moduleId).lessons.length, 0),
  proceduresAndAccessLessons:proceduresExpansion.reduce((sum, [moduleId]) => sum + data.modules.find(item => item.id === moduleId).lessons.length, 0),
  studyPlans:plans.map(plan => ({id:plan.id, modules:plan.moduleIds.length, lessons:plan.moduleIds.reduce((sum, moduleId) => sum + data.modules.find(item => item.id === moduleId).lessons.length, 0)})),
  remediationEntries:remediationMap.length,
  technicalCurriculum:technical ? {
    modules:technical.modules.length,
    categories:technical.categories.length,
    topics:technical.modules.reduce((sum,item) => sum + item.topics.length,0),
    lessonSchemaFields:technical.lessonSchema.length,
    macroblocks:technical.macroblocks.length,
    deliveredMacroblocks:technical.macroblocks.filter(item=>item.status==='Entregue').map(item=>item.id),
    canonicalProcedures:technical.canonicalProcedures.length,
    lessonRelations:technical.modules.reduce((sum,item)=>sum+item.lessonRelations.length,0),
    mappedCurrentLessons:new Set(technical.modules.flatMap(item => item.existingLessonIds)).size
  } : null,
  materialAtlas:atlas ? {
    materials:atlas.materials.length,
    variants:atlas.materials.reduce((sum,item)=>sum+item.variants.length,0),
    categories:atlas.categories.length,
    scaleSystems:atlas.scaleSystems.length,
    sourcesAndRequirements:atlas.sources.length
  } : null,
  errors,
  reviewFlagsCount:flags.length,
  reviewFlags:flags,
};
console.log(JSON.stringify(summary, null, 2));
if (errors.length) process.exit(1);
