import json,subprocess
from pathlib import Path
root=Path(__file__).parent
js=subprocess.check_output(['node','-e',"const fs=require('fs'),vm=require('vm');const c={window:{}};vm.runInNewContext(fs.readFileSync('data.js','utf8'),c);vm.runInNewContext(fs.readFileSync('procedimentos_mb03.js','utf8'),c);console.log(JSON.stringify({module:c.window.NEXO_DATA.modules.map(m=>({title:m.title,lessons:m.lessons.map(l=>l.title)})),proc:c.window.NEXO_PROCEDURES.procedures.map(p=>p.title),topics:c.window.NEXO_DATA.technicalCurriculum.modules.map(m=>m.title)}))"],cwd=root).decode()
d=json.loads(js)
modules_es='''Instrumental quirúrgico|Hilos y suturas|Posicionamiento quirúrgico|Asepsia y seguridad|Anatomía aplicada|Flujo de procedimientos|Entorno y equipo quirúrgico|Cirugía segura|Prevención de la infección quirúrgica|Recuento y objetos retenidos|Muestras e implantes|Central de esterilización y procesamiento|Energía, fuego y humo|Medicamentos y etiquetado|Anestesia y recuperación posanestésica|Seguridad laboral|Documentación, ética y privacidad|Eventos críticos y emergencias|Cirugía general y digestiva|Ortopedia y traumatología|Ginecología y obstetricia|Urología|Cirugía vascular|Neurocirugía y columna vertebral|Cabeza y cuello|Cirugía torácica y cardíaca|Cirugía pediátrica y neonatal|Cirugía mínimamente invasiva y robótica|Procedimientos y vías de acceso quirúrgico|Accesos vasculares y terapia de infusión|Vía aérea, sondas y drenajes|Asepsia, antisepsia y preparación de la piel|Procedimientos perioperatorios esenciales'''.split('|')
assert len(modules_es)==33,len(modules_es)
lessons_es='''La lógica de las categorías|Diferencias que generan confusión|Integridad, prueba funcional y respuesta ante fallas
Cómo clasificar un hilo|Agujas y principios de sutura|Selección según el contexto y trazabilidad de las suturas
Posiciones fundamentales|Lista de verificación del posicionamiento|Reevaluación después de cambios de posición y de la mesa
Principios del campo estéril|Recuento y comunicación
Planos y tejidos|Abdomen: referencias de orientación|Orientación anatómica y comunicación espacial
Tiempos quirúrgicos|Muestras y cierre seguro
Áreas, circulación y flujo seguro|Funciones, límites y responsabilidades
Los tres momentos de la lista de verificación|Comunicación y factores humanos
Preparación preoperatoria|Medidas intraoperatorias y posoperatorias
Cómo realizar un recuento fiable|Discrepancia: respuesta y documentación
Cadena segura de muestras|Implantes y trazabilidad
Flujo, clasificación y limpieza|Inspección, preparación y embalaje|Seguimiento y trazabilidad|Barrera estéril, almacenamiento e incidencias del paquete
Principios de energía quirúrgica|Incendio en el campo: prevención|Humo quirúrgico y jerarquía de controles|Fallas de energía quirúrgica y contingencia segura
Etiquetado en el campo y en quirófano|Medicamentos de alto riesgo y barreras de administración|Conciliación de medicamentos en el campo estéril
Fases y seguridad anestésica|Recuperación posanestésica: traslado y vigilancia|Alarmas y coordinación multiprofesional con anestesia
Riesgo biológico y objetos cortopunzantes|Riesgos químicos, físicos y ergonómicos
Registro perioperatorio de calidad|Privacidad y datos de salud|Cronología perioperatoria y trazabilidad
Liderazgo y comunicación en crisis|Preparación para eventos de alto riesgo|Análisis posterior a eventos y aprendizaje del sistema
Mapa de la cirugía abdominal|Recuperación integrada y traspaso clínico|Cambios de contaminación y reorganización del campo|Drenajes, ostomías y traspaso clínico abdominal
Implantes, lateralidad e imagen|Trauma, torniquete y prevención de infecciones|Torniquete: coordinación, tiempo y respuesta a alertas|Componentes, prueba y cemento: comunicación de hitos
Pelvis y vías de acceso|Cesárea: dos equipos, un plan|Fluidos y muestras en procedimientos ginecológicos|Hemorragia obstétrica: flujo y coordinación del quirófano
Endourología, irrigación y energía|Litotomía, stents y catéteres|Irrigación: circuito, balance y pérdida de retorno|Stents, catéteres y seguimiento al egreso
Cirugía abierta, endovascular e híbrida|Injertos, isquemia y prevención de infecciones|Quirófano híbrido: imagen, circulación y preparación para conversión|Pinzamiento vascular, reperfusión y explantes
Cráneo, microscopía y navegación|Columna vertebral: posición, nivel e implantes|Navegación y neuromonitorización: discrepancias y escalada|Nivel correcto y comprobación de tecnología en columna
Vía aérea compartida y muestras|Reconstrucción, traqueostomía y traspaso clínico|Vía aérea compartida y prevención de incendios|Colgajo libre: traslado y plan de monitorización
Pulmón, posición lateral y drenajes|Cirugía cardíaca, circulación extracorpórea y transiciones críticas|Ventilación, posición lateral y plan de conversión torácica|Hitos cardíacos y traslado a cuidados intensivos
Escala, fisiología y termorregulación|Recién nacido, equipo y familia|Componentes pequeños, peso y seguridad de medicamentos pediátricos|Termorregulación y transporte neonatal
Acoplamiento del robot, zonas y funciones del equipo|Interfaz estéril, fallas y uso seguro|Posicionamiento, acoplamiento y acceso de emergencia|Conversión, fallas y trazabilidad robótica
Clasificación y recorrido del procedimiento|Acceso abierto e incisiones: perspectiva perioperatoria|Acceso laparoscópico y robótico: puertos y geometría|Accesos endoscópicos y percutáneos|Conversión, cierre y traspaso del procedimiento
Mapa de dispositivos vasculares|Acceso venoso periférico: preparación y vigilancia|Acceso venoso central: asistencia y barrera máxima|Acceso arterial y sistema de presión|Acceso intraóseo y alternativas de emergencia|Mantenimiento, complicaciones y traspaso vascular
Mapa de dispositivos de vía aérea|Asistencia en vía aérea difícil y crisis|Catéter urinario en el perioperatorio|Sondas gástricas y enterales: preparación y confirmación|Drenajes quirúrgicos y torácicos|Catéteres neuroaxiales y accesos regionales
Asepsia, antisepsia, limpieza y esterilidad|Antisepsia quirúrgica de manos y colocación de indumentaria|Evaluación de la piel, limpieza y manejo del vello|Elección de antiséptico y regiones especiales|Aplicación, secado, campos y riesgo de incendio
Admisión y verificación preprocedimiento|Traslado, monitorización y protección de dispositivos|Apoyo en punciones, biopsias y procedimientos guiados|Heridas, apósitos y ostomías al finalizar|Transporte y traspaso con conciliación de dispositivos'''.splitlines()
assert len(lessons_es)==33,len(lessons_es)
for i,(module,line) in enumerate(zip(d['module'],lessons_es)):
 vals=line.split('|')
 assert len(vals)==len(module['lessons']),(i,module['title'],len(vals),len(module['lessons']))
proc_es='''Higiene de manos|Administración intramuscular de medicamentos|Acceso venoso periférico|Extracción de sangre venosa|Evaluación estructurada de heridas|Irrigación de heridas|Selección y cambio de apósitos|Heridas por mordedura animal o humana|Sutura simple interrumpida|Férula antebraquiopalmar|Evaluación neurovascular antes y después de la inmovilización|Glucemia capilar a pie de cama|Clasificación clínica y quirúrgica de las heridas|Retirada de puntos y grapas cutáneas|Electrocardiograma de 12 derivaciones a pie de cama|Administración intradérmica de medicamentos y pruebas|Administración subcutánea|Administración intravenosa de medicamentos|Infusión intermitente y continua|Reconstitución y dilución de medicamentos|Bombas de infusión: programación y alarmas|Medidas de seguridad para medicamentos de alto riesgo|Extracción de muestras para hemocultivo|Hemostasia inicial de heridas|Limpieza y eliminación de contaminantes de las heridas|Identificación de infección en heridas|Cuidados posteriores de heridas y seguimiento|Sutura continua|Sutura de colchonero vertical|Sutura de colchonero horizontal|Sutura intradérmica continua|Cierre dérmico profundo|Adhesivos cutáneos y tiras de aproximación|Grapas cutáneas|Férula tipo sugar-tong de antebrazo|Férula posterior de miembro inferior|Yeso circular: indicación, seguridad y vigilancia|Reconocimiento del síndrome compartimental|Hilos de sutura: materiales y selección|Agujas quirúrgicas: curvatura y punta|Cabestrillo: apoyo del miembro superior|Férula en U para húmero|Inmovilización del pulgar: férula tipo espica|Inmovilización de dedos y sindactilia terapéutica|Collar cervical: indicaciones y limitaciones|Desbridamiento: evaluación e indicación'''.split('|')
assert len(proc_es)==46,len(proc_es)
topics_es='''Bioseguridad|Instrumental quirúrgico|Agujas, jeringas y dispositivos|Administración de medicamentos|Accesos vasculares|Heridas y lesiones|Suturas y cierre|Anestesia y analgesia|Preparación quirúrgica|Vía aérea y oxigenoterapia|Procedimientos respiratorios|Emergencias|Ortopedia e inmovilización|Sondas y catéteres|Procedimientos ambulatorios|Cirugía general|Ginecología y obstetricia|Pediatría y neonatología|Neurología|Cardiología|Gastroenterología|Urología|Oftalmología|Otorrinolaringología|Dermatología|Cuidados posoperatorios|Diagnóstico a pie de cama|Documentación y comunicación'''.split('|')
assert len(topics_es)==28,len(topics_es)
tr={}
for m,es,l in zip(d['module'],modules_es,lessons_es):
 tr[m['title']]=es
 for lesson,esp in zip(m['lessons'],l.split('|')):tr[lesson]=esp
for src,es in zip(d['proc'],proc_es):tr[src]=es
for src,es in zip(d['topics'],topics_es):tr[src]=es
extra='''Início|Inicio
Procedimentos|Procedimientos
Atlas de materiais|Atlas de materiales
Atlas de Materiais|Atlas de materiales
Matriz técnica|Matriz técnica
Matriz Técnica|Matriz técnica
Biblioteca de aulas|Biblioteca de clases
Trilhas de aprendizagem|Itinerarios de aprendizaje
Planos de estudo|Planes de estudio
Desafio rápido|Desafío rápido
Meu progresso|Mi progreso
Plano de reforço|Plan de refuerzo
Fontes e créditos|Fuentes y créditos
Buscar|Buscar
Busca global|Búsqueda global
Idioma|Idioma
Perfil local|Perfil local
Salvar perfil|Guardar perfil
Cancelar|Cancelar
Seu nome|Tu nombre
Digite seu nome|Escribe tu nombre
Voltar|Volver
Voltar à matriz|Volver a la matriz
Voltar ao início|Volver al inicio
Anterior|Anterior
Próxima|Siguiente
Simulado|Simulacro
Casos|Casos
Casos clínicos|Casos clínicos
Checklists|Listas de verificación
Avaliações|Evaluaciones
Flashcards|Tarjetas de estudio
Videoteca|Videoteca
Roadmap|Plan de desarrollo
PLATAFORMA|PLATAFORMA
ESTUDAR|ESTUDIAR
RECURSOS|RECURSOS
PRATICAR|PRACTICAR
BUSCA GLOBAL|BÚSQUEDA GLOBAL
MÓDULOS|MÓDULOS
CONTEÚDO|CONTENIDO
MATERIAIS|MATERIALES
EXPANSÃO CURRICULAR|AMPLIACIÓN CURRICULAR
ESPECIALIDADES|ESPECIALIDADES
TODAS AS CATEGORIAS|TODAS LAS CATEGORÍAS
Página não encontrada|Página no encontrada
Conteúdo não encontrado|Contenido no encontrado
Nenhum conteúdo encontrado.|No se encontró contenido.
Nenhum material encontrado|No se encontró material
Nenhum procedimento encontrado|No se encontró procedimiento
Todas as categorias|Todas las categorías
Todos os módulos|Todos los módulos
Todas as escalas|Todas las escalas
Sem escala|Sin escala
Todos|Todos
Todas|Todas
Limpar|Limpiar
Concluir|Finalizar
Marcar como concluída|Marcar como completada
Aula concluída|Clase completada
Nesta aula|En esta clase
Conteúdo programático|Contenido del programa
Trilha|Itinerario
Trilhas|Itinerarios
Aula|Clase
Aulas|Clases
Material|Material
Materiais|Materiales
Material complementar|Material complementario
MATERIAL COMPLEMENTAR|MATERIAL COMPLEMENTARIO
Objetivos de aprendizagem|Objetivos de aprendizaje
OBJETIVOS DE APRENDIZAGEM|OBJETIVOS DE APRENDIZAJE
Exercício de fixação|Ejercicio de repaso
Pontos importantes|Puntos importantes
Fonte|Fuente
Fontes|Fuentes
Fontes da trilha|Fuentes del itinerario
Ver biblioteca científica|Ver biblioteca científica
Ver videoteca|Ver videoteca
Veja a técnica em vídeo|Observa la técnica en video
PRÉ-REQUISITOS|REQUISITOS PREVIOS
PRÉ-REQUISITO RECOMENDADO|REQUISITO PREVIO RECOMENDADO
População|Población
Ambiente|Entorno
Supervisão|Supervisión
Preparação|Preparación
Execução|Ejecución
Complicações|Complicaciones
Contraindicações|Contraindicaciones
Indicações|Indicaciones
Referências|Referencias
Segurança|Seguridad
Materiais necessários|Material necesario
Materiais relacionados|Materiales relacionados
PROCEDIMENTOS RELACIONADOS|PROCEDIMIENTOS RELACIONADOS
PRECAUÇÕES|PRECAUCIONES
ALTERNATIVAS|ALTERNATIVAS
RISCOS|RIESGOS
PROVENIÊNCIA|PROCEDENCIA
COMPATIBILIDADE|COMPATIBILIDAD
Verificação do fabricante obrigatória|Es obligatorio comprobar las instrucciones del fabricante
Dados da ficha|Datos de la ficha
Conteúdo de estudo|Contenido de estudio
Guia educacional|Guía educativa
Guia de estudo e simulação|Guía de estudio y simulación
Ficha de estudo|Ficha de estudio
Abrir ficha técnica|Abrir ficha técnica
Ficha técnica|Ficha técnica
Fichas técnicas|Fichas técnicas
Estado editorial|Estado editorial
Cadastro|Registro
Catalogado|Catalogado
Em desenvolvimento|En desarrollo
Revisão técnica|Revisión técnica
Validado|Verificado
Publicado|Publicado
Disponível|Disponible
Guia de estudo|Guía de estudio
Fechar|Cerrar
Perfil atualizado.|Perfil actualizado.
Não substitui treinamento supervisionado, avaliação clínica ou protocolos institucionais.|No sustituye el entrenamiento supervisado, la evaluación clínica ni los protocolos institucionales.
Nexo Cirúrgico|Nexo Cirúrgico
Product by InMed|Product by InMed
Matriz de procedimentos|Matriz de procedimientos
Biblioteca médica de procedimentos|Biblioteca médica de procedimientos
Atlas de materiais médicos|Atlas de materiales médicos
ESCOLHA O PROCEDIMENTO|ELIGE EL PROCEDIMIENTO
PROCEDIMENTOS FUNDAMENTAIS|PROCEDIMIENTOS FUNDAMENTALES
SIMULAÇÃO|SIMULACIÓN
ETAPAS|ETAPAS
ESPECIALIDADE|ESPECIALIDAD
QUESTÕES|PREGUNTAS
RESPOSTA|RESPUESTA
PERGUNTA|PREGUNTA
RESULTADO DO SIMULADO|RESULTADO DEL SIMULACRO
Acertos|Aciertos
Erros|Errores
Erros críticos|Errores críticos
Revisar|Repasar
Revisar etapa|Repasar etapa
Começar etapa|Iniciar etapa
Continuar etapa|Continuar etapa
CONTINUAR ESTUDANDO|SEGUIR ESTUDIANDO
PRÁTICA SUPERVISIONADA|PRÁCTICA SUPERVISADA
AVALIAÇÃO PRÁTICA|EVALUACIÓN PRÁCTICA
PLANO DE EVOLUÇÃO|PLAN DE EVOLUCIÓN
LEITURA|LECTURA
Duração|Duración
minutos|Minutos
Mais informações|Más información
Abrir|Abrir
Fechar menu|Cerrar menú
Abrir menu|Abrir menú
MEU PROGRESSO|MI PROGRESO
PERFIL LOCAL|PERFIL LOCAL
Nova tentativa|Nuevo intento
Nova simulação|Nueva simulación
Novo simulado|Nuevo simulacro
Novo desafio|Nuevo desafío
Questão|Pregunta
Nova aula|Nueva clase
Concluídas|Completadas
Em andamento|En curso
Ainda catalogados|Aún catalogados
Introdução|Introducción
Definição|Definición
Material e calibres|Material y calibres
Passo a passo|Paso a paso
Ver progresso|Ver progreso
Avaliação neurovascular|Evaluación neurovascular
Fios de sutura|Hilos de sutura
Fios e suturas|Hilos y suturas
Suturas|Suturas
Feridas|Heridas
Limpeza|Limpieza
Curativos|Apósitos
Imobilizações|Inmovilizaciones
Anestesia|Anestesia
Pediatria|Pediatría
Cirurgia|Cirugía
Enfermaria|Hospitalización
Urgência|Urgencias
Ambulatório|Consultorio
Cuidado posterior|Cuidados posteriores
Identificação|Identificación
Resumo|Resumen
Lote|Lote
Versão|Versión
Processamento|Procesamiento
Configurações|Configuración
Ajustes|Ajustes
Visualizar|Ver
Baixar|Descargar
Copiar|Copiar
'''
for line in extra.splitlines():
 if not line.strip():continue
 pt,es=line.split('|',1);tr[pt]=es
(root/'i18n-catalog.es.json').write_text(json.dumps(tr,ensure_ascii=False,indent=2)+'\n')
print('i18n dictionary entries:',len(tr),'covers titles',len(d['proc']),'procedures',sum(map(lambda m:len(m['lessons']),d['module'])),'lessons')
