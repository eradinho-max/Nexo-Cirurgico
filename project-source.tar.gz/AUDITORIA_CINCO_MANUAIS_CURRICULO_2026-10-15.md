# Nexo Cirúrgico — Auditoria editorial, procedimental e de acessibilidade
**Base examinada:** Nexo v1.4.3 / cinco PDFs enviados / data 15-10-2026  
**Status:** avaliação curricular e técnica; NÃO equivale a revisão clínica independente.

## 1. Síntese executiva

**Constatação principal:** a contagem de aulas não representa quantidade de habilidades ensinadas. O repositório contém 33 trilhas antigas com 115 aulas curtas, uma matriz curricular com 227 tópicos, e apenas **46 fichas de procedimento**. O módulo M16 — Cirurgia Geral apresenta **zero** fichas procedimentais; a trilha antiga “Cirurgia geral e digestiva” possui quatro aulas, concentradas em fluxo perioperatório (organização, campo, transição), e não nas técnicas. O relatório anterior registrava o conteúdo como completo quando na realidade são entidades de naturezas diferentes.

**Cobertura de fichas:** 46/227 tópicos editoriais = **20,3%**. Os 181 restantes estão sem ficha individual; **21/28** módulos não possuem nenhuma ficha procedimental. Essas métricas não aferem qualidade de cada ficha, maturidade clínica ou habilidade de quem estuda.

**Ponto forte:** das 46 fichas, 46 têm as 14 chaves editoriais definidas. Algumas incluem sequências de apenas 4–6 itens, poucos materiais contextualizados e **nenhum vídeo por ficha** no conjunto verificado. São roteiros iniciais, ainda não evidência de ensino prático validado.

**Dois problemas de produto:** (a) a leitura nos módulos internos não era assegurada pelo teste anterior — conferia apenas `font-size` em px e ignorava `.81rem` e a cascata específica; (b) não existia seletor PT/ES ou estrutura pronta para tradução integral.

## 2. Documentos examinados — escopo e uso correto

| Fonte | Conteúdo aproveitável para o currículo | Referências do PDF enviado | Restrições |
|---|---|---|---|
| Myers & Hale, *Guía de procedimientos clínicos* (2014) | IV, administração de medicamentos, curativos, coleta, drenagens, oxigenoterapia, sondas, transfusão, aspiração e ECG | PDF p.5–14 (sumário), p.16 (pré e pós-intervenção), p.19 (IV), p.84–99 (injeções, medicação), p.139–155 (sangue/sondas), p.165–166 (via aérea) | Livro orientado a rotinas assistenciais; recomendações de RCP de 2010 não servem como diretriz atual |
| Jesús Tapia Jurado, *Manual de procedimientos médico-quirúrgicos para el médico general* (2005) | 38 capítulos de manobras: injeções, acesso vascular, sondas, feridas, anestesia local, sutura, imobilização, abscessos, corpos estranhos, punção lombar e posoperatório | PDF p.12–14 (índice); cap. 11 p.152; cap. 15 p.208; cap. 16 p.222; cap. 21 p.294; cap. 34 p.414 | Manual histórico; adaptar escolhas técnicas e farmacológicas a diretrizes atuais |
| *Manual de terapéutica médica y procedimientos de urgencias*, 7ª ed. | RCP, via aérea, acessos venosos centrais, urgências respiratórias e circulatórias, choque, queimaduras, mordeduras | PDF p.2–6 (índice), p.7 (RCP), p.27 (via aérea), p.36 (centrais) | Predominantemente terapêutico, não guia de técnica de todos os 109 capítulos; capítulos de RCP citam diretrizes de 2015 |
| FMUSP, *Manual Básico de Procedimentos Médicos Hospitalares* (2017) | Modelo de técnica operacional e checklist: intubação, CVC em 3 sítios, crico, toracocentese, pericardiocentese, dreno pleural, paracentese, sonda vesical, PAI e suturas | PDF p.15–16 (índice); p.28, 43, 61, 75, 84, 104, 110, 139, 150, 166, 189, 209 (capítulos) | Referência anatômico-técnica; imagens do livro não devem ser republicadas sem licença |
| FMUSP, *Medicina de Emergência: Abordagem Prática*, 19ª ed. (2025) | Atualização contextual: via aérea, sedação/analgesia, anestesia regional, trauma, POCUS, acesso vascular, toracocentese e drenagem | PDF p.89 (via aérea), p.272 (sedação), p.283 (anestesia regional), p.924 (trauma), p.1602 (acesso guiado por US), p.1667 (acessos), p.1684 (toracocentese) | Nem todo capítulo é procedimento; não converter toda doença/terapêutica em “aula técnica” |

**Observação sobre paginação:** o número de página acima é a página física do PDF (primeira capa = página 1), não o número impresso no livro. Essa distinção deve existir no cadastro das fontes.

## 3. Matriz da cobertura REAL das fichas do código

| Módulo | Fichas / tópicos | Situação de produção |
|---|---|---|
| M01 Biossegurança | 1/8 | Parcial |
| M02 Instrumentação cirúrgica | 0/10 | Sem fichas |
| M03 Agulhas, seringas e dispositivos | 0/10 | Sem fichas (há itens no Atlas, que é diferente) |
| M04 Administração de medicamentos | 8/10 | Avançado, sujeito a revisão clínica |
| M05 Acessos vasculares | 3/8 | Insuficiente |
| M06 Feridas e lesões | 10/10 | Estruturalmente coberto, precisa aprofundamento prático |
| M07 Suturas e fechamento | 11/11 | Estruturalmente coberto, precisa técnica visual |
| M08 Anestesia e analgesia | 0/10 | Sem fichas |
| M09 Preparo cirúrgico | 0/11 | Sem fichas |
| M10 Via aérea e oxigenoterapia | 0/9 | Sem fichas |
| M11 Procedimentos respiratórios | 0/6 | Sem fichas |
| M12 Emergências | 0/9 | Sem fichas |
| M13 Ortopedia e imobilização | 11/11 | Estruturalmente coberto, simulações específicas pendentes |
| M14 Sondas e cateteres | 0/7 | Sem fichas |
| M15 Procedimentos ambulatoriais | 0/5 | Sem fichas |
| M16 Cirurgia geral | 0/8 | Sem fichas; problema central reportado |
| M17 Ginecologia e obstetrícia | 0/8 | Sem fichas |
| M18 Pediatria e neonatologia | 0/7 | Sem fichas |
| M19 Neurologia | 0/5 | Sem fichas |
| M20 Cardiologia | 0/7 | Sem fichas |
| M21 Gastroenterologia | 0/7 | Sem fichas |
| M22 Urologia | 0/6 | Sem fichas |
| M23 Oftalmologia | 0/7 | Sem fichas |
| M24 Otorrinolaringologia | 0/6 | Sem fichas |
| M25 Dermatologia | 0/7 | Sem fichas |
| M26 Cuidados pós-operatórios | 0/10 | Sem fichas |
| M27 Diagnóstico à beira-leito | 2/6 | Parcial |
| M28 Documentação e comunicação | 0/8 | Sem fichas |

**Risco de interpretação:** módulos/abas sem fichas não significam ausência absoluta de informação: há aulas conceituais ou materiais relacionados, mas NÃO roteiros de execução próprios.

## 4. Expansão curricular — priorização por competência, não por volume de texto

**Prioridade P0: máximo valor formativo, maior frequência, menor especialização.**

| Bloco e procedimentos a cadastrar individualmente | Fonte principal no material enviado | Descrição da lacuna |
|---|---|---|
| M02: montar bandeja de pequena cirurgia; reconhecer instrumentos de corte/dissecção/hemostasia/preensão; manejo de perfurocortantes; preparo da mesa | Tapia cap. 16 / FMUSP cap. 1 e 13 | M02 sem ficha; catálogo instrumental não substitui treino de seleção e manejo |
| M09: avaliação e consentimento pré-procedimento, identificação e lateralidade, preparo da pele, checagem de materiais, posicionamento, checklist e transferência | FMUSP cap. 1; Myers p.16; OMS segurança cirúrgica | M09 sem ficha |
| M08: anestesia local infiltrativa; bloqueio digital e princípios de analgesia; identificação e prevenção da toxicidade do anestésico | Tapia cap. 15; Emergência 2025 caps. 14–15 | M08 sem ficha; definir limites de treinamento |
| M14: sonda nasogástrica, sonda enteral, verificação segura do posicionamento; sonda vesical intermitente e de demora; retirada e complicações | Tapia caps. 3–5; FMUSP cap. 10; Myers p.147–153 (numeração impressa) | M14 sem ficha |
| M10: ventilação com bolsa-válvula-máscara; dispositivos supraglóticos; intubação orotraqueal (simulação); confirmação por capnografia | FMUSP cap. 2; Emergência 2025 cap. 2 | M10 sem ficha |
| M11: gasometria arterial; toracocentese; drenagem torácica; aspiração em via aérea | FMUSP caps. 6 e 8; Myers p.15; Emergência 2025 cap. 122 | M11 sem ficha |
| M12: RCP adulta atualizada; DEA/desfibrilação; controle externo de hemorragia; imobilização no trauma | Tapia caps. 8–9; Emergência 2025 caps. 3–5 e 63 | M12 sem ficha, atualizar para AHA 2025 |
| M16: tempos cirúrgicos; montagem da mesa; incisão e escolha de lâmina; dissecção; hemostasia e ligaduras; fechamento por planos; instalação e controle de drenos; cuidados da incisão | Tapia caps. 11, 15, 16, 21, 37; FMUSP caps. 1 e 13 | **Zero fichas de técnica cirúrgica geral** |
| M05: acesso venoso central jugular/subclávio/femoral e punção arterial; acesso vascular guiado por ultrassom | FMUSP caps. 3,5,11,12; Emergência 2025 caps. 117 e 121 | M05 tem só 3/8 |

**Prioridade P1: procedimentos especiais e ambulatoriais, com limitação explícita do nível de supervisão.**

| Área | Procedimentos concretos | Fonte |
|---|---|---|
| M15/M25 | Drenagem de abscesso superficial; biópsia punch e excisional; manejo de lesão ungueal; exérese de lesões superficiais | Tapia caps. 21, 30, 31 |
| M23/M24 | Irrigação ocular, corpo estranho ocular superficial; irrigação auricular conforme indicação; corpo estranho auricular/nasal; controle da epistaxe | Tapia caps. 22–25; Myers p.105–106 (impressa) |
| M17 | Exame especular e coleta cervical; cuidado procedimental obstétrico, episiotomia e episiorrafia em contexto apropriado | Tapia cap. 33 |
| M18 | Acesso pediátrico, coleta capilar, precauções e dispositivos de pequeno calibre; suporte inicial neonatal | Tapia cap. 20; Myers seção neonato |
| M19/M21 | Punção lombar; paracentese abdominal; preparação, material, riscos e confirmação | Tapia cap. 34; FMUSP cap. 9; Merck versão atualizada |
| M20 | ECG; desfibrilação/cardioversão; marca-passo transcutâneo, conforme treinamento | Emergência 2025 cap. 120 |
| M22 | Sonda uretral e irrigação vesical; rotas de escalonamento em obstruções/dificuldades de passagem | Tapia cap. 5; FMUSP cap. 10 |
| M26 | Troca de curativos pós-operatórios, drenos Penrose/JP, monitorização e resposta a complicações da incisão, retirada de dispositivos | Myers seção feridas; Tapia cap. 37 |

**Prioridade P2/avançada:** cricotireoidostomia, pericardiocentese, venodissecção, técnica de punção em cavidades de maior risco, endoscopia e técnicas cirúrgicas especializadas; conteúdos operacionais detalhados condicionados a escopo médico e simulação supervisionada. Fontes: FMUSP caps. 4,7; Tapia caps. 10,17–19; Emergência 2025 capítulo 122 (número em PDF conforme índice).

## 5. O que NÃO transformar em ficha de procedimento

Evitar copiar a lista de doenças do livro de urgências como se cada entidade fosse uma habilidade manual. Choque, sepse, pancreatite, infecção do trato urinário, síndrome coronariana e outros assuntos são **contextos clínicos**: entram como indicações, contraindicações, decisões e casos, não necessariamente como técnica autônoma. Um tópico só vira ficha se houver ação técnica ensinável com material, preparo, sequência, confirmação e cuidados pós-execução.

## 6. Contrato editorial sugerido: “como fazer” sem virar aula clássica

A ficha deve abrir diretamente no **fluxo operacional**, sem texto histórico longo:

1. **Quando fazer / quando não fazer:** indicações e fatores que contraindicam ou alteram a técnica.
2. **Bandeja técnica ilustrada:** nome, fotografia/esquema original, calibre, alternativas e incompatibilidades de cada material.
3. **Paciente e ambiente:** identificação, consentimento, posicionamento, analgesia, antissepsia e supervisão requerida.
4. **Sequência de execução:** passos curtos, numerados, com ponto de confirmação e erro crítico para simulação.
5. **Conferência do resultado:** critérios para reconhecer execução correta e sinais de falha.
6. **Depois de fazer:** documentação, monitoramento, complicações, reavaliação e quando pedir ajuda.
7. **Vídeo externo:** link para instituição/canal original, revisão de conteúdo, crédito e data de verificação.
8. **Treinar:** checklist objetivo OSCE/skills-lab, simulação de bandeja e teste de escolha do material.

As 14 chaves do banco podem permanecer como schema interno; a interface não deve obrigar o estudante a percorrer 14 seções extensas para chegar à execução. Usar seis a oito painéis de experiência e colapsar teoria complementar.

## 7. Leitura: não basta elevar uma regra global de CSS

**Causa confirmada no código:** a v1.4.3 possui grande quantidade de tamanhos de 14px, mas a auditoria anterior conferia apenas `font-size:NNpx`; ignorava valores como `.81rem`, elementos herdados e a experiência efetiva da página. Como o próprio usuário observou, parte do problema se mantém nas páginas internas.

**Correção desta entrega:** novo `leitura.css` aplicado por último no HTML, priorizando `.lesson-content`, `.procedure-field`, `.procedure-training`, conteúdos de módulos e áreas do Atlas. Texto didático com tamanho base 18px (~13,5pt), ajustável via controles `A−/A+` entre 16,18,20,22px; títulos de conteúdo a partir de 18–20px. Preferência salva localmente. Menus e rótulos secundários mantêm 14–16px. **Teste de navegador real continua bloqueado por `ERR_BLOCKED_BY_ADMINISTRATOR` no ambiente**, portanto QA visual manual em desktop e celular continua exigência de aceite.

## 8. Idiomas PT/ES: arquitetura em duas etapas, sem ilusão de tradução clínica

**Nesta entrega técnica:** seletor PT / ES beta persistente; tradução inicial da navegação principal, títulos de página reconhecidos e campo de busca; aviso visível, em espanhol, de que 115 aulas e 46 fichas clínicas estão ainda em português. Todas as rotas e IDs permanecem estáveis.

**Para concluir o requisito de produto:** passar a armazenar cada conteúdo como `title: {pt,es}`, `fields: {pt,es}` e `references` independentes de idioma, com revisão médica bilíngue; traduzir materiais, variantes, instruções, perguntas, alternativas, explicações, alertas e textos de acessibilidade. Não traduzir doses, calibres, rotas e siglas automaticamente; resolver termos equivalentes (Jelco/catéter periférico; tala/férula; gesso/yeso) em aliases distintos. Só declarar `Español completo` quando os testes confirmarem cobertura de todos os campos clínicos e interfaces.

## 9. Atualização clínica e direitos autorais

- Myers (2014), Tapia Jurado (2005) e o manual de terapêutica/urgências 7e são **bases bibliográficas históricas**, não substitutos de recomendações atuais. Conferir RCP/engasgo com AHA 2025; infecção cirúrgica com OMS 2018 e seus updates; cateteres com OMS 2024/2026 e CDC; procedimentos individuais com fontes clínicas atualizadas e protocolos locais.
- Os PDFs recebidos contêm conteúdo protegido por copyright e NÃO foram adicionados ao GitHub, à Vercel, ao ZIP público ou à aplicação. Registrar apenas metadados da obra, capítulo/página física do PDF, referência e notas originais de síntese. Não republicar imagens, figuras, páginas ou tabelas desses livros sem licença adequada.
- Para os vídeos externos, guardar URL original, autor/canal, título, data, idioma, avaliação da demonstração, link de acesso e data de nova verificação.

## 10. Roadmap de execução sem reiniciar oito macroblocos

**Passagem A — MB03.4, legibilidade e idioma da interface (nesta entrega):** `leitura.css`, controle A± persistente, `idiomas.js` PT/ES beta, testes estruturais, preservação do acervo. Publicação clínica não autorizada.

**Passagem B — MB03.5/MB04, núcleo de habilidades cirúrgicas:** desenvolver P0 M02/M09/M16 em sequência, depois M08/M10/M14/M11/M12; pelo menos uma ficha completa e um vídeo indicado por procedimento, quando houver fonte adequada. Expandir Atlas somente com o material exigido por essas fichas.

**Passagem C — MB04, cirurgia e anestesia:** checklist pré-anestésico, técnica de anestesia local e segurança, centro cirúrgico, temáticas de risco e cuidados na SRPA. Submeter fármacos e doses à revisão clínica.

**Passagem D — MB05, urgência e especialidades:** punções de cavidades, POCUS, drenagens, procedimentos otorrino/oftalmo/dermato, gineco, neonatologia e pediatria, conforme supervisão.

**Passagem E — MB06/MB07:** videoteca por ficha e checklists avaliativos supervisionados; não atribuir “habilidade certificada” por quiz digital.

**Passagem F — MB08:** auditoria clínica, acessibilidade desktop/mobile, idioma completo, linkagem bibliográfica, segurança, direitos e testes de regressão.

**Critério de aceite por ficha:** material obrigatório e variações, anatomia, preparo, contraindicações, 4–12 etapas simulatórias verificáveis, pontos críticos e critérios de parada, resultado esperado, complicações, checklist, origem das evidências e revisor identificável; estado `revisão clínica` até aprovação.

## 11. Testes realizados nesta entrega

- Dados originais: 33 trilhas, 115 aulas, 46 fichas práticas, 227 tópicos, 41 materiais e 210 questões: preservados.
- `npm run qa`: aprovado no código local; 92 alertas editoriais preexistentes nas 210 questões, nenhum erro estrutural comunicado pelos validadores.
- `npm run build`: 15 arquivos públicos necessários.
- `npm run qa:deploy`: aprovado.
- `node --check idiomas.js`: aprovado.
- Navegação e legibilidade medidas no Chromium: NÃO verificadas (acesso localhost bloqueado). Não confundir com teste funcional/visual aprovado.

### Próximos passos imediatos

1. Revisar visualmente em Vercel as páginas `#/aula/…` e `#/procedimento/PT-M07-03` no desktop e no celular (fonte 18px, A±, espaçamento, sem cortes).
2. Corrigir eventuais regressões visuais.
3. Construir primeiro lote de **habilidades de cirurgia geral**, sem acrescentar outros textos teóricos genéricos.
4. Implantar tradução médica PT/ES completa de forma incremental e revisada, iniciando pelas fichas e termos cirúrgicos.
