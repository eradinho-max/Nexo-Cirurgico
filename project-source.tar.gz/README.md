# Nexo Cirúrgico — versão 1.5.1 · MB04 Lote 2

O núcleo de **Cirurgia Geral, Anestesia e Preparo Perioperatório** inclui 29 fichas (M16: 8, M08: 10, M09: 11). A biblioteca total contém **75 fichas** de 227 tópicos e o Atlas possui **52 materiais / 180 variantes**. As 115 aulas, 210 questões, 30 casos e 137 flashcards anteriores foram preservados.

O seletor PT/ES traduz os títulos e introduções do novo lote; textos técnicos extensos continuam em português. A publicação é educacional, não certifica execução independente; não há bloqueio de estudo por aprovação externa.

**Executar:** `npm run qa:all`; **deploy:** GitHub → Vercel usando `dist`. Confira `MB04_LOTE2_RELATORIO.md` e `ROADMAP.md`.

---

# Nexo Cirúrgico — v1.5.0 | MB04 Lote 1

**Estado de referência:** 54 fichas técnicas e M16 com oito tópicos próprios, preservação de todo o acervo histórico. Ver `MB04_LOTE1_RELATORIO.md` e `ROADMAP.md`. Publicação para estudo/simulação, sem certificação profissional.

## Atualização MB03.4 — Leitura e idiomas (15/10/2026)

- Fonte de texto das aulas e fichas ampliada para 18px por padrão (ajustável entre 16 e 22px); versão PT/ES *interface beta*.
- **A tradução médica completa NÃO está pronta**: aulas e fichas permanecem em português no modo ES, com aviso visível.
- Auditoria detalhada dos cinco livros recebidos: `AUDITORIA_CINCO_MANUAIS_CURRICULO_2026-10-15.md`.
- QA local: `npm run qa:reader-lang` e `npm run qa`; inspeção visual ainda pendente.
- Os cinco PDFs e suas figuras não integram a publicação nem o código, por direitos autorais.

# Nexo Cirúrgico — v1.4.3 • MB03 consolidado • GitHub + Vercel

Plataforma educacional original em expansão do núcleo perioperatório para uma biblioteca médica integrada de procedimentos. O público principal desta fase é formado por estudantes de Medicina e médicos em treinamento supervisionado. A marca **Nexo Cirúrgico** permanece provisória.

## O que está implementado

- Interface 1.3 inspirada na referência fornecida, com sidebar azul-marinho, topbar clara e logomarca vetorial própria
- Dashboard responsivo com indicadores reais, continuidade de estudo, próximos passos, atalhos, destaques, matriz e meta local
- Biblioteca com 33 trilhas e 115 aulas autorais, totalizando 2.068 minutos
- Matriz técnica com 28 módulos, seis macroáreas, 227 tópicos e 224 procedimentos canônicos
- Status, prioridade, aliases e revisão individual por tópico
- 254 relações de aula classificadas como cobertura direta, fundamento ou pré-requisito
- Busca normalizada por acentos, siglas e sinônimos, com resultado no tópico exato
- Atlas de Materiais com 41 fichas, 158 variantes, oito categorias e sete sistemas de escala
- Relação material → variante → procedimento → fonte, incluindo compatibilidades e instruções de fabricante
- Logomarca vetorial própria com cruz médica e capelo, sem recorte do screenshot de referência
- Visuais originais no Atlas e quatro SVGs próprios publicados no dashboard (JPGs históricos não incluídos no deploy até a conferência de licença)
- **54 fichas técnicas editoriais** (15 lote 1 + 23 lote 2 + 8 lote 3) com 14 campos, referências, kits de treinamento supervisionado, materiais e limitações, sem validação clínica
- 10 trilhas P2 de especialidade, com 40 aulas
- 5 novas trilhas sobre procedimentos, vias cirúrgicas, acessos vasculares, via aérea, sondas, drenos, assepsia e assistência perioperatória
- 3 planos progressivos que organizam todas as 115 aulas em fundamentos, prática ampliada e especialidades
- Aulas com objetivos, tópicos, alertas, bibliografia contextual e materiais complementares
- 137 flashcards filtráveis, com marcação de domínio
- Desafio rápido com 5 questões e feedback imediato
- Banco com 210 questões vinculadas a 28 competências e simulado de 20 questões sorteadas
- 30 casos situacionais interativos, incluindo 10 casos P2 de especialidade
- Blueprint ampliado com distribuição por competência e dificuldade
- Relatório formativo por competência ao concluir o simulado
- Plano de reforço por competência e etapa, com 84 vínculos para aulas recomendadas
- Histórico local das últimas dez tentativas, incluindo questões sorteadas e erros para remediação
- Painel de progresso por trilha
- Checklist de estudo interativo e imprimível com 90 itens, incluindo roteiros de especialidades, procedimentos e acessos
- Videoteca com 9 links institucionais ou educacionais, título e crédito ao canal
- Biblioteca com 72 publicações-base e registro de fontes visuais
- referências P2 e de acessos/dispositivos verificadas em 13/10/2026, com estado de atualidade visível
- Roadmap interativo com 7 fases, gates e critérios de conclusão
- Busca global de materiais, variantes, procedimentos exatos, módulos, aulas, casos, competências, vídeos, publicações e roadmap
- Perfil local e persistência por `localStorage`
- Layout adaptado para desktop, tablet e celular

## Pesquisa e plano curricular

A auditoria de cobertura, referências consultadas, matriz de expansão, política de vídeos e plano de governança estão em:

- [`PESQUISA_E_PLANO_CURRICULAR.md`](PESQUISA_E_PLANO_CURRICULAR.md)
- [`PLANO_EXPANSAO_PROCEDIMENTOS.md`](PLANO_EXPANSAO_PROCEDIMENTOS.md) — matriz de 28 módulos e execução dos oito macroblocos
- [`AUDITORIA_INDEPENDENTE_MB01.md`](AUDITORIA_INDEPENDENTE_MB01.md) — parecer externo e critérios de aceite do MB02
- [`ATLAS_MATERIAIS_MB02.md`](ATLAS_MATERIAIS_MB02.md) — modelo, catálogo inicial, fontes e testes do Atlas
- [`INTERFACE_NEXO_CIRURGICO.md`](INTERFACE_NEXO_CIRURGICO.md) — identidade, componentes, integridade dos dados e responsividade da interface 1.3
- [`EXPANSAO_CONTEUDO_88_AULAS.md`](EXPANSAO_CONTEUDO_88_AULAS.md) — registro histórico do reequilíbrio anterior
- [`MATRIZ_PROCEDIMENTOS_E_ACESSOS.md`](MATRIZ_PROCEDIMENTOS_E_ACESSOS.md)
- [`MAPA_PROGRESSAO_CURRICULAR.md`](MAPA_PROGRESSAO_CURRICULAR.md)
- [`REMEDIACAO_FORMATIVA.md`](REMEDIACAO_FORMATIVA.md)
- [`ROADMAP.md`](ROADMAP.md)
- [`BLUEPRINT_AVALIACAO.md`](BLUEPRINT_AVALIACAO.md)
- [`AUDITORIA_ESTRUTURAL_1_2.md`](AUDITORIA_ESTRUTURAL_1_2.md)
- [`AUDITORIA_BANCO_1_0.md`](AUDITORIA_BANCO_1_0.md) — registro histórico do núcleo
- [`PACOTE_REVISAO_INDEPENDENTE.xlsx`](PACOTE_REVISAO_INDEPENDENTE.xlsx)
- [`MATRIZ_P2_ESPECIALIDADES.md`](MATRIZ_P2_ESPECIALIDADES.md)
- [`REFERENCIAS_ATUALIZADAS_2026.md`](REFERENCIAS_ATUALIZADAS_2026.md)

**Estado atual:** MB01 e MB02 implementados; MB03 em consolidação (46 fichas). O sistema mantém 227 tópicos catalogados, mas apenas 38 fichas redigidas, todas pendentes de revisão clínica. O site pode ser usado como piloto educacional, não como protocolo médico ou certificação de competência.

## Executar

A aplicação não possui dependências de execução. Sirva a pasta por HTTP:

```bash
python3 -m http.server 4173 --bind 0.0.0.0
```

Depois, abra `http://localhost:4173`.

Para repetir as auditorias estruturais:

```bash
node qa_content.js
node qa_assessment.js
node qa_atlas.js
```

O smoke test de interface usa `jsdom` somente como dependência de desenvolvimento:

```bash
npm install
npm run qa:ui
# ou todos os testes:
npm run qa
```

## Direitos e materiais externos

- Os vídeos são abertos na página original do YouTube; a plataforma não baixa, edita nem hospeda a mídia.
- Não são copiadas miniaturas dos vídeos. Os cartões usam grafismo próprio e mostram o crédito do canal.
- Crédito não substitui autorização de reutilização.
- Se houver incorporação futura, deverá ser usado somente o player oficial, após verificação das permissões e políticas aplicáveis.
- Imagens futuras devem ser próprias, de domínio público ou acompanhadas de licença compatível e registro de atribuição.

## Limites deste MVP

- Não há autenticação real, banco de dados ou painel administrativo.
- O progresso fica apenas no navegador do usuário.
- O conteúdo é introdutório e precisa de revisão técnico-científica e validação por profissionais habilitados antes de publicação profissional.
- Vídeos complementam o estudo, mas não substituem normas, instruções de uso, protocolos institucionais ou prática supervisionada.
- Links externos podem mudar ou ser removidos pelo titular.

## Próxima etapa recomendada

Executar o **MB03 — Procedimentos fundamentais**, começando pelas fichas canônicas de acesso venoso periférico, coleta, administração, feridas, curativos, suturas e imobilizações, reutilizando o Atlas. A auditoria clínica, o preenchimento do pacote de revisão e o piloto permanecem programados para depois da conclusão editorial, antes de qualquer publicação profissional.


## Versão 1.4.0-mb03.1 — procedimentos técnicos (14/10/2026)

Novo acesso em **Procedimentos** (`#/procedimentos`): 15 fichas técnicas originais, em revisão, com 14 campos, referências, materiais ligados ao Atlas e checklists de simulação. As antigas 115 aulas continuam disponíveis em **Biblioteca de aulas** (`#/biblioteca`). Não há certificação clínica nem autorização de prática independente.

**Executar offline:** abra `index.html` em servidor estático (ex.: `python -m http.server 8080` e `http://localhost:8080`). Não existe backend e os dados de progresso são locais ao navegador.

**Auditoria sem instalação npm:** `node qa_content.js`, `node qa_assessment.js`, `node qa_atlas.js`, `node qa_mb03.js`; ou `npm run qa`. O teste mais amplo com jsdom é opcional (`npm install && npm run qa:ui`). Teste Playwright alternativo em `qa_browser_mb03.py` necessita Python Playwright e um Chromium permitido pelo ambiente.

Documentação de aceite, limitações e próximos passos: `MB03_ENTREGA_PARCIAL.md`. Para regenerar as 15 fichas atuais com dados originais: `python build_mb03.py`.


## GitHub + Vercel (fase piloto)

Este pacote contém `vercel.json`, build de arquivos públicos em `dist/`, fluxo de QA no GitHub Actions e instruções em **[`DEPLOY_GITHUB_VERCEL.md`](DEPLOY_GITHUB_VERCEL.md)**.

```bash
npm run qa
npm run build
npm run qa:deploy
npm run preview -- --dist
```

- Hospedagem de aplicação estática sem banco de dados e sem exigência de serviços pagos no MVP.
- Os arquivos de pesquisa, QA e planilhas **não** são enviados ao diretório público.
- `robots.txt` e `noindex` são medidas temporárias do piloto, não autenticação. Qualquer pessoa com o URL pode acessar a aplicação.
- O progresso local não sincroniza entre aparelhos.
- Fotografias JPG antigas permanecem no ZIP-fonte para preservação histórica, mas **não são publicadas**; confirmar direitos antes de qualquer reutilização.
- Conteúdo procedimental em **revisão técnica**, não clínico-assistencial. A aprovação clínica exige validação por profissional e protocolo institucional.

## Consolidação MB03 / Legibilidade (v1.4.3)

Interface revista: texto principal 16 px, legendas e textos secundários 14 px como mínimo no CSS; 46 fichas estruturadas, Atlas com 41 materiais e 158 variantes. Revisão médica independente pendente. Ver `MB03_CONSOLIDACAO.md`.


## v1.4.5 — Português/Espanhol sem bloqueio de revisão

- Seletor PT/ES ativo e persistido localmente; menus, títulos das 115 aulas, nomes das 46 fichas práticas e descrições iniciais das 46 fichas possuem tradução espanhola editorial.
- Busca por termos comuns em ambos os idiomas com aliases (ex.: `sutura simple` → `sutura simples`).
- Removidos banner de aviso do idioma ES e bloqueios visuais de aprovação/revisão externa.
- O conteúdo pode ser estudado e divulgado como educativo independentemente de revisor externo; documentos mantêm autoria, fonte, versão e limites de aplicação.
- **Não confundir:** as seções técnicas completas, 115 corpos de aulas, questões e casos não foram traduzidos integralmente; preservam o português original. A interface e os títulos estão traduzidos, e a tradução dos textos clínicos seguirá incrementalmente.
- Os campos de revisão internos podem existir para rastrear atualizações, mas não impedem disponibilização educacional.
- QA: `npm run qa:all`; o idioma é testado por `scripts/qa-i18n-functional.mjs`, sem exigir serviço externo.
