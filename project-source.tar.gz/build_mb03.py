"""Gera fichas educacionais MB03 originais, sem alterar o banco legado."""
import json
from pathlib import Path
from datetime import date
ROOT=Path(__file__).parent
F=['definition','indications','contraindications','anatomy','materials','environment','patient','analgesia','sequence','confirmation','complications','aftercare','skills-checklist','media-references']
S={
 'WHO-PIV':('OMS — Diretriz de cateteres periféricos (2024)','https://www.who.int/publications/i/item/9789240093829'),
 'CDC-INJ':('CDC — Práticas seguras de injeção','https://www.cdc.gov/injection-safety/hcp/clinical-safety/'),
 'WHO-HAND':('OMS — Cinco momentos para higiene das mãos','https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene'),
 'MERCK-WOUND':('Merck Manual — Limpeza, irrigação e curativos (revisado 2026)','https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds'),
 'MERCK-SUT':('Merck Manual — Sutura simples interrompida (revisado 2026)','https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures'),
 'CDC-TET':('CDC — Manejo de feridas e profilaxia antitetânica (2026)','https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html'),
 'CDC-RABIES':('CDC — Profilaxia da raiva após exposição','https://www.cdc.gov/rabies/hcp/clinical-care/post-exposure-prophylaxis.html'),
 'AAOS-CAST':('AAOS — Cuidados com talas e gessos','https://www.orthoinfo.org/recovery/care-of-casts-and-splints/'),
 'CDC-GLU':('CDC — Segurança na monitorização de glicemia','https://www.cdc.gov/injection-safety/hcp/infection-control/'),
 'WHO-PHLEB':('OMS — Boas práticas em flebotomia','https://www.who.int/publications/i/item/9789241599221'),
 'NHSN-WOUND':('CDC/NHSN — Classificação de feridas operatórias','https://www.cdc.gov/nhsn/index.html'),
 'ECG-CHSS':('CHSS eLearning — ECG de 12 derivações e posicionamento','https://www.chsselearning.org.uk/hearte/9-cardiac-investigations/electrocardiography/12-lead-ecg/'),
}
P=[]
def a(pid,title,scope,level,materials,extras,refs,fields,critical,pop='Adulto;Pediatria sob protocolo específico',supervision='Simulação e execução supervisionada por profissional habilitado',prereqs=None):
 assert len(fields)==14, (pid,len(fields))
 d={"id":pid,"topicIds":[pid],"title":title,"priority":"P0","level":level,"scope":scope,"population":pop,"environment":"Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura","supervision":supervision,"professionalScope":"Conforme habilitação, atribuições legais e protocolo institucional","prerequisites":prereqs or ['Higienização das mãos','Identificação e consentimento','Reconhecimento de eventos adversos'],"editorial":{"status":"revisao-tecnica","version":"0.1","clinicalReviewer":None,"reviewedOn":None,"publishedOn":None},"materialLinks":materials,"additionalSupplies":extras,"criticalErrors":critical,"fields":{k:[x.strip() for x in v.split('|') if x.strip()] for k,v in zip(F,fields)},"references":[{"id":s,"title":S[s][0],"url":S[s][1],"checkedOn":"2026-10-14"} for s in refs],"media":[],"illustration":{"type":"original-schematic","caption":"Roteiro de segurança original; não representa anatomia em escala","author":"Nexo Cirúrgico","license":"Original do projeto"}}
 d['fields']['media-references'] += ['Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.','Fontes e data de conferência identificadas na seção final da ficha.']
 P.append(d)

a('PT-M01-01','Higienização das mãos','Biossegurança','Básico',[],['Preparação alcoólica apropriada ou água e sabonete; papel-toalha; pia funcional'],['WHO-HAND'],[
'Prática fundamental para interromper transmissão cruzada de microrganismos e proteger paciente e equipe.',
'Antes de tocar o paciente; antes de procedimento limpo/asséptico; após risco de fluidos; após tocar paciente; após tocar superfícies próximas.',
'Não há contraindicação à higiene; alergia ou lesão cutânea requer adequação do produto e avaliação ocupacional.',
'Mãos, unhas, espaços interdigitais, polegares, pontas dos dedos e punhos; integridade cutânea e adornos interferem.',
'Preparação alcoólica regulamentada quando indicada; água e sabonete quando mãos visivelmente sujas ou conforme protocolo.',
'Garantir suprimentos acessíveis e pontos de higiene nos locais de cuidado.',
'Explicar ações ao paciente quando pertinente; remover acessórios de mão conforme regras locais.',
'Não requer anestesia ou analgesia.',
'Identificar o momento assistencial | Escolher água e sabonete ou produto alcoólico conforme indicação | Cobrir todas as superfícies das mãos até secagem completa | Não substituir higiene por uso de luvas.',
'Mãos secas após fricção alcoólica; ausência de áreas negligenciadas na demonstração observada.',
'Erro de oportunidade, técnica incompleta, contaminação após higiene e dermatite; corrigir e repetir quando necessário.',
'Repetir nos cinco momentos; notificar problemas de suprimento ou dermatite ocupacional.',
'Reconhece os cinco momentos | Seleciona método apropriado | Abrange polegares e pontas dos dedos | Não considera luvas substitutas.',
'Usar recursos da OMS como apoio de aprendizagem, não como autorização de reutilização de mídia.'
],['Deixar de higienizar antes de técnica asséptica','Tratar luvas como substituto da higiene'],pop='Todas as faixas etárias')

a('PT-M04-05','Administração intramuscular de medicamentos','Administração de medicamentos','Básico', ['MAT-MED-001','MAT-MED-002'],['Medicamento prescrito, diluente compatível se aplicável, antisséptico, luvas, gaze, coletor de perfurocortantes'],['CDC-INJ','WHO-HAND'],[
'Administração de fármaco no tecido muscular, observando indicação da via e formulação autorizada.',
'Quando a apresentação e a prescrição permitem via IM, com volume, local e absorção compatíveis.',
'Não utilizar via IM quando a formulação não for destinada a ela; avaliar infecção local, alterações de coagulação e riscos individuais.',
'Identificar marcos anatômicos de locais adequados, com variações por faixa etária e massa muscular; evitar estruturas neurovasculares.',
'Conferir medicamento, dose, diluição, seringa e agulha de comprimento/calibre apropriados; agulha e seringa de uso único.',
'Área limpa, recipiente de descarte próximo e disponibilidade de manejo de reação adversa.',
'Conferir paciente, prescrição, alergias, contraindicações, consentimento, integridade do local e capacidade de colaborar.',
'Medidas de conforto e posicionamento; necessidade de analgesia específica depende do procedimento e paciente.',
'Validar prescrição e preparo com identificação completa | Localizar sítio anatômico compatível e posicionar | Higienizar mãos e seguir política de antissepsia | Administrar sob técnica do serviço e descarte imediato sem reencape | Documentar lote quando pertinente.',
'Confirmar medicamento, dose, via, local e documentação; observar resposta e reação imediata.',
'Lesão nervosa ou vascular, dor, hematoma, infecção, reação alérgica; interromper e acionar suporte se houver reação grave.',
'Orientar sinais de alerta, cuidados locais e registro de administração; vigiar reações.',
'Confere identificação/alergias | Justifica sítio e dispositivo | Mantém assepsia | Descarta sem reencapar | Reconhece anafilaxia.',
'Tabelas de comprimentos e volumes devem ser formuladas por medicamento, idade e fabricante, e não presumidas de uma regra universal.'
],['Agulha compartilhada ou reutilizada','Medicação em via não autorizada','Falta de confirmação de alergias'])

a('PT-M05-01','Acesso venoso periférico','Acessos vasculares','Intermediário',['MAT-VAS-001','MAT-INF-001','MAT-INF-002','MAT-MED-001'],['Garrote, antisséptico adequado, luvas, solução de flushing compatível, gaze, cobertura transparente ou apropriada, descarte perfurocortante'],['WHO-PIV','WHO-HAND'],[
'Introdução de cateter curto em veia periférica para terapia intravenosa e outras indicações clínicas.',
'Infusão de fluidos/medicamentos compatíveis, contraste ou necessidade de acesso venoso conforme avaliação.',
'Evitar áreas de infecção, flebite, comprometimento circulatório e locais com restrições clínicas; reconsiderar necessidade e via.',
'Veias periféricas do membro superior, anatomia e mobilidade; escolha do vaso deve considerar terapêutica e preservação vascular.',
'Cateter com calibre e comprimento adequados ao vaso e terapia; conector, extensão, cobertura, solução e embalagem íntegra.',
'Higiene das mãos, campo limpo, iluminação, contenção mínima e descarte imediatamente acessível.',
'Identificação, consentimento, alergias, pele/vasculatura, histórico de tentativas e necessidade de analgesia individualizada.',
'Analgesia tópica ou outra medida de conforto pode ser considerada quando adequada à população e disponibilidade.',
'Planejar sítio e dispositivo | Higienizar mãos e preparar material | Realizar antissepsia e preservar área preparada | Simular sequência de inserção e liberação segura do mecanismo | Confirmar permeabilidade, fixar e identificar | Registrar e ensinar sinais de alerta.',
'Confirmar funcionamento sem sinais de infiltração ou dor; seguir protocolo de permeabilidade e documentação.',
'Infiltração, extravasamento, flebite, trombose, infecção, hematoma, perfurocortante; interromper uso e avaliar complicações.',
'Inspecionar inserção e trajeto venoso pelo menos diariamente; reavaliar necessidade e remover conforme indicação e protocolo.',
'Indica necessidade | Seleciona calibre pelo vaso/terapia | Preserva antissepsia | Confirma funcionamento | Reconhece extravasamento | Registra.',
'O calibre não é exclusivo de faixas etárias; orientações de marca e protocolo local prevalecem.'
],['Reutilizar cateter','Manter infusão diante de extravasamento','Omitir antissepsia'],pop='Adulto;Criança;Neonato com protocolo e supervisão específicos')

a('PT-M05-02','Coleta de sangue venoso','Acessos vasculares','Básico',['MAT-VAS-002','MAT-MED-002','MAT-MED-001'],['Tubos identificados conforme exames, garrote, luvas, antisséptico, gaze, curativo e descarte'],['WHO-PHLEB','WHO-HAND','CDC-INJ'],[
'Obtenção de amostra venosa para análises laboratoriais com rastreabilidade pré-analítica.',
'Quando exames solicitados demandam sangue venoso e a condição do paciente permite coleta periférica.',
'Evitar local com infecção, hematoma, infusão ativa ou restrições institucionais; avaliar acesso alternativo.',
'Rede venosa superficial, proximidade de estruturas nervosas e artérias; cuidado especial com anatomia pediátrica.',
'Dispositivo apropriado à veia, sistema fechado quando possível, tubos corretos, identificação à beira-leito.',
'Preparar bancada, descarte, transporte e requisitos de conservação do laboratório.',
'Conferir dois identificadores, prescrição, preparo do exame e riscos de síncope ou sangramento.',
'Medidas de conforto e posicionamento, especialmente se histórico de reação vasovagal.',
'Confirmar pedidos e tubos | Higienizar mãos e selecionar dispositivo | Executar antissepsia e coleta conforme protocolo | Homogeneizar tubos quando indicado | Soltar garrote, retirar e descartar dispositivo | Identificar amostras na presença do paciente.',
'Conferir identificação, volume, qualidade da amostra e condições de envio; garantir hemostasia local.',
'Hematoma, punção arterial acidental, síncope, hemólise e identificação incorreta; interromper e reavaliar.',
'Orientar compressão local, sinais de retorno e registrar intercorrências.',
'Confere dois identificadores | Seleciona tubos corretos | Controla exposição | Identifica tubos no ponto de cuidado | Evita hemólise.',
'Ordem de coleta, anticoagulantes e volumes devem seguir manual do laboratório e fabricante.'
],['Tubo sem identificação','Reutilização de agulha','Identificação posterior fora do paciente'])

a('PT-M06-01','Avaliação estruturada da ferida','Feridas e lesões','Básico',[],['Luvas, fonte de luz, régua descartável apropriada, gaze, material de documentação autorizado'],['MERCK-WOUND','CDC-TET'],[
'Exame padronizado da lesão para decidir urgência, limpeza, imagem, fechamento e acompanhamento.',
'Toda lesão cutânea traumática, cirúrgica ou crônica requer caracterização antes da conduta.',
'Ferida profunda, isquemia, sangramento persistente ou comprometimento neurovascular demandam avaliação urgente especializada.',
'Localização, bordas, leito, profundidade, vascularização e proximidade de tendões, vasos, nervos e articulações.',
'Iluminação, luvas, material de mensuração e cobertura; fotografia somente com autorização e proteção dos dados.',
'Privacidade, assepsia adequada ao cenário e acesso a controle de sangramento.',
'Investigar mecanismo/tempo da lesão, imunização antitetânica, comorbidades, medicamentos e sintomas sistêmicos.',
'Oferecer controle da dor conforme avaliação; evitar exploração dolorosa sem analgesia.',
'Estabilizar e controlar sangramento | Inspecionar dimensão, bordas, exsudato, tecido, corpos estranhos e perfusão | Avaliar função sensitiva e motora | Identificar possível contaminação/infecção | Decidir irrigação, fechamento ou encaminhamento.',
'Documentar local, medidas, extensão, tecidos envolvidos, perfusão e conduta justificada.',
'Infecção, corpo estranho oculto, lesão tendínea, nervosa ou vascular; não mascarar sinais de gravidade.',
'Orientar cuidados e prazo de reavaliação, incluindo sinais de alarme e profilaxias indicadas.',
'Classifica mecanismo | Avalia profundidade | Examina função e perfusão | Verifica tétano | Documenta plano e retorno.',
'A classificação cirúrgica limpa/limpa-contaminada/contaminada/suja não substitui a classificação das feridas traumáticas.'
],['Suturar sem pesquisar lesão profunda','Ignorar perfusão ou função distal'])

a('PT-M06-03','Irrigação de ferida','Feridas e lesões','Básico',['MAT-MED-001'],['Soro fisiológico ou água apropriada conforme protocolo, seringa e proteção de respingos, recipiente, gaze e equipamento de proteção'],['MERCK-WOUND','CDC-TET'],[
'Limpeza mecânica por fluxo líquido para reduzir carga de contaminantes antes da decisão de fechamento.',
'Feridas traumáticas e lesões com resíduos quando irrigação está indicada no plano de cuidado.',
'Não irrigar de forma não controlada cavidades profundas ou trajetos com suspeita de lesão de estruturas; pedir avaliação especializada.',
'Reconhecer profundidade, limites e estruturas adjacentes; realizar exame vascular, neurológico e tendíneo antes do fechamento.',
'Solução salina ou água apropriada conforme cenário; dispositivo que forneça fluxo controlado, cobertura e gaze.',
'Garantir iluminação, contenção de respingos, segurança de perfurocortantes e descarte.',
'Explicar desconforto, obter consentimento e avaliar riscos de retenção de corpo estranho.',
'Analgesia local ou sistêmica individualizada pode ser necessária para inspeção e limpeza adequadas.',
'Controlar sangramento | Examinar extensão e corpo estranho | Proteger paciente/equipe | Irrigar sem traumatizar tecidos | Retirar contaminantes visíveis com instrumentos adequados | Reavaliar e decidir fechamento/encaminhamento.',
'Campo sem sujeira grosseira; tecidos viáveis e integridade funcional novamente documentada.',
'Lesão por pressão exagerada, contaminação secundária, retenção de corpo estranho e falha em reconhecer lesão profunda.',
'Aplicar cobertura apropriada, atualizar avaliação de tétano e organizar retorno.',
'Avalia antes de irrigar | Escolhe solução apropriada | Protege de respingos | Reavalia tecido e função | Evita lesão adicional.',
'Antissépticos citotóxicos não devem ser aplicados indiscriminadamente no leito da ferida.'
],['Fechar ferida com corpo estranho suspeito','Irrigação sem avaliação de lesão profunda'])

a('PT-M06-07','Seleção e troca de curativos','Feridas e lesões','Básico',[],['Luvas, solução adequada de limpeza, compressa não aderente, gaze absorvente, fixação e descarte'],['MERCK-WOUND'],[
'Escolha, aplicação e troca de cobertura para proteção do leito e manejo do exsudato.',
'Feridas que demandam proteção ou controle de umidade/exsudato, conforme etiologia e estágio.',
'Evitar cobertura oclusiva inadequada em infecção não controlada ou maceração; priorizar avaliação de perfusão e etiologia.',
'Avaliar leito, pele perilesional, cavidades, exsudato, perfusão e áreas de pressão.',
'Escolher cobertura segundo exsudato, aderência, profundidade e fabricante; material não aderente quando necessário.',
'Preparar superfície limpa, privacidade e local apropriado para descarte contaminado.',
'Conferir alergias a adesivos, dor, odor, temperatura, sinais de infecção e evolução anterior.',
'Analgesia antes da troca quando indicada; evitar retirada traumática de coberturas aderidas.',
'Examinar curativo anterior | Higienizar mãos e proteger-se | Remover cobertura preservando tecido | Limpar e avaliar leito | Selecionar cobertura com justificativa | Fixar sem restringir circulação | Registrar achados.',
'Cobertura protege sem compressão excessiva, controle de exsudato e ausência de piora visível.',
'Maceração, dermatite de contato, dor, infecção, reação alérgica, isquemia por fixação inadequada.',
'Definir periodicidade de troca pela ferida e pelo produto, orientar sinais de piora e revisão.',
'Distingue leito/perilesão | Reconhece exsudato | Justifica tipo de cobertura | Evita fixação compressiva | Documenta evolução.',
'A periodicidade não deve ser uma regra única para todas as coberturas.'
],['Cobrir sem avaliar perfusão','Aplicar material não compatível com o leito'])

a('PT-M06-09','Feridas por mordedura animal ou humana','Feridas e lesões','Intermediário',[],['Solução para lavagem abundante, material de irrigação, EPI, cobertura apropriada e acesso a avaliação de profilaxias'],['CDC-TET','CDC-RABIES','MERCK-WOUND'],[
'Abordagem de lesões com inoculação potencial de microrganismos por saliva, incluindo risco de raiva em exposições selecionadas.',
'Mordidas, arranhaduras com exposição, lesões perfurantes e mordeduras humanas.',
'Não presumir fechamento primário automático; suspeita de lesão em mão, tendão, articulação ou estrutura profunda exige avaliação especializada.',
'Inspecionar profundidade e relação com articulações, tendões, nervos e vasos, especialmente na mão.',
'Luvas, material de limpeza/irrigação, cobertura; acesso a imunobiológicos conforme avaliação epidemiológica.',
'Preparar lavagem precoce, contenção de secreções e encaminhamento quando necessário.',
'Documentar espécie, situação do animal, local, tempo de exposição, vacinação conhecida, histórico antitetânico e imunossupressão.',
'Avaliar analgesia e necessidade de avaliação especializada conforme dor e complexidade.',
'Controlar hemorragia | Realizar lavagem abundante apropriada | Explorar lesões e função | Avaliar necessidade de antibiótico, tétano e raiva separadamente | Definir fechamento seletivo e seguimento.',
'Registrar risco de raiva avaliado e decisão/protocolo consultado; documentar exame neurovascular e plano de retorno.',
'Infecção polimicrobiana, tenossinovite, artrite séptica, sepse, raiva e tétano; encaminhar urgentemente nos cenários de risco.',
'Orientar vigilância de sinais de infecção e reavaliação precoce conforme local/risco.',
'Pergunta espécie/situação | Examina mão/estrutura profunda | Diferencia três profilaxias | Não sutura automaticamente | Registra encaminhamento.',
'Conduta antirrábica deve considerar protocolos epidemiológicos do país/região e comunicação às autoridades sanitárias.'
],['Substituir tétano por antibiótico','Omitir avaliação antirrábica','Fechamento automático de ferida profunda da mão'])

a('PT-M07-03','Sutura simples interrompida','Suturas e fechamento','Intermediário',['MAT-SUT-001','MAT-SUT-003','MAT-INS-003','MAT-INS-004'],['Tesoura de sutura, gaze, campos, materiais de irrigação, anestésico local se indicado, EPI e cobertura'],['MERCK-SUT','MERCK-WOUND','CDC-TET'],[
'Técnica de aproximação cutânea com pontos separados, adequada a determinadas feridas após avaliação.',
'Feridas com bordas aproximáveis sem tensão excessiva, após limpeza, inspeção e decisão fundamentada de fechamento.',
'Não fechar sem avaliar ferida contaminada/infectada, perda tecidual, perfusão, corpo estranho e lesões profundas; considerar alternativas.',
'Pele, derme, margens e estruturas profundas adjacentes; tensão e linhas de força locais.',
'Porta-agulhas, pinça adequada, fio/agulha escolhidos por sítio e tensão, tesoura, anestesia e curativo.',
'Boa iluminação, preparação de campo e descarte seguro de instrumentos perfurantes.',
'Informar paciente, confirmar alergias, tétano, mecanismo, exame neurovascular/tendíneo e consentimento.',
'Anestesia local conforme protocolo e dose segura individualizada; não usar dose universal.',
'Exame e hemostasia | Analgesia, limpeza/irrigação e desbridamento quando apropriado | Posicionar instrumentos em modelo | Simular passagem simétrica da agulha respeitando tecidos | Aproximar sem estrangulamento | Verificar bordas e aplicar curativo.',
'Coaptação adequada, sem isquemia, tensão excessiva, lacunas ou lesão funcional; documentação do material usado.',
'Isquemia das bordas, infecção, deiscência, lesão por agulha, corpo estranho e cicatriz desfavorável; escalar quando necessário.',
'Orientar cuidados, sinais de infecção, revisão e retirada de pontos conforme localização e evolução.',
'Escolhe ferida apropriada | Verifica estruturas | Seleciona fio | Evita tensão | Mantém segurança de agulhas | Orienta retorno.',
'Aula textual não certifica habilidade; manobras devem ser praticadas em simulador com instrutor.'
],['Fechar lesão profunda não explorada','Estrangular bordas','Agulha descartada inadequadamente'])

a('PT-M13-02','Tala antebraquiopalmar','Ortopedia e imobilização','Intermediário',[],['Material de tala apropriado, acolchoamento, bandagem, água conforme fabricante, tesoura e proteção da pele'],['AAOS-CAST'],[
'Imobilização não circunferencial de punho/antebraço para suporte temporário ou terapêutico em indicações selecionadas.',
'Lesões traumáticas selecionadas enquanto se define diagnóstico e tratamento, ou imobilização pós-procedimento indicada.',
'Não usar como substituto de avaliação urgente em suspeita de fratura exposta, isquemia, síndrome compartimental ou déficit neurológico.',
'Destacar cotovelo, antebraço, punho, proeminências ósseas, dedos e avaliação distal neurovascular.',
'Tala, acolchoamento, material de fixação e instruções de ativação/tempo de cura do fabricante.',
'Preparar ambiente e material, prever edema e acesso para reavaliação.',
'Identificar lado, dor, deformidade, integridade cutânea, pulso, perfusão, sensibilidade e movimento previamente.',
'Analgesia apropriada à dor e eventual redução realizada apenas por profissional habilitado.',
'Avaliar antes da imobilização | Proteger proeminências e pele | Moldar tala conforme indicação e posicionamento seguro | Fixar sem constrição circunferencial | Avaliar perfusão/sensibilidade/motricidade novamente | Explicar cuidados e alarme.',
'Estabilidade e conforto relativos sem comprometimento de circulação, sensibilidade ou movimento dos dedos.',
'Compressão, queimadura térmica durante endurecimento, maceração, neuropraxia, síndrome compartimental; remover/avaliar imediatamente sinais graves.',
'Orientar elevação, proteção contra umidade conforme material, retorno e sinais de alarme.',
'Examina NV antes/depois | Protege proeminências | Acomoda edema | Molda adequadamente | Informa sinais de urgência.',
'Posições específicas e espessura da tala devem ser definidas conforme lesão e protocolo local.'
],['Não examinar neurovascular distal','Bandagem constritiva','Ignorar dor crescente'],pop='Adultos;Crianças com técnica e vigilância específicas')

a('PT-M13-10','Avaliação neurovascular antes e depois da imobilização','Ortopedia e imobilização','Básico',[],['Boa iluminação, dispositivo de comparação bilateral, registro, oxímetro/temperatura se apropriado'],['AAOS-CAST'],[
'Exame seriado de perfusão, sensibilidade e função motora distal em trauma e após aplicação de talas ou gesso.',
'Toda imobilização de membros, suspeita de compressão ou dor/parestesia em membro traumatizado.',
'Não postergar avaliação urgente por ausência de pulso palpável, isquemia ou suspeita de síndrome compartimental.',
'Conhecer territórios nervosos, motricidade distal, pulsos periféricos e áreas de circulação relevantes.',
'Lanterna/iluminação, relógio, registro e recursos adequados para avaliar perfusão.',
'Garantir acesso ao segmento distal e referência de comparação contralateral.',
'Explicar exame, avaliar dor, sensibilidade prévia, circulação e função antes de qualquer imobilização.',
'Evitar estímulos dolorosos desnecessários; analgesia não deve atrasar avaliação de emergência.',
'Comparar perfusão e cor | Verificar temperatura, enchimento capilar e pulsos quando pertinentes | Testar sensibilidade e motricidade por territórios | Registrar antes e após | Repetir se dor, edema ou parestesia.',
'Comparação bilateral e registro explícito de alterações; definir destino/urgência em caso de achados anormais.',
'Déficit neurológico, compressão, isquemia, síndrome compartimental; sinal de alerta exige avaliação imediata.',
'Instruir a buscar ajuda por dor progressiva, formigamento, perda de movimento e mudança de cor ou temperatura.',
'Testa e documenta perfusão | Documenta motricidade e sensibilidade | Repete após tala | Reconhece emergência.',
'Pulsos preservados não excluem síndrome compartimental.'
],['Concluir que pulso normal exclui síndrome compartimental','Deixar de repetir exame após imobilização'])

a('PT-M27-01','Glicemia capilar à beira-leito','Diagnóstico à beira-leito','Básico',[],['Glicosímetro validado, tira compatível, lanceta de uso único, EPI e descarte de perfurocortantes'],['CDC-GLU','WHO-HAND'],[
'Determinação point-of-care de glicose com dispositivo adequado e controle de qualidade.',
'Monitorização ou avaliação rápida quando resultado influencia decisão clínica.',
'Resultados incompatíveis com quadro clínico ou contexto de má perfusão exigem confirmação laboratorial conforme protocolo.',
'Polpa digital ou outro local validado pelo dispositivo e faixa etária; reconhecer limitações por perfusão.',
'Lanceta descartável por paciente, tira dentro da validade, equipamento com QC e instrução de uso atual.',
'Confirmar funcionamento, calibração/controle do aparelho, limpeza e descarte.',
'Identificar paciente e indicar o teste; avaliar mãos, perfusão, substâncias na pele e contexto clínico.',
'Puncionamento breve; medidas de conforto conforme idade e técnica.',
'Higienizar mãos | Conferir tira e aparelho | Preparar local sem contaminar amostra | Coletar pelo dispositivo conforme IFU | Descartar lanceta sem reencape | Interpretar no contexto e registrar.',
'Valor e horário documentados com identificação do equipamento; confirmar discrepâncias críticas.',
'Falso resultado por contaminação, baixa perfusão, técnica incorreta; contaminação cruzada e acidente perfurocortante.',
'Comunicar resultados críticos e tratar segundo protocolo clínico; higienizar equipamento entre pacientes.',
'Usa lanceta única | Verifica QC | Identifica paciente | Interpreta limitações | Desinfeta equipamento.',
'Não utilizar valor isolado quando incompatível com estado clínico.'
],['Lanceta reutilizada','Glicosímetro compartilhado sem desinfecção','Ignorar hipoglicemia clínica por leitura suspeita'])


a('PT-M06-06','Classificação clínica e cirúrgica das feridas','Feridas e lesões','Básico',[],['Luvas, material de inspeção e registro clínico'],['MERCK-WOUND','NHSN-WOUND'],[
'Organização da avaliação de feridas traumáticas, cirúrgicas ou crônicas sem confundir sistemas classificatórios distintos.',
'Toda caracterização de ferida para documentação, risco de infecção e escolha do cuidado.',
'Classificação isolada não justifica fechamento ou antibiótico e não substitui exame clínico.',
'Reconhecer local, tecidos, profundidade, comunicação com cavidades e estruturas lesadas.',
'Instrumentos de mensuração e registro padronizado; não é necessária escala Gauge/French.',
'Garantir iluminação, privacidade e barreiras de proteção.',
'Investigar mecanismo, tempo, presença de sujidade, perfusão, sinais de infecção e comorbidades.',
'Analgesia individualizada quando exame é doloroso.',
'Caracterizar ferida por etiologia e profundidade | Diferenciar lesão traumática de classificação de ferida operatória | Quando pertinente, distinguir I limpa, II limpa-contaminada, III contaminada e IV suja/infectada | Registrar justificativa e conduta clínica.',
'Documentar classificação usada e critérios objetivos, sem misturar classificações cirúrgica, traumática e de risco de tétano.',
'Subestimar contaminação, corpo estranho e comprometimento vascular pode causar fechamento inadequado; reavaliar risco.',
'Planejar reavaliação, prevenção de infecção e cuidados conforme etiologia.',
'Distingue três sistemas classificatórios | Reconhece ferida infectada | Avalia mecanismo e profundidade | Justifica conduta.',
'Revisar definições de classes operatórias com protocolo institucional e vigilância de infecção.'
],['Rotular mordedura automaticamente como ferida cirúrgica classe IV','Indicar sutura com base apenas na classe'])

a('PT-M07-11','Retirada de pontos e grampos cutâneos','Suturas e fechamento','Básico',['MAT-INS-007'],['Removedor apropriado de grampos, pinça e tesoura esterilizados quando indicados, EPI, gaze, solução de limpeza, fita de suporte da ferida'],['MERCK-SUT'],[
'Remoção controlada de dispositivos de fechamento após avaliação de reparação tecidual e risco de deiscência.',
'Feridas cicatrizadas suficientemente após período e localização adequados, com indicação profissional.',
'Não retirar indiscriminadamente diante de deiscência, sinais graves de infecção, isquemia ou tensão não resolvida.',
'Avaliar bordas da epiderme, profundidade, articulações, localização facial ou de membros e zonas de tensão.',
'Tesoura apropriada, pinça, removedor de grampos, gaze e material de suporte se indicado.',
'Boa iluminação, higiene das mãos, descarte de materiais contaminados e plano para abertura inesperada da ferida.',
'Conferir data, tipo de fechamento, antecedentes de infecção, diabetes/imunossupressão e aspecto atual.',
'Explicar desconforto possível; analgesia frequentemente não é necessária, mas individualizar.',
'Examinar coaptação e sinais de infecção | Higienizar mãos e preparar material | Realizar remoção segundo tipo de fechamento e treinamento | Reavaliar imediatamente bordas | Aplicar suporte ou interromper remoção quando abertura ameaçar.',
'Bordas íntegras sem abertura ou sangramento relevante; documentar quantidade retirada e retenções suspeitas.',
'Deiscência, sangramento, fragmentos de fio, infecção e lesão cutânea; interromper e buscar avaliação.',
'Proteger a região conforme necessidade e orientar sinais de alerta e retorno.',
'Avalia tensão e cicatrização | Seleciona instrumento adequado | Confere integridade após remoção | Documenta.',
'Tempo de retirada depende do local e evolução; evitar calendário universal sem avaliação.'
],['Remover pontos apesar de deiscência progressiva','Deixar fragmento de fio sem documentação'])

a('PT-M27-02','Eletrocardiograma de 12 derivações à beira-leito','Diagnóstico à beira-leito','Básico',[],['Eletrocardiógrafo de 12 derivações, eletrodos compatíveis, condutor quando apropriado, papel/registro digital e material para preparo da pele'],['ECG-CHSS','WHO-HAND'],[
'Registro não invasivo da atividade elétrica cardíaca com posicionamento padronizado de eletrodos e identificação adequada.',
'Investigação de sintomas cardíacos, arritmias, monitoramento e situações agudas conforme avaliação clínica.',
'Não postergar atendimento urgente para aguardar ECG; artefatos e posicionamento inadequado exigem repetição.',
'Identificar referências anatômicas para V1-V6 e membros; reconhecer diferenças em condições especiais.',
'Eletrodos, cabos, equipamento calibrado e papel/registros; conferir integridade e limpeza do sistema.',
'Preparar superfície, controle de interferências, isolamento elétrico e privacidade.',
'Confirmar identidade, explicar procedimento e obter posição tolerável, expondo apenas áreas necessárias.',
'Indolor; analgesia não é necessária, exceto manejo de dor do quadro clínico concomitante.',
'Conferir identificação e qualidade do equipamento | Preparar pele | Localizar pontos anatômicos e posicionar eletrodos segundo padrão de 12 derivações | Solicitar imobilidade breve | Registrar e conferir calibração/artefatos.',
'Obtém traçado legível, com nome e data corretos, 12 derivações, velocidade e amplitude registradas.',
'Inversão de cabos, derivações precordiais mal posicionadas, artefatos, interpretação precipitada; repetir traçado quando necessário.',
'Encaminhar interpretação ao profissional responsável e comunicar imediatamente resultados críticos conforme fluxo local.',
'Posiciona eletrodos pelo marco anatômico | Confere qualidade e dados | Reconhece artefatos | Comunica urgência.',
'Esta ficha cobre aquisição técnica, não interpretação cardiológica completa.'
],['Troca de identificação do paciente','Ignorar suspeita de evento cardíaco agudo durante preparação'])

out={"version":"0.1","macroblock":"MB03","generatedOn":"2026-10-14","status":"revisao-tecnica","sourcePolicy":"Textos originais resumem princípios de segurança; revisão especializada obrigatória antes de publicação clínica.","procedures":P}
p=ROOT/'procedimentos_mb03.js'
p.write_text('/* MB03: fichas técnicas originais, em revisão clínica, separadas do acervo legado. */\nwindow.NEXO_PROCEDURES = '+json.dumps(out,ensure_ascii=False,indent=2)+';\n'+"""
/* Vincular status apenas às fichas redigidas; manter demais tópicos catalogados. */
(function(){
 const data=window.NEXO_DATA;
 const phase=data.technicalCurriculum.macroblocks.find(m=>m.id==='MB03');
 if(phase){phase.status='Em desenvolvimento';phase.description='Primeiro lote: 15 fichas técnicas editoriais. Pendentes outros procedimentos, ilustrações e revisão clínica.';}
 const topicIndex=data.technicalCurriculum.modules.flatMap(m=>m.topics);
 for(const procedure of window.NEXO_PROCEDURES.procedures){
  for(const topicId of procedure.topicIds){
   const topic=topicIndex.find(t=>t.id===topicId);
   if(!topic)throw Error('MB03: tópico inexistente: '+topicId);
   topic.status='revisao-tecnica';
   topic.revision={...topic.revision,version:'0.2',state:'revisao-tecnica',reviewedOn:null,reviewer:null};
  }
 }
})();
""",encoding='utf-8')
print(len(P),'fichas,',p.stat().st_size,'bytes')
