/* MB04 Lote 1: testes de contrato curricular, navegação e preservação do conteúdo. */
const vm=require('node:vm'), fs=require('node:fs'), path=require('node:path');
const root=__dirname,errors=[];let checks=0;
function assert(label,pass){checks++;if(!pass)errors.push(label)}
function element(){return{innerHTML:'',textContent:'',value:'',style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelectorAll:()=>[],querySelector:()=>null,focus(){},parentElement:{addEventListener(){},contains(){return false},classList:{add(){},remove(){}}}}}
function build(){const events={},els={},location={hash:'#/dashboard'},window={},ctx={window,console,location,localStorage:{getItem:()=>null,setItem(){}},setTimeout:()=>0,clearTimeout:()=>{},requestAnimationFrame:()=>{}};const document={title:'',querySelectorAll:()=>[],addEventListener(){},getElementById(id){return els[id]||(els[id]=element())}};Object.assign(ctx,{document});Object.assign(window,{window,document,location,localStorage:ctx.localStorage,scrollTo(){},addEventListener:(name,fn)=>events[name]=fn});vm.createContext(ctx);for(const n of ['data.js','procedimentos_mb03.js','procedimentos_mb04_l2.js','app.js'])vm.runInContext(fs.readFileSync(path.join(root,n),'utf8'),ctx,{filename:n});return {window,events,els,location};}
const t=build(),d=t.window.NEXO_DATA,p=t.window.NEXO_PROCEDURES.procedures,fields=d.technicalCurriculum.lessonSchema.map(x=>x.id),atlas=d.materialAtlas.materials;
const m16=d.technicalCurriculum.modules.find(m=>m.id==='M16'),mb04=d.technicalCurriculum.macroblocks.find(m=>m.id==='MB04');
assert('oito tópicos canônicos M16',m16.topics.length===8);
assert('oito fichas M16',p.filter(x=>x.id.startsWith('PT-M16-')).length===8);
assert('75 fichas totais sem duplicação',p.length===75&&new Set(p.map(x=>x.id)).size===75);
assert('MB04 em desenvolvimento',mb04.status==='Em desenvolvimento');
assert('M16 tem estado editorial independente',m16.topics.every(x=>x.status==='em-desenvolvimento'&&x.revision.version==='0.1-MB04-L1'));
assert('arquivo histórico ainda 33/115/210/30/137',d.modules.length===33&&d.modules.flatMap(x=>x.lessons).length===115&&d.quiz.length===210&&d.cases.length===30&&d.flashcards.length===137);
for(const proc of p.filter(x=>x.id.startsWith('PT-M16-'))){
 assert(proc.id+' ficha de 14 campos',fields.length===14&&fields.every(x=>Array.isArray(proc.fields[x])&&proc.fields[x].length>0));
 assert(proc.id+' 5+ etapas práticas',proc.fields.sequence.length>=5);
 assert(proc.id+' checklist prático',proc.fields['skills-checklist'].length>=5);
 assert(proc.id+' riscos e prevenção',proc.criticalErrors.length>=3&&proc.fields.complications.length>0);
 assert(proc.id+' fontes institucionais',proc.references.length>=2&&proc.references.every(x=>x.url.startsWith('https://')));
 assert(proc.id+' vínculo bidirecional ao Atlas',proc.materialLinks.length>=3&&proc.materialLinks.every(mid=>atlas.some(m=>m.id===mid&&m.procedureLinks.some(link=>link.topicId===proc.id))));
 assert(proc.id+' contexto de supervisão',proc.supervision.includes('supervisionada')&&proc.environment.includes('simulação'));
}
function render(route){t.location.hash='#/'+route;t.events.hashchange();return t.els.app.innerHTML}
assert('75 cartões e filtro para Cirurgia Geral',render('procedimentos').split('class="procedure-card"').length-1===75&&t.els.app.innerHTML.includes('Cirurgia geral'));
for(const proc of p.filter(x=>x.id.startsWith('PT-M16-'))){const html=render('procedimento/'+proc.id);assert(proc.id+' rota renderiza 14 painéis',html.includes('class="procedure-header"')&&(html.match(/class="panel procedure-field"/g)||[]).length===14);assert(proc.id+' tem guia de simulação',html.includes('mb04-quick')&&html.includes('GUIA OPERACIONAL'));}
assert('M16 exibe oito fichas na matriz', (render('matriz-tecnica/M16').match(/Abrir ficha técnica/g)||[]).length===8);
assert('atlas tem retorno para M16',render('atlas/MAT-INS-005').includes('#/procedimento/PT-M16-03'));
assert('roadmap mostra M16 oito operacionais',render('roadmap').includes('29 procedimentos operacionais no MB04'));
assert('MB03 não desapareceu',render('procedimento/PT-M05-01').includes('Conferência da bandeja'));
const css=fs.readFileSync(path.join(root,'procedimentos.css'),'utf8');assert('fonte rápida responsiva',css.includes('.mb04-quick li{font-size:var(--nexo-reader-size,18px)'));
const i18n=fs.readFileSync(path.join(root,'idiomas.js'),'utf8');for(const word of ['Incisiones y vías de abordaje','Disección por planos','Cierre por planos','Cirugía general']) assert('termo ES '+word,i18n.includes(word));
console.log(JSON.stringify({status:errors.length?'FALHOU':'APROVADO',checks,passed:checks-errors.length,errors},null,2));if(errors.length)process.exit(1);
