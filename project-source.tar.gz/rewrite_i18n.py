from pathlib import Path
import json
root=Path(__file__).parent
p=root/'i18n-catalog.es.json';tr=json.loads(p.read_text())
fields={
 'Definição e finalidade':'Definición y finalidad','Indicações clínicas':'Indicaciones clínicas','Contraindicações e alternativas':'Contraindicaciones y alternativas','Anatomia e referências':'Anatomía y referencias','Materiais e calibres':'Materiales y calibres','Preparação do ambiente':'Preparación del entorno','Preparação do paciente':'Preparación del paciente','Anestesia e analgesia':'Anestesia y analgesia','Sequência técnica ilustrada':'Secuencia técnica ilustrada','Confirmação do resultado':'Confirmación del resultado','Complicações e manejo inicial':'Complicaciones y manejo inicial','Cuidados posteriores':'Cuidados posteriores','Checklist de habilidades':'Lista de habilidades','Vídeo, referências e revisão':'Video y referencias',
 'Conferência da bandeja / kit':'Comprobación de bandeja / kit','14 campos técnicos':'14 apartados técnicos','matéria original':'material original','Referências vinculadas ao Atlas (conferir fabricante, escala e indicação individual).':'Referencias vinculadas al Atlas (comprobar fabricante, escala e indicación individual).',
 'Outros insumos necessários — cadastro no Atlas pendente':'Otros insumos necesarios — pendientes de incorporar al Atlas','Checklist formativo, sem atribuição automática de competência clínica:':'Lista de verificación formativa, sin acreditación automática de competencia clínica:',
 'Índice da ficha':'Índice de la ficha','Pré-requisitos':'Requisitos previos','Voltar às fichas':'Volver a las fichas','Ver tópico na matriz':'Ver tema en la matriz','FICHA TÉCNICA • MB03':'FICHA TÉCNICA • MB03',
 'Escopo profissional':'Ámbito profesional','Falhas críticas a evitar':'Errores críticos que se deben evitar','PREPARO DE SIMULAÇÃO':'PREPARACIÓN DE SIMULACIÓN','Consultar no Atlas':'Consultar en el Atlas',
 'Visual e licença':'Recurso visual y licencia','VISUAL E LICENÇA':'RECURSO VISUAL Y LICENCIA','PRECAUÇÕES':'PRECAUCIONES','APLICAÇÕES GERAIS':'APLICACIONES GENERALES','Onde aparece':'Dónde se utiliza','Antes de selecionar':'Antes de elegir','O que reconhecer':'Qué identificar','Dependem do contexto':'Dependen del contexto','Relações condicionais':'Relaciones condicionadas','fontes ou requisitos':'fuentes o requisitos','fontes/requisitos':'fuentes/requisitos','materiais iniciais':'materiales iniciales','variantes estruturadas':'variantes estructuradas','variantes no recorte':'variantes en el filtro','categorias':'categorías','fontes e requisitos':'fuentes y requisitos','no Atlas':'en el Atlas',
 'Microblocos':'Microbloques','módulos na matriz':'módulos en la matriz','tópicos catalogados':'temas catalogados','campos por ficha técnica':'apartados por ficha técnica','ESTADO ATUAL':'ESTADO ACTUAL','PLANO DE EVOLUÇÃO':'PLAN DE EVOLUCIÓN','IMPLEMENTAÇÃO POR MACROBLOCOS':'IMPLEMENTACIÓN POR MACROBLOQUES',
 'Guia de estudo e simulação':'Guía de estudio y simulación','Material didático disponível para estudo. Em atendimento real, seguir formação, supervisão e protocolos do serviço.':'Material didáctico disponible para el estudio. En la atención real, seguir la formación, supervisión y los protocolos del servicio.',
 'Estudo independente disponível. A execução no paciente exige treinamento e supervisão adequados.':'Estudio autónomo disponible. La realización en pacientes requiere formación y supervisión adecuadas.',
 'Esta lista é formativa, incompleta para uso assistencial e deve ser conferida com o protocolo do serviço.':'Esta lista es formativa y no es exhaustiva para la asistencia; debe cotejarse con el protocolo del servicio.',
 'Conteúdo educacional complementar. Não substitui treinamento supervisionado, avaliação clínica ou protocolos institucionais.':'Material educativo complementario. No reemplaza el entrenamiento supervisado, la evaluación clínica ni los protocolos institucionales.',
 'Material → variante → procedimento → fonte':'Material → variante → procedimiento → fuente',
 'Atendimento real requer supervisão':'La atención real requiere supervisión',
 'Português':'Português','Español':'Español'
}
tr.update(fields)
(root/'i18n-catalog.es.json').write_text(json.dumps(tr,ensure_ascii=False,indent=2)+'\n')
code=r'''/* Nexo Cirúrgico — interface PT/ES; uso educacional sem bloqueio editorial. */
(() => {
  'use strict';
  const translations = __MAP__;
  const selector = document.getElementById('languageSelector');
  const smaller = document.getElementById('readerSmaller');
  const larger = document.getElementById('readerLarger');
  if (!selector || !smaller || !larger) return;
  const get = (key,fallback) => { try { return localStorage.getItem(key) || fallback; } catch { return fallback; } };
  const set = (key,val) => { try { localStorage.setItem(key,val); } catch {} };
  let language = get('nexo-ui-language','pt');
  if (!['pt','es'].includes(language)) language='pt';
  let font = Number(get('nexo-reader-font','18'));
  if (![16,18,20,22].includes(font)) font=18;
  const originalText = new WeakMap();
  const originalAttributes = new WeakMap();
  const attrs = ['placeholder','aria-label','title'];
  const patterns = [
    [/^(\d+) (fichas técnicas|fichas|materiais|módulos|tópicos|variantes|questões|aulas|campos técnicos|itens conferidos|itens marcados)(.*)$/i,(_,n,k,end) => `${n} ${({ 'fichas técnicas':'fichas técnicas','fichas':'fichas','materiais':'materiales','módulos':'módulos','tópicos':'temas','variantes':'variantes','questões':'preguntas','aulas':'clases','campos técnicos':'apartados técnicos','itens conferidos':'elementos comprobados','itens marcados':'elementos marcados' })[k.toLowerCase()]||k}${end}`],
    [/^(\d+) de (\d+) (materiais|itens marcados nesta sessão|itens conferidos.*)$/, (_,a,b,c)=>`${a} de ${b} ${({'materiais':'materiales','itens marcados nesta sessão':'elementos marcados en esta sesión'})[c]||c}`]
  ];
  function translate(text) {
    if (language !== 'es' || !text || !text.trim()) return text;
    const match = text.match(/^(\s*)([\s\S]*?)(\s*)$/);
    const lead=match[1], core=match[2], tail=match[3];
    let translated = translations[core];
    if (!translated && /^PT-M\d+-\d+ — /.test(core)) {
      const prefix=core.slice(0,core.indexOf(' — ')+3);translated=prefix+(translations[core.slice(prefix.length)]||core.slice(prefix.length));
    }
    if (!translated) for(const [regex,callback] of patterns){if(regex.test(core)){translated=core.replace(regex,callback);break;}}
    return lead+(translated||core)+tail;
  }
  function rewriteText(node) {
    if (!originalText.has(node)) originalText.set(node,node.nodeValue);
    const original=originalText.get(node);
    const translated=translate(original);
    if (node.nodeValue!==translated) node.nodeValue=translated;
  }
  function rewriteAttrs(element) {
    let values=originalAttributes.get(element);
    if(!values){values={};for(const attr of attrs){if(element.hasAttribute(attr))values[attr]=element.getAttribute(attr);}originalAttributes.set(element,values);}
    for (const [attribute,value] of Object.entries(values)) {
      const translated=translate(value);
      if(element.getAttribute(attribute)!==translated)element.setAttribute(attribute,translated);
    }
  }
  const excluded='script,style,code,pre,textarea,svg,noscript,[data-nexo-untranslated]';
  function walk(root) {
    if(!root) return;
    if(root.nodeType===Node.TEXT_NODE) {if(!root.parentElement?.closest(excluded))rewriteText(root);return;}
    if(root.nodeType!==Node.ELEMENT_NODE && root.nodeType!==Node.DOCUMENT_NODE)return;
    if(root.nodeType===Node.ELEMENT_NODE&&root.matches(excluded))return;
    if(root.nodeType===Node.ELEMENT_NODE)rewriteAttrs(root);
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);
    let current;
    while((current=walker.nextNode())) {
      if(current.nodeType===Node.ELEMENT_NODE){if(!current.matches(excluded))rewriteAttrs(current);continue;}
      if(!current.parentElement?.closest(excluded))rewriteText(current);
    }
  }
  let scheduled=false;
  function sync(){
    scheduled=false;
    document.documentElement.lang=language==='es'?'es':'pt-BR';
    document.documentElement.dataset.nexoLanguage=language;
    selector.value=language;
    walk(document.body);
    const page=document.getElementById('pageTitle');
    if(page)document.title=`${page.textContent.trim()} — Nexo Cirúrgico`;
  }
  function schedule(){if(!scheduled){scheduled=true;Promise.resolve().then(sync);}}
  const obs=new MutationObserver(records=>{
    if(records.some(r=>r.addedNodes?.length))schedule();
  });
  obs.observe(document.body,{childList:true,subtree:true});
  function updateFont(){document.documentElement.style.setProperty('--nexo-reader-size',`${font}px`);smaller.disabled=font<=16;larger.disabled=font>=22;set('nexo-reader-font',String(font));}
  function setLanguage(value){language=value==='es'?'es':'pt';set('nexo-ui-language',language);schedule();window.dispatchEvent(new Event('hashchange'));}
  selector.addEventListener('change',()=>setLanguage(selector.value));
  smaller.addEventListener('click',()=>{font=Math.max(16,font-2);updateFont();});
  larger.addEventListener('click',()=>{font=Math.min(22,font+2);updateFont();});
  window.NEXO_I18N={get language(){return language;},translate,change:setLanguage,refresh:schedule,dictionarySize:Object.keys(translations).length};
  updateFont();schedule();
})();
'''.replace('__MAP__',json.dumps(tr,ensure_ascii=False,separators=(',',':')))
(root/'idiomas.js').write_text(code)
print('Language JS bytes',len(code),'map count',len(tr))
