# Nexo Cirúrgico — matriz P2 de especialidades

**Versão:** segunda redação  
**Data:** 13 de outubro de 2026  
**Estado:** 10 trilhas, 40 aulas, 40 flashcards, 10 checklists, competências C19–C28, 60 questões e 10 casos incorporados; aprofundamento visual pendente

## Entregas incorporadas

| Nº | Trilha | Aulas-base | Aulas de aprofundamento |
|---:|---|---|---|
| 19 | Cirurgia geral e digestiva | Mapa abdominal; Recuperação integrada | Transições de contaminação; Dispositivos e handoff |
| 20 | Ortopedia e trauma | Implantes e imagem; Trauma e segurança | Torniquete e alertas; Componentes, prova e cimento |
| 21 | Ginecologia e obstetrícia | Pelve e vias; Cesárea e equipes | Fluidos e espécimes; Hemorragia e coordenação |
| 22 | Urologia | Endourologia; Litotomia e dispositivos | Circuito de irrigação; Stents e cadeia de saída |
| 23 | Cirurgia vascular | Abordagens e sala híbrida; Enxertos e ISC | Tecnologia da sala híbrida; Marcos e explantes |
| 24 | Neurocirurgia e coluna | Crânio e navegação; Coluna e implantes | Navegação e neuromonitorização; Nível e tecnologia |
| 25 | Cabeça e pescoço | Via aérea e espécimes; Reconstrução e handoff | Via aérea e fogo; Retalho e monitorização |
| 26 | Torácica e cardíaca | Pulmão e drenos; Cardíaca e CEC | Ventilação e conversão; Marcos e transferência |
| 27 | Pediátrica e neonatal | Escala e fisiologia; Neonato e família | Microcomponentes e medicamentos; Cadeia térmica e transporte |
| 28 | Minimamente invasiva e robótica | Docking e funções; Interface e falha | Posicionamento e acesso; Conversão e rastreabilidade |

## Matriz de avaliação P2

| Competência | Especialidade | Questões | Casos |
|---|---|---:|---:|
| C19 | Cirurgia geral e digestiva | 6 | 1 |
| C20 | Ortopedia e trauma | 6 | 1 |
| C21 | Ginecologia e obstetrícia | 6 | 1 |
| C22 | Urologia | 6 | 1 |
| C23 | Cirurgia vascular | 6 | 1 |
| C24 | Neurocirurgia e coluna | 6 | 1 |
| C25 | Cabeça e pescoço | 6 | 1 |
| C26 | Cirurgia torácica e cardíaca | 6 | 1 |
| C27 | Cirurgia pediátrica e neonatal | 6 | 1 |
| C28 | Minimamente invasiva e robótica | 6 | 1 |
| **Total P2** | — | **60** | **10** |

A distribuição adicionada contém 15 itens básicos, 33 de aplicação e 12 de análise. Somada ao núcleo, a plataforma passa a 53/115/42, preservando aproximadamente 25%/55%/20%.

## Limites curriculares

As trilhas não ensinam técnica operatória passo a passo e não substituem treinamento prático. O conteúdo se concentra em:

- preparação da sala;
- comunicação e pausas;
- posicionamento;
- equipamentos e dispositivos;
- implantes e rastreabilidade;
- espécimes;
- prevenção de infecção;
- transições e handoff;
- reconhecimento de risco e escalonamento.

Não há dose, escolha individual de medicamento, regulagem universal de energia, pressão de torniquete, pressão de irrigação ou configuração de equipamento. Esses parâmetros dependem de profissional habilitado, protocolo, paciente e instrução do fabricante.

## Próximas entregas P2

1. revisão da progressão didática entre as quatro aulas de cada trilha;
2. expansão anatômica visual com ativos licenciados;
3. remediação direcionada para as questões P2;
4. revisão de linguagem e acessibilidade após a conclusão editorial;
5. auditoria técnica consolidada no final, conforme decisão do projeto.
