# Nexo Cirúrgico — matriz de procedimentos, acessos e antissepsia

**Data:** 13 de outubro de 2026  
**Estado:** cinco trilhas e 27 aulas incorporadas  
**Profundidade:** foco perioperatório; procedimentos invasivos dependem de habilitação e treinamento supervisionado

## 1. Motivo da expansão

A cobertura anterior privilegiava segurança e especialidades, mas ainda deixava pouco explícitos:

- famílias de procedimentos e vias de acesso cirúrgico;
- acesso venoso periférico e central;
- acesso arterial e de emergência;
- via aérea e estratégia de resgate;
- cateter urinário, sondas, drenos e acessos regionais;
- assepsia, antissepsia, preparo da pele e colocação de campos;
- procedimentos assistenciais de admissão, transferência, curativos e handoff.

O lote foi criado sem adicionar novas questões, preservando o reequilíbrio em favor das aulas.

## 2. Trilhas incorporadas

| Nº | Trilha | Aulas | Minutos |
|---:|---|---:|---:|
| 29 | Procedimentos e vias de acesso cirúrgico | 5 | 92 |
| 30 | Acessos vasculares e terapia infusional | 6 | 114 |
| 31 | Via aérea, sondas e drenos | 6 | 111 |
| 32 | Assepsia, antissepsia e preparo da pele | 5 | 94 |
| 33 | Procedimentos perioperatórios essenciais | 5 | 90 |
| **Total do lote** | — | **27** | **501** |

## 3. Detalhamento curricular

### Trilha 29 — Procedimentos e vias de acesso cirúrgico

1. classificação e jornada do procedimento;
2. acesso aberto e implicações das incisões;
3. acesso laparoscópico e robótico, portais e geometria;
4. acessos endoscópicos e percutâneos;
5. conversão, encerramento e handoff.

A trilha compara abordagens sem ensinar escolha ou execução autônoma de incisão, portal ou punção.

### Trilha 30 — Acessos vasculares e terapia infusional

1. mapa dos dispositivos vasculares;
2. acesso venoso periférico;
3. acesso venoso central;
4. acesso arterial e sistema de pressão;
5. acesso intraósseo e opções de emergência;
6. manutenção, complicações e handoff.

O conteúdo apresenta indicação conceitual, preparo, barreiras, assistência, vigilância e documentação. Punção e inserção exigem competência prática validada.

### Trilha 31 — Via aérea, sondas e drenos

1. mapa de dispositivos de via aérea;
2. assistência à via aérea difícil e crise;
3. cateter urinário no perioperatório;
4. sondas gástricas e enterais;
5. drenos cirúrgicos e torácicos;
6. cateteres de neuroeixo e acessos regionais.

A trilha não oferece algoritmo terapêutico nem ensina intubação, sondagem, drenagem ou punção como prática autônoma.

### Trilha 32 — Assepsia, antissepsia e preparo da pele

1. diferenças entre limpeza, antissepsia, desinfecção, esterilidade e assepsia;
2. antissepsia cirúrgica das mãos e paramentação;
3. avaliação da pele, limpeza e manejo de pelos;
4. seleção do antisséptico e regiões especiais;
5. aplicação, secagem, campos e risco de fogo.

Produto, concentração, tempo, área e compatibilidade dependem da instrução de uso e do protocolo validado.

### Trilha 33 — Procedimentos perioperatórios essenciais

1. admissão e verificação pré-procedimento;
2. transferência, monitorização e proteção de dispositivos;
3. apoio a punções, biópsias e procedimentos guiados;
4. feridas, curativos e estomas no encerramento;
5. transporte e handoff com reconciliação de dispositivos.

## 4. Apoios de estudo

- 27 flashcards novos, um por aula;
- cinco checklists de revisão, com cinco itens cada;
- novas aulas indexadas na busca global;
- bibliografia exibida a partir das fontes vinculadas à trilha;
- nenhuma questão ou caso novo neste lote.

## 5. Referências priorizadas

- OMS 2024 — cateteres periféricos;
- OMS 2026 — cateteres venosos centrais;
- INS 2024 — terapia infusional;
- ASA 2020 — acesso venoso central;
- ASA 2022 — via aérea difícil;
- CDC 2025 — prevenção de ITU associada a cateter;
- AORN 2026 — antissepsia da pele e prática perioperatória;
- documentos brasileiros de cirurgia segura, ISC, NR-32, Cofen e CFM já catalogados.

Diretrizes protegidas são usadas apenas para sínteses originais. Tabelas, algoritmos e ilustrações não foram copiados.

## 6. Estado global após o lote

| Indicador | Total atual |
|---|---:|
| Trilhas | 33 |
| Aulas | 115 |
| Minutos | 2.068 |
| Flashcards | 137 |
| Questões | 210 |
| Casos | 30 |
| Itens de checklist | 90 |
| Fontes | 72 |
| Questões por aula | 1,83 |

## 7. Limites e validação pendente

- O conteúdo é educacional e não certifica competência prática.
- Punção, inserção, intubação, sondagem e manipulação de drenos exigem treinamento, supervisão, habilitação e protocolo.
- Parâmetros, tamanhos, concentrações, volumes e escolhas individuais não são universalizados.
- A auditoria clínica independente, a revisão contextual e o piloto continuam adiados até a conclusão editorial.
