import json, re
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter

root=Path(__file__).resolve().parent
text=(root/'data.js').read_text()
data=json.loads(re.sub(r'^window\.NEXO_DATA\s*=\s*','',text).rstrip().rstrip(';'))

wb=Workbook(); wb.remove(wb.active)
navy='0C2C30'; teal='14A38B'; mint='DFF5EE'; white='FFFFFF'; light='F3F6F5'; line='DFE7E5'; orange='FFF1E7'; red='FFE8E5'; gray='6C7F81'
thin=Side(style='thin',color=line)

module_by_id={m['id']:m for m in data['modules']}
comp_by_id={c['id']:c for c in data['competencies']}
source_by_id={s['id']:s for s in data['evidence']}
letters='ABCD'

def setup(ws,title,subtitle=None):
    ws.sheet_view.showGridLines=False
    ws.freeze_panes='A2'
    ws.row_dimensions[1].height=31
    for cell in ws[1]:
        cell.fill=PatternFill('solid',fgColor=navy); cell.font=Font(color=white,bold=True,size=10)
        cell.alignment=Alignment(vertical='center',wrap_text=True)
        cell.border=Border(bottom=thin)
    ws.auto_filter.ref=ws.dimensions
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0

def widths(ws,widths):
    for col,w in widths.items(): ws.column_dimensions[col].width=w

def style_body(ws,wrap_cols=()):
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font=Font(size=9,color='173136'); c.alignment=Alignment(vertical='top',wrap_text=c.column in wrap_cols)
            c.border=Border(bottom=thin)
        if row[0].row%2==0:
            for c in row: c.fill=PatternFill('solid',fgColor='F8FAF9')

def add_validations(ws,start,end,cols):
    options={
      'decision':'"Pendente,Aprovar,Corrigir,Arquivar"',
      'yesno':'"Pendente,Sim,Não,NA"',
      'score':'whole'
    }
    for col,kind in cols.items():
        if kind=='score':
            dv=DataValidation(type='whole',operator='between',formula1='1',formula2='4',allow_blank=True)
            dv.prompt='Use 1 (inadequado) a 4 (adequado).'; dv.error='Informe um número entre 1 e 4.'
        else:
            dv=DataValidation(type='list',formula1=options[kind],allow_blank=True)
        ws.add_data_validation(dv); dv.add(f'{col}{start}:{col}{end}')

# LEIA-ME
ws=wb.create_sheet('LEIA-ME')
ws.sheet_view.showGridLines=False
ws.column_dimensions['A'].width=25; ws.column_dimensions['B'].width=98
rows=[
('PACOTE DE REVISÃO INDEPENDENTE','Nexo Cirúrgico — Banco 1.0'),
('Versão','1.0 • 13/10/2026'),
('Finalidade',f'Apoiar revisão clínica, educacional e de qualidade das {len(data["quiz"])} questões e {len(data["cases"])} casos. O arquivo não comprova validação até que revisores habilitados preencham identificação, decisão, comentários e data.'),
('Estado atual','Estrutura quantitativa e auditoria automatizada concluídas; revisão humana e piloto pendentes.'),
('Fluxo recomendado','1) atribuir revisores; 2) revisar fonte e precisão; 3) avaliar uma única melhor resposta; 4) avaliar distratores e escopo; 5) registrar decisão; 6) corrigir; 7) fazer segunda checagem; 8) congelar versão aprovada.'),
('Decisões','Pendente: não revisado. Aprovar: pronto após revisão. Corrigir: requer alteração. Arquivar: retirar do banco.'),
('Escala 1–4','1 inadequado; 2 requer correção importante; 3 adequado com ajuste menor; 4 adequado.'),
('Separação de funções','Sempre que possível, autor e revisor devem ser pessoas diferentes. Conteúdos de maior risco precisam de especialista temático.'),
('Limite','O pacote não substitui conselho profissional, protocolo institucional, instruções do fabricante, comissão de controle de infecção ou validação local.'),
('Privacidade do piloto','Use código pseudônimo de participante. Não registre nome, prontuário ou dados clínicos. Defina base legal, retenção e acesso antes de coletar dados.'),
('Planilhas','QUESTOES e CASOS: revisão. COMPETENCIAS: matriz. FONTES: catálogo. REVISORES: atribuições. PILOTO: modelo de coleta. DICIONARIO: definição dos campos.')]
for r,row in enumerate(rows,1):
    ws.cell(r,1,row[0]); ws.cell(r,2,row[1]); ws.row_dimensions[r].height=30 if r>2 else 38
    for c in ws[r]: c.alignment=Alignment(vertical='center',wrap_text=True); c.border=Border(bottom=thin)
    ws.cell(r,1).font=Font(bold=True,color=white if r==1 else navy,size=12 if r==1 else 10)
    ws.cell(r,2).font=Font(bold=r==1,color=white if r==1 else '173136',size=12 if r==1 else 10)
    if r==1:
        ws.cell(r,1).fill=ws.cell(r,2).fill=PatternFill('solid',fgColor=navy)
    elif r%2==0:
        ws.cell(r,1).fill=ws.cell(r,2).fill=PatternFill('solid',fgColor=light)

# RESUMO
ws=wb.create_sheet('RESUMO')
headers=['Indicador','Resultado','Critério/observação']; ws.append(headers)
from collections import Counter
qans=Counter(q['answer'] for q in data['quiz']); cans=Counter(c['answer'] for c in data['cases']); dif=Counter(q['difficulty'] for q in data['quiz'])
summary=[
('Questões',len(data['quiz']),f'Meta estrutural: {data["assessmentBlueprint"]["targetQuestions"]}'),('Casos',len(data['cases']),f'Meta estrutural: {data["assessmentBlueprint"]["targetCases"]}'),('Competências',len(data['competencies']),f'Matriz atual: {len(data["competencies"])}'),('Fontes',len(data['evidence']),'Catálogo vinculado'),
('Dificuldade — Básico',dif['Básico'],'Meta aproximada: 25%'),('Dificuldade — Aplicação',dif['Aplicação'],'Meta aproximada: 55%'),('Dificuldade — Análise',dif['Análise'],'Meta: 20%'),
('Gabarito questões — A/B/C/D',f"{qans[0]} / {qans[1]} / {qans[2]} / {qans[3]}",'Distribuição balanceada; diferença máxima de 1'),('Gabarito casos — A/B/C/D',f"{cans[0]} / {cans[1]} / {cans[2]} / {cans[3]}",'Distribuição balanceada; diferença máxima de 1'),
('Revisão humana concluída',0,'Atualizar somente após assinatura dos revisores'),('Piloto concluído','Não','Executar após correções da revisão')]
for x in summary: ws.append(x)
setup(ws,''); widths(ws,{'A':33,'B':22,'C':58}); style_body(ws,(3,))

# QUESTOES
ws=wb.create_sheet('QUESTOES')
qheads=['ID','Competência','Módulo','Dificuldade','Categoria','Enunciado','Alternativa A','Alternativa B','Alternativa C','Alternativa D','Gabarito','Resposta correta','Justificativa','Fontes (IDs)','Decisão do revisor','Precisão clínica 1–4','Uma melhor resposta?','Distratores plausíveis?','Escopo profissional seguro?','Atualização necessária?','Comentários/correção proposta','Revisor','Data da revisão']
ws.append(qheads)
for q in data['quiz']:
    comp=comp_by_id[q['competencyId']]; mod=module_by_id[comp['moduleId']]
    ws.append([q['id'],q['competencyId'],mod['title'],q['difficulty'],q['category'],q['question'],*q['options'],letters[q['answer']],q['options'][q['answer']],q['explanation'],', '.join(q['sourceIds']),'Pendente','','Pendente','Pendente','Pendente','Pendente','','',''])
setup(ws,''); widths(ws,{'A':7,'B':12,'C':24,'D':12,'E':20,'F':48,'G':34,'H':34,'I':34,'J':34,'K':9,'L':34,'M':48,'N':29,'O':18,'P':18,'Q':20,'R':20,'S':22,'T':21,'U':45,'V':22,'W':15}); style_body(ws,tuple(range(5,24)))
q_end=1+len(data['quiz'])
add_validations(ws,2,q_end,{'O':'decision','P':'score','Q':'yesno','R':'yesno','S':'yesno','T':'yesno'})
ws.conditional_formatting.add(f'O2:O{q_end}',FormulaRule(formula=['$O2="Aprovar"'],fill=PatternFill('solid',fgColor=mint)))
ws.conditional_formatting.add(f'O2:O{q_end}',FormulaRule(formula=['$O2="Corrigir"'],fill=PatternFill('solid',fgColor=orange)))
ws.conditional_formatting.add(f'O2:O{q_end}',FormulaRule(formula=['$O2="Arquivar"'],fill=PatternFill('solid',fgColor=red)))

# CASOS
ws=wb.create_sheet('CASOS')
cheads=['ID','Número','Competência','Módulo','Dificuldade','Categoria','Título','Contexto','Decisão/pergunta','Alternativa A','Alternativa B','Alternativa C','Alternativa D','Gabarito','Resposta correta','Justificativa','Consequência/aprendizado','Fontes (IDs)','Decisão do revisor','Precisão clínica 1–4','Uma melhor resposta?','Consequência coerente?','Escopo profissional seguro?','Comentários/correção proposta','Revisor','Data da revisão']
ws.append(cheads)
for c in data['cases']:
    mod=module_by_id[c['moduleId']]
    ws.append([c['id'],c['number'],c['competencyId'],mod['title'],c['difficulty'],c['category'],c['title'],c['context'],c['prompt'],*c['options'],letters[c['answer']],c['options'][c['answer']],c['rationale'],c['consequence'],', '.join(c['sourceIds']),'Pendente','','Pendente','Pendente','Pendente','','',''])
setup(ws,''); widths(ws,{'A':12,'B':8,'C':12,'D':25,'E':12,'F':22,'G':28,'H':55,'I':38,'J':34,'K':34,'L':34,'M':34,'N':9,'O':36,'P':48,'Q':48,'R':28,'S':18,'T':18,'U':20,'V':20,'W':22,'X':45,'Y':22,'Z':15}); style_body(ws,tuple(range(6,27)))
c_end=1+len(data['cases'])
add_validations(ws,2,c_end,{'S':'decision','T':'score','U':'yesno','V':'yesno','W':'yesno'})
ws.conditional_formatting.add(f'S2:S{c_end}',FormulaRule(formula=['$S2="Aprovar"'],fill=PatternFill('solid',fgColor=mint)))
ws.conditional_formatting.add(f'S2:S{c_end}',FormulaRule(formula=['$S2="Corrigir"'],fill=PatternFill('solid',fgColor=orange)))
ws.conditional_formatting.add(f'S2:S{c_end}',FormulaRule(formula=['$S2="Arquivar"'],fill=PatternFill('solid',fgColor=red)))

# COMPETENCIAS
ws=wb.create_sheet('COMPETENCIAS'); ws.append(['ID','Competência','Descrição','Módulo','Meta de questões','Questões atuais','Casos atuais','Fontes centrais'])
for c in data['competencies']:
    ws.append([c['id'],c['title'],c['description'],module_by_id[c['moduleId']]['title'],c['targetQuestions'],sum(q['competencyId']==c['id'] for q in data['quiz']),sum(x['competencyId']==c['id'] for x in data['cases']),', '.join(c['sourceIds'])])
setup(ws,''); widths(ws,{'A':9,'B':28,'C':58,'D':27,'E':18,'F':18,'G':14,'H':40}); style_body(ws,(2,3,4,8))

# FONTES
ws=wb.create_sheet('FONTES'); ws.append(['ID','Título','Organização','Ano','Tipo','Tema','URL','Uso no conteúdo'])
for s in data['evidence']: ws.append([s['id'],s['title'],s['organization'],s['year'],s.get('access',''),s['topic'],s['url'],s.get('notes','')])
setup(ws,''); widths(ws,{'A':27,'B':58,'C':28,'D':10,'E':18,'F':24,'G':62,'H':60}); style_body(ws,(2,7,8))

# REVISORES
ws=wb.create_sheet('REVISORES'); ws.append(['Área/competência','Papel mínimo','Nome do revisor','Registro/qualificação','Conflito de interesse declarado?','Escopo atribuído','Data de início','Data de conclusão','Assinatura/aceite'])
assign=[('Liderança clínica','Enfermeiro perioperatório'),('Instrumentais e fluxo','Profissional perioperatório experiente'),('CME','Especialista em processamento'),('ISC e assepsia','Controle de infecção'),('Anestesia/SRPA','Anestesiologista'),('Medicamentos','Farmacêutico ou enfermeiro especialista'),('Energia e incêndio','Engenharia clínica/especialista'),('NR-32','Segurança do trabalho'),('Privacidade','Jurídico/privacidade'),('Avaliação','Designer instrucional/psicometria'),('Linguagem e acessibilidade','Revisor e especialista em acessibilidade')]
for a,b in assign: ws.append([a,b,'','','Pendente','','','',''])
setup(ws,''); widths(ws,{'A':28,'B':38,'C':27,'D':30,'E':28,'F':45,'G':16,'H':18,'I':24}); style_body(ws,(1,2,4,6,9)); add_validations(ws,2,50,{'E':'yesno'})

# PILOTO
ws=wb.create_sheet('PILOTO'); ws.append(['Código pseudônimo','Data/hora','ID do item','Tipo','Competência','Alternativa marcada','Correta?','Tempo em segundos','Confiança 1–5','Ambiguidade percebida?','Comentário livre','Versão do banco'])
for _ in range(100): ws.append(['','','','','','','','','','','','1.0'])
setup(ws,''); widths(ws,{'A':20,'B':20,'C':14,'D':13,'E':14,'F':20,'G':12,'H':20,'I':16,'J':23,'K':55,'L':16}); style_body(ws,(11,));
for col,formula in {'D':'"Questão,Caso"','G':'"Sim,Não"','J':'"Sim,Não"'}.items():
    dv=DataValidation(type='list',formula1=formula,allow_blank=True); ws.add_data_validation(dv); dv.add(f'{col}2:{col}1001')
dv=DataValidation(type='whole',operator='between',formula1='1',formula2='5',allow_blank=True); ws.add_data_validation(dv); dv.add('I2:I1001')

# DICIONARIO
ws=wb.create_sheet('DICIONARIO'); ws.append(['Campo','Definição','Regra'])
defs=[('Precisão clínica 1–4','Julgamento do revisor sobre correção e atualidade','1 inadequado; 2 correção importante; 3 ajuste menor; 4 adequado'),('Uma melhor resposta?','Confirma que somente uma alternativa é defensável como melhor','Se Não, corrigir ou arquivar'),('Distratores plausíveis?','Alternativas incorretas representam erros realistas sem enganar por detalhe irrelevante','Evitar absurdos e pegadinhas'),('Escopo profissional seguro?','Texto respeita habilitação, protocolo local e responsabilidade da equipe','Se Não, corrigir antes do piloto'),('Atualização necessária?','Fonte ou recomendação precisa de atualização','Registrar fonte proposta nos comentários'),('Dificuldade','Classificação editorial inicial','Confirmar após dados do piloto'),('Confiança 1–5','Segurança subjetiva do participante na resposta','1 muito baixa; 5 muito alta'),('Código pseudônimo','Identificador sem nome ou dado clínico','Manter chave de identificação fora deste arquivo, se necessária')]
for x in defs: ws.append(x)
setup(ws,''); widths(ws,{'A':30,'B':62,'C':62}); style_body(ws,(2,3))

# Tab colors and metadata
for ws in wb.worksheets: ws.sheet_properties.tabColor=teal
wb.properties.title='Nexo Cirúrgico — pacote de revisão independente'
wb.properties.subject=f'Revisão das {len(data["quiz"])} questões, {len(data["cases"])} casos e blueprint de competências'
wb.properties.creator='Nexo Cirúrgico — marca provisória'
wb.properties.description='Instrumento editorial; não comprova validação clínica até preenchimento por revisores habilitados.'
out=root/'PACOTE_REVISAO_INDEPENDENTE.xlsx'
wb.save(out)
print(out)
