/* Traduções de apresentação dos tópicos MB04 L2; textos integrais técnicos continuam em português. */
window.NEXO_L2_TRANSLATIONS={
  "PT-M08-01": "Anestesia tópica",
  "PT-M08-02": "Anestesia por infiltración",
  "PT-M08-03": "Bloqueos nerviosos periféricos",
  "PT-M08-04": "Sedación para procedimientos",
  "PT-M08-05": "Anestesia raquídea",
  "PT-M08-06": "Anestesia epidural",
  "PT-M08-07": "Anestesia general",
  "PT-M08-08": "Equipo y circuitos de anestesia",
  "PT-M08-09": "Toxicidad sistémica por anestésicos locales",
  "PT-M08-10": "Recuperación posanestésica",
  "PT-M09-01": "Evaluación preoperatoria",
  "PT-M09-02": "Ayuno individualizado",
  "PT-M09-03": "Pruebas preoperatorias indicadas",
  "PT-M09-04": "Consentimiento y lateralidad",
  "PT-M09-05": "Profilaxis antimicrobiana",
  "PT-M09-06": "Prevención tromboembólica",
  "PT-M09-07": "Baño y manejo del vello",
  "PT-M09-08": "Preparación antiséptica de la piel",
  "PT-M09-09": "Marcación del sitio quirúrgico",
  "PT-M09-10": "Posicionamiento seguro",
  "PT-M09-11": "Lista de verificación de cirugía segura"
};
