# Registro novo — MB04 Lote 2 (16/10/2026)

**M08 e M09 receberam 21 fichas operacionais.** A matriz agora contabiliza 75/227 tópicos com ficha, sendo 29 de Cirurgia Geral + Anestesia + Preparo. O Atlas soma 52 materiais / 180 variantes. Guia educacional sem bloqueio de leitura, referência por procedimento, roteiro de simulação, checklist e integração com o Atlas. Próxima implementação: MB05 Lote 1 (via aérea e urgências); manter escopo dos 8 macroblocos, sem reabrir fases concluídas para retrabalho.

---


## Registro atual — MB04 Lote 1 (16/10/2026)

**Mapa Mestre mantém o escopo dos oito macroblocos.** O módulo M16 (Cirurgia Geral) agora tem 8/8 tópicos com fichas de estudo operacional em desenvolvimento e acesso livre para simulação: incisões, dissecção, hemostasia, laparotomia, laparoscopia, fechamento por planos, drenos e conversão/encerramento seguro. **Essas fichas não tornam o MB04 inteiro concluído**: anestesia, preparo perioperatório e recuperação continuam pendentes.

Dados de referência: 33 trilhas / 115 aulas antigas / 210 questões / 30 casos / 137 flashcards; 28 módulos / 227 tópicos; **54 fichas técnicas** (46 MB03 + 8 MB04); 41 materiais / 158 variantes no Atlas.

Revisão externa não bloqueia estudo. Conteúdo médico continua sujeito a atualização e erratas, e a execução invasiva exige habilitação/supervisão. O seletor PT/ES traduz interface, títulos e aberturas das novas fichas; demais campos em espanhol continuam incrementais. Nenhum dos cinco PDFs protegidos foi publicado.

**Próximo lote:** M08 e M09 — anestesia local, preparo do paciente, checklist pré-operatório, monitorização e recuperação; sem recriar módulos nem duplicar aulas.

# Nexo Cirúrgico — roadmap editorial e de produto

**Versão:** 1.4.1-mb03.2  
**Atualização:** 14 de outubro de 2026  
**Escopo:** plataforma de estudos; não inclui página de vendas  
**Objetivo:** evoluir o núcleo perioperatório para uma plataforma médica integrada de procedimentos, com conteúdo original, rastreável, supervisionado, revisado e seguro.

---

## 1. Posição atual

A plataforma possui:

- **interface 1.4 responsiva (refino de logomarca e crédito InMed)**, com identidade provisória vetorial, dashboard orientado a dados e navegação preservada;
- **33 trilhas atuais**;
- **115 aulas atuais**;
- **28 módulos na matriz técnica de expansão**;
- **227 tópicos técnicos e 224 procedimentos canônicos**;
- **30 materiais e 133 variantes no Atlas MB02**;
- **38 fichas técnicas do MB03 em revisão (15 no lote 1 + 23 no lote 2), com 14 campos cada**;
- **2.068 minutos** de conteúdo desenvolvido;
- **137 flashcards**;
- **3 planos de estudo progressivos**, cobrindo todas as 115 aulas;
- **remediação formativa para 28 competências**, com 84 vínculos de aula;
- **210 questões** vinculadas a 28 competências;
- **30 casos situacionais sintéticos**;
- **90 itens** de checklist;
- **72 fontes** normativas, técnicas ou científicas catalogadas, incluindo diretrizes de 2024–2026 para cateteres e antissepsia verificadas em 13/10/2026;
- **9 vídeos externos** com crédito e sem cópia ou re-hospedagem.

### Leitura correta do status

- **Produto:** MVP funcional e navegável; MB01 corrigido e MB02 entregue.
- **Matriz técnica:** 28 módulos, seis macroáreas, 227 tópicos, 224 procedimentos canônicos e relações de aula tipadas.
- **Atlas de materiais:** 30 fichas e 133 variantes com escalas, compatibilidades, fontes e visuais originais; revisão clínica pendente.
- **Conteúdo P0/P1:** ampliado com procedimentos, vias cirúrgicas, acessos vasculares, via aérea, sondas, drenos e preparo antisséptico; auditoria formal adiada.
- **Conteúdo P2:** 10 trilhas, 40 aulas, 40 flashcards, 10 competências, 60 questões, 10 casos e checklists por especialidade; aprofundamento visual pendente.
- **Referências:** expansões P2 e de acessos priorizam documentos oficiais de 2024–2026, verificados em 13/10/2026.
- **Curso profissional:** ainda não pronto para publicação como formação abrangente.

Percentuais do roadmap representam **maturidade editorial**, não certificação clínica.

---

## 2. Fases

| Fase | Entrega | Estado | Gate de saída |
|---|---|---:|---|
| 00 | Produto-base: aulas, avaliações, progresso, videoteca e fontes | Concluído | QA funcional aprovado |
| 01 | Fundamentos P0 | Auditoria adiada — 80% | Assepsia, antissepsia e procedimentos perioperatórios incorporados; revisão especializada ao final |
| 02 | Prática ampliada P1 | Auditoria adiada — 76% | Acessos, vias, sondas e drenos incorporados; aprovação multiprofissional ao final |
| 03 | Casos e avaliação robusta | Auditoria adiada — 86% | Blueprint com 28 competências, 210 questões e 30 casos; revisão e piloto ao final |
| 04 | Anatomia e especialidades P2 | Em desenvolvimento — 78% | 40 aulas P2 e checklists incorporados; anatomia visual licenciada ainda pendente |
| 05 | Governança e validação | Parcial — 32% | Fontes e direitos em andamento; auditoria clínica consolidada ao final |
| 06 | Plataforma de produção | Planejado — 15% | Backend, autenticação, painel editorial e analytics com privacidade |

### Programa transversal de expansão procedimental

| Macrobloco | Estado | Entrega |
|---|---|---|
| MB01 — Arquitetura curricular | **Entregue** | Status por tópico, prioridades inclusivas, aliases, relações tipadas e fichas canônicas |
| MB02 — Atlas de materiais | **Entregue** | 30 materiais, 133 variantes, escalas, compatibilidades, fontes e visuais originais |
| MB03 — Procedimentos fundamentais | Próximo | Acessos, coletas, administração, feridas, suturas e imobilizações |
| MB04 — Cirurgia e anestesia | Planejado | Fluxos integrados do pré-operatório à recuperação |
| MB05 — Urgência e especialidades | Planejado | Emergências, via aérea, drenagens, sondagens e especialidades |
| MB06 — Videoteca vinculada | Planejado | Vídeo por procedimento, autoria, revisão e conformidade |
| MB07 — Avaliação prática | Planejado | Checklists de simulação, sequência e erros críticos |
| MB08 — Revisão e publicação | Planejado | Revisão clínica, acessibilidade, piloto e aprovação |

O programa e a matriz detalhada estão documentados em `PLANO_EXPANSAO_PROCEDIMENTOS.md`.

---

## 3. Conteúdo P0 — segunda redação ampliada

1. ambiente, áreas e equipe;
2. papéis e limites profissionais;
3. cirurgia segura e comunicação;
4. técnica asséptica;
5. instrumentais;
6. fios e suturas;
7. posicionamento;
8. prevenção de ISC;
9. contagens e itens retidos;
10. espécimes e implantes;
11. fluxo do procedimento;
12. CME e reprocessamento;
13. assepsia, antissepsia, mãos, pele e campos;
14. admissão, transferência, curativos e handoff perioperatório.

### Pendências do gate P0

- revisão por enfermeiro perioperatório/instrumentador;
- revisão do bloco de CME por especialista responsável;
- revisão de ISC por controle de infecção;
- padronização de termos e escopo profissional;
- bibliografia granular por tópico quando necessário;
- análise pedagógica e teste com estudantes.

---

## 4. Conteúdo P1 — segunda redação ampliada

1. energia cirúrgica;
2. incêndio no campo;
3. fumaça cirúrgica;
4. medicamentos e rotulagem;
5. medicamentos de alta vigilância;
6. anestesia e SRPA;
7. segurança ocupacional e NR-32;
8. documentação perioperatória;
9. ética, prontuário eletrônico e LGPD;
10. gestão de crises e auxílios cognitivos;
11. preparação e simulação de eventos críticos;
12. procedimentos e vias de acesso cirúrgico;
13. acesso venoso periférico e central, arterial e de emergência;
14. via aérea, sondas, drenos e acessos regionais.

### Fontes incorporadas

- protocolo brasileiro de segurança de medicamentos;
- OMS — Medication Without Harm;
- Resoluções CFM nº 2.174/2017 e nº 2.471/2026;
- NR-32;
- manual Anvisa de segurança contra incêndio;
- RDC nº 36/2013;
- Resoluções Cofen nº 736/2024 e nº 754/2024;
- Código de Ética de Enfermagem;
- LGPD;
- AORN, NIOSH, Stanford Emergency Manual e recursos MHAUS como complementos;
- OMS 2024 para cateteres periféricos e OMS 2026 para cateteres centrais;
- INS 2024 para terapia infusional;
- ASA 2020 para acesso central e ASA 2022 para via aérea difícil;
- CDC 2025 para cateter urinário.

### Pendências do gate P1

- anestesiologista: anestesia, sedação, SRPA e eventos críticos;
- farmacêutico/enfermagem: medicamentos e rotulagem;
- segurança do trabalho: NR-32, químicos, gases e radiação;
- especialista em energia cirúrgica/engenharia clínica: eletrocirurgia;
- privacidade/jurídico: LGPD, imagens e prontuário;
- brigada/engenharia: incêndio e evacuação;
- especialista em terapia infusional: acessos vasculares e dispositivos;
- anestesiologia e enfermagem: via aérea, neuroeixo e interfaces de segurança;
- controle de infecção: preparo da pele e prevenção associada a cateteres;
- revisão dos auxílios cognitivos para o contexto institucional brasileiro.

---

## 5. Casos e avaliação — estrutura concluída

A versão atual contém um blueprint de **28 competências, 30 casos e 210 questões**. O núcleo original permanece rastreável e a expansão P2 acrescenta 10 competências, 60 questões e 10 casos. A documentação está em `BLUEPRINT_AVALIACAO.md` e nas rotas internas `#/blueprint` e `#/casos`.

Os ciclos abaixo descrevem a estrutura entregue e o trabalho de validação ainda necessário.

### Ciclo 1 — blueprint — concluído

**Entregas:**

- matriz competência × módulo × dificuldade;
- taxonomia das questões;
- regras de escrita e revisão de itens;
- tags para identificar lacunas de aprendizagem;
- critérios de aprovação e remediação.

**Meta:** definir a arquitetura antes de aumentar o banco.

### Ciclo 2 — 30 casos situacionais — primeira redação concluída

Distribuição do núcleo inicial:

- 3 casos de cirurgia segura e comunicação;
- 3 de técnica asséptica/ISC;
- 2 de posicionamento;
- 2 de contagem;
- 2 de espécimes/implantes;
- 2 de CME;
- 2 de medicamentos;
- 2 de energia/fogo/fumaça;
- 2 de emergência e transferência.

Expansão P2: um caso para cada uma das dez especialidades — cirurgia geral, ortopedia, ginecologia/obstetrícia, urologia, vascular, neurocirurgia, cabeça e pescoço, torácica/cardíaca, pediatria e robótica.

Cada caso contém contexto, decisão, alternativas, consequência, justificativa, referência e limite profissional.

### Ciclo 3 — banco de 210 questões — estrutura ampliada

- pelo menos 50% de aplicação em cenário;
- no máximo 25% de recordação simples;
- justificativa para resposta correta e distratores críticos;
- referência e competência vinculadas;
- revisão técnica independente;
- controle de versão e histórico de alteração.

### Ciclo 4 — relatório de desempenho — versão formativa implementada

- resultado por competência no final do simulado;
- remediação por plano e competência com aulas recomendadas;
- registro local das últimas dez tentativas, questões sorteadas e erros;
- histórico exibido no painel de progresso;
- dificuldade e discriminação dos itens quando houver amostra suficiente;
- exclusão ou revisão de questões problemáticas.

### Auditoria estrutural — concluída

- gabaritos das questões balanceados em 53/53/52/52;
- gabaritos dos casos balanceados em 8/8/7/7;
- 28 competências totalizando exatamente 210 itens;
- IDs, fontes, alternativas, competências e metas verificados;
- teste reproduzível em `qa_assessment.js`;
- relatório atual em `AUDITORIA_ESTRUTURAL_1_2.md`;
- relatório histórico do núcleo em `AUDITORIA_BANCO_1_0.md`;
- pacote de revisão atualizado em `PACOTE_REVISAO_INDEPENDENTE.xlsx`.

### Auditoria e piloto — adiados por decisão do projeto

A revisão clínica independente, a análise dos distratores e o piloto serão executados após a conclusão das fases editoriais. Até lá, o material permanece explicitamente identificado como primeira redação não validada.

### Próxima ação operacional

1. iniciar o MB03 pelas fichas canônicas de acesso venoso periférico, coleta, administração, feridas, suturas e imobilizações;
2. vincular materiais do Atlas sem transformar variantes em prescrições universais;
3. verificar acessibilidade e responsividade continuamente;
4. consolidar a auditoria clínica no final da produção editorial.

---

## 6. Fase P2 — especialidades em desenvolvimento

A primeira redação foi iniciada antes da auditoria consolidada, conforme decisão do projeto. As trilhas usam referências recentes e mantêm avisos de que o conteúdo ainda não passou pelo gate clínico.

### Subtrilhas incorporadas

- cirurgia geral e aparelho digestivo;
- ortopedia e trauma;
- ginecologia e obstetrícia;
- urologia;
- vascular;
- neurocirurgia;
- cabeça e pescoço;
- torácica e cardíaca;
- pediatria;
- cirurgia minimamente invasiva e robótica.

A versão atual mantém **40 aulas e 40 flashcards P2**, além de dez checklists de estudo por especialidade. O novo lote acrescenta **cinco trilhas e 27 aulas** sobre procedimentos, acessos, dispositivos e antissepsia, documentadas em `MATRIZ_PROCEDIMENTOS_E_ACESSOS.md`. As 115 aulas estão organizadas em três etapas no `MAPA_PROGRESSAO_CURRICULAR.md`, e a conversão dos resultados em aulas recomendadas está descrita em `REMEDIACAO_FORMATIVA.md`. A matriz de especialidades está em `MATRIZ_P2_ESPECIALIDADES.md`; o lote anterior está preservado em `EXPANSAO_CONTEUDO_88_AULAS.md`; e o registro de fontes recentes está em `REFERENCIAS_ATUALIZADAS_2026.md`.

Cada subtrilha ainda precisa de avaliação própria, anatomia visual licenciada, aprofundamento e, ao final, revisão por especialista. Preferências individuais não devem ser apresentadas como regras universais.

---

## 7. Gate clínico: definição de pronto

Uma aula somente recebe estado **Aprovada** quando possui:

- público e pré-requisitos;
- competência observável;
- conteúdo original;
- fontes com edição e data;
- autor e revisor identificados;
- aprovação técnica registrada;
- avaliação alinhada;
- avisos de escopo e limites;
- mídia com direitos documentados;
- revisão de linguagem e acessibilidade;
- versão, data e próxima revisão.

Uma trilha somente atravessa o gate quando todas as aulas estão aprovadas e suas questões passaram por revisão independente.

---

## 8. Equipe mínima de validação

- liderança clínica: enfermeiro perioperatório;
- instrumentador ou profissional com experiência formal na área;
- especialista de CME;
- controle de infecção;
- anestesiologista;
- cirurgião consultor;
- farmacêutico clínico/hospitalar;
- segurança do trabalho/engenharia clínica;
- especialista em privacidade ou jurídico;
- designer instrucional;
- revisão de português e acessibilidade.

Uma mesma pessoa pode cobrir mais de uma função somente quando houver competência comprovada e conflito de interesse controlado.

---

## 9. Produto de produção

### Backend e conteúdo

- banco relacional para usuários, aulas, versões e avaliações;
- painel editorial com estados: rascunho, revisão, aprovado, publicado e arquivado;
- trilha de auditoria;
- referências e ativos ligados a cada versão;
- expiração programada de conteúdo.

### Aprendizagem

- autenticação e perfis;
- sincronização de progresso;
- repetição espaçada;
- simulados por competência;
- certificados somente após definição jurídica e pedagógica;
- painel de desempenho sem expor dados desnecessários.

### Qualidade

- acessibilidade WCAG;
- testes automatizados;
- monitoramento de erros;
- política de privacidade;
- retenção e exclusão de dados;
- backup e recuperação;
- plano de resposta a incidente.

---

## 10. Ordem recomendada de execução

As etapas anteriores de P2, avaliações, planos progressivos e remediação já foram entregues. A sequência atual é:

1. **MB01 — arquitetura curricular corrigida: entregue.**
2. **MB02 — Atlas de materiais com ativos próprios: entregue.**
3. **MB03 — desenvolver procedimentos fundamentais de alta frequência.**
4. **MB04 — integrar cirurgia, anestesia e recuperação.**
5. **MB05 — ampliar urgência e especialidades.**
6. **MB06 — vincular videoteca por procedimento e revisar conformidade.**
7. **MB07 — estruturar avaliação prática para simulação supervisionada.**
8. **Testar acessibilidade e congelar a versão editorial completa.**
9. **Nomear revisores clínicos e revisores de avaliação.**
10. **Revisar conteúdo, questões e casos com registro de decisão.**
11. **Corrigir, executar piloto e reequilibrar o blueprint.**
12. **Atravessar os gates clínicos P0, P1 e P2.**
13. **Migrar para backend e painel editorial.**
14. **Publicar somente módulos aprovados.**

---

## 11. Critério de sucesso

O sucesso não será medido apenas pela quantidade de aulas. A plataforma estará pronta para uma publicação profissional quando conseguir demonstrar:

- cobertura explícita das competências;
- revisão e responsabilidade editorial;
- atualização normativa;
- avaliações válidas;
- uso seguro e licenciado de mídia;
- acessibilidade;
- rastreabilidade de conteúdo e dados;
- clareza de que estudo digital não substitui habilitação e prática supervisionada.


## 7. Auditoria de transição e MB03 lote 1 (14/10/2026)

Ver `MB03_ENTREGA_PARCIAL.md`. 15/227 tópicos receberam fichas em revisão técnica; 212 permanecem apenas catalogados. Os 15 tópicos ainda carecem de revisão clínica; o status **Entregue** permanece exclusivo a MB01 e MB02. Testes automáticos independentes: 112/112 aprovados; teste real de navegador bloqueado pelo ambiente. Próximo marco: MB03 lote 2.


## Idiomas (v1.4.5)

O seletor PT/ES é funcional; textos de interface, títulos e resumos dos 46 procedimentos estão traduzidos. A tradução completa dos demais campos práticos e das 115 aulas é uma etapa de **produção editorial incremental**, não uma condição de autorização externa. Manter fontes, datas e correções identificadas. Nenhum livro isoladamente substitui comparação com recomendações atualizadas.
