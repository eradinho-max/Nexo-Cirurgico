# Nexo Cirúrgico — auditoria de cobertura, pesquisa e plano curricular

**Versão:** 2.0  
**Data da revisão:** 13 de outubro de 2026  
**Escopo:** plataforma médica de procedimentos em expansão a partir do núcleo perioperatório, sem página de vendas  
**Status do produto:** protótipo funcional; conteúdo profissional ainda em construção

> **Resposta direta:** o software está completo como MVP demonstrativo, mas o curso ainda não está completo para formação profissional. A base atual é útil para validar navegação, experiência de estudo e linguagem didática; ela não cobre, em profundidade suficiente, todo o trabalho perioperatório nem substitui formação regulamentada, prática supervisionada ou protocolos institucionais.

### Atualização de implementação — versão 2.0

As expansões P0, P1 e P2 foram incorporadas ao protótipo. A plataforma contém **33 trilhas, 115 aulas, 2.068 minutos, 137 flashcards, 210 questões, 30 casos situacionais, 90 itens de checklist e 72 publicações catalogadas**. Todas as aulas estão distribuídas em **três planos progressivos**, e os resultados dos simulados geram remediação para as 28 competências.

O MB01 foi corrigido após auditoria independente: os **227 tópicos** agora possuem status, prioridade, aliases e revisão individuais; existem **224 procedimentos canônicos** e 254 relações de aula tipadas. O MB02 acrescentou um Atlas com **30 materiais, 133 variantes, sete categorias e sete sistemas de escala**, usando visuais originais e proveniência explícita. Catálogo, fichas editoriais e relações não devem ser confundidos com conteúdo clinicamente validado. A auditoria clínica e o piloto permanecem adiados até a conclusão editorial.

Cada trilha possui fontes vinculadas e cada aula exibe bibliografia contextual. Os novos textos são rascunhos editoriais originais fundamentados nas publicações listadas; **ainda precisam de revisão e aprovação formal por especialistas antes de uso profissional**. O plano de evolução e os gates estão documentados em `ROADMAP.md` e na nova rota interna `#/roadmap`.

---

## 1. O que foi auditado

A versão atual possui:

- **33 trilhas atuais**;
- **115 aulas**, totalizando **2.068 minutos**;
- **28 módulos na matriz técnica de expansão**;
- **227 tópicos técnicos catalogados com ID editorial**;
- **137 flashcards**;
- **3 planos de estudo progressivos** cobrindo 100% das aulas;
- **remediação formativa para 28 competências**, com 84 vínculos para aulas;
- **210 questões** no banco de avaliação;
- **30 casos situacionais sintéticos**;
- **90 itens** no checklist de estudo;
- **72 publicações** catalogadas;
- progresso, busca, perfil, roadmap e estado local funcionando no navegador.

As trilhas atuais cobrem, em nível introdutório ou intermediário:

1. instrumentais cirúrgicos;
2. fios, agulhas e suturas;
3. posicionamento do paciente;
4. assepsia e segurança;
5. anatomia aplicada;
6. fluxo de procedimentos;
7. ambiente e equipe cirúrgica;
8. cirurgia segura;
9. prevenção de infecção de sítio cirúrgico;
10. contagens e itens retidos;
11. espécimes e implantes;
12. CME e processamento;
13. energia, fogo e fumaça;
14. medicamentos e rotulagem;
15. anestesia e SRPA;
16. segurança ocupacional;
17. documentação, ética e privacidade;
18. eventos críticos e emergências.

### Veredito de cobertura

| Dimensão | Situação atual | Avaliação |
|---|---|---|
| Experiência de produto | Rotas, aulas, progresso, avaliações e checklist funcionam | **MVP funcional** |
| Fundamentos conceituais | Dezoito trilhas com bibliografia contextual | **Bases P0 e P1 redigidas** |
| Profundidade clínica | Aulas curtas e demonstrativas | **Insuficiente para curso profissional** |
| Cobertura curricular | P0/P1 ampliados com procedimentos, acessos, dispositivos e antissepsia; 10 trilhas P2 com quatro aulas por especialidade | **Ampliada, ainda incompleta** |
| Avaliação de aprendizagem | 210 questões, 30 casos e 137 flashcards; banco de questões mantido sem nova expansão | **Estruturada; validação pendente** |
| Governança clínica | Sem revisão formal por especialistas registrada | **Pendente** |
| Referências | Existiam menções gerais; agora há biblioteca documental | **Em expansão** |
| Vídeos | Nova videoteca por links externos, sem re-hospedagem | **Piloto seguro** |

A limitação não é apenas o número de aulas. Conteúdo perioperatório exige coerência entre norma brasileira, diretriz profissional, protocolo local, instruções de uso do fabricante e atualização periódica. Um curso aparentemente extenso, mas sem essa governança, continuaria inadequado.

---

## 2. Hierarquia das fontes

A produção editorial deve usar a seguinte ordem de prioridade:

1. **Legislação, regulamentos e protocolos oficiais brasileiros** — Anvisa, Ministério da Saúde, Ministério do Trabalho e Cofen;
2. **documentos internacionais de referência** — OMS e CDC;
3. **diretrizes profissionais** — SOBECC e AORN, consultadas legalmente e sem reprodução indevida;
4. **revisões sistemáticas, revisões clínicas e estudos revisados por pares**;
5. **instruções de uso do fabricante**, aplicadas ao produto específico;
6. **vídeos educacionais**, somente como ilustração complementar.

Vídeos não devem ser usados como fonte normativa principal. Uma demonstração visual pode divergir de normas brasileiras, do manual do fabricante, da infraestrutura disponível ou do protocolo validado pela instituição.

---

## 3. Publicações prioritárias encontradas

### 3.1 Cirurgia segura

- **Ministério da Saúde, Anvisa e Fiocruz — Protocolo para Cirurgia Segura.** Base brasileira para identificação do paciente, local/procedimento, comunicação da equipe e uso da lista de verificação.  
  <https://www.gov.br/saude/pt-br/composicao/saes/dahu/pnsp/protocolos-basicos/protocolo-cirurgia-segura.pdf/view>
- **OMS — Surgical Safety Checklist e Implementation Manual.** Referência internacional para os momentos de entrada, pausa antes da incisão e saída.  
  <https://www.who.int/teams/integrated-health-services/patient-safety/research/safe-surgery/tool-and-resources>
- **OMS — Cirurgias Seguras Salvam Vidas.** Estrutura conceitual do segundo desafio global pela segurança do paciente.  
  <https://bvsms.saude.gov.br/bvs/publicacoes/seguranca_paciente_cirurgias_seguras_salvam_vidas.pdf>

**Implicação curricular:** expandir o tema para comunicação em circuito fechado, briefings, debriefings, identificação, lateralidade, alergias, antimicrobianos, risco hemorrágico, eventos críticos previstos e cultura de segurança. A lista deve ser ensinada como ferramenta de comunicação e barreira de segurança, não como mera marcação burocrática.

### 3.2 Prevenção de infecção de sítio cirúrgico

- **Anvisa — Protocolo de Prevenção de Infecção de Sítio Cirúrgico, versão 1, 2025.** Deve ser a referência brasileira central para o módulo.  
  <https://www.gov.br/anvisa/pt-br/centraisdeconteudo/publicacoes/servicosdesaude/publicacoes/Protocolo2PreveodeISCFINAL.pdf>
- **CDC — Guideline for the Prevention of Surgical Site Infection, 2017.** Referência internacional complementar.  
  <https://stacks.cdc.gov/view/cdc/79361>
- **SHEA/IDSA/APIC — Strategies to prevent surgical site infections in acute-care hospitals: 2022 Update.** Atualização de práticas hospitalares.  
  <https://stacks.cdc.gov/view/cdc/155079/cdc_155079_DS1.pdf>

**Implicação curricular:** separar higiene/preparo das mãos, paramentação, manutenção de campo estéril, preparo da pele, tricotomia quando indicada, profilaxia antimicrobiana no escopo da equipe, fatores do paciente e vigilância. Evitar regras universais inventadas; o protocolo institucional e o produto utilizado precisam ser considerados.

### 3.3 CME e processamento de produtos para saúde

- **Anvisa — RDC nº 15/2012.** Requisitos de boas práticas para processamento de produtos para saúde e funcionamento de CME.  
  <https://bvsms.saude.gov.br/bvs/saudelegis/anvisa/2012/rdc0015_15_03_2012.html>
- **OMS — Decontamination and reprocessing of medical devices for health-care facilities, 2016.** Estrutura internacional para limpeza, desinfecção, esterilização e sistemas de qualidade.  
  <https://www.who.int/publications/i/item/9789241549851>
- **OMS — Aide-mémoire de descontaminação e reprocessamento, 2022.** Síntese para implementação.  
  <https://www.who.int/publications/i/item/WHO-UHL-IHS-IPC-2022.4>

**Implicação curricular:** criar uma trilha própria de CME. É inadequado reduzir o tema a “lavar e esterilizar”. Devem ser tratados fluxo unidirecional, classificação, limpeza, inspeção, preparo, embalagem, monitoramento, armazenamento, rastreabilidade, não conformidade e responsabilidades.

### 3.4 Segurança ocupacional

- **NR-32, versão oficial atualizada em 2023.** Abrange riscos biológicos, perfurocortantes, resíduos, vestimentas e capacitação em serviços de saúde.  
  <https://www.gov.br/trabalho-e-emprego/pt-br/acesso-a-informacao/participacao-social/conselhos-e-orgaos-colegiados/comissao-tripartite-partitaria-permanente/normas-regulamentadora/normas-regulamentadoras-vigentes/nr-32-atualizada-2023-1.pdf>
- **NIOSH/CDC — Surgical Smoke Inhalation.** Riscos ocupacionais e necessidade de controle da fumaça cirúrgica.  
  <https://www.cdc.gov/niosh/bulletin/2020/surgical-smoke.html>

**Implicação curricular:** incluir prevenção de acidentes com perfurocortantes, vacinação, conduta pós-exposição segundo protocolo, EPI, riscos químicos, radiação, ergonomia, fumaça cirúrgica e cultura de notificação.

### 3.5 Exercício profissional

- **Cofen — Resolução nº 214/1998.** Dispõe sobre instrumentação cirúrgica.  
  <https://cofen.gov.br/resoluo-cofen-2141998/>
- **Cofen — Resolução nº 609/2019.** Atualiza especialidades de Enfermagem de nível médio, incluindo áreas relacionadas a Centro Cirúrgico e CME.  
  <https://www.cofen.gov.br/resolucao-cofen-no-609-2019/>
- **SOBECC — Diretrizes de Práticas em Enfermagem Perioperatória e Processamento de Produtos para Saúde, 8ª edição.** Referência profissional brasileira protegida por direitos autorais.  
  <https://sobecc.org.br/store-produto-detalhe.php?produto=3>

**Implicação curricular:** incluir papéis, limites, responsabilidade, supervisão, registro e trabalho em equipe. A redação final deve passar por revisão regulatória e profissional. A plataforma não deve induzir o estudante a executar atos fora de sua habilitação.

### 3.6 Contagem cirúrgica, espécimes e posicionamento

- **OMS/NCBI Bookshelf — prevenção de retenção não intencional de instrumentos e compressas.**  
  <https://www.ncbi.nlm.nih.gov/books/NBK143227/>
- **AORN — Guideline in Focus: Specimen Management.** Síntese sobre identificação, contenção, comunicação e transporte de espécimes.  
  <https://www.aorn.org/article/aorn-guideline-in-focus--specimen-management>
- **Revisão sistemática e meta-análise sobre posicionamento e segurança, 2025.**  
  <https://pmc.ncbi.nlm.nih.gov/articles/PMC12371821/>

**Implicação curricular:** desenvolver cenários de divergência de contagem, comunicação/escalonamento, documentação, preservação e identificação de espécimes, rastreabilidade de implantes e prevenção de lesões associadas ao posicionamento.

### 3.7 Fios e suturas

- **Revisão clínica aberta — Suture materials, 2023.** Classificação, propriedades e seleção de materiais de sutura.  
  <https://tidsskriftet.no/en/2023/06/clinical-review/suture-materials>

**Implicação curricular:** separar propriedades do material, construção, absorção, capilaridade, calibre, agulhas, embalagem/validade e princípios de manuseio. A escolha clínica depende do tecido, procedimento, paciente e preferência justificada do cirurgião, além do protocolo e fabricante.

### 3.8 Atualização de referências para P2 — 2026

A expansão por especialidade foi precedida por nova busca em fontes oficiais. Foram incorporadas referências Anvisa 2026, AORN 2026, ERAS colorretal 2025, ginecológica 2026 e cesariana 2025, AUA 2026, ESVS 2026, ACC/AHA 2026, ASA 2026, ERAS neonatal 2024 e FDA 2026. O registro de vigência, data de verificação e limitações está em `REFERENCIAS_ATUALIZADAS_2026.md`.

O rascunho FDA de 2026 sobre sistemas roboticamente assistidos é identificado como não vinculante e não é apresentado como norma final. Diretrizes antigas que continuam oficialmente listadas são mantidas com status explícito e monitoramento.

---

## 4. Matriz curricular proposta

### Prioridades

- **P0 — essencial antes de chamar o curso de formação abrangente**;
- **P1 — necessário para consolidar competência perioperatória geral**;
- **P2 — aprofundamento e especialidades.**

| # | Módulo proposto | Prioridade | Resultados de aprendizagem esperados | Fontes centrais |
|---:|---|:---:|---|---|
| 1 | Ambiente cirúrgico, áreas e fluxo | P0 | Reconhecer zonas, circulação, riscos, fluxo do paciente e integração com setores | SOBECC; protocolos locais |
| 2 | Equipe, papéis e limites profissionais | P0 | Diferenciar responsabilidades, comunicação, supervisão e limites da habilitação | Cofen; normas institucionais |
| 3 | Cultura de segurança e checklist | P0 | Aplicar os princípios dos três momentos e comunicação segura em cenários | MS/Anvisa/Fiocruz; OMS |
| 4 | Microbiologia, técnica asséptica e campo estéril | P0 | Explicar cadeia de contaminação, preparo das mãos, paramentação e correção de quebra de técnica | Anvisa ISC 2025; OMS |
| 5 | Instrumentais: nomenclatura, função e inspeção | P0 | Classificar, identificar riscos, verificar integridade e organizar por função | SOBECC; IFU do fabricante |
| 6 | Mesa, passagem e antecipação segura | P0 | Organizar de modo sistemático, comunicar e manter rastreabilidade/segurança | SOBECC; protocolos locais |
| 7 | Fios, agulhas, nós e manejo seguro | P0 | Comparar propriedades e reconhecer seleção contextual; demonstrar princípios em simulação | revisão clínica; fabricante |
| 8 | Posicionamento e prevenção de lesões | P0 | Relacionar posição, pressão, nervos, dispositivos, tempo e reavaliação | revisão sistemática; AORN/SOBECC |
| 9 | Contagens e prevenção de itens retidos | P0 | Executar lógica de contagem, comunicar divergências e documentar conforme protocolo | OMS; AORN/SOBECC |
| 10 | Espécimes, implantes e rastreabilidade | P0 | Identificar, acondicionar, comunicar e registrar sem quebra de cadeia | AORN; Anvisa; protocolo local |
| 11 | Prevenção de ISC | P0 | Relacionar medidas pré, intra e pós-operatórias ao risco de ISC | Anvisa 2025; CDC/SHEA |
| 12 | CME e processamento | P0 | Explicar etapas, controles, monitoramento e rastreabilidade | RDC 15/2012; OMS |
| 13 | Eletrocirurgia, incêndio e fumaça | P1 | Reconhecer o triângulo do fogo, riscos e controles; agir segundo protocolo | AORN; NIOSH; fabricante |
| 14 | Medicamentos e rotulagem no campo | P1 | Aplicar princípios de identificação, comunicação e dupla checagem | protocolos oficiais e institucionais |
| 15 | Anestesia e recuperação pós-anestésica | P1 | Reconhecer etapas, monitorização, transferência e sinais de alerta dentro do escopo | SOBECC; diretrizes de anestesia |
| 16 | Segurança ocupacional e NR-32 | P1 | Prevenir exposição, perfurocortantes e outros riscos; acionar fluxo pós-exposição | NR-32; NIOSH |
| 17 | Documentação, ética e privacidade | P1 | Registrar de forma objetiva, preservar confidencialidade e rastreabilidade | Cofen; legislação aplicável; protocolos |
| 18 | Eventos críticos e emergências | P1 | Reconhecer prioridades de comunicação e função de cada membro em emergência | protocolos institucionais; simulação |
| 19 | Anatomia cirúrgica aplicada por região | P2 | Relacionar estruturas, riscos e instrumental de forma contextual | atlas licenciados; revisão clínica |
| 20 | Trilhas por especialidade | P2 | Aplicar fundamentos a cirurgia geral, ortopedia, ginecologia, urologia, vascular, neuro e outras áreas | especialistas; literatura específica |

### Organização em fases

**Fase 1 — segurança essencial (P0):** módulos 1 a 12.  
**Fase 2 — prática perioperatória ampliada (P1):** módulos 13 a 18.  
**Fase 3 — anatomia e especialidades (P2):** a proposta inicial dos módulos 19 e 20 foi desdobrada em dez trilhas implementadas, numeradas de 19 a 28. Cada trilha possui quatro aulas, quatro flashcards, seis questões, um caso e um roteiro de estudo. Ver `MATRIZ_P2_ESPECIALIDADES.md`.

---

## 5. Meta editorial recomendada

Os números abaixo são **metas de produto**, não exigências normativas:

- **50 a 70 aulas** para o núcleo geral;
- **180 a 250 flashcards** com repetição espaçada futura;
- **250 a 400 questões** revisadas, com justificativa e referência;
- **20 a 30 casos clínico-operacionais** de tomada de decisão;
- **15 a 25 demonstrações em simulação** ou vídeo institucional;
- avaliação diagnóstica, avaliações por módulo e avaliação final;
- versão, data de revisão e bibliografia em cada aula.

### Distribuição do banco de questões

- 25% fundamentos e reconhecimento;
- 50% aplicação em cenários;
- 15% análise de falhas e segurança;
- 10% integração entre módulos.

Evitar questões baseadas somente em memorização de cor, forma ou listas. Cenários devem avaliar comunicação, prevenção de dano, identificação de quebra de técnica e decisão de interromper/escalonar conforme protocolo.

---

## 6. Governança clínica e editorial

### Fluxo obrigatório para cada aula

1. **Definir competência e público.** O que o aluno deve reconhecer, explicar ou demonstrar em simulação?
2. **Selecionar fontes.** Usar normas brasileiras e publicações atuais, registrando edição e data.
3. **Redigir conteúdo original.** Não copiar tabelas, ilustrações ou trechos extensos de obras protegidas.
4. **Revisão técnica.** Enfermeiro perioperatório/instrumentador habilitado e, conforme o tema, cirurgião, anestesiologista, profissional de CME, controle de infecção ou segurança do trabalho.
5. **Revisão pedagógica.** Clareza, carga cognitiva, objetivos e avaliação alinhados.
6. **Revisão jurídica/licenças.** Especialmente para mídia, marcas, privacidade e filmagem de pacientes.
7. **Publicar com versão.** Exibir revisor, data, fontes e próxima revisão.
8. **Monitorar.** Corrigir errata e revisar após mudança normativa ou em intervalo definido.

### Registro mínimo por conteúdo

- ID e título;
- público e pré-requisitos;
- objetivos observáveis;
- autores e revisores;
- referências com edição/URL;
- versão e data;
- data de próxima revisão;
- avisos de escopo;
- mídias utilizadas e respectivos direitos.

---

## 7. Curadoria inicial de vídeos

A autoria pública foi conferida pelo endpoint oficial **oEmbed** do YouTube em 13/10/2026. Isso confirma título e canal exibidos publicamente, mas **não concede licença para baixar, editar ou re-hospedar**.

| Tema | Material | Canal/crédito | Idioma | Uso na plataforma |
|---|---|---|---|---|
| Instrumentação | [Aula prática de instrumentação cirúrgica](https://www.youtube.com/watch?v=FrRc2zgiJUQ) | Santa Casa BH | Português | Link externo |
| Nós | [How to Tie a Two-Handed Surgical Square Knot](https://www.youtube.com/watch?v=t3ODIsIj5x4) | Stanford Surgery | Inglês | Link externo |
| Sutura | [Basic Skills Sutures and Knot Tying](https://www.youtube.com/watch?v=-lEtr4Jys_4) | Orthopaedic Surgical Videos/HSS | Inglês | Link externo |
| Preparo das mãos | [WHO surgical hand preparation technique](https://www.youtube.com/watch?v=h16JPBcOIGs) | Hôpitaux Universitaires de Genève | Visual | Link externo |
| Embalagens estéreis | [Opening Sterile Packages](https://www.youtube.com/watch?v=3La8r7qRALU) | Michigan Medicine | Inglês | Link externo |
| Campo estéril | [Sterile Field Setup](https://www.youtube.com/watch?v=T4OUPVFALZY) | College of Southern Maryland | Inglês | Link externo |
| Checklist | [Aplicação do checklist de cirurgia segura](https://www.youtube.com/watch?v=lcrHgzMmGDA) | HC-UFTM | Português | Link externo |
| Checklist | [Safe Surgery Using the WHO Checklist](https://www.youtube.com/watch?v=DqG_cInBRbo) | Medical Aid Films | Inglês | Link externo |
| Checklist | [Centro Cirúrgico e checklist da cirurgia segura](https://www.youtube.com/watch?v=hRnbqk_pRjA) | SOBECC | Português | Link externo |

### Critérios de inclusão

- autoria/canal identificável;
- preferência por universidade, hospital, órgão público ou entidade profissional;
- objetivo didático compatível;
- ausência de divulgação de dados identificáveis do paciente;
- técnica submetida à revisão clínica;
- aviso de imagens sensíveis quando aplicável;
- link ainda ativo na data de revisão.

### Critérios de exclusão

- autoria incerta;
- edição sensacionalista ou publicidade disfarçada;
- prática sem contexto ou com risco de ser interpretada como instrução autônoma;
- exposição indevida de paciente;
- conteúdo que contradiga norma, fabricante ou protocolo;
- cópia/reupload de terceiros.

---

## 8. Direitos autorais e YouTube

### Regra adotada para a primeira versão

A plataforma usa **link para a página original do vídeo**. Ela não:

- baixa o arquivo;
- remove marca ou créditos;
- recorta ou edita o vídeo;
- re-hospeda a mídia;
- copia miniaturas;
- afirma que crédito equivale a autorização.

Em cada cartão aparecem título, canal/titular, idioma, objetivo didático, link original e data de revisão.

### Se houver incorporação futura

Usar somente o **player oficial do YouTube**, depois de verificar que a incorporação está habilitada. Não interferir em controles, publicidade, marca ou métricas; não cobrar especificamente para assistir ao conteúdo de terceiro; e prever remoção rápida se o titular apagar ou restringir o vídeo. Em produto pago, obter análise jurídica ou autorização direta quando houver dúvida.

Referências:

- Termos do YouTube: <https://www.youtube.com/t/terms>
- Ajuda oficial para incorporação: <https://support.google.com/youtube/answer/171780>
- Licença padrão e Creative Commons: <https://support.google.com/youtube/answer/2797468>
- Mitos de direitos autorais: <https://support.google.com/youtube/answer/2797449>
- Políticas para serviços de API/player: <https://developers.google.com/youtube/terms/developer-policies>

> **Ponto jurídico essencial:** atribuição é obrigatória quando a licença a exige e é uma boa prática em todos os casos, mas o crédito, sozinho, não concede direito de cópia ou adaptação.

---

## 9. Imagens e ilustrações

Prioridade recomendada:

1. ilustração original contratada com cessão/licença documentada;
2. material em domínio público;
3. CC0;
4. CC BY 4.0;
5. CC BY-SA, se a obrigação de compartilhamento pela mesma licença for compatível;
6. licença comercial adquirida.

Fontes inicialmente adequadas para investigação:

- **Servier Medical Art — CC BY 4.0:** <https://smart.servier.com/>
- **NIH BioArt Source — licença indicada por item:** <https://bioart.niaid.nih.gov/>
- **Wikimedia Commons — licença varia por arquivo:** <https://commons.wikimedia.org/wiki/Category:Surgical_instruments>
- **OpenStax Anatomy & Physiology 1e em repositórios históricos — confirmar licença do arquivo:** <https://med.libretexts.org/Bookshelves/Anatomy_and_Physiology/Anatomy_and_Physiology_1e_(OpenStax)>

A edição atual **OpenStax Anatomy & Physiology 2e** usa CC BY-NC-SA 4.0; “NC” restringe uso comercial. Não se deve presumir que todas as edições ou imagens OpenStax têm a mesma licença.

### Registro de ativos

Para cada imagem, armazenar:

- título/descrição;
- autor ou instituição;
- URL original;
- licença exata e versão;
- data de consulta;
- arquivo da licença ou captura do registro;
- alterações realizadas;
- texto de atribuição publicado.

---

## 10. Riscos a controlar

1. **Conteúdo parecer autorização profissional.** Mitigação: avisos claros, definição de público e limites de escopo.
2. **Técnica desatualizada.** Mitigação: versionamento e revisão após mudança normativa.
3. **Generalização de protocolo local.** Mitigação: separar princípios gerais de instruções institucionais.
4. **Uso indevido de obras SOBECC/AORN.** Mitigação: consultar legalmente, sintetizar com redação original e citar; não copiar tabelas/figuras.
5. **Vídeo com prática inadequada.** Mitigação: revisão clínica e retirada imediata.
6. **Imagem ou vídeo sem autorização.** Mitigação: registro de licença; na dúvida, apenas link externo.
7. **Caso clínico identificável.** Mitigação: casos sintéticos ou totalmente anonimizados e revisão de privacidade.
8. **Avaliação superficial.** Mitigação: blueprint, revisores e análise de qualidade dos itens.

---

## 11. Plano de execução

### Etapa 1 — base e governança

- aprovar público-alvo e competências;
- nomear responsáveis técnicos/revisores;
- criar modelo-padrão de aula e registro de fontes;
- definir calendário de atualização;
- classificar conteúdo atual como “introdutório”.

### Etapa 2 — fechar lacunas P0 — segunda redação ampliada

- 12 módulos essenciais incorporados;
- bibliografia vinculada às aulas;
- banco inicial de 150 questões entregue e posteriormente ampliado;
- simulações de checklist, quebra de técnica, contagem e rastreabilidade incorporadas;
- revisão audiovisual consolidada permanece no gate editorial.

### Etapa 3 — ampliar prática P1 — conteúdo incorporado

- anestesia/SRPA, eletrocirurgia, fogo/fumaça, medicamentos, NR-32, documentação e emergências incorporados;
- procedimentos e vias cirúrgicas, acessos vasculares, via aérea, sondas, drenos e acessos regionais incorporados;
- assepsia, antissepsia, preparo da pele e assistência perioperatória aprofundados;
- banco de avaliação mantido em 210 questões para priorizar conteúdo;
- teste com turma piloto permanece adiado até a conclusão editorial.

### Etapa 4 — especialidades P2 — segunda redação e avaliação incorporadas

- dez trilhas e 40 aulas implementadas;
- 40 flashcards e dez roteiros de estudo por especialidade;
- competências C19–C28, 60 questões e dez casos incorporados;
- anatomia visual e variações de instrumental permanecem em expansão;
- preferências locais continuam explicitamente condicionadas a protocolo, equipe habilitada e instruções do fabricante.

### Etapa 5 — validação

- revisão clínica final;
- revisão regulatória e de direitos;
- teste de usabilidade e acessibilidade;
- prova piloto e análise de questões;
- publicação com versionamento.

---

## 12. Conclusão

A **Nexo Cirúrgico** já demonstra bem o produto: a pessoa consegue navegar, estudar, revisar e acompanhar progresso. Porém, chamar a versão atual de curso validado seria impreciso. A transformação em plataforma profissional exige principalmente **governança clínica, revisão especializada, anatomia visual licenciada, acessibilidade, piloto e controle contínuo de versões**.

A videoteca segue uma estratégia conservadora: **links externos com crédito e transparência**, sem copiar ou hospedar mídia. O MB01 corrigido e o núcleo do MB02 estão incorporados; o próximo passo é desenvolver no **MB03** as fichas canônicas dos procedimentos fundamentais de maior frequência, reutilizando o Atlas e mantendo revisão técnica documentada.
