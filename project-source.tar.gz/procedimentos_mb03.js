/* MB03: fichas educacionais originais em revisão clínica; não são protocolos. */
window.NEXO_PROCEDURES = {
  "version": "0.2",
  "macroblock": "MB03",
  "generatedOn": "2026-10-14",
  "status": "revisao-tecnica",
  "sourcePolicy": "Textos originais resumem princípios de segurança; revisão especializada obrigatória antes de publicação clínica.",
  "procedures": [
    {
      "id": "PT-M01-01",
      "topicIds": [
        "PT-M01-01"
      ],
      "title": "Higienização das mãos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Biossegurança",
      "population": "Todas as faixas etárias",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Preparação alcoólica apropriada ou água e sabonete; papel-toalha; pia funcional"
      ],
      "criticalErrors": [
        "Deixar de higienizar antes de técnica asséptica",
        "Tratar luvas como substituto da higiene"
      ],
      "fields": {
        "definition": [
          "Prática fundamental para interromper transmissão cruzada de microrganismos e proteger paciente e equipe."
        ],
        "indications": [
          "Antes de tocar o paciente; antes de procedimento limpo/asséptico; após risco de fluidos; após tocar paciente; após tocar superfícies próximas."
        ],
        "contraindications": [
          "Não há contraindicação à higiene; alergia ou lesão cutânea requer adequação do produto e avaliação ocupacional."
        ],
        "anatomy": [
          "Mãos, unhas, espaços interdigitais, polegares, pontas dos dedos e punhos; integridade cutânea e adornos interferem."
        ],
        "materials": [
          "Preparação alcoólica regulamentada quando indicada; água e sabonete quando mãos visivelmente sujas ou conforme protocolo."
        ],
        "environment": [
          "Garantir suprimentos acessíveis e pontos de higiene nos locais de cuidado."
        ],
        "patient": [
          "Explicar ações ao paciente quando pertinente; remover acessórios de mão conforme regras locais."
        ],
        "analgesia": [
          "Não requer anestesia ou analgesia."
        ],
        "sequence": [
          "Identificar o momento assistencial",
          "Escolher água e sabonete ou produto alcoólico conforme indicação",
          "Cobrir todas as superfícies das mãos até secagem completa",
          "Não substituir higiene por uso de luvas."
        ],
        "confirmation": [
          "Mãos secas após fricção alcoólica; ausência de áreas negligenciadas na demonstração observada."
        ],
        "complications": [
          "Erro de oportunidade, técnica incompleta, contaminação após higiene e dermatite; corrigir e repetir quando necessário."
        ],
        "aftercare": [
          "Repetir nos cinco momentos; notificar problemas de suprimento ou dermatite ocupacional."
        ],
        "skills-checklist": [
          "Reconhece os cinco momentos",
          "Seleciona método apropriado",
          "Abrange polegares e pontas dos dedos",
          "Não considera luvas substitutas."
        ],
        "media-references": [
          "Usar recursos da OMS como apoio de aprendizagem, não como autorização de reutilização de mídia.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-05",
      "topicIds": [
        "PT-M04-05"
      ],
      "title": "Administração intramuscular de medicamentos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Medicamento prescrito, diluente compatível se aplicável, antisséptico, luvas, gaze, coletor de perfurocortantes"
      ],
      "criticalErrors": [
        "Agulha compartilhada ou reutilizada",
        "Medicação em via não autorizada",
        "Falta de confirmação de alergias"
      ],
      "fields": {
        "definition": [
          "Administração de fármaco no tecido muscular, observando indicação da via e formulação autorizada."
        ],
        "indications": [
          "Quando a apresentação e a prescrição permitem via IM, com volume, local e absorção compatíveis."
        ],
        "contraindications": [
          "Não utilizar via IM quando a formulação não for destinada a ela; avaliar infecção local, alterações de coagulação e riscos individuais."
        ],
        "anatomy": [
          "Identificar marcos anatômicos de locais adequados, com variações por faixa etária e massa muscular; evitar estruturas neurovasculares."
        ],
        "materials": [
          "Conferir medicamento, dose, diluição, seringa e agulha de comprimento/calibre apropriados; agulha e seringa de uso único."
        ],
        "environment": [
          "Área limpa, recipiente de descarte próximo e disponibilidade de manejo de reação adversa."
        ],
        "patient": [
          "Conferir paciente, prescrição, alergias, contraindicações, consentimento, integridade do local e capacidade de colaborar."
        ],
        "analgesia": [
          "Medidas de conforto e posicionamento; necessidade de analgesia específica depende do procedimento e paciente."
        ],
        "sequence": [
          "Validar prescrição e preparo com identificação completa",
          "Localizar sítio anatômico compatível e posicionar",
          "Higienizar mãos e seguir política de antissepsia",
          "Administrar sob técnica do serviço e descarte imediato sem reencape",
          "Documentar lote quando pertinente."
        ],
        "confirmation": [
          "Confirmar medicamento, dose, via, local e documentação; observar resposta e reação imediata."
        ],
        "complications": [
          "Lesão nervosa ou vascular, dor, hematoma, infecção, reação alérgica; interromper e acionar suporte se houver reação grave."
        ],
        "aftercare": [
          "Orientar sinais de alerta, cuidados locais e registro de administração; vigiar reações."
        ],
        "skills-checklist": [
          "Confere identificação/alergias",
          "Justifica sítio e dispositivo",
          "Mantém assepsia",
          "Descarta sem reencapar",
          "Reconhece anafilaxia."
        ],
        "media-references": [
          "Tabelas de comprimentos e volumes devem ser formuladas por medicamento, idade e fabricante, e não presumidas de uma regra universal.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "CDC-INJ",
          "title": "CDC — Práticas seguras de injeção",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M05-01",
      "topicIds": [
        "PT-M05-01"
      ],
      "title": "Acesso venoso periférico",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Acessos vasculares",
      "population": "Adulto;Criança;Neonato com protocolo e supervisão específicos",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-001",
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Garrote, antisséptico adequado, luvas, solução de flushing compatível, gaze, cobertura transparente ou apropriada, descarte perfurocortante"
      ],
      "criticalErrors": [
        "Reutilizar cateter",
        "Manter infusão diante de extravasamento",
        "Omitir antissepsia"
      ],
      "fields": {
        "definition": [
          "Introdução de cateter curto em veia periférica para terapia intravenosa e outras indicações clínicas."
        ],
        "indications": [
          "Infusão de fluidos/medicamentos compatíveis, contraste ou necessidade de acesso venoso conforme avaliação."
        ],
        "contraindications": [
          "Evitar áreas de infecção, flebite, comprometimento circulatório e locais com restrições clínicas; reconsiderar necessidade e via."
        ],
        "anatomy": [
          "Veias periféricas do membro superior, anatomia e mobilidade; escolha do vaso deve considerar terapêutica e preservação vascular."
        ],
        "materials": [
          "Cateter com calibre e comprimento adequados ao vaso e terapia; conector, extensão, cobertura, solução e embalagem íntegra."
        ],
        "environment": [
          "Higiene das mãos, campo limpo, iluminação, contenção mínima e descarte imediatamente acessível."
        ],
        "patient": [
          "Identificação, consentimento, alergias, pele/vasculatura, histórico de tentativas e necessidade de analgesia individualizada."
        ],
        "analgesia": [
          "Analgesia tópica ou outra medida de conforto pode ser considerada quando adequada à população e disponibilidade."
        ],
        "sequence": [
          "Planejar sítio e dispositivo",
          "Higienizar mãos e preparar material",
          "Realizar antissepsia e preservar área preparada",
          "Simular sequência de inserção e liberação segura do mecanismo",
          "Confirmar permeabilidade, fixar e identificar",
          "Registrar e ensinar sinais de alerta."
        ],
        "confirmation": [
          "Confirmar funcionamento sem sinais de infiltração ou dor; seguir protocolo de permeabilidade e documentação."
        ],
        "complications": [
          "Infiltração, extravasamento, flebite, trombose, infecção, hematoma, perfurocortante; interromper uso e avaliar complicações."
        ],
        "aftercare": [
          "Inspecionar inserção e trajeto venoso pelo menos diariamente; reavaliar necessidade e remover conforme indicação e protocolo."
        ],
        "skills-checklist": [
          "Indica necessidade",
          "Seleciona calibre pelo vaso/terapia",
          "Preserva antissepsia",
          "Confirma funcionamento",
          "Reconhece extravasamento",
          "Registra."
        ],
        "media-references": [
          "O calibre não é exclusivo de faixas etárias; orientações de marca e protocolo local prevalecem.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "WHO-PIV",
          "title": "OMS — Diretriz de cateteres periféricos (2024)",
          "url": "https://www.who.int/publications/i/item/9789240093829",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M05-02",
      "topicIds": [
        "PT-M05-02"
      ],
      "title": "Coleta de sangue venoso",
      "priority": "P0",
      "level": "Básico",
      "scope": "Acessos vasculares",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-002",
        "MAT-MED-002",
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Tubos identificados conforme exames, garrote, luvas, antisséptico, gaze, curativo e descarte"
      ],
      "criticalErrors": [
        "Tubo sem identificação",
        "Reutilização de agulha",
        "Identificação posterior fora do paciente"
      ],
      "fields": {
        "definition": [
          "Obtenção de amostra venosa para análises laboratoriais com rastreabilidade pré-analítica."
        ],
        "indications": [
          "Quando exames solicitados demandam sangue venoso e a condição do paciente permite coleta periférica."
        ],
        "contraindications": [
          "Evitar local com infecção, hematoma, infusão ativa ou restrições institucionais; avaliar acesso alternativo."
        ],
        "anatomy": [
          "Rede venosa superficial, proximidade de estruturas nervosas e artérias; cuidado especial com anatomia pediátrica."
        ],
        "materials": [
          "Dispositivo apropriado à veia, sistema fechado quando possível, tubos corretos, identificação à beira-leito."
        ],
        "environment": [
          "Preparar bancada, descarte, transporte e requisitos de conservação do laboratório."
        ],
        "patient": [
          "Conferir dois identificadores, prescrição, preparo do exame e riscos de síncope ou sangramento."
        ],
        "analgesia": [
          "Medidas de conforto e posicionamento, especialmente se histórico de reação vasovagal."
        ],
        "sequence": [
          "Confirmar pedidos e tubos",
          "Higienizar mãos e selecionar dispositivo",
          "Executar antissepsia e coleta conforme protocolo",
          "Homogeneizar tubos quando indicado",
          "Soltar garrote, retirar e descartar dispositivo",
          "Identificar amostras na presença do paciente."
        ],
        "confirmation": [
          "Conferir identificação, volume, qualidade da amostra e condições de envio; garantir hemostasia local."
        ],
        "complications": [
          "Hematoma, punção arterial acidental, síncope, hemólise e identificação incorreta; interromper e reavaliar."
        ],
        "aftercare": [
          "Orientar compressão local, sinais de retorno e registrar intercorrências."
        ],
        "skills-checklist": [
          "Confere dois identificadores",
          "Seleciona tubos corretos",
          "Controla exposição",
          "Identifica tubos no ponto de cuidado",
          "Evita hemólise."
        ],
        "media-references": [
          "Ordem de coleta, anticoagulantes e volumes devem seguir manual do laboratório e fabricante.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "WHO-PHLEB",
          "title": "OMS — Boas práticas em flebotomia",
          "url": "https://www.who.int/publications/i/item/9789241599221",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-INJ",
          "title": "CDC — Práticas seguras de injeção",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-01",
      "topicIds": [
        "PT-M06-01"
      ],
      "title": "Avaliação estruturada da ferida",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Luvas, fonte de luz, régua descartável apropriada, gaze, material de documentação autorizado"
      ],
      "criticalErrors": [
        "Suturar sem pesquisar lesão profunda",
        "Ignorar perfusão ou função distal"
      ],
      "fields": {
        "definition": [
          "Exame padronizado da lesão para decidir urgência, limpeza, imagem, fechamento e acompanhamento."
        ],
        "indications": [
          "Toda lesão cutânea traumática, cirúrgica ou crônica requer caracterização antes da conduta."
        ],
        "contraindications": [
          "Ferida profunda, isquemia, sangramento persistente ou comprometimento neurovascular demandam avaliação urgente especializada."
        ],
        "anatomy": [
          "Localização, bordas, leito, profundidade, vascularização e proximidade de tendões, vasos, nervos e articulações."
        ],
        "materials": [
          "Iluminação, luvas, material de mensuração e cobertura; fotografia somente com autorização e proteção dos dados."
        ],
        "environment": [
          "Privacidade, assepsia adequada ao cenário e acesso a controle de sangramento."
        ],
        "patient": [
          "Investigar mecanismo/tempo da lesão, imunização antitetânica, comorbidades, medicamentos e sintomas sistêmicos."
        ],
        "analgesia": [
          "Oferecer controle da dor conforme avaliação; evitar exploração dolorosa sem analgesia."
        ],
        "sequence": [
          "Estabilizar e controlar sangramento",
          "Inspecionar dimensão, bordas, exsudato, tecido, corpos estranhos e perfusão",
          "Avaliar função sensitiva e motora",
          "Identificar possível contaminação/infecção",
          "Decidir irrigação, fechamento ou encaminhamento."
        ],
        "confirmation": [
          "Documentar local, medidas, extensão, tecidos envolvidos, perfusão e conduta justificada."
        ],
        "complications": [
          "Infecção, corpo estranho oculto, lesão tendínea, nervosa ou vascular; não mascarar sinais de gravidade."
        ],
        "aftercare": [
          "Orientar cuidados e prazo de reavaliação, incluindo sinais de alarme e profilaxias indicadas."
        ],
        "skills-checklist": [
          "Classifica mecanismo",
          "Avalia profundidade",
          "Examina função e perfusão",
          "Verifica tétano",
          "Documenta plano e retorno."
        ],
        "media-references": [
          "A classificação cirúrgica limpa/limpa-contaminada/contaminada/suja não substitui a classificação das feridas traumáticas.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-03",
      "topicIds": [
        "PT-M06-03"
      ],
      "title": "Irrigação de ferida",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Soro fisiológico ou água apropriada conforme protocolo, seringa e proteção de respingos, recipiente, gaze e equipamento de proteção"
      ],
      "criticalErrors": [
        "Fechar ferida com corpo estranho suspeito",
        "Irrigação sem avaliação de lesão profunda"
      ],
      "fields": {
        "definition": [
          "Limpeza mecânica por fluxo líquido para reduzir carga de contaminantes antes da decisão de fechamento."
        ],
        "indications": [
          "Feridas traumáticas e lesões com resíduos quando irrigação está indicada no plano de cuidado."
        ],
        "contraindications": [
          "Não irrigar de forma não controlada cavidades profundas ou trajetos com suspeita de lesão de estruturas; pedir avaliação especializada."
        ],
        "anatomy": [
          "Reconhecer profundidade, limites e estruturas adjacentes; realizar exame vascular, neurológico e tendíneo antes do fechamento."
        ],
        "materials": [
          "Solução salina ou água apropriada conforme cenário; dispositivo que forneça fluxo controlado, cobertura e gaze."
        ],
        "environment": [
          "Garantir iluminação, contenção de respingos, segurança de perfurocortantes e descarte."
        ],
        "patient": [
          "Explicar desconforto, obter consentimento e avaliar riscos de retenção de corpo estranho."
        ],
        "analgesia": [
          "Analgesia local ou sistêmica individualizada pode ser necessária para inspeção e limpeza adequadas."
        ],
        "sequence": [
          "Controlar sangramento",
          "Examinar extensão e corpo estranho",
          "Proteger paciente/equipe",
          "Irrigar sem traumatizar tecidos",
          "Retirar contaminantes visíveis com instrumentos adequados",
          "Reavaliar e decidir fechamento/encaminhamento."
        ],
        "confirmation": [
          "Campo sem sujeira grosseira; tecidos viáveis e integridade funcional novamente documentada."
        ],
        "complications": [
          "Lesão por pressão exagerada, contaminação secundária, retenção de corpo estranho e falha em reconhecer lesão profunda."
        ],
        "aftercare": [
          "Aplicar cobertura apropriada, atualizar avaliação de tétano e organizar retorno."
        ],
        "skills-checklist": [
          "Avalia antes de irrigar",
          "Escolhe solução apropriada",
          "Protege de respingos",
          "Reavalia tecido e função",
          "Evita lesão adicional."
        ],
        "media-references": [
          "Antissépticos citotóxicos não devem ser aplicados indiscriminadamente no leito da ferida.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-07",
      "topicIds": [
        "PT-M06-07"
      ],
      "title": "Seleção e troca de curativos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Luvas, solução adequada de limpeza, compressa não aderente, gaze absorvente, fixação e descarte"
      ],
      "criticalErrors": [
        "Cobrir sem avaliar perfusão",
        "Aplicar material não compatível com o leito"
      ],
      "fields": {
        "definition": [
          "Escolha, aplicação e troca de cobertura para proteção do leito e manejo do exsudato."
        ],
        "indications": [
          "Feridas que demandam proteção ou controle de umidade/exsudato, conforme etiologia e estágio."
        ],
        "contraindications": [
          "Evitar cobertura oclusiva inadequada em infecção não controlada ou maceração; priorizar avaliação de perfusão e etiologia."
        ],
        "anatomy": [
          "Avaliar leito, pele perilesional, cavidades, exsudato, perfusão e áreas de pressão."
        ],
        "materials": [
          "Escolher cobertura segundo exsudato, aderência, profundidade e fabricante; material não aderente quando necessário."
        ],
        "environment": [
          "Preparar superfície limpa, privacidade e local apropriado para descarte contaminado."
        ],
        "patient": [
          "Conferir alergias a adesivos, dor, odor, temperatura, sinais de infecção e evolução anterior."
        ],
        "analgesia": [
          "Analgesia antes da troca quando indicada; evitar retirada traumática de coberturas aderidas."
        ],
        "sequence": [
          "Examinar curativo anterior",
          "Higienizar mãos e proteger-se",
          "Remover cobertura preservando tecido",
          "Limpar e avaliar leito",
          "Selecionar cobertura com justificativa",
          "Fixar sem restringir circulação",
          "Registrar achados."
        ],
        "confirmation": [
          "Cobertura protege sem compressão excessiva, controle de exsudato e ausência de piora visível."
        ],
        "complications": [
          "Maceração, dermatite de contato, dor, infecção, reação alérgica, isquemia por fixação inadequada."
        ],
        "aftercare": [
          "Definir periodicidade de troca pela ferida e pelo produto, orientar sinais de piora e revisão."
        ],
        "skills-checklist": [
          "Distingue leito/perilesão",
          "Reconhece exsudato",
          "Justifica tipo de cobertura",
          "Evita fixação compressiva",
          "Documenta evolução."
        ],
        "media-references": [
          "A periodicidade não deve ser uma regra única para todas as coberturas.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-09",
      "topicIds": [
        "PT-M06-09"
      ],
      "title": "Feridas por mordedura animal ou humana",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Solução para lavagem abundante, material de irrigação, EPI, cobertura apropriada e acesso a avaliação de profilaxias"
      ],
      "criticalErrors": [
        "Substituir tétano por antibiótico",
        "Omitir avaliação antirrábica",
        "Fechamento automático de ferida profunda da mão"
      ],
      "fields": {
        "definition": [
          "Abordagem de lesões com inoculação potencial de microrganismos por saliva, incluindo risco de raiva em exposições selecionadas."
        ],
        "indications": [
          "Mordidas, arranhaduras com exposição, lesões perfurantes e mordeduras humanas."
        ],
        "contraindications": [
          "Não presumir fechamento primário automático; suspeita de lesão em mão, tendão, articulação ou estrutura profunda exige avaliação especializada."
        ],
        "anatomy": [
          "Inspecionar profundidade e relação com articulações, tendões, nervos e vasos, especialmente na mão."
        ],
        "materials": [
          "Luvas, material de limpeza/irrigação, cobertura; acesso a imunobiológicos conforme avaliação epidemiológica."
        ],
        "environment": [
          "Preparar lavagem precoce, contenção de secreções e encaminhamento quando necessário."
        ],
        "patient": [
          "Documentar espécie, situação do animal, local, tempo de exposição, vacinação conhecida, histórico antitetânico e imunossupressão."
        ],
        "analgesia": [
          "Avaliar analgesia e necessidade de avaliação especializada conforme dor e complexidade."
        ],
        "sequence": [
          "Controlar hemorragia",
          "Realizar lavagem abundante apropriada",
          "Explorar lesões e função",
          "Avaliar necessidade de antibiótico, tétano e raiva separadamente",
          "Definir fechamento seletivo e seguimento."
        ],
        "confirmation": [
          "Registrar risco de raiva avaliado e decisão/protocolo consultado; documentar exame neurovascular e plano de retorno."
        ],
        "complications": [
          "Infecção polimicrobiana, tenossinovite, artrite séptica, sepse, raiva e tétano; encaminhar urgentemente nos cenários de risco."
        ],
        "aftercare": [
          "Orientar vigilância de sinais de infecção e reavaliação precoce conforme local/risco."
        ],
        "skills-checklist": [
          "Pergunta espécie/situação",
          "Examina mão/estrutura profunda",
          "Diferencia três profilaxias",
          "Não sutura automaticamente",
          "Registra encaminhamento."
        ],
        "media-references": [
          "Conduta antirrábica deve considerar protocolos epidemiológicos do país/região e comunicação às autoridades sanitárias.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-RABIES",
          "title": "CDC — Profilaxia da raiva após exposição",
          "url": "https://www.cdc.gov/rabies/hcp/clinical-care/post-exposure-prophylaxis.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-03",
      "topicIds": [
        "PT-M07-03"
      ],
      "title": "Sutura simples interrompida",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-SUT-003",
        "MAT-INS-003",
        "MAT-INS-004"
      ],
      "additionalSupplies": [
        "Tesoura de sutura, gaze, campos, materiais de irrigação, anestésico local se indicado, EPI e cobertura"
      ],
      "criticalErrors": [
        "Fechar lesão profunda não explorada",
        "Estrangular bordas",
        "Agulha descartada inadequadamente"
      ],
      "fields": {
        "definition": [
          "Técnica de aproximação cutânea com pontos separados, adequada a determinadas feridas após avaliação."
        ],
        "indications": [
          "Feridas com bordas aproximáveis sem tensão excessiva, após limpeza, inspeção e decisão fundamentada de fechamento."
        ],
        "contraindications": [
          "Não fechar sem avaliar ferida contaminada/infectada, perda tecidual, perfusão, corpo estranho e lesões profundas; considerar alternativas."
        ],
        "anatomy": [
          "Pele, derme, margens e estruturas profundas adjacentes; tensão e linhas de força locais."
        ],
        "materials": [
          "Porta-agulhas, pinça adequada, fio/agulha escolhidos por sítio e tensão, tesoura, anestesia e curativo."
        ],
        "environment": [
          "Boa iluminação, preparação de campo e descarte seguro de instrumentos perfurantes."
        ],
        "patient": [
          "Informar paciente, confirmar alergias, tétano, mecanismo, exame neurovascular/tendíneo e consentimento."
        ],
        "analgesia": [
          "Anestesia local conforme protocolo e dose segura individualizada; não usar dose universal."
        ],
        "sequence": [
          "Exame e hemostasia",
          "Analgesia, limpeza/irrigação e desbridamento quando apropriado",
          "Posicionar instrumentos em modelo",
          "Simular passagem simétrica da agulha respeitando tecidos",
          "Aproximar sem estrangulamento",
          "Verificar bordas e aplicar curativo."
        ],
        "confirmation": [
          "Coaptação adequada, sem isquemia, tensão excessiva, lacunas ou lesão funcional; documentação do material usado."
        ],
        "complications": [
          "Isquemia das bordas, infecção, deiscência, lesão por agulha, corpo estranho e cicatriz desfavorável; escalar quando necessário."
        ],
        "aftercare": [
          "Orientar cuidados, sinais de infecção, revisão e retirada de pontos conforme localização e evolução."
        ],
        "skills-checklist": [
          "Escolhe ferida apropriada",
          "Verifica estruturas",
          "Seleciona fio",
          "Evita tensão",
          "Mantém segurança de agulhas",
          "Orienta retorno."
        ],
        "media-references": [
          "Aula textual não certifica habilidade; manobras devem ser praticadas em simulador com instrutor.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-SUT",
          "title": "Merck Manual — Sutura simples interrompida (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-02",
      "topicIds": [
        "PT-M13-02"
      ],
      "title": "Tala antebraquiopalmar",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos;Crianças com técnica e vigilância específicas",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Material de tala apropriado, acolchoamento, bandagem, água conforme fabricante, tesoura e proteção da pele"
      ],
      "criticalErrors": [
        "Não examinar neurovascular distal",
        "Bandagem constritiva",
        "Ignorar dor crescente"
      ],
      "fields": {
        "definition": [
          "Imobilização não circunferencial de punho/antebraço para suporte temporário ou terapêutico em indicações selecionadas."
        ],
        "indications": [
          "Lesões traumáticas selecionadas enquanto se define diagnóstico e tratamento, ou imobilização pós-procedimento indicada."
        ],
        "contraindications": [
          "Não usar como substituto de avaliação urgente em suspeita de fratura exposta, isquemia, síndrome compartimental ou déficit neurológico."
        ],
        "anatomy": [
          "Destacar cotovelo, antebraço, punho, proeminências ósseas, dedos e avaliação distal neurovascular."
        ],
        "materials": [
          "Tala, acolchoamento, material de fixação e instruções de ativação/tempo de cura do fabricante."
        ],
        "environment": [
          "Preparar ambiente e material, prever edema e acesso para reavaliação."
        ],
        "patient": [
          "Identificar lado, dor, deformidade, integridade cutânea, pulso, perfusão, sensibilidade e movimento previamente."
        ],
        "analgesia": [
          "Analgesia apropriada à dor e eventual redução realizada apenas por profissional habilitado."
        ],
        "sequence": [
          "Avaliar antes da imobilização",
          "Proteger proeminências e pele",
          "Moldar tala conforme indicação e posicionamento seguro",
          "Fixar sem constrição circunferencial",
          "Avaliar perfusão/sensibilidade/motricidade novamente",
          "Explicar cuidados e alarme."
        ],
        "confirmation": [
          "Estabilidade e conforto relativos sem comprometimento de circulação, sensibilidade ou movimento dos dedos."
        ],
        "complications": [
          "Compressão, queimadura térmica durante endurecimento, maceração, neuropraxia, síndrome compartimental; remover/avaliar imediatamente sinais graves."
        ],
        "aftercare": [
          "Orientar elevação, proteção contra umidade conforme material, retorno e sinais de alarme."
        ],
        "skills-checklist": [
          "Examina NV antes/depois",
          "Protege proeminências",
          "Acomoda edema",
          "Molda adequadamente",
          "Informa sinais de urgência."
        ],
        "media-references": [
          "Posições específicas e espessura da tala devem ser definidas conforme lesão e protocolo local.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "AAOS-CAST",
          "title": "AAOS — Cuidados com talas e gessos",
          "url": "https://www.orthoinfo.org/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-10",
      "topicIds": [
        "PT-M13-10"
      ],
      "title": "Avaliação neurovascular antes e depois da imobilização",
      "priority": "P0",
      "level": "Básico",
      "scope": "Ortopedia e imobilização",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Boa iluminação, dispositivo de comparação bilateral, registro, oxímetro/temperatura se apropriado"
      ],
      "criticalErrors": [
        "Concluir que pulso normal exclui síndrome compartimental",
        "Deixar de repetir exame após imobilização"
      ],
      "fields": {
        "definition": [
          "Exame seriado de perfusão, sensibilidade e função motora distal em trauma e após aplicação de talas ou gesso."
        ],
        "indications": [
          "Toda imobilização de membros, suspeita de compressão ou dor/parestesia em membro traumatizado."
        ],
        "contraindications": [
          "Não postergar avaliação urgente por ausência de pulso palpável, isquemia ou suspeita de síndrome compartimental."
        ],
        "anatomy": [
          "Conhecer territórios nervosos, motricidade distal, pulsos periféricos e áreas de circulação relevantes."
        ],
        "materials": [
          "Lanterna/iluminação, relógio, registro e recursos adequados para avaliar perfusão."
        ],
        "environment": [
          "Garantir acesso ao segmento distal e referência de comparação contralateral."
        ],
        "patient": [
          "Explicar exame, avaliar dor, sensibilidade prévia, circulação e função antes de qualquer imobilização."
        ],
        "analgesia": [
          "Evitar estímulos dolorosos desnecessários; analgesia não deve atrasar avaliação de emergência."
        ],
        "sequence": [
          "Comparar perfusão e cor",
          "Verificar temperatura, enchimento capilar e pulsos quando pertinentes",
          "Testar sensibilidade e motricidade por territórios",
          "Registrar antes e após",
          "Repetir se dor, edema ou parestesia."
        ],
        "confirmation": [
          "Comparação bilateral e registro explícito de alterações; definir destino/urgência em caso de achados anormais."
        ],
        "complications": [
          "Déficit neurológico, compressão, isquemia, síndrome compartimental; sinal de alerta exige avaliação imediata."
        ],
        "aftercare": [
          "Instruir a buscar ajuda por dor progressiva, formigamento, perda de movimento e mudança de cor ou temperatura."
        ],
        "skills-checklist": [
          "Testa e documenta perfusão",
          "Documenta motricidade e sensibilidade",
          "Repete após tala",
          "Reconhece emergência."
        ],
        "media-references": [
          "Pulsos preservados não excluem síndrome compartimental.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "AAOS-CAST",
          "title": "AAOS — Cuidados com talas e gessos",
          "url": "https://www.orthoinfo.org/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M27-01",
      "topicIds": [
        "PT-M27-01"
      ],
      "title": "Glicemia capilar à beira-leito",
      "priority": "P0",
      "level": "Básico",
      "scope": "Diagnóstico à beira-leito",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Glicosímetro validado, tira compatível, lanceta de uso único, EPI e descarte de perfurocortantes"
      ],
      "criticalErrors": [
        "Lanceta reutilizada",
        "Glicosímetro compartilhado sem desinfecção",
        "Ignorar hipoglicemia clínica por leitura suspeita"
      ],
      "fields": {
        "definition": [
          "Determinação point-of-care de glicose com dispositivo adequado e controle de qualidade."
        ],
        "indications": [
          "Monitorização ou avaliação rápida quando resultado influencia decisão clínica."
        ],
        "contraindications": [
          "Resultados incompatíveis com quadro clínico ou contexto de má perfusão exigem confirmação laboratorial conforme protocolo."
        ],
        "anatomy": [
          "Polpa digital ou outro local validado pelo dispositivo e faixa etária; reconhecer limitações por perfusão."
        ],
        "materials": [
          "Lanceta descartável por paciente, tira dentro da validade, equipamento com QC e instrução de uso atual."
        ],
        "environment": [
          "Confirmar funcionamento, calibração/controle do aparelho, limpeza e descarte."
        ],
        "patient": [
          "Identificar paciente e indicar o teste; avaliar mãos, perfusão, substâncias na pele e contexto clínico."
        ],
        "analgesia": [
          "Puncionamento breve; medidas de conforto conforme idade e técnica."
        ],
        "sequence": [
          "Higienizar mãos",
          "Conferir tira e aparelho",
          "Preparar local sem contaminar amostra",
          "Coletar pelo dispositivo conforme IFU",
          "Descartar lanceta sem reencape",
          "Interpretar no contexto e registrar."
        ],
        "confirmation": [
          "Valor e horário documentados com identificação do equipamento; confirmar discrepâncias críticas."
        ],
        "complications": [
          "Falso resultado por contaminação, baixa perfusão, técnica incorreta; contaminação cruzada e acidente perfurocortante."
        ],
        "aftercare": [
          "Comunicar resultados críticos e tratar segundo protocolo clínico; higienizar equipamento entre pacientes."
        ],
        "skills-checklist": [
          "Usa lanceta única",
          "Verifica QC",
          "Identifica paciente",
          "Interpreta limitações",
          "Desinfeta equipamento."
        ],
        "media-references": [
          "Não utilizar valor isolado quando incompatível com estado clínico.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "CDC-GLU",
          "title": "CDC — Segurança na monitorização de glicemia",
          "url": "https://www.cdc.gov/injection-safety/hcp/infection-control/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-06",
      "topicIds": [
        "PT-M06-06"
      ],
      "title": "Classificação clínica e cirúrgica das feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Luvas, material de inspeção e registro clínico"
      ],
      "criticalErrors": [
        "Rotular mordedura automaticamente como ferida cirúrgica classe IV",
        "Indicar sutura com base apenas na classe"
      ],
      "fields": {
        "definition": [
          "Organização da avaliação de feridas traumáticas, cirúrgicas ou crônicas sem confundir sistemas classificatórios distintos."
        ],
        "indications": [
          "Toda caracterização de ferida para documentação, risco de infecção e escolha do cuidado."
        ],
        "contraindications": [
          "Classificação isolada não justifica fechamento ou antibiótico e não substitui exame clínico."
        ],
        "anatomy": [
          "Reconhecer local, tecidos, profundidade, comunicação com cavidades e estruturas lesadas."
        ],
        "materials": [
          "Instrumentos de mensuração e registro padronizado; não é necessária escala Gauge/French."
        ],
        "environment": [
          "Garantir iluminação, privacidade e barreiras de proteção."
        ],
        "patient": [
          "Investigar mecanismo, tempo, presença de sujidade, perfusão, sinais de infecção e comorbidades."
        ],
        "analgesia": [
          "Analgesia individualizada quando exame é doloroso."
        ],
        "sequence": [
          "Caracterizar ferida por etiologia e profundidade",
          "Diferenciar lesão traumática de classificação de ferida operatória",
          "Quando pertinente, distinguir I limpa, II limpa-contaminada, III contaminada e IV suja/infectada",
          "Registrar justificativa e conduta clínica."
        ],
        "confirmation": [
          "Documentar classificação usada e critérios objetivos, sem misturar classificações cirúrgica, traumática e de risco de tétano."
        ],
        "complications": [
          "Subestimar contaminação, corpo estranho e comprometimento vascular pode causar fechamento inadequado; reavaliar risco."
        ],
        "aftercare": [
          "Planejar reavaliação, prevenção de infecção e cuidados conforme etiologia."
        ],
        "skills-checklist": [
          "Distingue três sistemas classificatórios",
          "Reconhece ferida infectada",
          "Avalia mecanismo e profundidade",
          "Justifica conduta."
        ],
        "media-references": [
          "Revisar definições de classes operatórias com protocolo institucional e vigilância de infecção.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "NHSN-WOUND",
          "title": "CDC/NHSN — Classificação de feridas operatórias",
          "url": "https://www.cdc.gov/nhsn/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-11",
      "topicIds": [
        "PT-M07-11"
      ],
      "title": "Retirada de pontos e grampos cutâneos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Suturas e fechamento",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-007"
      ],
      "additionalSupplies": [
        "Removedor apropriado de grampos, pinça e tesoura esterilizados quando indicados, EPI, gaze, solução de limpeza, fita de suporte da ferida"
      ],
      "criticalErrors": [
        "Remover pontos apesar de deiscência progressiva",
        "Deixar fragmento de fio sem documentação"
      ],
      "fields": {
        "definition": [
          "Remoção controlada de dispositivos de fechamento após avaliação de reparação tecidual e risco de deiscência."
        ],
        "indications": [
          "Feridas cicatrizadas suficientemente após período e localização adequados, com indicação profissional."
        ],
        "contraindications": [
          "Não retirar indiscriminadamente diante de deiscência, sinais graves de infecção, isquemia ou tensão não resolvida."
        ],
        "anatomy": [
          "Avaliar bordas da epiderme, profundidade, articulações, localização facial ou de membros e zonas de tensão."
        ],
        "materials": [
          "Tesoura apropriada, pinça, removedor de grampos, gaze e material de suporte se indicado."
        ],
        "environment": [
          "Boa iluminação, higiene das mãos, descarte de materiais contaminados e plano para abertura inesperada da ferida."
        ],
        "patient": [
          "Conferir data, tipo de fechamento, antecedentes de infecção, diabetes/imunossupressão e aspecto atual."
        ],
        "analgesia": [
          "Explicar desconforto possível; analgesia frequentemente não é necessária, mas individualizar."
        ],
        "sequence": [
          "Examinar coaptação e sinais de infecção",
          "Higienizar mãos e preparar material",
          "Realizar remoção segundo tipo de fechamento e treinamento",
          "Reavaliar imediatamente bordas",
          "Aplicar suporte ou interromper remoção quando abertura ameaçar."
        ],
        "confirmation": [
          "Bordas íntegras sem abertura ou sangramento relevante; documentar quantidade retirada e retenções suspeitas."
        ],
        "complications": [
          "Deiscência, sangramento, fragmentos de fio, infecção e lesão cutânea; interromper e buscar avaliação."
        ],
        "aftercare": [
          "Proteger a região conforme necessidade e orientar sinais de alerta e retorno."
        ],
        "skills-checklist": [
          "Avalia tensão e cicatrização",
          "Seleciona instrumento adequado",
          "Confere integridade após remoção",
          "Documenta."
        ],
        "media-references": [
          "Tempo de retirada depende do local e evolução; evitar calendário universal sem avaliação.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-SUT",
          "title": "Merck Manual — Sutura simples interrompida (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M27-02",
      "topicIds": [
        "PT-M27-02"
      ],
      "title": "Eletrocardiograma de 12 derivações à beira-leito",
      "priority": "P0",
      "level": "Básico",
      "scope": "Diagnóstico à beira-leito",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Eletrocardiógrafo de 12 derivações, eletrodos compatíveis, condutor quando apropriado, papel/registro digital e material para preparo da pele"
      ],
      "criticalErrors": [
        "Troca de identificação do paciente",
        "Ignorar suspeita de evento cardíaco agudo durante preparação"
      ],
      "fields": {
        "definition": [
          "Registro não invasivo da atividade elétrica cardíaca com posicionamento padronizado de eletrodos e identificação adequada."
        ],
        "indications": [
          "Investigação de sintomas cardíacos, arritmias, monitoramento e situações agudas conforme avaliação clínica."
        ],
        "contraindications": [
          "Não postergar atendimento urgente para aguardar ECG; artefatos e posicionamento inadequado exigem repetição."
        ],
        "anatomy": [
          "Identificar referências anatômicas para V1-V6 e membros; reconhecer diferenças em condições especiais."
        ],
        "materials": [
          "Eletrodos, cabos, equipamento calibrado e papel/registros; conferir integridade e limpeza do sistema."
        ],
        "environment": [
          "Preparar superfície, controle de interferências, isolamento elétrico e privacidade."
        ],
        "patient": [
          "Confirmar identidade, explicar procedimento e obter posição tolerável, expondo apenas áreas necessárias."
        ],
        "analgesia": [
          "Indolor; analgesia não é necessária, exceto manejo de dor do quadro clínico concomitante."
        ],
        "sequence": [
          "Conferir identificação e qualidade do equipamento",
          "Preparar pele",
          "Localizar pontos anatômicos e posicionar eletrodos segundo padrão de 12 derivações",
          "Solicitar imobilidade breve",
          "Registrar e conferir calibração/artefatos."
        ],
        "confirmation": [
          "Obtém traçado legível, com nome e data corretos, 12 derivações, velocidade e amplitude registradas."
        ],
        "complications": [
          "Inversão de cabos, derivações precordiais mal posicionadas, artefatos, interpretação precipitada; repetir traçado quando necessário."
        ],
        "aftercare": [
          "Encaminhar interpretação ao profissional responsável e comunicar imediatamente resultados críticos conforme fluxo local."
        ],
        "skills-checklist": [
          "Posiciona eletrodos pelo marco anatômico",
          "Confere qualidade e dados",
          "Reconhece artefatos",
          "Comunica urgência."
        ],
        "media-references": [
          "Esta ficha cobre aquisição técnica, não interpretação cardiológica completa.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "ECG-CHSS",
          "title": "CHSS eLearning — ECG de 12 derivações e posicionamento",
          "url": "https://www.chsselearning.org.uk/hearte/9-cardiac-investigations/electrocardiography/12-lead-ecg/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-03",
      "topicIds": [
        "PT-M04-03"
      ],
      "title": "Administração intradérmica de medicamentos e testes",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Seringa graduada de precisão, agulha apropriada, antisséptico e descarte imediato.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Produto usado na rota errada",
        "Leitura fora do intervalo indicado"
      ],
      "fields": {
        "definition": [
          "Administração superficial na derme para indicações autorizadas; não confundir com rotas intramuscular ou subcutânea."
        ],
        "indications": [
          "Testes e produtos expressamente indicados para via intradérmica, segundo bula e protocolo."
        ],
        "contraindications": [
          "Não aplicar produto cuja via seja diferente; avaliar dermatose no sítio e histórico de hipersensibilidade."
        ],
        "anatomy": [
          "Derme superficial; local depende da finalidade, com atenção à integridade da pele."
        ],
        "materials": [
          "Seringa graduada de precisão, agulha apropriada, antisséptico e descarte imediato. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Conferir paciente, produto, concentração e finalidade",
          "Selecionar e inspecionar área sem lesão",
          "Executar simulação de posicionamento e técnica segundo protocolo validado",
          "Identificar e registrar local, lote e reação observada"
        ],
        "confirmation": [
          "Registro de administração e leitura do resultado na janela definida pelo teste, quando pertinente."
        ],
        "complications": [
          "Reação local, aplicação em plano incorreto, erro de interpretação e reação sistêmica."
        ],
        "aftercare": [
          "Instruir sobre retorno para leitura e sinais de reação; não manipular a lesão de teste."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-VAC",
          "title": "CDC — Vaccine administration, route and sterile technique",
          "url": "https://www.cdc.gov/vaccines/hcp/imz-best-practices/vaccine-administration.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-04",
      "topicIds": [
        "PT-M04-04"
      ],
      "title": "Administração subcutânea",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Seringa/agulha ou dispositivo de aplicação apropriados, antisséptico e recipiente de descarte.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Reutilizar seringa ou agulha",
        "Administrar via SC uma formulação não aprovada"
      ],
      "fields": {
        "definition": [
          "Administração no tecido adiposo subcutâneo quando formulação e prescrição permitem."
        ],
        "indications": [
          "Medicamentos aprovados para SC, com plano de rodízio quando uso repetido."
        ],
        "contraindications": [
          "Não usar em pele infectada, área com lipodistrofia importante ou formulação não autorizada."
        ],
        "anatomy": [
          "Tecido entre a derme e o músculo; espessura variável por idade e biotipo."
        ],
        "materials": [
          "Seringa/agulha ou dispositivo de aplicação apropriados, antisséptico e recipiente de descarte. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Confirmar medicamento, dispositivo e via prescrita",
          "Avaliar e selecionar área adequada, considerando rodízio",
          "Simular técnica asséptica de aplicação e descarte de uso único",
          "Registrar sítio, horário e reações"
        ],
        "confirmation": [
          "Confirmação de dose e via com registro; monitorar resposta esperada para o fármaco."
        ],
        "complications": [
          "Hipoglicemia quando aplicável, hematoma, lipodistrofia, reação local e dose incorreta."
        ],
        "aftercare": [
          "Orientar rodízio de locais, vigilância para reação e descarte doméstico seguro quando pertinente."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-VAC",
          "title": "CDC — Vaccine administration, route and sterile technique",
          "url": "https://www.cdc.gov/vaccines/hcp/imz-best-practices/vaccine-administration.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-06",
      "topicIds": [
        "PT-M04-06"
      ],
      "title": "Administração intravenosa de medicamentos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-001",
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Cateter funcional, conector, extensão, seringas de uso único e diluente validado pela bula.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Infundir com acesso infiltrado",
        "Confundir IV push com infusão lenta indicada"
      ],
      "fields": {
        "definition": [
          "Introdução de medicamento prescrito pela via intravenosa, usando acesso comprovadamente funcionante e compatível."
        ],
        "indications": [
          "Quando o tratamento exigir efeito IV e a apresentação permitir essa via."
        ],
        "contraindications": [
          "Acesso com suspeita de extravasamento, incompatibilidade, indicação ou concentração não verificada."
        ],
        "anatomy": [
          "Anatomia vascular e posição do cateter, relação com pele, tecidos adjacentes e dispositivo."
        ],
        "materials": [
          "Cateter funcional, conector, extensão, seringas de uso único e diluente validado pela bula. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Conferir prescrição, alergias e identificação do acesso",
          "Verificar compatibilidade, necessidade de diluição e velocidade conforme protocolo",
          "Inspecionar local e permeabilidade, mantendo assepsia de conectores",
          "Simular administração/monitorização e documentar resposta"
        ],
        "confirmation": [
          "Sem sinais de infiltração; confirmação documentada de via, dose e velocidade autorizadas."
        ],
        "complications": [
          "Flebite, extravasamento, reação anafilática, infusão rápida, embolia ou incompatibilidade."
        ],
        "aftercare": [
          "Monitorar local e efeitos; interromper e acionar protocolo se houver reação ou extravasamento."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-07",
      "topicIds": [
        "PT-M04-07"
      ],
      "title": "Infusão intermitente e contínua",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-INF-003"
      ],
      "additionalSupplies": [
        "Equipo identificado, solução prescrita, bomba quando indicada, extensor e conectores compatíveis.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Bomba sem verificação",
        "Conexões incompatíveis ou via não conferida"
      ],
      "fields": {
        "definition": [
          "Entrega controlada de soluções ou fármacos IV por gravidade ou dispositivo apropriado."
        ],
        "indications": [
          "Fluidoterapia e terapias IV em regimes intermitente ou contínuo conforme prescrição."
        ],
        "contraindications": [
          "Produto, compatibilidade, acesso ou velocidade ainda não checados; restrições de volume individual."
        ],
        "anatomy": [
          "Sistema de infusão, acesso vascular e vulnerabilidade a extravasamento."
        ],
        "materials": [
          "Equipo identificado, solução prescrita, bomba quando indicada, extensor e conectores compatíveis. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Confirmar solução, paciente, acesso e regime",
          "Planejar início e término conforme prescrição",
          "Conferir compatibilidades e programação independente em alto risco",
          "Reavaliar sinais vitais, sítio e alarmes, registrando volumes"
        ],
        "confirmation": [
          "Balanço de entrada compatível com prescrição e monitorização de acesso e resposta clínica."
        ],
        "complications": [
          "Sobrecarga hídrica, subinfusão, bolus inadvertido, infecção e oclusão."
        ],
        "aftercare": [
          "Registrar volume, intercorrências, troca de sistema e decisão de suspensão."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-08",
      "topicIds": [
        "PT-M04-08"
      ],
      "title": "Reconstituição e diluição de medicamentos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-003"
      ],
      "additionalSupplies": [
        "Frasco, diluente indicado, dispositivos estéreis, rotulagem e referência farmacotécnica.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Confundir mg com mL",
        "Usar diluente não aprovado"
      ],
      "fields": {
        "definition": [
          "Preparação asséptica da forma farmacêutica e da concentração prescrita."
        ],
        "indications": [
          "Produtos que exigem diluente e concentração finais definidos em bula ou prescrição validada."
        ],
        "contraindications": [
          "Não improvisar diluente ou misturar soluções de compatibilidade desconhecida."
        ],
        "anatomy": [
          "Área limpa de preparo e dispositivos estéreis; não corresponde a um sítio anatômico."
        ],
        "materials": [
          "Frasco, diluente indicado, dispositivos estéreis, rotulagem e referência farmacotécnica. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Ler rótulo e instrução do fabricante, conferindo unidades",
          "Confirmar estabilidade, diluente e concentração-alvo",
          "Simular cálculo com dupla checagem e rotular concentração/horário",
          "Manter assepsia e descarte conforme condições de uso"
        ],
        "confirmation": [
          "Concentração, lote, validade e diluente documentados de forma verificável."
        ],
        "complications": [
          "Erro de dez vezes, incompatibilidade, contaminação, perda de estabilidade e sobredosagem."
        ],
        "aftercare": [
          "Não conservar fora das condições recomendadas; rastrear preparo e administração."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-09",
      "topicIds": [
        "PT-M04-09"
      ],
      "title": "Bombas de infusão: programação e alarmes",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-INF-003"
      ],
      "additionalSupplies": [
        "Bomba, equipo específico do modelo, etiquetas e solução prescrita.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar alarme",
        "Trocar equipamento sem conferir a taxa"
      ],
      "fields": {
        "definition": [
          "Controle programável de taxa, volume e duração em sistemas de infusão compatíveis."
        ],
        "indications": [
          "Fármacos e soluções cuja precisão exige bomba conforme protocolo."
        ],
        "contraindications": [
          "Sem confirmação da prescrição, do equipo compatível ou calibração/dispositivo funcional."
        ],
        "anatomy": [
          "Circuito infusional, conectores, acesso e medidas de pressão do equipamento."
        ],
        "materials": [
          "Bomba, equipo específico do modelo, etiquetas e solução prescrita. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Identificar paciente, solução e biblioteca de drogas da bomba",
          "Conferir unidades, volume, taxa e limites com dupla checagem quando exigida",
          "Simular montagem e teste de alarmes sem uso em paciente",
          "Documentar parâmetros e plano para interrupção de energia"
        ],
        "confirmation": [
          "Parâmetros condizentes com prescrição; alarmes e verificação de sistema registrados."
        ],
        "complications": [
          "Oclusão, ar, taxa incorreta, interrupção súbita e atraso no reconhecimento de extravasamento."
        ],
        "aftercare": [
          "Responder a alarmes pelo manual do equipamento; registrar trocas e rastreabilidade."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-10",
      "topicIds": [
        "PT-M04-10"
      ],
      "title": "Barreiras para medicamentos de alta vigilância",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-INF-003"
      ],
      "additionalSupplies": [
        "Rótulos padronizados, prescrição, bomba quando indicada e barreiras de dupla verificação.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar dupla checagem obrigatória",
        "Uso de abreviação ambígua de dose"
      ],
      "fields": {
        "definition": [
          "Conjunto de controles para medicamentos com dano potencial elevado em caso de erro."
        ],
        "indications": [
          "Insulina, anticoagulantes, eletrólitos concentrados e outros definidos pela lista institucional."
        ],
        "contraindications": [
          "Nunca administrar sem prescrição verificável, concentração rastreável e condições de monitorização."
        ],
        "anatomy": [
          "Vias e dispositivos diferem por produto; risco amplificado por dose/concentração."
        ],
        "materials": [
          "Rótulos padronizados, prescrição, bomba quando indicada e barreiras de dupla verificação. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Identificar fármaco de alto risco e aplicar protocolo específico",
          "Conferir dose, unidade, concentração, diluente, via, paciente e peso quando indicado",
          "Executar checagem independente real, sem mera assinatura",
          "Planejar monitorização laboratorial/clínica e reversão quando aplicável"
        ],
        "confirmation": [
          "Barreiras cumpridas, campos documentados e monitorização planejada antes do início."
        ],
        "complications": [
          "Erro grave de dose, hipoglicemia, sangramento e distúrbios eletrolíticos."
        ],
        "aftercare": [
          "Reconciliar medicamentos, reportar quase-erros e rever parâmetros ao transferir o paciente."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M05-03",
      "topicIds": [
        "PT-M05-03"
      ],
      "title": "Coleta para hemocultura",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Acessos vasculares",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-001",
        "MAT-VAS-002",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Conjunto de frascos conforme sistema laboratorial, antisséptico, material de venopunção e identificação.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Coletar após tocar novamente área antisséptica sem medida apropriada",
        "Frascos identificados incorretamente"
      ],
      "fields": {
        "definition": [
          "Coleta asséptica de sangue para detecção de microrganismos em suspeita de infecção de corrente sanguínea."
        ],
        "indications": [
          "Suspeita clínica de bacteremia ou sepse de acordo com avaliação e protocolo."
        ],
        "contraindications": [
          "Coleta sem identificação, frascos não adequados, volume ou momento não planejados."
        ],
        "anatomy": [
          "Veias periféricas e contaminação potencial por flora da pele ou conectores."
        ],
        "materials": [
          "Conjunto de frascos conforme sistema laboratorial, antisséptico, material de venopunção e identificação. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Confirmar indicação, dois identificadores e quantidade de conjuntos",
          "Realizar antissepsia da pele e septos dos frascos conforme orientação",
          "Planejar coleta preferencial antes de antibiótico se não atrasar tratamento essencial",
          "Registrar volumes, horários, locais e responsável por cada conjunto"
        ],
        "confirmation": [
          "Conjuntos corretamente identificados, volume aferido e transporte ao laboratório sem atraso indevido."
        ],
        "complications": [
          "Contaminação por flora cutânea, falso negativo por baixo volume e atraso terapêutico."
        ],
        "aftercare": [
          "Comunicar dificuldade de coleta e resultados críticos segundo fluxos assistenciais."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-BLOOD",
          "title": "CDC — Collect adult blood culture sets, 2026",
          "url": "https://www.cdc.gov/lab-quality/php/preventing-adult-blood-culture-contamination/collect.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-02",
      "topicIds": [
        "PT-M06-02"
      ],
      "title": "Hemostasia inicial de feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Gaze apropriada, compressas, luvas, material de curativo e recursos de escalonamento.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Atrasar emergência diante de instabilidade",
        "Ignorar déficit neurovascular"
      ],
      "fields": {
        "definition": [
          "Controle imediato de sangramento externo e identificação de hemorragia potencialmente grave."
        ],
        "indications": [
          "Sangramento por lesão tecidual, enquanto se avalia mecanismo e estabilidade."
        ],
        "contraindications": [
          "Não insistir em tratamento local isolado frente a instabilidade ou hemorragia não controlada."
        ],
        "anatomy": [
          "Vasos superficiais/profundos; proximidade de tendões, nervos e articulações."
        ],
        "materials": [
          "Gaze apropriada, compressas, luvas, material de curativo e recursos de escalonamento. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar segurança da cena, prioridades ABC e gravidade do sangramento",
          "Simular compressão direta contínua sem interrupções desnecessárias",
          "Reavaliar perfusão distal e solicitar ajuda urgente em sangramento importante",
          "Registrar localização, características e resposta"
        ],
        "confirmation": [
          "Redução/controle do sangramento com perfusão e avaliação clínica preservadas."
        ],
        "complications": [
          "Choque hemorrágico, hematoma, isquemia e lesão não identificada."
        ],
        "aftercare": [
          "Reavaliar curativo e sinais vitais; encaminhar sangramento refratário."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-WOUND25",
          "title": "AAFP — Laceration repair best practices, 2025",
          "url": "https://www.aafp.org/afp/afp-community-blog/laceration-repair-best-practices",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-04",
      "topicIds": [
        "PT-M06-04"
      ],
      "title": "Limpeza e remoção de contaminantes de feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-004",
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Solução adequada para irrigação, gaze, pinça apropriada e barreiras.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Suturar antes de explorar contaminantes",
        "Manipular corpo estranho profundo sem avaliação"
      ],
      "fields": {
        "definition": [
          "Remoção de sujeira e partículas acessíveis após avaliação de estruturas e riscos."
        ],
        "indications": [
          "Feridas com contaminantes ou corpos estranhos superficiais após estabilização."
        ],
        "contraindications": [
          "Não explorar profundamente sem condições ou treinamento; suspeita de corpo estranho profundo exige investigação."
        ],
        "anatomy": [
          "Camadas cutâneas e estruturas subjacentes vulneráveis."
        ],
        "materials": [
          "Solução adequada para irrigação, gaze, pinça apropriada e barreiras. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Identificar mecanismo, extensão, corpo estranho e estruturas em risco",
          "Selecionar irrigação compatível e controlar dor",
          "Remover contaminantes visíveis sem agressão desnecessária, com supervisão",
          "Reavaliar necessidade de imagem, desbridamento ou encaminhamento"
        ],
        "confirmation": [
          "Ferida avaliada quanto a partículas residuais e integridade estrutural antes do fechamento."
        ],
        "complications": [
          "Retenção de fragmentos, infecção, trauma adicional por exploração e atraso diagnóstico."
        ],
        "aftercare": [
          "Registrar material removido, orientação de retorno e sinais de alarme."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-WOUND25",
          "title": "AAFP — Laceration repair best practices, 2025",
          "url": "https://www.aafp.org/afp/afp-community-blog/laceration-repair-best-practices",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-08",
      "topicIds": [
        "PT-M06-08"
      ],
      "title": "Reconhecimento de infecção em feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Material de exame e curativo; coleta de amostra apenas quando clinicamente indicada.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar dor desproporcional",
        "Tratar sepse apenas com curativo"
      ],
      "fields": {
        "definition": [
          "Avaliação clínica de possível infecção local, disseminada ou complicação de cicatrização."
        ],
        "indications": [
          "Dor progressiva, eritema crescente, calor, secreção, febre ou atraso de cicatrização."
        ],
        "contraindications": [
          "Não assumir que toda secreção ou eritema equivale a infecção; diferenciais precisam de avaliação."
        ],
        "anatomy": [
          "Pele e tecidos profundos, drenagem linfática e sinais de extensão."
        ],
        "materials": [
          "Material de exame e curativo; coleta de amostra apenas quando clinicamente indicada. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Comparar evolução temporal, sinais locais e sistêmicos",
          "Verificar presença de flutuação, necrose, crepitação ou dor desproporcional",
          "Avaliar gravidade e necessidade de investigação/encaminhamento",
          "Documentar achados e plano de reavaliação"
        ],
        "confirmation": [
          "Estratificação de gravidade com plano de conduta e retorno definido."
        ],
        "complications": [
          "Abscesso não drenado, sepse, fasciíte necrosante e atraso terapêutico."
        ],
        "aftercare": [
          "Orientar retorno imediato em deterioração rápida, febre importante ou sinais sistêmicos."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND25",
          "title": "AAFP — Laceration repair best practices, 2025",
          "url": "https://www.aafp.org/afp/afp-community-blog/laceration-repair-best-practices",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-10",
      "topicIds": [
        "PT-M06-10"
      ],
      "title": "Cuidados posteriores de feridas e retorno",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001"
      ],
      "additionalSupplies": [
        "Cobertura adequada, material de higiene e orientações documentadas.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Não informar sinais de alarme",
        "Omitir seguimento em ferida de alto risco"
      ],
      "fields": {
        "definition": [
          "Seguimento de cicatrização, orientações e vigilância de complicações de feridas."
        ],
        "indications": [
          "Após limpeza, fechamento, curativo, desbridamento ou decisão de cicatrização secundária."
        ],
        "contraindications": [
          "Orientações genéricas sem considerar tipo de fechamento, comorbidades e exposição."
        ],
        "anatomy": [
          "Fases de cicatrização, perfusão local e tensão sobre os tecidos."
        ],
        "materials": [
          "Cobertura adequada, material de higiene e orientações documentadas. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Registrar tipo e localização da lesão e intervenção",
          "Orientar higiene, proteção, trocas de curativo e controle de dor individualizados",
          "Definir retorno e retirada de suturas conforme região e evolução",
          "Informar sinais de infecção, deiscência e quando buscar urgência"
        ],
        "confirmation": [
          "Paciente compreende cuidados, sinais de alarme e plano de acompanhamento."
        ],
        "complications": [
          "Infecção, maceração, deiscência e cicatriz hipertrófica."
        ],
        "aftercare": [
          "Reavaliar comorbidades e risco de tétano conforme classificação da ferida."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-TETANUS",
          "title": "CDC — Clinical guidance for wound management to prevent tetanus",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-04",
      "topicIds": [
        "PT-M07-04"
      ],
      "title": "Sutura contínua",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-INS-003",
        "MAT-INS-004"
      ],
      "additionalSupplies": [
        "Porta-agulhas, pinça, tesoura e fio/agulha adequados ao tecido.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Tracionar até isquemia da borda",
        "Fechar ferida contaminada sem avaliação"
      ],
      "fields": {
        "definition": [
          "Fechamento sequencial com fio contínuo, selecionado conforme tecido e tensão."
        ],
        "indications": [
          "Feridas adequadas à aproximação contínua após irrigação, inspeção e hemostasia."
        ],
        "contraindications": [
          "Contaminação relevante, tensão excessiva ou necessidade de drenagem podem tornar inadequada."
        ],
        "anatomy": [
          "Derme, bordas, eversão e linhas de tensão local."
        ],
        "materials": [
          "Porta-agulhas, pinça, tesoura e fio/agulha adequados ao tecido. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar ferida, necessidade de fechamento e analgesia",
          "Demonstrar em simulador início, espaçamento regular e término da linha",
          "Observar eversão, perfusão das bordas e ausência de estrangulamento",
          "Registrar tipo de sutura e plano de retirada"
        ],
        "confirmation": [
          "Bordas alinhadas, perfundidas, sem espaço morto ou tensão excessiva."
        ],
        "complications": [
          "Deiscência de toda a linha, necrose por tensão e marca de sutura."
        ],
        "aftercare": [
          "Cuidados locais, retorno por infecção/deiscência e cronograma de retirada."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-05",
      "topicIds": [
        "PT-M07-05"
      ],
      "title": "Sutura colchoeiro vertical",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Porta-agulhas, pinça, fios adequados e simulador de sutura.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Apertar excessivamente",
        "Ignorar isquemia do retalho"
      ],
      "fields": {
        "definition": [
          "Técnica de eversão de bordas, com passagens em profundidades distintas."
        ],
        "indications": [
          "Feridas selecionadas em que a eversão ou o controle de tensão é necessário."
        ],
        "contraindications": [
          "Risco de isquemia por compressão ou tecido friável; não substitui fechamento por planos quando preciso."
        ],
        "anatomy": [
          "Planos dérmico superficial/profundo; avaliar vascularização marginal."
        ],
        "materials": [
          "Porta-agulhas, pinça, fios adequados e simulador de sutura. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Inspecionar tensão, profundidade e viabilidade das bordas",
          "Demonstrar trajetos em simulador, distinguindo pontos superficial e profundo",
          "Aproximar sem estrangular a pele",
          "Reavaliar eversão, alinhamento e perfusão"
        ],
        "confirmation": [
          "Eversão suave e ausência de palidez persistente ou pregueamento importante."
        ],
        "complications": [
          "Necrose marginal, cicatriz em trilho e dor por tensão."
        ],
        "aftercare": [
          "Acompanhar bordas e tempo de retirada adaptado à localização."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-06",
      "topicIds": [
        "PT-M07-06"
      ],
      "title": "Sutura colchoeiro horizontal",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Fio e agulha adequados, pinça e porta-agulhas.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Estrangular margens",
        "Ignorar edema progressivo"
      ],
      "fields": {
        "definition": [
          "Ponto de aproximação e distribuição de tensão em segmentos de borda."
        ],
        "indications": [
          "Feridas em regiões selecionadas com necessidade de eversão/distribuição de tensão."
        ],
        "contraindications": [
          "Tecido vascularmente comprometido, risco de estrangulamento ou bordas muito delicadas."
        ],
        "anatomy": [
          "Perfusão marginal cutânea e relação do ponto com a borda da lesão."
        ],
        "materials": [
          "Fio e agulha adequados, pinça e porta-agulhas. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Examinar perfusão e necessidade de fechamento profundo",
          "Demonstrar configuração horizontal sobre manequim",
          "Manter aproximação com tensão mínima efetiva",
          "Reavaliar cor das bordas e registrar técnica"
        ],
        "confirmation": [
          "Aproximação simétrica, sem isquemia de bordas."
        ],
        "complications": [
          "Necrose por compressão, cicatriz excessiva e deiscência."
        ],
        "aftercare": [
          "Inspecionar pele e promover retirada no período clinicamente apropriado."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-07",
      "topicIds": [
        "PT-M07-07"
      ],
      "title": "Sutura intradérmica contínua",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-002",
        "MAT-SUT-001",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Fio absorvível ou não absorvível apropriado e porta-agulhas.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Fechar espaço morto importante só com intradérmica",
        "Aplicar em ferida infectada sem avaliação"
      ],
      "fields": {
        "definition": [
          "Aproximação cutânea por trajeto dérmico, geralmente para feridas limpas de baixa tensão."
        ],
        "indications": [
          "Incisões e feridas selecionadas com bordas bem alinhadas e tensão controlada."
        ],
        "contraindications": [
          "Ferida infectada, grande tensão ou necessidade de drenagem podem contraindicar fechamento fechado."
        ],
        "anatomy": [
          "Derme e planos de tensão; considerar necessidade de pontos profundos."
        ],
        "materials": [
          "Fio absorvível ou não absorvível apropriado e porta-agulhas. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar contaminação, hemostasia e alinhamento",
          "Simular passagem intradérmica mantendo plano regular",
          "Examinar se o fechamento é estável sem tensão excessiva",
          "Planejar cobertura e seguimento"
        ],
        "confirmation": [
          "Bordas aproximadas sem depressões ou tensão indevida."
        ],
        "complications": [
          "Deiscência, infecção retida e extrusão de fio."
        ],
        "aftercare": [
          "Monitorar ferida e informar uso de fio absorvível ou necessidade de remoção."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-08",
      "topicIds": [
        "PT-M07-08"
      ],
      "title": "Fechamento dérmico profundo",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-002",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Fio absorvível, porta-agulhas e instrumental adequado.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Suturar estrutura não identificada",
        "Fechar tecido desvitalizado"
      ],
      "fields": {
        "definition": [
          "Aproximação dos planos profundos para reduzir tensão superficial e espaço morto."
        ],
        "indications": [
          "Lacerações selecionadas com necessidade de reparo por camadas, após exclusão de lesão estrutural."
        ],
        "contraindications": [
          "Não utilizar para esconder infecção, tecido desvitalizado ou lesão de tendão/nervo não tratada."
        ],
        "anatomy": [
          "Derme profunda e tecido subcutâneo, sem invadir estruturas vasculonervosas."
        ],
        "materials": [
          "Fio absorvível, porta-agulhas e instrumental adequado. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Inspecionar anatomia e necessidade real do plano profundo",
          "Simular aproximação por camadas evitando incorporação de estruturas indevidas",
          "Confirmar redução de espaço morto e tensão superficial",
          "Documentar material implantado e planos fechados"
        ],
        "confirmation": [
          "Redução do espaço morto sem comprometimento da perfusão."
        ],
        "complications": [
          "Hematoma, corpo estranho, infecção profunda e lesão estrutural."
        ],
        "aftercare": [
          "Acompanhar sinais de infecção profunda e deiscência."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-09",
      "topicIds": [
        "PT-M07-09"
      ],
      "title": "Adesivos cutâneos e fitas de aproximação",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-003"
      ],
      "additionalSupplies": [
        "Adesivo médico apropriado ou fitas estéreis, barreiras e limpeza.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Colocar adesivo dentro da ferida",
        "Usar em ferida de alta tensão sem suporte"
      ],
      "fields": {
        "definition": [
          "Fechamento externo sem sutura em feridas superficiais selecionadas e de baixa tensão."
        ],
        "indications": [
          "Feridas lineares pequenas, limpas e de bordas facilmente aproximáveis."
        ],
        "contraindications": [
          "Feridas úmidas, infectadas, sob tensão significativa, em mucosas ou próximas aos olhos sem técnica específica."
        ],
        "anatomy": [
          "Epiderme e derme superficial; evitar que adesivo penetre no leito da ferida."
        ],
        "materials": [
          "Adesivo médico apropriado ou fitas estéreis, barreiras e limpeza. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar indicação, tensão e contaminação",
          "Limpar e secar bordas conforme o produto",
          "Simular aproximação mantendo adesivo apenas externamente",
          "Orientar tempo de desprendimento e cuidados locais"
        ],
        "confirmation": [
          "Bordas mantidas alinhadas, sem contato inadequado com olhos ou mucosas."
        ],
        "complications": [
          "Dermatite, deiscência e união incorreta de tecidos."
        ],
        "aftercare": [
          "Não remover agressivamente o filme; reavaliar abertura ou sinais de infecção."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-10",
      "topicIds": [
        "PT-M07-10"
      ],
      "title": "Grampos cutâneos",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Grampeador médico, removedor apropriado, pinça e material de antissepsia.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Aplicar sobre estrutura não avaliada",
        "Omitir registro/contagem de grampos"
      ],
      "fields": {
        "definition": [
          "Fechamento mecânico superficial de incisões ou feridas selecionadas."
        ],
        "indications": [
          "Incisões lineares, frequentemente couro cabeludo/tronco, de acordo com a indicação."
        ],
        "contraindications": [
          "Evitar em localização de exigência estética alta e sem hemostasia/avaliação das estruturas."
        ],
        "anatomy": [
          "Pele e tensão local; grampos não corrigem lesões profundas."
        ],
        "materials": [
          "Grampeador médico, removedor apropriado, pinça e material de antissepsia. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Reavaliar ferida, hemostasia e elegibilidade do fechamento",
          "Simular alinhamento cutâneo e aplicação com espaçamento regular",
          "Conferir eversão e alinhamento sem compressão excessiva",
          "Contar/documentar grampos e retirada programada"
        ],
        "confirmation": [
          "Aproximação estável das margens com perfusão preservada."
        ],
        "complications": [
          "Dor, infecção, marcas e retenção de grampo."
        ],
        "aftercare": [
          "Planejar remoção conforme localização e cicatrização; orientar inspeção."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-03",
      "topicIds": [
        "PT-M13-03"
      ],
      "title": "Tala tipo sugar-tong do antebraço",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Material de tala, acolchoamento, malha tubular e faixas; equipamento de corte seguro.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Não checar pulsos/sensibilidade",
        "Enfaixar excessivamente apertado"
      ],
      "fields": {
        "definition": [
          "Tala não circular que limita pronação e supinação do antebraço e estabiliza lesões selecionadas."
        ],
        "indications": [
          "Fraturas distais de rádio/ulna após avaliação e estabilização inicial, quando indicada."
        ],
        "contraindications": [
          "Necessidade de intervenção emergencial ou lesão neurovascular exige prioridade assistencial."
        ],
        "anatomy": [
          "Punho, antebraço, cotovelo e pontos de pressão óssea."
        ],
        "materials": [
          "Material de tala, acolchoamento, malha tubular e faixas; equipamento de corte seguro. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Registrar avaliação neurovascular e pele antes de começar",
          "Simular acolchoamento e moldagem ao redor do cotovelo em manequim",
          "Evitar compressão circular e regiões de atrito",
          "Reavaliar perfusão, sensibilidade e movimento distal após a aplicação"
        ],
        "confirmation": [
          "Alinhamento provisório e exame neurovascular distal mantido; controle clínico/imagem conforme indicação."
        ],
        "complications": [
          "Compressão, queimadura de cura, parestesia, perda de redução e síndrome compartimental."
        ],
        "aftercare": [
          "Orientar elevação conforme caso, não molhar e retorno imediato por dor crescente ou dedos frios."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-SUGAR",
          "title": "Merck Manual — Sugar-tong arm splint, 2026",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-an-upper-limb/how-to-apply-a-sugar-tong-arm-splint",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-05",
      "topicIds": [
        "PT-M13-05"
      ],
      "title": "Tala posterior de membro inferior",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Gesso ou material sintético de tala, acolchoamento, malha tubular e faixa elástica.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar lesão aberta",
        "Deixar tala circunferencial rígida no edema importante"
      ],
      "fields": {
        "definition": [
          "Imobilização não circunferencial da perna e tornozelo, útil no edema inicial."
        ],
        "indications": [
          "Entorses ou fraturas selecionadas e imobilização provisória antes de intervenção."
        ],
        "contraindications": [
          "Lesão aberta ou instável requer cuidado concomitante e avaliação urgente; posição depende da lesão."
        ],
        "anatomy": [
          "Região posterior da perna, calcâneo, maléolos e cabeças metatarsais."
        ],
        "materials": [
          "Gesso ou material sintético de tala, acolchoamento, malha tubular e faixa elástica. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar feridas e estado neurovascular distal",
          "Simular medida, proteção de saliências e posicionamento do tornozelo conforme lesão",
          "Moldar tala sem pressão focal e fixar sem circular apertado",
          "Repetir exame neurovascular e registrar resultado"
        ],
        "confirmation": [
          "Tala íntegra e confortável, sem alteração de perfusão, motricidade ou sensibilidade."
        ],
        "complications": [
          "Pontos de pressão, queimadura térmica, isquemia e deslocamento."
        ],
        "aftercare": [
          "Orientar não apoiar sem autorização e retorno urgente para dor progressiva ou alteração distal."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-SPLINT",
          "title": "Merck Manual — How to apply a posterior ankle splint",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-a-lower-limb/how-to-apply-a-posterior-ankle-splint",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-06",
      "topicIds": [
        "PT-M13-06"
      ],
      "title": "Gesso circular: indicação, segurança e vigilância",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Malha, algodão ortopédico, gesso ou fibra apropriada e ferramentas de retirada.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Aplicar circular em edema importante sem avaliação",
        "Ignorar dor desproporcional persistente"
      ],
      "fields": {
        "definition": [
          "Imobilização circunferencial rígida, tipicamente em condição apropriada de edema e estabilidade."
        ],
        "indications": [
          "Fraturas/lesões selecionadas após avaliação ortopédica, muitas vezes após fase inicial com tala."
        ],
        "contraindications": [
          "Edema importante ou comprometimento neurovascular fazem preferir alternativas e reavaliação."
        ],
        "anatomy": [
          "Segmento a imobilizar, proeminências ósseas e avaliação neurovascular distal."
        ],
        "materials": [
          "Malha, algodão ortopédico, gesso ou fibra apropriada e ferramentas de retirada. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Conferir indicação, imagem disponível, edema e pele",
          "Treinar acolchoamento homogêneo e modelagem sem pontos de pressão",
          "Identificar riscos térmicos e de constrição",
          "Verificar perfusão/sensibilidade e documentar orientações de emergência"
        ],
        "confirmation": [
          "Conforto inicial e exame distal preservado, com programação de reavaliação."
        ],
        "complications": [
          "Queimadura térmica, lesão de pressão, edema preso, isquemia e síndrome compartimental."
        ],
        "aftercare": [
          "Manter seco, não inserir objetos e buscar emergência por dor desproporcional, dormência ou dedos frios."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-SPLINT",
          "title": "Merck Manual — How to apply a posterior ankle splint",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-a-lower-limb/how-to-apply-a-posterior-ankle-splint",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-11",
      "topicIds": [
        "PT-M13-11"
      ],
      "title": "Reconhecimento de síndrome compartimental",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Material para exame neurovascular e recursos para escalonamento cirúrgico urgente.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Aguardar pulso desaparecer",
        "Atribuir dor progressiva apenas a ansiedade"
      ],
      "fields": {
        "definition": [
          "Identificação de aumento de pressão dentro de compartimento musculofascial com risco isquêmico."
        ],
        "indications": [
          "Dor progressiva ou desproporcional após trauma, fratura ou imobilização; suspeita clínica é emergência."
        ],
        "contraindications": [
          "Pulsos palpáveis não excluem síndrome compartimental; não observar passivamente paciente com suspeita."
        ],
        "anatomy": [
          "Compartimentos musculares fechados, vasos e nervos vulneráveis a pressão."
        ],
        "materials": [
          "Material para exame neurovascular e recursos para escalonamento cirúrgico urgente. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Considerar mecanismo, imobilização e evolução da dor",
          "Avaliar dor ao alongamento passivo, sensibilidade e motricidade",
          "Acionar avaliação cirúrgica urgente e remover fator compressivo conforme equipe",
          "Documentar horários e reavaliações seriadas sem atrasar intervenção"
        ],
        "confirmation": [
          "Reconhecimento precoce e encaminhamento urgente, não aguardar ausência de pulso."
        ],
        "complications": [
          "Necrose muscular, lesão nervosa permanente, rabdomiólise e perda do membro."
        ],
        "aftercare": [
          "Seguir plano da equipe cirúrgica, monitorização seriada e documentação de evolução."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-SUGAR",
          "title": "Merck Manual — Sugar-tong arm splint, 2026",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-an-upper-limb/how-to-apply-a-sugar-tong-arm-splint",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    }
  ]
};
/* Sincroniza o estado editorial das fichas atuais sem publicar conteúdo clínico. */
(function(){
 const curriculum=window.NEXO_DATA.technicalCurriculum;
 const macro=curriculum.macroblocks.find(m=>m.id==='MB03');
 if(macro){macro.status='Em desenvolvimento';macro.description='MB03: lotes 1 e 2 — 38 fichas técnicas em revisão clínica; procedimentos adicionais e validação pendentes.'}
 const index=new Map(curriculum.modules.flatMap(m=>m.topics).map(t=>[t.id,t]));
 for(const procedure of window.NEXO_PROCEDURES.procedures){
   for(const tid of procedure.topicIds){const topic=index.get(tid);if(!topic)throw Error('Procedimento sem tópico: '+tid);
     topic.status='revisao-tecnica';topic.revision={...topic.revision,version:'0.2',state:'revisao-tecnica',reviewedOn:null,reviewer:null};
   }
 }
})();
