/* MB03 + MB04 Lote 1: fichas de estudo prático para simulação com fontes e versões registradas. */
window.NEXO_PROCEDURES = {
  "version": "0.3-MB04-L1",
  "macroblock": "MB03",
  "generatedOn": "2026-10-15",
  "status": "revisao-tecnica",
  "sourcePolicy": "Fontes identificadas; fichas educacionais para simulação, com atualização contínua e sem bloqueio de acesso ao estudo.",
  "procedures": [
    {
      "id": "PT-M01-01",
      "topicIds": [
        "PT-M01-01"
      ],
      "title": "Higienização das mãos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Biossegurança",
      "population": "Todas as faixas etárias",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Preparação alcoólica apropriada ou água e sabonete; papel-toalha; pia funcional"
      ],
      "criticalErrors": [
        "Deixar de higienizar antes de técnica asséptica",
        "Tratar luvas como substituto da higiene"
      ],
      "fields": {
        "definition": [
          "Prática fundamental para interromper transmissão cruzada de microrganismos e proteger paciente e equipe."
        ],
        "indications": [
          "Antes de tocar o paciente; antes de procedimento limpo/asséptico; após risco de fluidos; após tocar paciente; após tocar superfícies próximas."
        ],
        "contraindications": [
          "Não há contraindicação à higiene; alergia ou lesão cutânea requer adequação do produto e avaliação ocupacional."
        ],
        "anatomy": [
          "Mãos, unhas, espaços interdigitais, polegares, pontas dos dedos e punhos; integridade cutânea e adornos interferem."
        ],
        "materials": [
          "Preparação alcoólica regulamentada quando indicada; água e sabonete quando mãos visivelmente sujas ou conforme protocolo."
        ],
        "environment": [
          "Garantir suprimentos acessíveis e pontos de higiene nos locais de cuidado."
        ],
        "patient": [
          "Explicar ações ao paciente quando pertinente; remover acessórios de mão conforme regras locais."
        ],
        "analgesia": [
          "Não requer anestesia ou analgesia."
        ],
        "sequence": [
          "Identificar o momento assistencial",
          "Escolher água e sabonete ou produto alcoólico conforme indicação",
          "Cobrir todas as superfícies das mãos até secagem completa",
          "Não substituir higiene por uso de luvas."
        ],
        "confirmation": [
          "Mãos secas após fricção alcoólica; ausência de áreas negligenciadas na demonstração observada."
        ],
        "complications": [
          "Erro de oportunidade, técnica incompleta, contaminação após higiene e dermatite; corrigir e repetir quando necessário."
        ],
        "aftercare": [
          "Repetir nos cinco momentos; notificar problemas de suprimento ou dermatite ocupacional."
        ],
        "skills-checklist": [
          "Reconhece os cinco momentos",
          "Seleciona método apropriado",
          "Abrange polegares e pontas dos dedos",
          "Não considera luvas substitutas."
        ],
        "media-references": [
          "Usar recursos da OMS como apoio de aprendizagem, não como autorização de reutilização de mídia.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-05",
      "topicIds": [
        "PT-M04-05"
      ],
      "title": "Administração intramuscular de medicamentos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Medicamento prescrito, diluente compatível se aplicável, antisséptico, luvas, gaze, coletor de perfurocortantes"
      ],
      "criticalErrors": [
        "Agulha compartilhada ou reutilizada",
        "Medicação em via não autorizada",
        "Falta de confirmação de alergias"
      ],
      "fields": {
        "definition": [
          "Administração de fármaco no tecido muscular, observando indicação da via e formulação autorizada."
        ],
        "indications": [
          "Quando a apresentação e a prescrição permitem via IM, com volume, local e absorção compatíveis."
        ],
        "contraindications": [
          "Não utilizar via IM quando a formulação não for destinada a ela; avaliar infecção local, alterações de coagulação e riscos individuais."
        ],
        "anatomy": [
          "Identificar marcos anatômicos de locais adequados, com variações por faixa etária e massa muscular; evitar estruturas neurovasculares."
        ],
        "materials": [
          "Conferir medicamento, dose, diluição, seringa e agulha de comprimento/calibre apropriados; agulha e seringa de uso único."
        ],
        "environment": [
          "Área limpa, recipiente de descarte próximo e disponibilidade de manejo de reação adversa."
        ],
        "patient": [
          "Conferir paciente, prescrição, alergias, contraindicações, consentimento, integridade do local e capacidade de colaborar."
        ],
        "analgesia": [
          "Medidas de conforto e posicionamento; necessidade de analgesia específica depende do procedimento e paciente."
        ],
        "sequence": [
          "Validar prescrição e preparo com identificação completa",
          "Localizar sítio anatômico compatível e posicionar",
          "Higienizar mãos e seguir política de antissepsia",
          "Administrar sob técnica do serviço e descarte imediato sem reencape",
          "Documentar lote quando pertinente."
        ],
        "confirmation": [
          "Confirmar medicamento, dose, via, local e documentação; observar resposta e reação imediata."
        ],
        "complications": [
          "Lesão nervosa ou vascular, dor, hematoma, infecção, reação alérgica; interromper e acionar suporte se houver reação grave."
        ],
        "aftercare": [
          "Orientar sinais de alerta, cuidados locais e registro de administração; vigiar reações."
        ],
        "skills-checklist": [
          "Confere identificação/alergias",
          "Justifica sítio e dispositivo",
          "Mantém assepsia",
          "Descarta sem reencapar",
          "Reconhece anafilaxia."
        ],
        "media-references": [
          "Tabelas de comprimentos e volumes devem ser formuladas por medicamento, idade e fabricante, e não presumidas de uma regra universal.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "CDC-INJ",
          "title": "CDC — Práticas seguras de injeção",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M05-01",
      "topicIds": [
        "PT-M05-01"
      ],
      "title": "Acesso venoso periférico",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Acessos vasculares",
      "population": "Adulto;Criança;Neonato com protocolo e supervisão específicos",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-001",
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Garrote, antisséptico adequado, luvas, solução de flushing compatível, gaze, cobertura transparente ou apropriada, descarte perfurocortante"
      ],
      "criticalErrors": [
        "Reutilizar cateter",
        "Manter infusão diante de extravasamento",
        "Omitir antissepsia"
      ],
      "fields": {
        "definition": [
          "Introdução de cateter curto em veia periférica para terapia intravenosa e outras indicações clínicas."
        ],
        "indications": [
          "Infusão de fluidos/medicamentos compatíveis, contraste ou necessidade de acesso venoso conforme avaliação."
        ],
        "contraindications": [
          "Evitar áreas de infecção, flebite, comprometimento circulatório e locais com restrições clínicas; reconsiderar necessidade e via."
        ],
        "anatomy": [
          "Veias periféricas do membro superior, anatomia e mobilidade; escolha do vaso deve considerar terapêutica e preservação vascular."
        ],
        "materials": [
          "Cateter com calibre e comprimento adequados ao vaso e terapia; conector, extensão, cobertura, solução e embalagem íntegra."
        ],
        "environment": [
          "Higiene das mãos, campo limpo, iluminação, contenção mínima e descarte imediatamente acessível."
        ],
        "patient": [
          "Identificação, consentimento, alergias, pele/vasculatura, histórico de tentativas e necessidade de analgesia individualizada."
        ],
        "analgesia": [
          "Analgesia tópica ou outra medida de conforto pode ser considerada quando adequada à população e disponibilidade."
        ],
        "sequence": [
          "Planejar sítio e dispositivo",
          "Higienizar mãos e preparar material",
          "Realizar antissepsia e preservar área preparada",
          "Simular sequência de inserção e liberação segura do mecanismo",
          "Confirmar permeabilidade, fixar e identificar",
          "Registrar e ensinar sinais de alerta."
        ],
        "confirmation": [
          "Confirmar funcionamento sem sinais de infiltração ou dor; seguir protocolo de permeabilidade e documentação."
        ],
        "complications": [
          "Infiltração, extravasamento, flebite, trombose, infecção, hematoma, perfurocortante; interromper uso e avaliar complicações."
        ],
        "aftercare": [
          "Inspecionar inserção e trajeto venoso pelo menos diariamente; reavaliar necessidade e remover conforme indicação e protocolo."
        ],
        "skills-checklist": [
          "Indica necessidade",
          "Seleciona calibre pelo vaso/terapia",
          "Preserva antissepsia",
          "Confirma funcionamento",
          "Reconhece extravasamento",
          "Registra."
        ],
        "media-references": [
          "O calibre não é exclusivo de faixas etárias; orientações de marca e protocolo local prevalecem.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "WHO-PIV",
          "title": "OMS — Diretriz de cateteres periféricos (2024)",
          "url": "https://www.who.int/publications/i/item/9789240093829",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M05-02",
      "topicIds": [
        "PT-M05-02"
      ],
      "title": "Coleta de sangue venoso",
      "priority": "P0",
      "level": "Básico",
      "scope": "Acessos vasculares",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-002",
        "MAT-MED-002",
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Tubos identificados conforme exames, garrote, luvas, antisséptico, gaze, curativo e descarte"
      ],
      "criticalErrors": [
        "Tubo sem identificação",
        "Reutilização de agulha",
        "Identificação posterior fora do paciente"
      ],
      "fields": {
        "definition": [
          "Obtenção de amostra venosa para análises laboratoriais com rastreabilidade pré-analítica."
        ],
        "indications": [
          "Quando exames solicitados demandam sangue venoso e a condição do paciente permite coleta periférica."
        ],
        "contraindications": [
          "Evitar local com infecção, hematoma, infusão ativa ou restrições institucionais; avaliar acesso alternativo."
        ],
        "anatomy": [
          "Rede venosa superficial, proximidade de estruturas nervosas e artérias; cuidado especial com anatomia pediátrica."
        ],
        "materials": [
          "Dispositivo apropriado à veia, sistema fechado quando possível, tubos corretos, identificação à beira-leito."
        ],
        "environment": [
          "Preparar bancada, descarte, transporte e requisitos de conservação do laboratório."
        ],
        "patient": [
          "Conferir dois identificadores, prescrição, preparo do exame e riscos de síncope ou sangramento."
        ],
        "analgesia": [
          "Medidas de conforto e posicionamento, especialmente se histórico de reação vasovagal."
        ],
        "sequence": [
          "Confirmar pedidos e tubos",
          "Higienizar mãos e selecionar dispositivo",
          "Executar antissepsia e coleta conforme protocolo",
          "Homogeneizar tubos quando indicado",
          "Soltar garrote, retirar e descartar dispositivo",
          "Identificar amostras na presença do paciente."
        ],
        "confirmation": [
          "Conferir identificação, volume, qualidade da amostra e condições de envio; garantir hemostasia local."
        ],
        "complications": [
          "Hematoma, punção arterial acidental, síncope, hemólise e identificação incorreta; interromper e reavaliar."
        ],
        "aftercare": [
          "Orientar compressão local, sinais de retorno e registrar intercorrências."
        ],
        "skills-checklist": [
          "Confere dois identificadores",
          "Seleciona tubos corretos",
          "Controla exposição",
          "Identifica tubos no ponto de cuidado",
          "Evita hemólise."
        ],
        "media-references": [
          "Ordem de coleta, anticoagulantes e volumes devem seguir manual do laboratório e fabricante.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "WHO-PHLEB",
          "title": "OMS — Boas práticas em flebotomia",
          "url": "https://www.who.int/publications/i/item/9789241599221",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-INJ",
          "title": "CDC — Práticas seguras de injeção",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-01",
      "topicIds": [
        "PT-M06-01"
      ],
      "title": "Avaliação estruturada da ferida",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Luvas, fonte de luz, régua descartável apropriada, gaze, material de documentação autorizado"
      ],
      "criticalErrors": [
        "Suturar sem pesquisar lesão profunda",
        "Ignorar perfusão ou função distal"
      ],
      "fields": {
        "definition": [
          "Exame padronizado da lesão para decidir urgência, limpeza, imagem, fechamento e acompanhamento."
        ],
        "indications": [
          "Toda lesão cutânea traumática, cirúrgica ou crônica requer caracterização antes da conduta."
        ],
        "contraindications": [
          "Ferida profunda, isquemia, sangramento persistente ou comprometimento neurovascular demandam avaliação urgente especializada."
        ],
        "anatomy": [
          "Localização, bordas, leito, profundidade, vascularização e proximidade de tendões, vasos, nervos e articulações."
        ],
        "materials": [
          "Iluminação, luvas, material de mensuração e cobertura; fotografia somente com autorização e proteção dos dados."
        ],
        "environment": [
          "Privacidade, assepsia adequada ao cenário e acesso a controle de sangramento."
        ],
        "patient": [
          "Investigar mecanismo/tempo da lesão, imunização antitetânica, comorbidades, medicamentos e sintomas sistêmicos."
        ],
        "analgesia": [
          "Oferecer controle da dor conforme avaliação; evitar exploração dolorosa sem analgesia."
        ],
        "sequence": [
          "Estabilizar e controlar sangramento",
          "Inspecionar dimensão, bordas, exsudato, tecido, corpos estranhos e perfusão",
          "Avaliar função sensitiva e motora",
          "Identificar possível contaminação/infecção",
          "Decidir irrigação, fechamento ou encaminhamento."
        ],
        "confirmation": [
          "Documentar local, medidas, extensão, tecidos envolvidos, perfusão e conduta justificada."
        ],
        "complications": [
          "Infecção, corpo estranho oculto, lesão tendínea, nervosa ou vascular; não mascarar sinais de gravidade."
        ],
        "aftercare": [
          "Orientar cuidados e prazo de reavaliação, incluindo sinais de alarme e profilaxias indicadas."
        ],
        "skills-checklist": [
          "Classifica mecanismo",
          "Avalia profundidade",
          "Examina função e perfusão",
          "Verifica tétano",
          "Documenta plano e retorno."
        ],
        "media-references": [
          "A classificação cirúrgica limpa/limpa-contaminada/contaminada/suja não substitui a classificação das feridas traumáticas.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-03",
      "topicIds": [
        "PT-M06-03"
      ],
      "title": "Irrigação de ferida",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Soro fisiológico ou água apropriada conforme protocolo, seringa e proteção de respingos, recipiente, gaze e equipamento de proteção"
      ],
      "criticalErrors": [
        "Fechar ferida com corpo estranho suspeito",
        "Irrigação sem avaliação de lesão profunda"
      ],
      "fields": {
        "definition": [
          "Limpeza mecânica por fluxo líquido para reduzir carga de contaminantes antes da decisão de fechamento."
        ],
        "indications": [
          "Feridas traumáticas e lesões com resíduos quando irrigação está indicada no plano de cuidado."
        ],
        "contraindications": [
          "Não irrigar de forma não controlada cavidades profundas ou trajetos com suspeita de lesão de estruturas; pedir avaliação especializada."
        ],
        "anatomy": [
          "Reconhecer profundidade, limites e estruturas adjacentes; realizar exame vascular, neurológico e tendíneo antes do fechamento."
        ],
        "materials": [
          "Solução salina ou água apropriada conforme cenário; dispositivo que forneça fluxo controlado, cobertura e gaze."
        ],
        "environment": [
          "Garantir iluminação, contenção de respingos, segurança de perfurocortantes e descarte."
        ],
        "patient": [
          "Explicar desconforto, obter consentimento e avaliar riscos de retenção de corpo estranho."
        ],
        "analgesia": [
          "Analgesia local ou sistêmica individualizada pode ser necessária para inspeção e limpeza adequadas."
        ],
        "sequence": [
          "Controlar sangramento",
          "Examinar extensão e corpo estranho",
          "Proteger paciente/equipe",
          "Irrigar sem traumatizar tecidos",
          "Retirar contaminantes visíveis com instrumentos adequados",
          "Reavaliar e decidir fechamento/encaminhamento."
        ],
        "confirmation": [
          "Campo sem sujeira grosseira; tecidos viáveis e integridade funcional novamente documentada."
        ],
        "complications": [
          "Lesão por pressão exagerada, contaminação secundária, retenção de corpo estranho e falha em reconhecer lesão profunda."
        ],
        "aftercare": [
          "Aplicar cobertura apropriada, atualizar avaliação de tétano e organizar retorno."
        ],
        "skills-checklist": [
          "Avalia antes de irrigar",
          "Escolhe solução apropriada",
          "Protege de respingos",
          "Reavalia tecido e função",
          "Evita lesão adicional."
        ],
        "media-references": [
          "Antissépticos citotóxicos não devem ser aplicados indiscriminadamente no leito da ferida.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-07",
      "topicIds": [
        "PT-M06-07"
      ],
      "title": "Seleção e troca de curativos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Luvas, solução adequada de limpeza, compressa não aderente, gaze absorvente, fixação e descarte"
      ],
      "criticalErrors": [
        "Cobrir sem avaliar perfusão",
        "Aplicar material não compatível com o leito"
      ],
      "fields": {
        "definition": [
          "Escolha, aplicação e troca de cobertura para proteção do leito e manejo do exsudato."
        ],
        "indications": [
          "Feridas que demandam proteção ou controle de umidade/exsudato, conforme etiologia e estágio."
        ],
        "contraindications": [
          "Evitar cobertura oclusiva inadequada em infecção não controlada ou maceração; priorizar avaliação de perfusão e etiologia."
        ],
        "anatomy": [
          "Avaliar leito, pele perilesional, cavidades, exsudato, perfusão e áreas de pressão."
        ],
        "materials": [
          "Escolher cobertura segundo exsudato, aderência, profundidade e fabricante; material não aderente quando necessário."
        ],
        "environment": [
          "Preparar superfície limpa, privacidade e local apropriado para descarte contaminado."
        ],
        "patient": [
          "Conferir alergias a adesivos, dor, odor, temperatura, sinais de infecção e evolução anterior."
        ],
        "analgesia": [
          "Analgesia antes da troca quando indicada; evitar retirada traumática de coberturas aderidas."
        ],
        "sequence": [
          "Examinar curativo anterior",
          "Higienizar mãos e proteger-se",
          "Remover cobertura preservando tecido",
          "Limpar e avaliar leito",
          "Selecionar cobertura com justificativa",
          "Fixar sem restringir circulação",
          "Registrar achados."
        ],
        "confirmation": [
          "Cobertura protege sem compressão excessiva, controle de exsudato e ausência de piora visível."
        ],
        "complications": [
          "Maceração, dermatite de contato, dor, infecção, reação alérgica, isquemia por fixação inadequada."
        ],
        "aftercare": [
          "Definir periodicidade de troca pela ferida e pelo produto, orientar sinais de piora e revisão."
        ],
        "skills-checklist": [
          "Distingue leito/perilesão",
          "Reconhece exsudato",
          "Justifica tipo de cobertura",
          "Evita fixação compressiva",
          "Documenta evolução."
        ],
        "media-references": [
          "A periodicidade não deve ser uma regra única para todas as coberturas.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-09",
      "topicIds": [
        "PT-M06-09"
      ],
      "title": "Feridas por mordedura animal ou humana",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Solução para lavagem abundante, material de irrigação, EPI, cobertura apropriada e acesso a avaliação de profilaxias"
      ],
      "criticalErrors": [
        "Substituir tétano por antibiótico",
        "Omitir avaliação antirrábica",
        "Fechamento automático de ferida profunda da mão"
      ],
      "fields": {
        "definition": [
          "Abordagem de lesões com inoculação potencial de microrganismos por saliva, incluindo risco de raiva em exposições selecionadas."
        ],
        "indications": [
          "Mordidas, arranhaduras com exposição, lesões perfurantes e mordeduras humanas."
        ],
        "contraindications": [
          "Não presumir fechamento primário automático; suspeita de lesão em mão, tendão, articulação ou estrutura profunda exige avaliação especializada."
        ],
        "anatomy": [
          "Inspecionar profundidade e relação com articulações, tendões, nervos e vasos, especialmente na mão."
        ],
        "materials": [
          "Luvas, material de limpeza/irrigação, cobertura; acesso a imunobiológicos conforme avaliação epidemiológica."
        ],
        "environment": [
          "Preparar lavagem precoce, contenção de secreções e encaminhamento quando necessário."
        ],
        "patient": [
          "Documentar espécie, situação do animal, local, tempo de exposição, vacinação conhecida, histórico antitetânico e imunossupressão."
        ],
        "analgesia": [
          "Avaliar analgesia e necessidade de avaliação especializada conforme dor e complexidade."
        ],
        "sequence": [
          "Controlar hemorragia",
          "Realizar lavagem abundante apropriada",
          "Explorar lesões e função",
          "Avaliar necessidade de antibiótico, tétano e raiva separadamente",
          "Definir fechamento seletivo e seguimento."
        ],
        "confirmation": [
          "Registrar risco de raiva avaliado e decisão/protocolo consultado; documentar exame neurovascular e plano de retorno."
        ],
        "complications": [
          "Infecção polimicrobiana, tenossinovite, artrite séptica, sepse, raiva e tétano; encaminhar urgentemente nos cenários de risco."
        ],
        "aftercare": [
          "Orientar vigilância de sinais de infecção e reavaliação precoce conforme local/risco."
        ],
        "skills-checklist": [
          "Pergunta espécie/situação",
          "Examina mão/estrutura profunda",
          "Diferencia três profilaxias",
          "Não sutura automaticamente",
          "Registra encaminhamento."
        ],
        "media-references": [
          "Conduta antirrábica deve considerar protocolos epidemiológicos do país/região e comunicação às autoridades sanitárias.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-RABIES",
          "title": "CDC — Profilaxia da raiva após exposição",
          "url": "https://www.cdc.gov/rabies/hcp/clinical-care/post-exposure-prophylaxis.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-03",
      "topicIds": [
        "PT-M07-03"
      ],
      "title": "Sutura simples interrompida",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-SUT-003",
        "MAT-INS-003",
        "MAT-INS-004"
      ],
      "additionalSupplies": [
        "Tesoura de sutura, gaze, campos, materiais de irrigação, anestésico local se indicado, EPI e cobertura"
      ],
      "criticalErrors": [
        "Fechar lesão profunda não explorada",
        "Estrangular bordas",
        "Agulha descartada inadequadamente"
      ],
      "fields": {
        "definition": [
          "Técnica de aproximação cutânea com pontos separados, adequada a determinadas feridas após avaliação."
        ],
        "indications": [
          "Feridas com bordas aproximáveis sem tensão excessiva, após limpeza, inspeção e decisão fundamentada de fechamento."
        ],
        "contraindications": [
          "Não fechar sem avaliar ferida contaminada/infectada, perda tecidual, perfusão, corpo estranho e lesões profundas; considerar alternativas."
        ],
        "anatomy": [
          "Pele, derme, margens e estruturas profundas adjacentes; tensão e linhas de força locais."
        ],
        "materials": [
          "Porta-agulhas, pinça adequada, fio/agulha escolhidos por sítio e tensão, tesoura, anestesia e curativo."
        ],
        "environment": [
          "Boa iluminação, preparação de campo e descarte seguro de instrumentos perfurantes."
        ],
        "patient": [
          "Informar paciente, confirmar alergias, tétano, mecanismo, exame neurovascular/tendíneo e consentimento."
        ],
        "analgesia": [
          "Anestesia local conforme protocolo e dose segura individualizada; não usar dose universal."
        ],
        "sequence": [
          "Exame e hemostasia",
          "Analgesia, limpeza/irrigação e desbridamento quando apropriado",
          "Posicionar instrumentos em modelo",
          "Simular passagem simétrica da agulha respeitando tecidos",
          "Aproximar sem estrangulamento",
          "Verificar bordas e aplicar curativo."
        ],
        "confirmation": [
          "Coaptação adequada, sem isquemia, tensão excessiva, lacunas ou lesão funcional; documentação do material usado."
        ],
        "complications": [
          "Isquemia das bordas, infecção, deiscência, lesão por agulha, corpo estranho e cicatriz desfavorável; escalar quando necessário."
        ],
        "aftercare": [
          "Orientar cuidados, sinais de infecção, revisão e retirada de pontos conforme localização e evolução."
        ],
        "skills-checklist": [
          "Escolhe ferida apropriada",
          "Verifica estruturas",
          "Seleciona fio",
          "Evita tensão",
          "Mantém segurança de agulhas",
          "Orienta retorno."
        ],
        "media-references": [
          "Aula textual não certifica habilidade; manobras devem ser praticadas em simulador com instrutor.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-SUT",
          "title": "Merck Manual — Sutura simples interrompida (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "CDC-TET",
          "title": "CDC — Manejo de feridas e profilaxia antitetânica (2026)",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-02",
      "topicIds": [
        "PT-M13-02"
      ],
      "title": "Tala antebraquiopalmar",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos;Crianças com técnica e vigilância específicas",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Material de tala apropriado, acolchoamento, bandagem, água conforme fabricante, tesoura e proteção da pele"
      ],
      "criticalErrors": [
        "Não examinar neurovascular distal",
        "Bandagem constritiva",
        "Ignorar dor crescente"
      ],
      "fields": {
        "definition": [
          "Imobilização não circunferencial de punho/antebraço para suporte temporário ou terapêutico em indicações selecionadas."
        ],
        "indications": [
          "Lesões traumáticas selecionadas enquanto se define diagnóstico e tratamento, ou imobilização pós-procedimento indicada."
        ],
        "contraindications": [
          "Não usar como substituto de avaliação urgente em suspeita de fratura exposta, isquemia, síndrome compartimental ou déficit neurológico."
        ],
        "anatomy": [
          "Destacar cotovelo, antebraço, punho, proeminências ósseas, dedos e avaliação distal neurovascular."
        ],
        "materials": [
          "Tala, acolchoamento, material de fixação e instruções de ativação/tempo de cura do fabricante."
        ],
        "environment": [
          "Preparar ambiente e material, prever edema e acesso para reavaliação."
        ],
        "patient": [
          "Identificar lado, dor, deformidade, integridade cutânea, pulso, perfusão, sensibilidade e movimento previamente."
        ],
        "analgesia": [
          "Analgesia apropriada à dor e eventual redução realizada apenas por profissional habilitado."
        ],
        "sequence": [
          "Avaliar antes da imobilização",
          "Proteger proeminências e pele",
          "Moldar tala conforme indicação e posicionamento seguro",
          "Fixar sem constrição circunferencial",
          "Avaliar perfusão/sensibilidade/motricidade novamente",
          "Explicar cuidados e alarme."
        ],
        "confirmation": [
          "Estabilidade e conforto relativos sem comprometimento de circulação, sensibilidade ou movimento dos dedos."
        ],
        "complications": [
          "Compressão, queimadura térmica durante endurecimento, maceração, neuropraxia, síndrome compartimental; remover/avaliar imediatamente sinais graves."
        ],
        "aftercare": [
          "Orientar elevação, proteção contra umidade conforme material, retorno e sinais de alarme."
        ],
        "skills-checklist": [
          "Examina NV antes/depois",
          "Protege proeminências",
          "Acomoda edema",
          "Molda adequadamente",
          "Informa sinais de urgência."
        ],
        "media-references": [
          "Posições específicas e espessura da tala devem ser definidas conforme lesão e protocolo local.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "AAOS-CAST",
          "title": "AAOS — Cuidados com talas e gessos",
          "url": "https://www.orthoinfo.org/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-10",
      "topicIds": [
        "PT-M13-10"
      ],
      "title": "Avaliação neurovascular antes e depois da imobilização",
      "priority": "P0",
      "level": "Básico",
      "scope": "Ortopedia e imobilização",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Boa iluminação, dispositivo de comparação bilateral, registro, oxímetro/temperatura se apropriado"
      ],
      "criticalErrors": [
        "Concluir que pulso normal exclui síndrome compartimental",
        "Deixar de repetir exame após imobilização"
      ],
      "fields": {
        "definition": [
          "Exame seriado de perfusão, sensibilidade e função motora distal em trauma e após aplicação de talas ou gesso."
        ],
        "indications": [
          "Toda imobilização de membros, suspeita de compressão ou dor/parestesia em membro traumatizado."
        ],
        "contraindications": [
          "Não postergar avaliação urgente por ausência de pulso palpável, isquemia ou suspeita de síndrome compartimental."
        ],
        "anatomy": [
          "Conhecer territórios nervosos, motricidade distal, pulsos periféricos e áreas de circulação relevantes."
        ],
        "materials": [
          "Lanterna/iluminação, relógio, registro e recursos adequados para avaliar perfusão."
        ],
        "environment": [
          "Garantir acesso ao segmento distal e referência de comparação contralateral."
        ],
        "patient": [
          "Explicar exame, avaliar dor, sensibilidade prévia, circulação e função antes de qualquer imobilização."
        ],
        "analgesia": [
          "Evitar estímulos dolorosos desnecessários; analgesia não deve atrasar avaliação de emergência."
        ],
        "sequence": [
          "Comparar perfusão e cor",
          "Verificar temperatura, enchimento capilar e pulsos quando pertinentes",
          "Testar sensibilidade e motricidade por territórios",
          "Registrar antes e após",
          "Repetir se dor, edema ou parestesia."
        ],
        "confirmation": [
          "Comparação bilateral e registro explícito de alterações; definir destino/urgência em caso de achados anormais."
        ],
        "complications": [
          "Déficit neurológico, compressão, isquemia, síndrome compartimental; sinal de alerta exige avaliação imediata."
        ],
        "aftercare": [
          "Instruir a buscar ajuda por dor progressiva, formigamento, perda de movimento e mudança de cor ou temperatura."
        ],
        "skills-checklist": [
          "Testa e documenta perfusão",
          "Documenta motricidade e sensibilidade",
          "Repete após tala",
          "Reconhece emergência."
        ],
        "media-references": [
          "Pulsos preservados não excluem síndrome compartimental.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "AAOS-CAST",
          "title": "AAOS — Cuidados com talas e gessos",
          "url": "https://www.orthoinfo.org/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M27-01",
      "topicIds": [
        "PT-M27-01"
      ],
      "title": "Glicemia capilar à beira-leito",
      "priority": "P0",
      "level": "Básico",
      "scope": "Diagnóstico à beira-leito",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Glicosímetro validado, tira compatível, lanceta de uso único, EPI e descarte de perfurocortantes"
      ],
      "criticalErrors": [
        "Lanceta reutilizada",
        "Glicosímetro compartilhado sem desinfecção",
        "Ignorar hipoglicemia clínica por leitura suspeita"
      ],
      "fields": {
        "definition": [
          "Determinação point-of-care de glicose com dispositivo adequado e controle de qualidade."
        ],
        "indications": [
          "Monitorização ou avaliação rápida quando resultado influencia decisão clínica."
        ],
        "contraindications": [
          "Resultados incompatíveis com quadro clínico ou contexto de má perfusão exigem confirmação laboratorial conforme protocolo."
        ],
        "anatomy": [
          "Polpa digital ou outro local validado pelo dispositivo e faixa etária; reconhecer limitações por perfusão."
        ],
        "materials": [
          "Lanceta descartável por paciente, tira dentro da validade, equipamento com QC e instrução de uso atual."
        ],
        "environment": [
          "Confirmar funcionamento, calibração/controle do aparelho, limpeza e descarte."
        ],
        "patient": [
          "Identificar paciente e indicar o teste; avaliar mãos, perfusão, substâncias na pele e contexto clínico."
        ],
        "analgesia": [
          "Puncionamento breve; medidas de conforto conforme idade e técnica."
        ],
        "sequence": [
          "Higienizar mãos",
          "Conferir tira e aparelho",
          "Preparar local sem contaminar amostra",
          "Coletar pelo dispositivo conforme IFU",
          "Descartar lanceta sem reencape",
          "Interpretar no contexto e registrar."
        ],
        "confirmation": [
          "Valor e horário documentados com identificação do equipamento; confirmar discrepâncias críticas."
        ],
        "complications": [
          "Falso resultado por contaminação, baixa perfusão, técnica incorreta; contaminação cruzada e acidente perfurocortante."
        ],
        "aftercare": [
          "Comunicar resultados críticos e tratar segundo protocolo clínico; higienizar equipamento entre pacientes."
        ],
        "skills-checklist": [
          "Usa lanceta única",
          "Verifica QC",
          "Identifica paciente",
          "Interpreta limitações",
          "Desinfeta equipamento."
        ],
        "media-references": [
          "Não utilizar valor isolado quando incompatível com estado clínico.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "CDC-GLU",
          "title": "CDC — Segurança na monitorização de glicemia",
          "url": "https://www.cdc.gov/injection-safety/hcp/infection-control/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-06",
      "topicIds": [
        "PT-M06-06"
      ],
      "title": "Classificação clínica e cirúrgica das feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Luvas, material de inspeção e registro clínico"
      ],
      "criticalErrors": [
        "Rotular mordedura automaticamente como ferida cirúrgica classe IV",
        "Indicar sutura com base apenas na classe"
      ],
      "fields": {
        "definition": [
          "Organização da avaliação de feridas traumáticas, cirúrgicas ou crônicas sem confundir sistemas classificatórios distintos."
        ],
        "indications": [
          "Toda caracterização de ferida para documentação, risco de infecção e escolha do cuidado."
        ],
        "contraindications": [
          "Classificação isolada não justifica fechamento ou antibiótico e não substitui exame clínico."
        ],
        "anatomy": [
          "Reconhecer local, tecidos, profundidade, comunicação com cavidades e estruturas lesadas."
        ],
        "materials": [
          "Instrumentos de mensuração e registro padronizado; não é necessária escala Gauge/French."
        ],
        "environment": [
          "Garantir iluminação, privacidade e barreiras de proteção."
        ],
        "patient": [
          "Investigar mecanismo, tempo, presença de sujidade, perfusão, sinais de infecção e comorbidades."
        ],
        "analgesia": [
          "Analgesia individualizada quando exame é doloroso."
        ],
        "sequence": [
          "Caracterizar ferida por etiologia e profundidade",
          "Diferenciar lesão traumática de classificação de ferida operatória",
          "Quando pertinente, distinguir I limpa, II limpa-contaminada, III contaminada e IV suja/infectada",
          "Registrar justificativa e conduta clínica."
        ],
        "confirmation": [
          "Documentar classificação usada e critérios objetivos, sem misturar classificações cirúrgica, traumática e de risco de tétano."
        ],
        "complications": [
          "Subestimar contaminação, corpo estranho e comprometimento vascular pode causar fechamento inadequado; reavaliar risco."
        ],
        "aftercare": [
          "Planejar reavaliação, prevenção de infecção e cuidados conforme etiologia."
        ],
        "skills-checklist": [
          "Distingue três sistemas classificatórios",
          "Reconhece ferida infectada",
          "Avalia mecanismo e profundidade",
          "Justifica conduta."
        ],
        "media-references": [
          "Revisar definições de classes operatórias com protocolo institucional e vigilância de infecção.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-WOUND",
          "title": "Merck Manual — Limpeza, irrigação e curativos (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "NHSN-WOUND",
          "title": "CDC/NHSN — Classificação de feridas operatórias",
          "url": "https://www.cdc.gov/nhsn/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-11",
      "topicIds": [
        "PT-M07-11"
      ],
      "title": "Retirada de pontos e grampos cutâneos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Suturas e fechamento",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-007",
        "MAT-CLO-003"
      ],
      "additionalSupplies": [
        "Removedor apropriado de grampos, pinça e tesoura esterilizados quando indicados, EPI, gaze, solução de limpeza, fita de suporte da ferida"
      ],
      "criticalErrors": [
        "Remover pontos apesar de deiscência progressiva",
        "Deixar fragmento de fio sem documentação"
      ],
      "fields": {
        "definition": [
          "Remoção controlada de dispositivos de fechamento após avaliação de reparação tecidual e risco de deiscência."
        ],
        "indications": [
          "Feridas cicatrizadas suficientemente após período e localização adequados, com indicação profissional."
        ],
        "contraindications": [
          "Não retirar indiscriminadamente diante de deiscência, sinais graves de infecção, isquemia ou tensão não resolvida."
        ],
        "anatomy": [
          "Avaliar bordas da epiderme, profundidade, articulações, localização facial ou de membros e zonas de tensão."
        ],
        "materials": [
          "Tesoura apropriada, pinça, removedor de grampos, gaze e material de suporte se indicado.",
          "Consulte 1 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Boa iluminação, higiene das mãos, descarte de materiais contaminados e plano para abertura inesperada da ferida."
        ],
        "patient": [
          "Conferir data, tipo de fechamento, antecedentes de infecção, diabetes/imunossupressão e aspecto atual."
        ],
        "analgesia": [
          "Explicar desconforto possível; analgesia frequentemente não é necessária, mas individualizar."
        ],
        "sequence": [
          "Examinar coaptação e sinais de infecção",
          "Higienizar mãos e preparar material",
          "Realizar remoção segundo tipo de fechamento e treinamento",
          "Reavaliar imediatamente bordas",
          "Aplicar suporte ou interromper remoção quando abertura ameaçar."
        ],
        "confirmation": [
          "Bordas íntegras sem abertura ou sangramento relevante; documentar quantidade retirada e retenções suspeitas."
        ],
        "complications": [
          "Deiscência, sangramento, fragmentos de fio, infecção e lesão cutânea; interromper e buscar avaliação."
        ],
        "aftercare": [
          "Proteger a região conforme necessidade e orientar sinais de alerta e retorno."
        ],
        "skills-checklist": [
          "Avalia tensão e cicatrização",
          "Seleciona instrumento adequado",
          "Confere integridade após remoção",
          "Documenta."
        ],
        "media-references": [
          "Tempo de retirada depende do local e evolução; evitar calendário universal sem avaliação.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "MERCK-SUT",
          "title": "Merck Manual — Sutura simples interrompida (revisado 2026)",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M27-02",
      "topicIds": [
        "PT-M27-02"
      ],
      "title": "Eletrocardiograma de 12 derivações à beira-leito",
      "priority": "P0",
      "level": "Básico",
      "scope": "Diagnóstico à beira-leito",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Eletrocardiógrafo de 12 derivações, eletrodos compatíveis, condutor quando apropriado, papel/registro digital e material para preparo da pele"
      ],
      "criticalErrors": [
        "Troca de identificação do paciente",
        "Ignorar suspeita de evento cardíaco agudo durante preparação"
      ],
      "fields": {
        "definition": [
          "Registro não invasivo da atividade elétrica cardíaca com posicionamento padronizado de eletrodos e identificação adequada."
        ],
        "indications": [
          "Investigação de sintomas cardíacos, arritmias, monitoramento e situações agudas conforme avaliação clínica."
        ],
        "contraindications": [
          "Não postergar atendimento urgente para aguardar ECG; artefatos e posicionamento inadequado exigem repetição."
        ],
        "anatomy": [
          "Identificar referências anatômicas para V1-V6 e membros; reconhecer diferenças em condições especiais."
        ],
        "materials": [
          "Eletrodos, cabos, equipamento calibrado e papel/registros; conferir integridade e limpeza do sistema."
        ],
        "environment": [
          "Preparar superfície, controle de interferências, isolamento elétrico e privacidade."
        ],
        "patient": [
          "Confirmar identidade, explicar procedimento e obter posição tolerável, expondo apenas áreas necessárias."
        ],
        "analgesia": [
          "Indolor; analgesia não é necessária, exceto manejo de dor do quadro clínico concomitante."
        ],
        "sequence": [
          "Conferir identificação e qualidade do equipamento",
          "Preparar pele",
          "Localizar pontos anatômicos e posicionar eletrodos segundo padrão de 12 derivações",
          "Solicitar imobilidade breve",
          "Registrar e conferir calibração/artefatos."
        ],
        "confirmation": [
          "Obtém traçado legível, com nome e data corretos, 12 derivações, velocidade e amplitude registradas."
        ],
        "complications": [
          "Inversão de cabos, derivações precordiais mal posicionadas, artefatos, interpretação precipitada; repetir traçado quando necessário."
        ],
        "aftercare": [
          "Encaminhar interpretação ao profissional responsável e comunicar imediatamente resultados críticos conforme fluxo local."
        ],
        "skills-checklist": [
          "Posiciona eletrodos pelo marco anatômico",
          "Confere qualidade e dados",
          "Reconhece artefatos",
          "Comunica urgência."
        ],
        "media-references": [
          "Esta ficha cobre aquisição técnica, não interpretação cardiológica completa.",
          "Vídeo não cadastrado: inclusão prevista no MB06 com crédito e revisão técnica.",
          "Fontes e data de conferência identificadas na seção final da ficha."
        ]
      },
      "references": [
        {
          "id": "ECG-CHSS",
          "title": "CHSS eLearning — ECG de 12 derivações e posicionamento",
          "url": "https://www.chsselearning.org.uk/hearte/9-cardiac-investigations/electrocardiography/12-lead-ecg/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "WHO-HAND",
          "title": "OMS — Cinco momentos para higiene das mãos",
          "url": "https://www.who.int/campaigns/world-hand-hygiene-day/key-resources-on-hand-hygiene",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-03",
      "topicIds": [
        "PT-M04-03"
      ],
      "title": "Administração intradérmica de medicamentos e testes",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Seringa graduada de precisão, agulha apropriada, antisséptico e descarte imediato.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Produto usado na rota errada",
        "Leitura fora do intervalo indicado"
      ],
      "fields": {
        "definition": [
          "Administração superficial na derme para indicações autorizadas; não confundir com rotas intramuscular ou subcutânea."
        ],
        "indications": [
          "Testes e produtos expressamente indicados para via intradérmica, segundo bula e protocolo."
        ],
        "contraindications": [
          "Não aplicar produto cuja via seja diferente; avaliar dermatose no sítio e histórico de hipersensibilidade."
        ],
        "anatomy": [
          "Derme superficial; local depende da finalidade, com atenção à integridade da pele."
        ],
        "materials": [
          "Seringa graduada de precisão, agulha apropriada, antisséptico e descarte imediato. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Conferir paciente, produto, concentração e finalidade",
          "Selecionar e inspecionar área sem lesão",
          "Executar simulação de posicionamento e técnica segundo protocolo validado",
          "Identificar e registrar local, lote e reação observada"
        ],
        "confirmation": [
          "Registro de administração e leitura do resultado na janela definida pelo teste, quando pertinente."
        ],
        "complications": [
          "Reação local, aplicação em plano incorreto, erro de interpretação e reação sistêmica."
        ],
        "aftercare": [
          "Instruir sobre retorno para leitura e sinais de reação; não manipular a lesão de teste."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-VAC",
          "title": "CDC — Vaccine administration, route and sterile technique",
          "url": "https://www.cdc.gov/vaccines/hcp/imz-best-practices/vaccine-administration.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-04",
      "topicIds": [
        "PT-M04-04"
      ],
      "title": "Administração subcutânea",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Seringa/agulha ou dispositivo de aplicação apropriados, antisséptico e recipiente de descarte.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Reutilizar seringa ou agulha",
        "Administrar via SC uma formulação não aprovada"
      ],
      "fields": {
        "definition": [
          "Administração no tecido adiposo subcutâneo quando formulação e prescrição permitem."
        ],
        "indications": [
          "Medicamentos aprovados para SC, com plano de rodízio quando uso repetido."
        ],
        "contraindications": [
          "Não usar em pele infectada, área com lipodistrofia importante ou formulação não autorizada."
        ],
        "anatomy": [
          "Tecido entre a derme e o músculo; espessura variável por idade e biotipo."
        ],
        "materials": [
          "Seringa/agulha ou dispositivo de aplicação apropriados, antisséptico e recipiente de descarte. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Confirmar medicamento, dispositivo e via prescrita",
          "Avaliar e selecionar área adequada, considerando rodízio",
          "Simular técnica asséptica de aplicação e descarte de uso único",
          "Registrar sítio, horário e reações"
        ],
        "confirmation": [
          "Confirmação de dose e via com registro; monitorar resposta esperada para o fármaco."
        ],
        "complications": [
          "Hipoglicemia quando aplicável, hematoma, lipodistrofia, reação local e dose incorreta."
        ],
        "aftercare": [
          "Orientar rodízio de locais, vigilância para reação e descarte doméstico seguro quando pertinente."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-VAC",
          "title": "CDC — Vaccine administration, route and sterile technique",
          "url": "https://www.cdc.gov/vaccines/hcp/imz-best-practices/vaccine-administration.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-06",
      "topicIds": [
        "PT-M04-06"
      ],
      "title": "Administração intravenosa de medicamentos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-001",
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-MED-001"
      ],
      "additionalSupplies": [
        "Cateter funcional, conector, extensão, seringas de uso único e diluente validado pela bula.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Infundir com acesso infiltrado",
        "Confundir IV push com infusão lenta indicada"
      ],
      "fields": {
        "definition": [
          "Introdução de medicamento prescrito pela via intravenosa, usando acesso comprovadamente funcionante e compatível."
        ],
        "indications": [
          "Quando o tratamento exigir efeito IV e a apresentação permitir essa via."
        ],
        "contraindications": [
          "Acesso com suspeita de extravasamento, incompatibilidade, indicação ou concentração não verificada."
        ],
        "anatomy": [
          "Anatomia vascular e posição do cateter, relação com pele, tecidos adjacentes e dispositivo."
        ],
        "materials": [
          "Cateter funcional, conector, extensão, seringas de uso único e diluente validado pela bula. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Conferir prescrição, alergias e identificação do acesso",
          "Verificar compatibilidade, necessidade de diluição e velocidade conforme protocolo",
          "Inspecionar local e permeabilidade, mantendo assepsia de conectores",
          "Simular administração/monitorização e documentar resposta"
        ],
        "confirmation": [
          "Sem sinais de infiltração; confirmação documentada de via, dose e velocidade autorizadas."
        ],
        "complications": [
          "Flebite, extravasamento, reação anafilática, infusão rápida, embolia ou incompatibilidade."
        ],
        "aftercare": [
          "Monitorar local e efeitos; interromper e acionar protocolo se houver reação ou extravasamento."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-07",
      "topicIds": [
        "PT-M04-07"
      ],
      "title": "Infusão intermitente e contínua",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-INF-003"
      ],
      "additionalSupplies": [
        "Equipo identificado, solução prescrita, bomba quando indicada, extensor e conectores compatíveis.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Bomba sem verificação",
        "Conexões incompatíveis ou via não conferida"
      ],
      "fields": {
        "definition": [
          "Entrega controlada de soluções ou fármacos IV por gravidade ou dispositivo apropriado."
        ],
        "indications": [
          "Fluidoterapia e terapias IV em regimes intermitente ou contínuo conforme prescrição."
        ],
        "contraindications": [
          "Produto, compatibilidade, acesso ou velocidade ainda não checados; restrições de volume individual."
        ],
        "anatomy": [
          "Sistema de infusão, acesso vascular e vulnerabilidade a extravasamento."
        ],
        "materials": [
          "Equipo identificado, solução prescrita, bomba quando indicada, extensor e conectores compatíveis. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Confirmar solução, paciente, acesso e regime",
          "Planejar início e término conforme prescrição",
          "Conferir compatibilidades e programação independente em alto risco",
          "Reavaliar sinais vitais, sítio e alarmes, registrando volumes"
        ],
        "confirmation": [
          "Balanço de entrada compatível com prescrição e monitorização de acesso e resposta clínica."
        ],
        "complications": [
          "Sobrecarga hídrica, subinfusão, bolus inadvertido, infecção e oclusão."
        ],
        "aftercare": [
          "Registrar volume, intercorrências, troca de sistema e decisão de suspensão."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-08",
      "topicIds": [
        "PT-M04-08"
      ],
      "title": "Reconstituição e diluição de medicamentos",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-MED-003"
      ],
      "additionalSupplies": [
        "Frasco, diluente indicado, dispositivos estéreis, rotulagem e referência farmacotécnica.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Confundir mg com mL",
        "Usar diluente não aprovado"
      ],
      "fields": {
        "definition": [
          "Preparação asséptica da forma farmacêutica e da concentração prescrita."
        ],
        "indications": [
          "Produtos que exigem diluente e concentração finais definidos em bula ou prescrição validada."
        ],
        "contraindications": [
          "Não improvisar diluente ou misturar soluções de compatibilidade desconhecida."
        ],
        "anatomy": [
          "Área limpa de preparo e dispositivos estéreis; não corresponde a um sítio anatômico."
        ],
        "materials": [
          "Frasco, diluente indicado, dispositivos estéreis, rotulagem e referência farmacotécnica. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Ler rótulo e instrução do fabricante, conferindo unidades",
          "Confirmar estabilidade, diluente e concentração-alvo",
          "Simular cálculo com dupla checagem e rotular concentração/horário",
          "Manter assepsia e descarte conforme condições de uso"
        ],
        "confirmation": [
          "Concentração, lote, validade e diluente documentados de forma verificável."
        ],
        "complications": [
          "Erro de dez vezes, incompatibilidade, contaminação, perda de estabilidade e sobredosagem."
        ],
        "aftercare": [
          "Não conservar fora das condições recomendadas; rastrear preparo e administração."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-09",
      "topicIds": [
        "PT-M04-09"
      ],
      "title": "Bombas de infusão: programação e alarmes",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INF-001",
        "MAT-INF-002",
        "MAT-INF-003"
      ],
      "additionalSupplies": [
        "Bomba, equipo específico do modelo, etiquetas e solução prescrita.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar alarme",
        "Trocar equipamento sem conferir a taxa"
      ],
      "fields": {
        "definition": [
          "Controle programável de taxa, volume e duração em sistemas de infusão compatíveis."
        ],
        "indications": [
          "Fármacos e soluções cuja precisão exige bomba conforme protocolo."
        ],
        "contraindications": [
          "Sem confirmação da prescrição, do equipo compatível ou calibração/dispositivo funcional."
        ],
        "anatomy": [
          "Circuito infusional, conectores, acesso e medidas de pressão do equipamento."
        ],
        "materials": [
          "Bomba, equipo específico do modelo, etiquetas e solução prescrita. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Identificar paciente, solução e biblioteca de drogas da bomba",
          "Conferir unidades, volume, taxa e limites com dupla checagem quando exigida",
          "Simular montagem e teste de alarmes sem uso em paciente",
          "Documentar parâmetros e plano para interrupção de energia"
        ],
        "confirmation": [
          "Parâmetros condizentes com prescrição; alarmes e verificação de sistema registrados."
        ],
        "complications": [
          "Oclusão, ar, taxa incorreta, interrupção súbita e atraso no reconhecimento de extravasamento."
        ],
        "aftercare": [
          "Responder a alarmes pelo manual do equipamento; registrar trocas e rastreabilidade."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M04-10",
      "topicIds": [
        "PT-M04-10"
      ],
      "title": "Barreiras para medicamentos de alta vigilância",
      "priority": "P0",
      "level": "Básico",
      "scope": "Administração de medicamentos",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-MED-001",
        "MAT-INF-003"
      ],
      "additionalSupplies": [
        "Rótulos padronizados, prescrição, bomba quando indicada e barreiras de dupla verificação.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar dupla checagem obrigatória",
        "Uso de abreviação ambígua de dose"
      ],
      "fields": {
        "definition": [
          "Conjunto de controles para medicamentos com dano potencial elevado em caso de erro."
        ],
        "indications": [
          "Insulina, anticoagulantes, eletrólitos concentrados e outros definidos pela lista institucional."
        ],
        "contraindications": [
          "Nunca administrar sem prescrição verificável, concentração rastreável e condições de monitorização."
        ],
        "anatomy": [
          "Vias e dispositivos diferem por produto; risco amplificado por dose/concentração."
        ],
        "materials": [
          "Rótulos padronizados, prescrição, bomba quando indicada e barreiras de dupla verificação. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Identificar fármaco de alto risco e aplicar protocolo específico",
          "Conferir dose, unidade, concentração, diluente, via, paciente e peso quando indicado",
          "Executar checagem independente real, sem mera assinatura",
          "Planejar monitorização laboratorial/clínica e reversão quando aplicável"
        ],
        "confirmation": [
          "Barreiras cumpridas, campos documentados e monitorização planejada antes do início."
        ],
        "complications": [
          "Erro grave de dose, hipoglicemia, sangramento e distúrbios eletrolíticos."
        ],
        "aftercare": [
          "Reconciliar medicamentos, reportar quase-erros e rever parâmetros ao transferir o paciente."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-MED",
          "title": "OMS — Medication Without Harm, 2024",
          "url": "https://www.who.int/publications/i/item/9789240062764",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M05-03",
      "topicIds": [
        "PT-M05-03"
      ],
      "title": "Coleta para hemocultura",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Acessos vasculares",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-VAS-001",
        "MAT-VAS-002",
        "MAT-MED-002"
      ],
      "additionalSupplies": [
        "Conjunto de frascos conforme sistema laboratorial, antisséptico, material de venopunção e identificação.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Coletar após tocar novamente área antisséptica sem medida apropriada",
        "Frascos identificados incorretamente"
      ],
      "fields": {
        "definition": [
          "Coleta asséptica de sangue para detecção de microrganismos em suspeita de infecção de corrente sanguínea."
        ],
        "indications": [
          "Suspeita clínica de bacteremia ou sepse de acordo com avaliação e protocolo."
        ],
        "contraindications": [
          "Coleta sem identificação, frascos não adequados, volume ou momento não planejados."
        ],
        "anatomy": [
          "Veias periféricas e contaminação potencial por flora da pele ou conectores."
        ],
        "materials": [
          "Conjunto de frascos conforme sistema laboratorial, antisséptico, material de venopunção e identificação. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Confirmar indicação, dois identificadores e quantidade de conjuntos",
          "Realizar antissepsia da pele e septos dos frascos conforme orientação",
          "Planejar coleta preferencial antes de antibiótico se não atrasar tratamento essencial",
          "Registrar volumes, horários, locais e responsável por cada conjunto"
        ],
        "confirmation": [
          "Conjuntos corretamente identificados, volume aferido e transporte ao laboratório sem atraso indevido."
        ],
        "complications": [
          "Contaminação por flora cutânea, falso negativo por baixo volume e atraso terapêutico."
        ],
        "aftercare": [
          "Comunicar dificuldade de coleta e resultados críticos segundo fluxos assistenciais."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-BLOOD",
          "title": "CDC — Collect adult blood culture sets, 2026",
          "url": "https://www.cdc.gov/lab-quality/php/preventing-adult-blood-culture-contamination/collect.html",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-INJ",
          "title": "CDC — Preventing unsafe injection practices",
          "url": "https://www.cdc.gov/injection-safety/hcp/clinical-safety/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-02",
      "topicIds": [
        "PT-M06-02"
      ],
      "title": "Hemostasia inicial de feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Gaze apropriada, compressas, luvas, material de curativo e recursos de escalonamento.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Atrasar emergência diante de instabilidade",
        "Ignorar déficit neurovascular"
      ],
      "fields": {
        "definition": [
          "Controle imediato de sangramento externo e identificação de hemorragia potencialmente grave."
        ],
        "indications": [
          "Sangramento por lesão tecidual, enquanto se avalia mecanismo e estabilidade."
        ],
        "contraindications": [
          "Não insistir em tratamento local isolado frente a instabilidade ou hemorragia não controlada."
        ],
        "anatomy": [
          "Vasos superficiais/profundos; proximidade de tendões, nervos e articulações."
        ],
        "materials": [
          "Gaze apropriada, compressas, luvas, material de curativo e recursos de escalonamento. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar segurança da cena, prioridades ABC e gravidade do sangramento",
          "Simular compressão direta contínua sem interrupções desnecessárias",
          "Reavaliar perfusão distal e solicitar ajuda urgente em sangramento importante",
          "Registrar localização, características e resposta"
        ],
        "confirmation": [
          "Redução/controle do sangramento com perfusão e avaliação clínica preservadas."
        ],
        "complications": [
          "Choque hemorrágico, hematoma, isquemia e lesão não identificada."
        ],
        "aftercare": [
          "Reavaliar curativo e sinais vitais; encaminhar sangramento refratário."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-WOUND25",
          "title": "AAFP — Laceration repair best practices, 2025",
          "url": "https://www.aafp.org/afp/afp-community-blog/laceration-repair-best-practices",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-04",
      "topicIds": [
        "PT-M06-04"
      ],
      "title": "Limpeza e remoção de contaminantes de feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-004",
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Solução adequada para irrigação, gaze, pinça apropriada e barreiras.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Suturar antes de explorar contaminantes",
        "Manipular corpo estranho profundo sem avaliação"
      ],
      "fields": {
        "definition": [
          "Remoção de sujeira e partículas acessíveis após avaliação de estruturas e riscos."
        ],
        "indications": [
          "Feridas com contaminantes ou corpos estranhos superficiais após estabilização."
        ],
        "contraindications": [
          "Não explorar profundamente sem condições ou treinamento; suspeita de corpo estranho profundo exige investigação."
        ],
        "anatomy": [
          "Camadas cutâneas e estruturas subjacentes vulneráveis."
        ],
        "materials": [
          "Solução adequada para irrigação, gaze, pinça apropriada e barreiras. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Identificar mecanismo, extensão, corpo estranho e estruturas em risco",
          "Selecionar irrigação compatível e controlar dor",
          "Remover contaminantes visíveis sem agressão desnecessária, com supervisão",
          "Reavaliar necessidade de imagem, desbridamento ou encaminhamento"
        ],
        "confirmation": [
          "Ferida avaliada quanto a partículas residuais e integridade estrutural antes do fechamento."
        ],
        "complications": [
          "Retenção de fragmentos, infecção, trauma adicional por exploração e atraso diagnóstico."
        ],
        "aftercare": [
          "Registrar material removido, orientação de retorno e sinais de alarme."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-WOUND25",
          "title": "AAFP — Laceration repair best practices, 2025",
          "url": "https://www.aafp.org/afp/afp-community-blog/laceration-repair-best-practices",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-08",
      "topicIds": [
        "PT-M06-08"
      ],
      "title": "Reconhecimento de infecção em feridas",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Material de exame e curativo; coleta de amostra apenas quando clinicamente indicada.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar dor desproporcional",
        "Tratar sepse apenas com curativo"
      ],
      "fields": {
        "definition": [
          "Avaliação clínica de possível infecção local, disseminada ou complicação de cicatrização."
        ],
        "indications": [
          "Dor progressiva, eritema crescente, calor, secreção, febre ou atraso de cicatrização."
        ],
        "contraindications": [
          "Não assumir que toda secreção ou eritema equivale a infecção; diferenciais precisam de avaliação."
        ],
        "anatomy": [
          "Pele e tecidos profundos, drenagem linfática e sinais de extensão."
        ],
        "materials": [
          "Material de exame e curativo; coleta de amostra apenas quando clinicamente indicada. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Comparar evolução temporal, sinais locais e sistêmicos",
          "Verificar presença de flutuação, necrose, crepitação ou dor desproporcional",
          "Avaliar gravidade e necessidade de investigação/encaminhamento",
          "Documentar achados e plano de reavaliação"
        ],
        "confirmation": [
          "Estratificação de gravidade com plano de conduta e retorno definido."
        ],
        "complications": [
          "Abscesso não drenado, sepse, fasciíte necrosante e atraso terapêutico."
        ],
        "aftercare": [
          "Orientar retorno imediato em deterioração rápida, febre importante ou sinais sistêmicos."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND25",
          "title": "AAFP — Laceration repair best practices, 2025",
          "url": "https://www.aafp.org/afp/afp-community-blog/laceration-repair-best-practices",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-10",
      "topicIds": [
        "PT-M06-10"
      ],
      "title": "Cuidados posteriores de feridas e retorno",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001"
      ],
      "additionalSupplies": [
        "Cobertura adequada, material de higiene e orientações documentadas.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Não informar sinais de alarme",
        "Omitir seguimento em ferida de alto risco"
      ],
      "fields": {
        "definition": [
          "Seguimento de cicatrização, orientações e vigilância de complicações de feridas."
        ],
        "indications": [
          "Após limpeza, fechamento, curativo, desbridamento ou decisão de cicatrização secundária."
        ],
        "contraindications": [
          "Orientações genéricas sem considerar tipo de fechamento, comorbidades e exposição."
        ],
        "anatomy": [
          "Fases de cicatrização, perfusão local e tensão sobre os tecidos."
        ],
        "materials": [
          "Cobertura adequada, material de higiene e orientações documentadas. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Registrar tipo e localização da lesão e intervenção",
          "Orientar higiene, proteção, trocas de curativo e controle de dor individualizados",
          "Definir retorno e retirada de suturas conforme região e evolução",
          "Informar sinais de infecção, deiscência e quando buscar urgência"
        ],
        "confirmation": [
          "Paciente compreende cuidados, sinais de alarme e plano de acompanhamento."
        ],
        "complications": [
          "Infecção, maceração, deiscência e cicatriz hipertrófica."
        ],
        "aftercare": [
          "Reavaliar comorbidades e risco de tétano conforme classificação da ferida."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-TETANUS",
          "title": "CDC — Clinical guidance for wound management to prevent tetanus",
          "url": "https://www.cdc.gov/tetanus/hcp/clinical-guidance/index.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-04",
      "topicIds": [
        "PT-M07-04"
      ],
      "title": "Sutura contínua",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-INS-003",
        "MAT-INS-004"
      ],
      "additionalSupplies": [
        "Porta-agulhas, pinça, tesoura e fio/agulha adequados ao tecido.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Tracionar até isquemia da borda",
        "Fechar ferida contaminada sem avaliação"
      ],
      "fields": {
        "definition": [
          "Fechamento sequencial com fio contínuo, selecionado conforme tecido e tensão."
        ],
        "indications": [
          "Feridas adequadas à aproximação contínua após irrigação, inspeção e hemostasia."
        ],
        "contraindications": [
          "Contaminação relevante, tensão excessiva ou necessidade de drenagem podem tornar inadequada."
        ],
        "anatomy": [
          "Derme, bordas, eversão e linhas de tensão local."
        ],
        "materials": [
          "Porta-agulhas, pinça, tesoura e fio/agulha adequados ao tecido. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar ferida, necessidade de fechamento e analgesia",
          "Demonstrar em simulador início, espaçamento regular e término da linha",
          "Observar eversão, perfusão das bordas e ausência de estrangulamento",
          "Registrar tipo de sutura e plano de retirada"
        ],
        "confirmation": [
          "Bordas alinhadas, perfundidas, sem espaço morto ou tensão excessiva."
        ],
        "complications": [
          "Deiscência de toda a linha, necrose por tensão e marca de sutura."
        ],
        "aftercare": [
          "Cuidados locais, retorno por infecção/deiscência e cronograma de retirada."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-05",
      "topicIds": [
        "PT-M07-05"
      ],
      "title": "Sutura colchoeiro vertical",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Porta-agulhas, pinça, fios adequados e simulador de sutura.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Apertar excessivamente",
        "Ignorar isquemia do retalho"
      ],
      "fields": {
        "definition": [
          "Técnica de eversão de bordas, com passagens em profundidades distintas."
        ],
        "indications": [
          "Feridas selecionadas em que a eversão ou o controle de tensão é necessário."
        ],
        "contraindications": [
          "Risco de isquemia por compressão ou tecido friável; não substitui fechamento por planos quando preciso."
        ],
        "anatomy": [
          "Planos dérmico superficial/profundo; avaliar vascularização marginal."
        ],
        "materials": [
          "Porta-agulhas, pinça, fios adequados e simulador de sutura. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Inspecionar tensão, profundidade e viabilidade das bordas",
          "Demonstrar trajetos em simulador, distinguindo pontos superficial e profundo",
          "Aproximar sem estrangular a pele",
          "Reavaliar eversão, alinhamento e perfusão"
        ],
        "confirmation": [
          "Eversão suave e ausência de palidez persistente ou pregueamento importante."
        ],
        "complications": [
          "Necrose marginal, cicatriz em trilho e dor por tensão."
        ],
        "aftercare": [
          "Acompanhar bordas e tempo de retirada adaptado à localização."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-06",
      "topicIds": [
        "PT-M07-06"
      ],
      "title": "Sutura colchoeiro horizontal",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Fio e agulha adequados, pinça e porta-agulhas.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Estrangular margens",
        "Ignorar edema progressivo"
      ],
      "fields": {
        "definition": [
          "Ponto de aproximação e distribuição de tensão em segmentos de borda."
        ],
        "indications": [
          "Feridas em regiões selecionadas com necessidade de eversão/distribuição de tensão."
        ],
        "contraindications": [
          "Tecido vascularmente comprometido, risco de estrangulamento ou bordas muito delicadas."
        ],
        "anatomy": [
          "Perfusão marginal cutânea e relação do ponto com a borda da lesão."
        ],
        "materials": [
          "Fio e agulha adequados, pinça e porta-agulhas. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Examinar perfusão e necessidade de fechamento profundo",
          "Demonstrar configuração horizontal sobre manequim",
          "Manter aproximação com tensão mínima efetiva",
          "Reavaliar cor das bordas e registrar técnica"
        ],
        "confirmation": [
          "Aproximação simétrica, sem isquemia de bordas."
        ],
        "complications": [
          "Necrose por compressão, cicatriz excessiva e deiscência."
        ],
        "aftercare": [
          "Inspecionar pele e promover retirada no período clinicamente apropriado."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-07",
      "topicIds": [
        "PT-M07-07"
      ],
      "title": "Sutura intradérmica contínua",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-002",
        "MAT-SUT-001",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Fio absorvível ou não absorvível apropriado e porta-agulhas.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Fechar espaço morto importante só com intradérmica",
        "Aplicar em ferida infectada sem avaliação"
      ],
      "fields": {
        "definition": [
          "Aproximação cutânea por trajeto dérmico, geralmente para feridas limpas de baixa tensão."
        ],
        "indications": [
          "Incisões e feridas selecionadas com bordas bem alinhadas e tensão controlada."
        ],
        "contraindications": [
          "Ferida infectada, grande tensão ou necessidade de drenagem podem contraindicar fechamento fechado."
        ],
        "anatomy": [
          "Derme e planos de tensão; considerar necessidade de pontos profundos."
        ],
        "materials": [
          "Fio absorvível ou não absorvível apropriado e porta-agulhas. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar contaminação, hemostasia e alinhamento",
          "Simular passagem intradérmica mantendo plano regular",
          "Examinar se o fechamento é estável sem tensão excessiva",
          "Planejar cobertura e seguimento"
        ],
        "confirmation": [
          "Bordas aproximadas sem depressões ou tensão indevida."
        ],
        "complications": [
          "Deiscência, infecção retida e extrusão de fio."
        ],
        "aftercare": [
          "Monitorar ferida e informar uso de fio absorvível ou necessidade de remoção."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-08",
      "topicIds": [
        "PT-M07-08"
      ],
      "title": "Fechamento dérmico profundo",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-002",
        "MAT-INS-003"
      ],
      "additionalSupplies": [
        "Fio absorvível, porta-agulhas e instrumental adequado.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Suturar estrutura não identificada",
        "Fechar tecido desvitalizado"
      ],
      "fields": {
        "definition": [
          "Aproximação dos planos profundos para reduzir tensão superficial e espaço morto."
        ],
        "indications": [
          "Lacerações selecionadas com necessidade de reparo por camadas, após exclusão de lesão estrutural."
        ],
        "contraindications": [
          "Não utilizar para esconder infecção, tecido desvitalizado ou lesão de tendão/nervo não tratada."
        ],
        "anatomy": [
          "Derme profunda e tecido subcutâneo, sem invadir estruturas vasculonervosas."
        ],
        "materials": [
          "Fio absorvível, porta-agulhas e instrumental adequado. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Inspecionar anatomia e necessidade real do plano profundo",
          "Simular aproximação por camadas evitando incorporação de estruturas indevidas",
          "Confirmar redução de espaço morto e tensão superficial",
          "Documentar material implantado e planos fechados"
        ],
        "confirmation": [
          "Redução do espaço morto sem comprometimento da perfusão."
        ],
        "complications": [
          "Hematoma, corpo estranho, infecção profunda e lesão estrutural."
        ],
        "aftercare": [
          "Acompanhar sinais de infecção profunda e deiscência."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-09",
      "topicIds": [
        "PT-M07-09"
      ],
      "title": "Adesivos cutâneos e fitas de aproximação",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-003",
        "MAT-CLO-001"
      ],
      "additionalSupplies": [
        "Adesivo médico apropriado ou fitas estéreis, barreiras e limpeza.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Colocar adesivo dentro da ferida",
        "Usar em ferida de alta tensão sem suporte"
      ],
      "fields": {
        "definition": [
          "Fechamento externo sem sutura em feridas superficiais selecionadas e de baixa tensão."
        ],
        "indications": [
          "Feridas lineares pequenas, limpas e de bordas facilmente aproximáveis."
        ],
        "contraindications": [
          "Feridas úmidas, infectadas, sob tensão significativa, em mucosas ou próximas aos olhos sem técnica específica."
        ],
        "anatomy": [
          "Epiderme e derme superficial; evitar que adesivo penetre no leito da ferida."
        ],
        "materials": [
          "Adesivo médico apropriado ou fitas estéreis, barreiras e limpeza. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo.",
          "Consulte 1 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar indicação, tensão e contaminação",
          "Limpar e secar bordas conforme o produto",
          "Simular aproximação mantendo adesivo apenas externamente",
          "Orientar tempo de desprendimento e cuidados locais"
        ],
        "confirmation": [
          "Bordas mantidas alinhadas, sem contato inadequado com olhos ou mucosas."
        ],
        "complications": [
          "Dermatite, deiscência e união incorreta de tecidos."
        ],
        "aftercare": [
          "Não remover agressivamente o filme; reavaliar abertura ou sinais de infecção."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-10",
      "topicIds": [
        "PT-M07-10"
      ],
      "title": "Grampos cutâneos",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-003",
        "MAT-CLO-002"
      ],
      "additionalSupplies": [
        "Grampeador médico, removedor apropriado, pinça e material de antissepsia.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Aplicar sobre estrutura não avaliada",
        "Omitir registro/contagem de grampos"
      ],
      "fields": {
        "definition": [
          "Fechamento mecânico superficial de incisões ou feridas selecionadas."
        ],
        "indications": [
          "Incisões lineares, frequentemente couro cabeludo/tronco, de acordo com a indicação."
        ],
        "contraindications": [
          "Evitar em localização de exigência estética alta e sem hemostasia/avaliação das estruturas."
        ],
        "anatomy": [
          "Pele e tensão local; grampos não corrigem lesões profundas."
        ],
        "materials": [
          "Grampeador médico, removedor apropriado, pinça e material de antissepsia. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo.",
          "Consulte 1 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Reavaliar ferida, hemostasia e elegibilidade do fechamento",
          "Simular alinhamento cutâneo e aplicação com espaçamento regular",
          "Conferir eversão e alinhamento sem compressão excessiva",
          "Contar/documentar grampos e retirada programada"
        ],
        "confirmation": [
          "Aproximação estável das margens com perfusão preservada."
        ],
        "complications": [
          "Dor, infecção, marcas e retenção de grampo."
        ],
        "aftercare": [
          "Planejar remoção conforme localização e cicatrização; orientar inspeção."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-WOUND",
          "title": "AAFP — Laceration repair: a practical approach",
          "url": "https://www.aafp.org/afp/2017/0515/p628",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-03",
      "topicIds": [
        "PT-M13-03"
      ],
      "title": "Tala tipo sugar-tong do antebraço",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005",
        "MAT-ORT-001",
        "MAT-ORT-002",
        "MAT-ORT-003",
        "MAT-ORT-005"
      ],
      "additionalSupplies": [
        "Material de tala, acolchoamento, malha tubular e faixas; equipamento de corte seguro.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Não checar pulsos/sensibilidade",
        "Enfaixar excessivamente apertado"
      ],
      "fields": {
        "definition": [
          "Tala não circular que limita pronação e supinação do antebraço e estabiliza lesões selecionadas."
        ],
        "indications": [
          "Fraturas distais de rádio/ulna após avaliação e estabilização inicial, quando indicada."
        ],
        "contraindications": [
          "Necessidade de intervenção emergencial ou lesão neurovascular exige prioridade assistencial."
        ],
        "anatomy": [
          "Punho, antebraço, cotovelo e pontos de pressão óssea."
        ],
        "materials": [
          "Material de tala, acolchoamento, malha tubular e faixas; equipamento de corte seguro. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo.",
          "Consulte 4 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Registrar avaliação neurovascular e pele antes de começar",
          "Simular acolchoamento e moldagem ao redor do cotovelo em manequim",
          "Evitar compressão circular e regiões de atrito",
          "Reavaliar perfusão, sensibilidade e movimento distal após a aplicação"
        ],
        "confirmation": [
          "Alinhamento provisório e exame neurovascular distal mantido; controle clínico/imagem conforme indicação."
        ],
        "complications": [
          "Compressão, queimadura de cura, parestesia, perda de redução e síndrome compartimental."
        ],
        "aftercare": [
          "Orientar elevação conforme caso, não molhar e retorno imediato por dor crescente ou dedos frios."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-SUGAR",
          "title": "Merck Manual — Sugar-tong arm splint, 2026",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-an-upper-limb/how-to-apply-a-sugar-tong-arm-splint",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-05",
      "topicIds": [
        "PT-M13-05"
      ],
      "title": "Tala posterior de membro inferior",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005",
        "MAT-ORT-001",
        "MAT-ORT-002",
        "MAT-ORT-003",
        "MAT-ORT-005"
      ],
      "additionalSupplies": [
        "Gesso ou material sintético de tala, acolchoamento, malha tubular e faixa elástica.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Ignorar lesão aberta",
        "Deixar tala circunferencial rígida no edema importante"
      ],
      "fields": {
        "definition": [
          "Imobilização não circunferencial da perna e tornozelo, útil no edema inicial."
        ],
        "indications": [
          "Entorses ou fraturas selecionadas e imobilização provisória antes de intervenção."
        ],
        "contraindications": [
          "Lesão aberta ou instável requer cuidado concomitante e avaliação urgente; posição depende da lesão."
        ],
        "anatomy": [
          "Região posterior da perna, calcâneo, maléolos e cabeças metatarsais."
        ],
        "materials": [
          "Gesso ou material sintético de tala, acolchoamento, malha tubular e faixa elástica. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo.",
          "Consulte 4 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Avaliar feridas e estado neurovascular distal",
          "Simular medida, proteção de saliências e posicionamento do tornozelo conforme lesão",
          "Moldar tala sem pressão focal e fixar sem circular apertado",
          "Repetir exame neurovascular e registrar resultado"
        ],
        "confirmation": [
          "Tala íntegra e confortável, sem alteração de perfusão, motricidade ou sensibilidade."
        ],
        "complications": [
          "Pontos de pressão, queimadura térmica, isquemia e deslocamento."
        ],
        "aftercare": [
          "Orientar não apoiar sem autorização e retorno urgente para dor progressiva ou alteração distal."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-SPLINT",
          "title": "Merck Manual — How to apply a posterior ankle splint",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-a-lower-limb/how-to-apply-a-posterior-ankle-splint",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-06",
      "topicIds": [
        "PT-M13-06"
      ],
      "title": "Gesso circular: indicação, segurança e vigilância",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005",
        "MAT-ORT-001",
        "MAT-ORT-002",
        "MAT-ORT-003",
        "MAT-ORT-004"
      ],
      "additionalSupplies": [
        "Malha, algodão ortopédico, gesso ou fibra apropriada e ferramentas de retirada.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Aplicar circular em edema importante sem avaliação",
        "Ignorar dor desproporcional persistente"
      ],
      "fields": {
        "definition": [
          "Imobilização circunferencial rígida, tipicamente em condição apropriada de edema e estabilidade."
        ],
        "indications": [
          "Fraturas/lesões selecionadas após avaliação ortopédica, muitas vezes após fase inicial com tala."
        ],
        "contraindications": [
          "Edema importante ou comprometimento neurovascular fazem preferir alternativas e reavaliação."
        ],
        "anatomy": [
          "Segmento a imobilizar, proeminências ósseas e avaliação neurovascular distal."
        ],
        "materials": [
          "Malha, algodão ortopédico, gesso ou fibra apropriada e ferramentas de retirada. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo.",
          "Consulte 4 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Conferir indicação, imagem disponível, edema e pele",
          "Treinar acolchoamento homogêneo e modelagem sem pontos de pressão",
          "Identificar riscos térmicos e de constrição",
          "Verificar perfusão/sensibilidade e documentar orientações de emergência"
        ],
        "confirmation": [
          "Conforto inicial e exame distal preservado, com programação de reavaliação."
        ],
        "complications": [
          "Queimadura térmica, lesão de pressão, edema preso, isquemia e síndrome compartimental."
        ],
        "aftercare": [
          "Manter seco, não inserir objetos e buscar emergência por dor desproporcional, dormência ou dedos frios."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-SPLINT",
          "title": "Merck Manual — How to apply a posterior ankle splint",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-a-lower-limb/how-to-apply-a-posterior-ankle-splint",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-11",
      "topicIds": [
        "PT-M13-11"
      ],
      "title": "Reconhecimento de síndrome compartimental",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Material para exame neurovascular e recursos para escalonamento cirúrgico urgente.; validar lista e variações com o procedimento e fabricante."
      ],
      "criticalErrors": [
        "Aguardar pulso desaparecer",
        "Atribuir dor progressiva apenas a ansiedade"
      ],
      "fields": {
        "definition": [
          "Identificação de aumento de pressão dentro de compartimento musculofascial com risco isquêmico."
        ],
        "indications": [
          "Dor progressiva ou desproporcional após trauma, fratura ou imobilização; suspeita clínica é emergência."
        ],
        "contraindications": [
          "Pulsos palpáveis não excluem síndrome compartimental; não observar passivamente paciente com suspeita."
        ],
        "anatomy": [
          "Compartimentos musculares fechados, vasos e nervos vulneráveis a pressão."
        ],
        "materials": [
          "Material para exame neurovascular e recursos para escalonamento cirúrgico urgente. Conferir embalagem, integridade, escala, esterilidade e compatibilidade conforme dispositivo."
        ],
        "environment": [
          "Preparar bancada e equipamento necessários; separar área limpa de materiais usados; conferir iluminação, descarte e acesso à equipe de resgate."
        ],
        "patient": [
          "Confirmar dois identificadores, indicação, alergias e consentimento; avaliar fatores individuais, idade, estado clínico e risco de complicações."
        ],
        "analgesia": [
          "Definir necessidade de conforto, analgesia ou anestesia conforme contexto clínico, prescrição e protocolo; não extrapolar doses entre populações."
        ],
        "sequence": [
          "Considerar mecanismo, imobilização e evolução da dor",
          "Avaliar dor ao alongamento passivo, sensibilidade e motricidade",
          "Acionar avaliação cirúrgica urgente e remover fator compressivo conforme equipe",
          "Documentar horários e reavaliações seriadas sem atrasar intervenção"
        ],
        "confirmation": [
          "Reconhecimento precoce e encaminhamento urgente, não aguardar ausência de pulso."
        ],
        "complications": [
          "Necrose muscular, lesão nervosa permanente, rabdomiólise e perda do membro."
        ],
        "aftercare": [
          "Seguir plano da equipe cirúrgica, monitorização seriada e documentação de evolução."
        ],
        "skills-checklist": [
          "Explica indicação, contraindicações e alternativas",
          "Seleciona e confere materiais, tamanhos e integridade",
          "Demonstra as etapas em ambiente simulado com supervisão",
          "Reconhece riscos e verbaliza quando interromper/acionar ajuda",
          "Registra a execução simulada e o plano de reavaliação"
        ],
        "media-references": [
          "Materiais educativos de referência listados nesta ficha; nenhuma imagem ou vídeo de terceiros foi copiado.",
          "Vídeo externo ainda não selecionado ou validado (MB06).",
          "Revisão clínica institucional obrigatória antes de publicação assistencial."
        ]
      },
      "references": [
        {
          "id": "SRC-MB03-CAST",
          "title": "AAOS OrthoInfo — Cast and splint care",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        },
        {
          "id": "SRC-MB03-SUGAR",
          "title": "Merck Manual — Sugar-tong arm splint, 2026",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-splint-or-immobilize-an-upper-limb/how-to-apply-a-sugar-tong-arm-splint",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-01",
      "topicIds": [
        "PT-M07-01"
      ],
      "title": "Fios de sutura: materiais e seleção",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-001",
        "MAT-SUT-002",
        "MAT-SUT-004",
        "MAT-SUT-005",
        "MAT-SUT-006"
      ],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Escolha incompatível com o tecido, uso sem avaliação de contaminação.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Reconhecer fios absorvíveis e não absorvíveis, mono e multifilamentares, diferenças de memória, resistência e resposta tecidual."
        ],
        "indications": [
          "Quando o fechamento foi indicado e a escolha do fio depende do tecido, tensão, risco de infecção e necessidade de remoção."
        ],
        "contraindications": [
          "Não escolher fio somente pela cor ou número; atenção a alergia, contaminação, tecido isquêmico e indicação de fechamento tardio."
        ],
        "anatomy": [
          "Comparar escala USP, diâmetro nominal, tipo de polímero, absorção e embalagem íntegra."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.",
          "Consulte 5 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Examinar identificação e validade dos fios disponíveis",
          "Associar propriedades ao plano anatômico e à tensão",
          "Justificar a seleção em cenário simulado",
          "Verificar conformidade com protocolo e supervisão"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Escolha incompatível com o tecido, uso sem avaliação de contaminação. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Examinar identificação e validade dos fios disponíveis",
          "Associar propriedades ao plano anatômico e à tensão",
          "Justificar a seleção em cenário simulado",
          "Verificar conformidade com protocolo e supervisão"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M07-01",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M07-02",
      "topicIds": [
        "PT-M07-02"
      ],
      "title": "Agulhas cirúrgicas: curvatura e ponta",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Suturas e fechamento",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-SUT-003"
      ],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Manipular agulha sem instrumental apropriado; descartar incorretamente.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Diferenciar agulhas cilíndricas, cortantes e cortantes reversas, com curvatura e montagem apropriadas ao tecido."
        ],
        "indications": [
          "Planejamento do fechamento de tecidos, considerando profundidade, acesso e risco de lesão."
        ],
        "contraindications": [
          "Não utilizar agulha danificada, não reutilizar material de uso único e não confundir formato com calibre do fio."
        ],
        "anatomy": [
          "Comparar curvatura (por exemplo 3/8 e 1/2 círculo), ponta, comprimento e compatibilidade com porta-agulhas."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.",
          "Consulte 1 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Identificar o tipo de ponta em modelos",
          "Relacionar curvatura à exposição do campo",
          "Demonstrar passagem segura do instrumento em simulação",
          "Conferir integridade antes da utilização"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Manipular agulha sem instrumental apropriado; descartar incorretamente. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Identificar o tipo de ponta em modelos",
          "Relacionar curvatura à exposição do campo",
          "Demonstra passagem segura do instrumento em simulação",
          "Conferir integridade antes da utilização"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M07-02",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-01",
      "topicIds": [
        "PT-M13-01"
      ],
      "title": "Tipóia: suporte do membro superior",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-ORT-005"
      ],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Pressão sobre pescoço, compressão do punho, ausência de reavaliação distal.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Suporte provisório do membro superior para conforto e limitação de movimento em lesões selecionadas."
        ],
        "indications": [
          "Uso quando indicado após avaliação da lesão e da necessidade de imobilização complementar."
        ],
        "contraindications": [
          "Não substituir imobilização definitiva quando ela for necessária; reconsiderar diante de alteração neurovascular."
        ],
        "anatomy": [
          "Inspecionar suporte, pontos de pressão, integridade cutânea, edema e alinhamento tolerado."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.",
          "Consulte 1 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Registrar perfusão, motricidade e sensibilidade antes da aplicação",
          "Selecionar tamanho e ajustar suporte sem comprimir",
          "Inspecionar pontos de pressão e conforto",
          "Reavaliar perfusão e orientar sinais de alarme"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Pressão sobre pescoço, compressão do punho, ausência de reavaliação distal. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Registrar perfusão, motricidade e sensibilidade antes da aplicação",
          "Selecionar tamanho e ajustar suporte sem comprimir",
          "Inspecionar pontos de pressão e conforto",
          "Reavaliar perfusão e orientar sinais de alarme"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M13-01",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-04",
      "topicIds": [
        "PT-M13-04"
      ],
      "title": "Tala tipo U para úmero",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-ORT-001",
        "MAT-ORT-002",
        "MAT-ORT-005"
      ],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Apertar sobre edema, não avaliar função radial, ignorar dor progressiva.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Imobilização temporária do braço em situações selecionadas, com proteção de proeminências ósseas."
        ],
        "indications": [
          "Indicação após avaliação da lesão, neurovascular e da necessidade de redução ou tratamento específico."
        ],
        "contraindications": [
          "Evitar compressão circunferencial excessiva, especialmente na presença de edema progressivo."
        ],
        "anatomy": [
          "Avaliar braço, cotovelo, pele, artéria braquial e função nervosa distal antes e depois."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.",
          "Consulte 3 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Conferir avaliação neurovascular basal",
          "Preparar materiais e acolchoamento em manequim",
          "Demonstrar proteção de proeminências e ajuste seguro",
          "Reexaminar perfusão, sensibilidade e movimento distal"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Apertar sobre edema, não avaliar função radial, ignorar dor progressiva. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Conferir avaliação neurovascular basal",
          "Preparar materiais e acolchoamento em manequim",
          "Demonstra proteção de proeminências e ajuste seguro",
          "Reexaminar perfusão, sensibilidade e movimento distal"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M13-04",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-07",
      "topicIds": [
        "PT-M13-07"
      ],
      "title": "Imobilização do polegar: thumb spica",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-ORT-002",
        "MAT-ORT-005"
      ],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Cobertura compressiva, ausência de retorno para lesão oculta ou dor persistente.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Tala de imobilização seletiva do polegar e do punho em lesões ou suspeitas que exigem proteção."
        ],
        "indications": [
          "Lesões do polegar e suspeita de algumas fraturas do escafoide, condicionadas ao exame e à imagem."
        ],
        "contraindications": [
          "Imobilização não substitui avaliação de lesão instável, aberta ou comprometimento neurovascular."
        ],
        "anatomy": [
          "Avaliar tabaqueira anatômica, polegar, punho, pele e função distal."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.",
          "Consulte 2 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Registrar achados clínicos e necessidade de imagem",
          "Selecionar tamanho e acolchoamento em simulação",
          "Proteger proeminências sem apertar o polegar",
          "Reavaliar perfusão, sensibilidade e mobilidade das partes livres"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Cobertura compressiva, ausência de retorno para lesão oculta ou dor persistente. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Registrar achados clínicos e necessidade de imagem",
          "Selecionar tamanho e acolchoamento em simulação",
          "Proteger proeminências sem apertar o polegar",
          "Reavaliar perfusão, sensibilidade e mobilidade das partes livres"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M13-07",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://www.aafp.org/pubs/afp/issues/2009/0901/p491.html",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-08",
      "topicIds": [
        "PT-M13-08"
      ],
      "title": "Imobilização de dedos e buddy taping",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-ORT-005"
      ],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Prender dedos em desalinhamento, lesão por maceração, tensão excessiva.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Estabilização de lesões selecionadas de dedos com proteção de pele e alinhamento anatômico."
        ],
        "indications": [
          "Lesões estáveis conforme avaliação e exclusão de deformidade que exija outra conduta."
        ],
        "contraindications": [
          "Não aplicar sem avaliação de rotação, estabilidade, lesão tendínea ou déficit neurovascular."
        ],
        "anatomy": [
          "Inspecionar articulações, leito ungueal, alinhamento rotacional, pele entre os dedos."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.",
          "Consulte 1 ficha(s) do Atlas vinculada(s); seleção final sujeita à indicação, protocolo e validação técnica."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Documentar alinhamento, integridade cutânea e exame distal",
          "Selecionar proteção entre dedos em treinamento",
          "Demonstrar estabilização sem compressão",
          "Checar circulação e orientar revisão da pele"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Prender dedos em desalinhamento, lesão por maceração, tensão excessiva. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Documentar alinhamento, integridade cutânea e exame distal",
          "Selecionar proteção entre dedos em treinamento",
          "Demonstra estabilização sem compressão",
          "Checar circulação e orientar revisão da pele"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M13-08",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M13-09",
      "topicIds": [
        "PT-M13-09"
      ],
      "title": "Colar cervical: indicações e limitações",
      "priority": "P0",
      "level": "Intermediário",
      "scope": "Ortopedia e imobilização",
      "population": "Adultos; adaptar para pediatria e gestação por protocolo específico",
      "environment": "Ambulatório, enfermaria, laboratório de simulação ou serviço habilitado conforme procedimento",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Identificação do paciente e consentimento",
        "Biossegurança e técnica asséptica quando indicada",
        "Anatomia, complicações e solicitação de ajuda"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Aplicar tamanho inadequado, prejudicar via aérea, confiar apenas no colar como imobilização.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Recurso de restrição de movimento cervical em pacientes selecionados, integrado à avaliação do trauma."
        ],
        "indications": [
          "Situações de suspeita de lesão cervical conforme critérios clínicos e protocolos de trauma."
        ],
        "contraindications": [
          "Não usar indiscriminadamente nem atrasar manejo da via aérea e outras prioridades de ressuscitação."
        ],
        "anatomy": [
          "Manter referência do alinhamento cervical, avaliar integridade da pele e sinais neurológicos."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Identificar quando restrição de movimento é necessária",
          "Demonstrar medidas de estabilização em manequim",
          "Verificar adequação e riscos de pressão do dispositivo",
          "Reavaliar via aérea, pele e exame neurológico"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Aplicar tamanho inadequado, prejudicar via aérea, confiar apenas no colar como imobilização. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Identificar quando restrição de movimento é necessária",
          "Demonstra medidas de estabilização em manequim",
          "Verificar adequação e riscos de pressão do dispositivo",
          "Reavaliar via aérea, pele e exame neurológico"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M13-09",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://www.facs.org/quality-programs/trauma/education/advanced-trauma-life-support/",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; treinamento em manequim; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M06-05",
      "topicIds": [
        "PT-M06-05"
      ],
      "title": "Desbridamento: avaliação e indicação",
      "priority": "P0",
      "level": "Básico",
      "scope": "Feridas e lesões",
      "population": "Adulto;Pediatria sob protocolo específico",
      "environment": "Ambulatório, enfermaria ou serviço de urgência conforme indicação e estrutura",
      "supervision": "Simulação e execução supervisionada por profissional habilitado",
      "professionalScope": "Conforme habilitação, atribuições legais e protocolo institucional",
      "prerequisites": [
        "Higienização das mãos",
        "Identificação e consentimento",
        "Reconhecimento de eventos adversos"
      ],
      "editorial": {
        "status": "revisao-tecnica",
        "version": "0.2",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [],
      "additionalSupplies": [
        "Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação"
      ],
      "criticalErrors": [
        "Remover tecido viável, causar hemorragia, negligenciar isquemia ou infecção profunda.",
        "Omitir identificação do paciente, consentimento ou avaliação de segurança"
      ],
      "fields": {
        "definition": [
          "Avaliar tecido desvitalizado e modalidades de remoção de tecido, em ambiente e competência apropriados."
        ],
        "indications": [
          "Feridas selecionadas com tecido desvitalizado após avaliação de perfusão, infecção e objetivos terapêuticos."
        ],
        "contraindications": [
          "Não realizar desbridamento instrumental sem habilidade, condições de segurança ou avaliação de isquemia."
        ],
        "anatomy": [
          "Considerar profundidade, estruturas profundas, perfusão, sangramento, dor e limites do tecido viável."
        ],
        "materials": [
          "Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço."
        ],
        "environment": [
          "Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada."
        ],
        "patient": [
          "Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta."
        ],
        "analgesia": [
          "Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado."
        ],
        "sequence": [
          "Identificar características de tecido desvitalizado em imagens educativas",
          "Registrar perfusão, infecção e riscos",
          "Diferenciar opções de tratamento e necessidade de encaminhamento",
          "Descrever plano de monitoramento e reavaliação"
        ],
        "confirmation": [
          "Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada."
        ],
        "complications": [
          "Reconhecer riscos específicos: Remover tecido viável, causar hemorragia, negligenciar isquemia ou infecção profunda. Encaminhar para reavaliação quando houver piora ou achados de alarme."
        ],
        "aftercare": [
          "Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado."
        ],
        "skills-checklist": [
          "Identificar características de tecido desvitalizado em imagens educativas",
          "Registrar perfusão, infecção e riscos",
          "Diferenciar opções de tratamento e necessidade de encaminhamento",
          "Descrever plano de monitoramento e reavaliação"
        ],
        "media-references": [
          "Ficha original em revisão clínica — não substitui demonstração supervisionada.",
          "Vídeo externo poderá ser cadastrado com licença e crédito no MB06.",
          "Fonte de apoio e data de conferência identificadas ao final."
        ]
      },
      "references": [
        {
          "id": "MB03-L3-REF-PT-M06-05",
          "title": "Referência institucional de apoio — verificar aplicabilidade local",
          "url": "https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds",
          "checkedOn": "2026-10-14"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Roteiro de segurança original; não representa anatomia em escala",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-01",
      "topicIds": [
        "PT-M16-01"
      ],
      "title": "Incisões e vias de acesso",
      "priority": "P1",
      "level": "Fundamental / intermediário",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-001",
        "MAT-INS-002",
        "MAT-INS-004",
        "MAT-INS-006",
        "MAT-INS-008"
      ],
      "additionalSupplies": [
        "Campos, compressas estéreis, solução antisséptica apropriada, marcador cirúrgico quando indicado",
        "Modelo de pele/tecidos para simulação; sistema de descarte de perfurocortantes"
      ],
      "criticalErrors": [
        "Incisão sem identificação do paciente, lateralidade, local e procedimento",
        "Plano anatômico errado ou exposição insuficiente de estruturas em risco",
        "Uso de antisséptico alcoólico ainda úmido quando houver energia cirúrgica"
      ],
      "fields": {
        "definition": [
          "Escolha e preparo de uma via de acesso cirúrgica, com planejamento anatômico, proteção de estruturas e abertura tecidual controlada; treinamento inicial em modelos de simulação."
        ],
        "indications": [
          "Acesso para exploração, tratamento ou drenagem quando indicação cirúrgica estabelecida; a via depende do órgão-alvo, exposição necessária e características do paciente."
        ],
        "contraindications": [
          "Não há uma incisão universal: avaliar cicatrizes, infecção local, vascularização, cirurgias prévias e possibilidade de via menos invasiva. Escolha final cabe à equipe cirúrgica."
        ],
        "anatomy": [
          "Reconhecer pele, tecido subcutâneo, fáscia, aponeurose e musculatura; localizar projeções vasculonervosas e cicatrizes antes de marcar o trajeto."
        ],
        "materials": [
          "Cabo e lâmina de bisturi compatíveis (número conforme alvo e fabricante), pinça de preensão, tesoura de dissecção, afastador, compressas e recursos de hemostasia."
        ],
        "environment": [
          "Conferir mesa, iluminação, equipamento de aspiração/hemostasia, campo estéril e descarte de lâminas. Confirmar checklist cirúrgico."
        ],
        "patient": [
          "Identificação dupla, consentimento, procedimento/local/lado, alergias, preparo cutâneo, posicionamento com proteção de pontos de pressão e comunicação com anestesia."
        ],
        "analgesia": [
          "Plano anestésico proporcional à extensão e localização; infiltração, bloqueio ou anestesia geral conforme avaliação da anestesiologia/equipe habilitada."
        ],
        "sequence": [
          "No simulador, marcar limites anatômicos e estruturas a proteger.",
          "Selecionar lâmina e instrumental de preensão com conferência de compatibilidade.",
          "Demonstrar incisão controlada por camadas e proteção do tecido adjacente, sem avançar em planos não identificados.",
          "Expor a área de forma progressiva, mantendo hemostasia e comunicação da mudança de plano.",
          "Realizar pausa de segurança diante de sangramento inesperado ou anatomia incerta."
        ],
        "confirmation": [
          "Campo adequadamente exposto, limites anatômicos reconhecidos, hemostasia controlada e integridade dos tecidos adjacentes."
        ],
        "complications": [
          "Sangramento, lesão nervosa/vascular, queimadura por energia, infecção, cicatriz desfavorável ou deiscência; interromper, identificar e comunicar intercorrências."
        ],
        "aftercare": [
          "Registrar acesso e achados, integridade do campo, material utilizado e plano de fechamento/curativo; vigiar perfusão, dor e sinais de infecção."
        ],
        "skills-checklist": [
          "Confere paciente, procedimento e lado antes de iniciar",
          "Marca referências e estruturas vulneráveis no modelo",
          "Escolhe lâmina e protege perfurocortantes",
          "Demonstra acesso por planos e reconhece necessidade de hemostasia",
          "Confere material e comunica intercorrências"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "WHO-SAFE-2009",
          "title": "OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)",
          "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "NICE-NG125",
          "title": "NICE NG125 — Surgical site infections: prevention and treatment",
          "url": "https://www.nice.org.uk/guidance/ng125/chapter/Recommendations",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-02",
      "topicIds": [
        "PT-M16-02"
      ],
      "title": "Dissecção por planos",
      "priority": "P1",
      "level": "Intermediário",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-004",
        "MAT-INS-006",
        "MAT-INS-007",
        "MAT-INS-008",
        "MAT-INS-005"
      ],
      "additionalSupplies": [
        "Modelo anatômico multicamadas, gazes e afastadores apropriados ao acesso",
        "Instrumentos de dissecção romba e delicada conforme estrutura alvo"
      ],
      "criticalErrors": [
        "Tracionar tecido não identificado",
        "Dissecção cega junto a vasos, nervos ou vísceras",
        "Usar eletrocirurgia sem reconhecer a estrutura adjacente"
      ],
      "fields": {
        "definition": [
          "Separação progressiva dos tecidos em planos anatômicos com técnica romba, cortante ou combinação conforme necessidade de exposição."
        ],
        "indications": [
          "Acesso a estruturas-alvo em procedimentos abertos, controle de tecido cicatricial e identificação segura de planos cirúrgicos."
        ],
        "contraindications": [
          "Aderências complexas, anatomia distorcida e campo hemorrágico exigem maior exposição e decisão por especialista; não avançar quando o plano é incerto."
        ],
        "anatomy": [
          "Distinguir pele, subcutâneo, fáscias, fibras musculares, planos avasculares e planos com estruturas neurovasculares."
        ],
        "materials": [
          "Pinças atraumáticas e de dissecção, tesoura Metzenbaum, afastadores, hemostáticas e material para proteção do campo."
        ],
        "environment": [
          "Exposição e iluminação adequadas, instrumental funcional, orientação espacial da equipe e recursos de hemostasia disponíveis."
        ],
        "patient": [
          "Posicionar para preservar ergonomia, proteção cutânea e acesso; identificar cirurgias prévias e fatores que podem alterar os planos."
        ],
        "analgesia": [
          "Conforme operação principal; controlar analgesia e estabilidade antes de manipular planos mais profundos."
        ],
        "sequence": [
          "Identificar no modelo a camada atual e a seguinte.",
          "Fazer tração e contratração delicadas com auxílio de afastadores.",
          "Demonstrar dissecção romba no plano apropriado e técnica cortante apenas onde a estrutura foi identificada.",
          "Inspecionar frequentemente pontos de sangramento e reconhecer plano avascular quando presente.",
          "Suspender avanço quando não for possível identificar estruturas com confiança."
        ],
        "confirmation": [
          "Camadas distinguíveis, estruturas preservadas, campo sem tração excessiva e manutenção da hemostasia."
        ],
        "complications": [
          "Laceração vascular, lesão nervosa, perfuração visceral, seroma, queimaduras e sangramento oculto; reconhecer e pedir apoio."
        ],
        "aftercare": [
          "Reavaliar viabilidade e hemostasia antes de continuar; documentar alterações anatômicas e danos identificados."
        ],
        "skills-checklist": [
          "Aponta as camadas no modelo",
          "Demonstra tração/contratração controladas",
          "Seleciona técnica romba ou cortante justificadamente",
          "Identifica estruturas vulneráveis",
          "Interrompe a técnica diante de incerteza anatômica"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "WHO-SAFE-2009",
          "title": "OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)",
          "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-03",
      "topicIds": [
        "PT-M16-03"
      ],
      "title": "Hemostasia e ligaduras",
      "priority": "P1",
      "level": "Intermediário",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005",
        "MAT-INS-003",
        "MAT-SUT-002",
        "MAT-SUT-004",
        "MAT-INS-004"
      ],
      "additionalSupplies": [
        "Compressas estéreis contáveis; recurso de aspiração e energia cirúrgica quando disponíveis e indicados",
        "Pinças hemostáticas adicionais conforme calibre e localização do vaso"
      ],
      "criticalErrors": [
        "Aplicar energia junto a estruturas não visualizadas",
        "Ligadura sem conferência do vaso e de estruturas adjacentes",
        "Encerrar a operação sem verificar hemostasia de planos profundos"
      ],
      "fields": {
        "definition": [
          "Conjunto de estratégias para localizar, conter e tratar sangramento operatório por compressão, pinçamento, ligadura ou tecnologia apropriada."
        ],
        "indications": [
          "Sangramento tecidual ou vascular durante dissecção/fechamento e prevenção de perda sanguínea no campo operatório."
        ],
        "contraindications": [
          "A técnica varia com vaso, calibre, perfusão e órgão: não usar eletrocoagulação ou pinçamento às cegas, sobretudo perto de nervos e vísceras."
        ],
        "anatomy": [
          "Identificar trajeto vascular, perfusão distal, relação com estruturas nervosas e planos de acesso; distinguir sangramento capilar, venoso e arterial."
        ],
        "materials": [
          "Pinças hemostáticas, porta-agulhas, fios adequados ao vaso/tecido, compressas e instrumento de energia quando indicado."
        ],
        "environment": [
          "Aspirador pronto, compressas contadas e plano de resposta a sangramento de maior porte, com comunicação anestésica."
        ],
        "patient": [
          "Antecedentes de anticoagulantes/coagulopatia e avaliação do risco hemorrágico; acesso a hemoderivados quando plano cirúrgico demandar."
        ],
        "analgesia": [
          "Gerenciamento anestésico e hemodinâmico durante controle de sangramento; procedimento invasivo por equipe habilitada."
        ],
        "sequence": [
          "Em modelo de simulação, localizar a origem do sangramento.",
          "Demonstrar compressão adequada e exposição do campo.",
          "Selecionar entre compressão, ligadura ou outro método de forma justificada e confirmar identificação das estruturas.",
          "Treinar ligadura/controle em modelo vascular sem tensionar excessivamente o tecido.",
          "Reinspecionar o campo depois do controle, inclusive após mudanças de pressão ou posição."
        ],
        "confirmation": [
          "Ausência de sangramento ativo relevante, perfusão preservada dos tecidos de interesse, estabilidade hemodinâmica e contagem das compressas."
        ],
        "complications": [
          "Hemorragia persistente, lesão vascular, isquemia por ligadura inadequada, queimadura por energia e hematoma pós-operatório; solicitar apoio e tratar causa."
        ],
        "aftercare": [
          "Registrar método hemostático, estimativa de perdas conforme rotina, necessidade de observação e sinais de ressangramento."
        ],
        "skills-checklist": [
          "Reconhece tipo provável de sangramento",
          "Aplica compressão no modelo antes de avançar",
          "Identifica vasos/estruturas antes de ligar",
          "Justifica seleção de hemostasia",
          "Confere campo e hemostasia ao final"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "WHO-SAFE-2009",
          "title": "OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)",
          "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "WHO-SSI-2018",
          "title": "OMS — Global guidelines for prevention of surgical site infection (2018)",
          "url": "https://www.who.int/publications/i/item/9789241550475",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-04",
      "topicIds": [
        "PT-M16-04"
      ],
      "title": "Laparotomia: preparo e princípios de abertura",
      "priority": "P2",
      "level": "Avançado / observação supervisionada",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-001",
        "MAT-INS-002",
        "MAT-INS-006",
        "MAT-INS-008",
        "MAT-INS-005",
        "MAT-SUT-005"
      ],
      "additionalSupplies": [
        "Afastadores abdominais conforme cirurgia, sistema de aspiração, compressas radiopacas contáveis, fios para fáscia",
        "Simulador de parede abdominal com peritônio e camadas reconhecíveis"
      ],
      "criticalErrors": [
        "Abertura abdominal sem reconhecer anatomia, aderências ou cicatrizes",
        "Não identificar risco de lesão visceral na entrada",
        "Falha de contagem de compressas/instrumentos"
      ],
      "fields": {
        "definition": [
          "Acesso aberto à cavidade abdominal realizado por equipe cirúrgica, com escolha da incisão, identificação das camadas e proteção das vísceras."
        ],
        "indications": [
          "Exploração ou tratamento de patologia abdominal quando a abordagem aberta está indicada, inclusive conversão de abordagem minimamente invasiva."
        ],
        "contraindications": [
          "Não existe indicação universal para acesso aberto; discutir alternativas, aderências, condição hemodinâmica, infecção e riscos anestésicos."
        ],
        "anatomy": [
          "Parede abdominal: pele, subcutâneo, aponeurose, músculos/linha alba, fáscia transversalis, peritônio; vísceras e vasos próximos à entrada."
        ],
        "materials": [
          "Instrumental de corte/dissecção, afastadores, hemostasia, aspiração, compressas contáveis, sutura de fechamento fascial; escolher conforme técnica."
        ],
        "environment": [
          "Sala de cirurgia equipada, equipamentos e iluminação revisados, contagens iniciais, plano anestésico, protocolo de antibiótico quando indicado."
        ],
        "patient": [
          "Jejum e avaliação anestésica individualizados, identificação/local/consentimento, antissepsia, posicionamento, monitorização e checklist OMS."
        ],
        "analgesia": [
          "Anestesia e analgesia definidas pela anestesiologia; considerar analgesia multimodal e prevenção de náuseas conforme risco."
        ],
        "sequence": [
          "No simulador, identificar e marcar referências da parede abdominal e a possível via de acesso.",
          "Conferir equipe, instrumentais, contagens e campo.",
          "Demonstrar abertura progressiva de planos em modelo, com proteção de estruturas profundas.",
          "Explicar por que toda entrada no peritônio requer visualização segura e reavaliação de aderências.",
          "Antes de encerrar, simular hemostasia, contagens, fechamento da fáscia e registro."
        ],
        "confirmation": [
          "Exposição alcançada sem lesão simulada, estruturas reconhecidas, contagens reconciliadas e plano de fechamento adequado."
        ],
        "complications": [
          "Hemorragia, lesão visceral, infecção, deiscência, hérnia incisional, dor e complicações anestésicas; reconhecimento precoce é obrigatório."
        ],
        "aftercare": [
          "Handoff estruturado para recuperação com acesso realizado, intercorrências, risco hemorrágico e plano de analgesia/cuidado da ferida."
        ],
        "skills-checklist": [
          "Localiza camadas da parede abdominal",
          "Identifica riscos de vísceras aderidas",
          "Confere checklist e contagens",
          "Descreve acesso apenas no simulador",
          "Explica fechamento fascial e handoff"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "WHO-SAFE-2009",
          "title": "OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)",
          "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "NICE-NG125",
          "title": "NICE NG125 — Surgical site infections: prevention and treatment",
          "url": "https://www.nice.org.uk/guidance/ng125/chapter/Recommendations",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "WHO-SSI-2018",
          "title": "OMS — Global guidelines for prevention of surgical site infection (2018)",
          "url": "https://www.who.int/publications/i/item/9789241550475",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-05",
      "topicIds": [
        "PT-M16-05"
      ],
      "title": "Laparoscopia: equipamentos, acesso e segurança",
      "priority": "P2",
      "level": "Avançado / observação supervisionada",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-001",
        "MAT-INS-002",
        "MAT-INS-005",
        "MAT-INS-008"
      ],
      "additionalSupplies": [
        "Coluna de vídeo, óptica e câmera, insuflador de CO₂, fonte de luz, trocartes e cânulas compatíveis",
        "Instrumentais laparoscópicos, sistema de energia e dispositivos de aspiração/irrigação compatíveis",
        "Simulador de caixa laparoscópica para treino bimanual e ergonomia"
      ],
      "criticalErrors": [
        "Iniciar sem verificar insuflador, imagem, cabos e pressão definida pela equipe",
        "Utilizar energia fora do campo visual",
        "Não identificar falha de acesso, lesão ou condição que requer conversão"
      ],
      "fields": {
        "definition": [
          "Abordagem minimamente invasiva com óptica, pneumoperitônio e instrumentos especializados; este módulo ensina preparação, ergonomia e reconhecimento de segurança em simulador."
        ],
        "indications": [
          "Cirurgias elegíveis para abordagem minimamente invasiva conforme indicação, condições clínicas, anatomia e experiência da equipe."
        ],
        "contraindications": [
          "Acesso inviável, instabilidade ou condição clínica/operatória que torne a abordagem inadequada; decisões caso a caso por cirurgião e anestesiologista."
        ],
        "anatomy": [
          "Parede abdominal, grandes vasos retroperitoneais, vísceras sob pontos de entrada e orientação do campo por vídeo; reconhecer limites de visão e profundidade."
        ],
        "materials": [
          "Câmera e torre, insuflação de CO₂, trocartes, óptica, pinças laparoscópicas, sistema de energia e recursos de conversão a cirurgia aberta."
        ],
        "environment": [
          "Testar imagem/foco, fonte de luz, insuflador, conexões, integridade de trocartes, ergonomia do monitor, aspiração e disponibilidade para conversão."
        ],
        "patient": [
          "Checklist de identificação/procedimento, posicionamento e proteção de pontos de pressão, preparo cutâneo e avaliação cardiopulmonar/anestésica."
        ],
        "analgesia": [
          "Geralmente requer anestesia geral e controle ventilatório durante pneumoperitônio; regime e contraindicações individualizados."
        ],
        "sequence": [
          "Montar no simulador torre, ótica, monitor, insuflador e cabos, identificando suas funções.",
          "Simular posicionamento ergonômico da equipe e disposição dos portais sem inserção no paciente.",
          "Treinar coordenação mão–olho e manuseio atraumático com câmera em simulador de caixa.",
          "Demonstrar regras de segurança de energia e resposta a perda de imagem, sangramento ou falha de insuflação.",
          "Descrever indicação de interromper/converter com comunicação entre cirurgia e anestesia."
        ],
        "confirmation": [
          "Imagem, luz e insuflação testadas; exercício bimanual sem colisões ou tração excessiva; resposta ao problema técnico descrita."
        ],
        "complications": [
          "Lesão vascular/visceral na entrada, hipercapnia, embolia gasosa rara, queimaduras e lesões por posição; reconhecer sinais e acionar equipe."
        ],
        "aftercare": [
          "Registrar dispositivos e portais utilizados, contagens, complicações, sítios de acesso e plano de vigilância pós-operatória."
        ],
        "skills-checklist": [
          "Reconhece câmera, insuflador, óptica e trocartes",
          "Executa checklist de equipamento antes da simulação",
          "Manuseia dois instrumentos com controle em caixa de treinamento",
          "Interrompe exercício diante de falha de imagem",
          "Conhece recursos e comunicação de conversão"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "WHO-SAFE-2009",
          "title": "OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)",
          "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "NICE-NG125",
          "title": "NICE NG125 — Surgical site infections: prevention and treatment",
          "url": "https://www.nice.org.uk/guidance/ng125/chapter/Recommendations",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-06",
      "topicIds": [
        "PT-M16-06"
      ],
      "title": "Fechamento por planos",
      "priority": "P1",
      "level": "Intermediário / avançado",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-003",
        "MAT-INS-004",
        "MAT-INS-007",
        "MAT-SUT-002",
        "MAT-SUT-005",
        "MAT-SUT-006"
      ],
      "additionalSupplies": [
        "Modelo de parede abdominal com camadas; compressas e cobertura para ferida operatória",
        "Fios e agulhas específicos conforme plano, tensão, contaminação e fabricante"
      ],
      "criticalErrors": [
        "Fechar cavidade antes de conferir hemostasia, estruturas e contagens",
        "Incluir estruturas ou comprimir tecido com tensão excessiva",
        "Escolher fio ou agulha sem considerar o plano e o suporte mecânico necessário"
      ],
      "fields": {
        "definition": [
          "Reconstrução progressiva dos planos operados, respeitando função anatômica, viabilidade tecidual e resistência exigida em cada camada."
        ],
        "indications": [
          "Encerramento cirúrgico após tratamento, hemostasia e verificação do campo; a técnica depende do tipo de incisão e risco de infecção."
        ],
        "contraindications": [
          "Contaminação e infecção podem requerer estratégias de fechamento diferido; tecido isquêmico ou sob tensão excessiva exige reavaliação."
        ],
        "anatomy": [
          "Reconhecer fáscia/aponeurose como camada de sustentação, subcutâneo, derme e epiderme; evitar incorporar vasos, nervos ou alças."
        ],
        "materials": [
          "Porta-agulhas, pinça, tesoura e suturas absorvíveis ou não conforme função do plano, curva e ponta da agulha, tensão e técnica."
        ],
        "environment": [
          "Campo iluminado, contagem reconciliada, fios e agulhas identificados, apoio para hemostasia e curativo disponível."
        ],
        "patient": [
          "Rever risco de infecção, obesidade, diabetes, cicatrização, perda tecidual e pressão intra-abdominal conforme caso."
        ],
        "analgesia": [
          "Controle anestésico intraoperatório e analgesia pós-operatória individualizados; técnica de fechamento dentro da cirurgia programada."
        ],
        "sequence": [
          "No modelo multicamadas, classificar os planos que precisam ser aproximados e os que não precisam de sutura adicional.",
          "Selecionar fio e agulha justificando suporte mecânico e reação tecidual.",
          "Demonstrar aproximação sem estrangular bordas, com nós seguros e tensão distribuída.",
          "Conferir fechamento do plano estrutural, hemostasia e espaços mortos conforme contexto.",
          "Simular cobertura, contagem final e documentação dos fios usados."
        ],
        "confirmation": [
          "Boa coaptação sem isquemia aparente, suporte da camada estrutural, ausência de espaço morto inadequado e contagem final reconciliada."
        ],
        "complications": [
          "Seroma, hematoma, infecção de sítio cirúrgico, deiscência, hérnia incisional e necrose por tensão; identificar sinais precoces."
        ],
        "aftercare": [
          "Curativo apropriado, plano de analgesia e mobilização, orientação de sinais de alarme e revisão da ferida conforme risco."
        ],
        "skills-checklist": [
          "Reconhece aponeurose e demais camadas",
          "Seleciona fio conforme função do plano",
          "Executa aproximação em modelo sem estrangulamento",
          "Confere hemostasia e contagens",
          "Documenta fio, plano e cuidados posteriores"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "NICE-NG125",
          "title": "NICE NG125 — Surgical site infections: prevention and treatment",
          "url": "https://www.nice.org.uk/guidance/ng125/chapter/Recommendations",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "WHO-SSI-2018",
          "title": "OMS — Global guidelines for prevention of surgical site infection (2018)",
          "url": "https://www.who.int/publications/i/item/9789241550475",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-07",
      "topicIds": [
        "PT-M16-07"
      ],
      "title": "Drenos cirúrgicos: seleção, instalação e vigilância",
      "priority": "P1",
      "level": "Intermediário / avançado",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-005",
        "MAT-INS-003",
        "MAT-SUT-001"
      ],
      "additionalSupplies": [
        "Dispositivo de drenagem adequado ao procedimento (Penrose, dreno fechado com reservatório ou outro)",
        "Sistema coletor identificado, curativo estéril e material de fixação; confirmar IFU e integridade"
      ],
      "criticalErrors": [
        "Usar dreno sem indicação documentada",
        "Conexão inadequada, quebra do sistema fechado ou tração sobre o dreno",
        "Retirada ou manipulação sem verificar indicação, tipo, débito e protocolo"
      ],
      "fields": {
        "definition": [
          "Dispositivos para evacuação controlada de líquidos/ar ou monitorização de saída em contextos operatórios selecionados."
        ],
        "indications": [
          "Coleção ou espaço cirúrgico com necessidade de drenagem conforme decisão técnica; não são indicados rotineiramente em todas as cirurgias."
        ],
        "contraindications": [
          "Evitar uso sem benefício esperado; risco de infecção ascendente, erosão ou permanência desnecessária; dispositivos específicos têm contraindicações próprias."
        ],
        "anatomy": [
          "Percurso do dreno em relação à cavidade tratada, estruturas vasculares, vísceras e ponto de exteriorização; evitar compressão/angulação."
        ],
        "materials": [
          "Dreno especificado por tipo/diâmetro e fabricante, reservatório ou coletor quando indicado, fio de fixação, gaze e cobertura."
        ],
        "environment": [
          "Dispor sistema fechado e identificado, organizar armazenamento com estabilidade do reservatório e circuito, materiais para documentação do débito."
        ],
        "patient": [
          "Informar finalidade e mobilização segura; avaliar posição, conforto, alergias e risco de retirada acidental."
        ],
        "analgesia": [
          "A inserção acompanha plano anestésico do procedimento; cuidados e retirada conforme analgesia e decisão da equipe."
        ],
        "sequence": [
          "Identificar em bandeja simulada drenagens abertas e fechadas e seus objetivos.",
          "Conferir integridade, reservatório, conectores e material de fixação do modelo.",
          "Simular posicionamento e fixação no manequim sem pinçamento do circuito e sem tração de pele.",
          "Demonstrar mensuração do débito, aspecto e documentação sem abrir desnecessariamente o sistema.",
          "Reconhecer situações para comunicar perda de sucção, alteração súbita de débito, dor ou febre."
        ],
        "confirmation": [
          "Fixação e permeabilidade mantidas, integridade do sistema, mensuração clara de débito e ausência de tração no modelo."
        ],
        "complications": [
          "Obstrução, infecção, sangramento, deslocamento, lesão de estruturas e retenção do dreno; reconhecer e documentar."
        ],
        "aftercare": [
          "Registrar tipo, local, características de débito e curativo; reavaliar diariamente indicação e necessidade de manutenção."
        ],
        "skills-checklist": [
          "Diferencia dreno aberto e fechado",
          "Seleciona o sistema adequado no cenário simulado",
          "Checa circuito, reservatório e fixação",
          "Registra débito e aspecto",
          "Identifica critérios de alerta e reavaliação"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "NICE-NG125",
          "title": "NICE NG125 — Surgical site infections: prevention and treatment",
          "url": "https://www.nice.org.uk/guidance/ng125/chapter/Recommendations",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "WHO-SSI-2018",
          "title": "OMS — Global guidelines for prevention of surgical site infection (2018)",
          "url": "https://www.who.int/publications/i/item/9789241550475",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    },
    {
      "id": "PT-M16-08",
      "topicIds": [
        "PT-M16-08"
      ],
      "title": "Conversão e encerramento cirúrgico seguro",
      "priority": "P2",
      "level": "Avançado / trabalho em equipe",
      "scope": "Cirurgia geral",
      "population": "Adultos; adequar a indicação, anatomia e riscos em pediatria e gestação",
      "environment": "Centro cirúrgico equipado; treino inicial em laboratório de simulação",
      "supervision": "Simulação orientada; execução invasiva somente por equipe habilitada e supervisionada",
      "professionalScope": "Conforme habilitação legal, treinamento específico e protocolo institucional",
      "prerequisites": [
        "Assepsia, antissepsia e segurança cirúrgica",
        "Anatomia por planos e reconhecimento de instrumentos",
        "Comunicação cirúrgica e preparo para intercorrências"
      ],
      "editorial": {
        "status": "em-desenvolvimento",
        "version": "0.1-MB04-L1",
        "clinicalReviewer": null,
        "reviewedOn": null,
        "publishedOn": null
      },
      "materialLinks": [
        "MAT-INS-001",
        "MAT-INS-003",
        "MAT-INS-005",
        "MAT-SUT-005"
      ],
      "additionalSupplies": [
        "Formulário de checklist OMS, mapa de contagem de agulhas, gazes, compressas e instrumentos",
        "Instrumental alternativo e campo para acesso aberto quando previsto",
        "Identificação e acondicionamento seguro de amostras e materiais implantados"
      ],
      "criticalErrors": [
        "Persistir numa via insegura diante de complicação ou visualização insuficiente",
        "Fechar sem contagem final reconciliada ou deixar divergência sem investigação",
        "Transferir paciente sem relato das intercorrências, dispositivos e plano de vigilância"
      ],
      "fields": {
        "definition": [
          "Reconhecimento da necessidade de mudar a via cirúrgica e execução dos passos de segurança para concluir o procedimento, contabilizar materiais e transferir cuidados."
        ],
        "indications": [
          "Mudança de abordagem por acesso insuficiente, complicação ou necessidade cirúrgica; encerramento seguro obrigatório em todos os procedimentos."
        ],
        "contraindications": [
          "Não existem condições aceitáveis para omitir as verificações de segurança; decisões de conversão competem à equipe habilitada."
        ],
        "anatomy": [
          "Reavaliar a anatomia e eventuais lesões identificadas; localizar a nova via de acesso caso a equipe indique conversão."
        ],
        "materials": [
          "Checklist, materiais de contagem, instrumentos de hemostasia e fechamento, identificação de espécimes e meios seguros de handoff."
        ],
        "environment": [
          "Pausar para comunicação estruturada, definir novos papéis e recursos, confirmar disponibilidade de instrumentais, anestesia e suporte."
        ],
        "patient": [
          "Reconfirmar lateridade/procedimento quando houver mudança de plano, alergias, estado hemodinâmico, riscos e comunicação de eventos adversos."
        ],
        "analgesia": [
          "Reavaliação contínua pela anestesiologia conforme duração, sangramento e ampliação do procedimento; plano pós-operatório atualizado."
        ],
        "sequence": [
          "No cenário simulado, identificar sinal que justifica solicitar ajuda ou converter a técnica.",
          "Comunicar imediatamente equipe/anestesia, riscos e recursos necessários para o novo plano.",
          "Reconciliar instrumentos, compressas, agulhas, espécimes e implantes com registro da divergência, se houver.",
          "Simular o Sign Out: procedimento realizado, contagens, equipamentos, amostras e plano de recuperação.",
          "Transmitir handoff estruturado com intercorrências, analgesia, acesso, drenos e sinais de alerta."
        ],
        "confirmation": [
          "Equipe ciente da abordagem final, contagens e amostras reconciliadas, documentação completa e plano pós-operatório compreendido."
        ],
        "complications": [
          "Objeto retido, perda de informação, falha de contagem, agravamento não comunicado, sangramento ou reação adversa; acionar rastreio de segurança institucional."
        ],
        "aftercare": [
          "Registro cirúrgico e anestésico, identificação de dispositivos e espécimes, instrução de recuperação e critérios para escalonamento."
        ],
        "skills-checklist": [
          "Reconhece situação de conversão e pede ajuda",
          "Realiza comunicação fechada com equipe",
          "Reconciliou contagens e espécimes no cenário",
          "Executa Sign Out OMS",
          "Faz handoff estruturado com riscos e plano"
        ],
        "media-references": [
          "Referências institucionais de segurança e de prevenção de infecção disponíveis abaixo.",
          "Leitura complementar: Tapia Jurado, Manual de procedimientos médico-quirúrgicos (2005), capítulos 11, 15, 16 e 37; FMUSP, Manual Básico de Procedimentos Médicos Hospitalares (2017). Comparar com normas atuais antes de aplicar.",
          "Videodemonstração externa ainda não cadastrada — integração por procedimento no MB06."
        ]
      },
      "references": [
        {
          "id": "WHO-SAFE-2009",
          "title": "OMS — Lista de Verificação de Segurança Cirúrgica (19 itens)",
          "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "NICE-NG125",
          "title": "NICE NG125 — Surgical site infections: prevention and treatment",
          "url": "https://www.nice.org.uk/guidance/ng125/chapter/Recommendations",
          "checkedOn": "2026-10-15"
        },
        {
          "id": "ACS-SURGICAL-PRINCIPLES",
          "title": "American College of Surgeons — Surgical Education and Training",
          "url": "https://www.facs.org/education/",
          "checkedOn": "2026-10-15"
        }
      ],
      "media": [],
      "illustration": {
        "type": "original-schematic",
        "caption": "Conteúdo textual original para simulação; nenhuma imagem dos livros reproduzida",
        "author": "Nexo Cirúrgico",
        "license": "Original do projeto"
      }
    }
  ]
};
/* Sincroniza o estado editorial das fichas atuais sem publicar conteúdo clínico. */
(function(){
 const curriculum=window.NEXO_DATA.technicalCurriculum;
 const macro=curriculum.macroblocks.find(m=>m.id==='MB03');
 if(macro){macro.status='Em desenvolvimento';macro.description='MB03: 46 fichas fundamentais cadastradas; treino supervisionado e aprofundamentos seguem em expansão.'}
 const index=new Map(curriculum.modules.flatMap(m=>m.topics).map(t=>[t.id,t]));
 for(const procedure of window.NEXO_PROCEDURES.procedures){
   for(const tid of procedure.topicIds){const topic=index.get(tid);if(!topic)throw Error('Procedimento sem tópico: '+tid);
     topic.status='revisao-tecnica';topic.revision={...topic.revision,version:'0.2',state:'revisao-tecnica',reviewedOn:null,reviewer:null};
   }
 }
})();

/* MB04 — cirurgias: estágio de criação separado da liberação para execução clínica. */
(function(){
 const curriculum=window.NEXO_DATA.technicalCurriculum;
 const macro=curriculum.macroblocks.find(m=>m.id==='MB04');
 if(macro){macro.status='Em desenvolvimento';macro.description='MB04 Lote 1: oito roteiros de Cirurgia Geral (M16); anestesia e demais procedimentos ficam para o lote seguinte.'}
 const module=curriculum.modules.find(m=>m.id==='M16');
 for(const topic of module.topics){
  if(window.NEXO_PROCEDURES.procedures.some(p=>p.id===topic.id)){
    topic.status='em-desenvolvimento';topic.revision={...topic.revision,version:'0.1-MB04-L1',state:'em-desenvolvimento'};
  }
 }
})();

/* Liga Atlas → ficha cirúrgica, mantendo navegação bidirecional sem inventar compatibilidade. */
(function(){
 const materials=new Map(window.NEXO_DATA.materialAtlas.materials.map(item=>[item.id,item]));
 for(const procedure of window.NEXO_PROCEDURES.procedures.filter(p=>p.id.startsWith('PT-M16-'))){
  for(const materialId of procedure.materialLinks){
   const material=materials.get(materialId);
   if(!material)throw new Error('MB04: material não cadastrado '+materialId);
   if(!material.procedureLinks.some(link=>link.topicId===procedure.id)){
    material.procedureLinks.push({topicId:procedure.id,role:'dependente-indicacao',note:'Instrumental de simulação; selecionar conforme técnica, tecido e fabricante.'});
   }
  }
 }
})();
