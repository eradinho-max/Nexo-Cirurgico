import json, copy, pathlib
root=pathlib.Path(__file__).parent
p=root/'procedimentos_mb03.js'; raw=p.read_text(); mark='window.NEXO_PROCEDURES = '; st=raw.index(mark)+len(mark); obj,off=json.JSONDecoder().raw_decode(raw[st:]); end=st+off
existing={x['id'] for x in obj['procedures']}
seed=next(x for x in obj['procedures'] if x['id']=='PT-M13-03');suture=next(x for x in obj['procedures'] if x['id']=='PT-M07-03');wound=next(x for x in obj['procedures'] if x['id']=='PT-M06-03')
# Material descriptions and steps are supervised training objectives, NOT clinical protocols.
entries=[
('PT-M07-01','Fios de sutura: materiais e seleção','Suturas e fechamento',suture,'https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures',
 'Reconhecer fios absorvíveis e não absorvíveis, mono e multifilamentares, diferenças de memória, resistência e resposta tecidual.',
 'Quando o fechamento foi indicado e a escolha do fio depende do tecido, tensão, risco de infecção e necessidade de remoção.',
 'Não escolher fio somente pela cor ou número; atenção a alergia, contaminação, tecido isquêmico e indicação de fechamento tardio.',
 'Comparar escala USP, diâmetro nominal, tipo de polímero, absorção e embalagem íntegra.',
 ['Examinar identificação e validade dos fios disponíveis','Associar propriedades ao plano anatômico e à tensão','Justificar a seleção em cenário simulado','Verificar conformidade com protocolo e supervisão'],
 'Escolha incompatível com o tecido, uso sem avaliação de contaminação.'),
('PT-M07-02','Agulhas cirúrgicas: curvatura e ponta','Suturas e fechamento',suture,'https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-repair-a-laceration-with-simple-interrupted-sutures',
 'Diferenciar agulhas cilíndricas, cortantes e cortantes reversas, com curvatura e montagem apropriadas ao tecido.',
 'Planejamento do fechamento de tecidos, considerando profundidade, acesso e risco de lesão.',
 'Não utilizar agulha danificada, não reutilizar material de uso único e não confundir formato com calibre do fio.',
 'Comparar curvatura (por exemplo 3/8 e 1/2 círculo), ponta, comprimento e compatibilidade com porta-agulhas.',
 ['Identificar o tipo de ponta em modelos','Relacionar curvatura à exposição do campo','Demonstrar passagem segura do instrumento em simulação','Conferir integridade antes da utilização'],
 'Manipular agulha sem instrumental apropriado; descartar incorretamente.'),
('PT-M13-01','Tipóia: suporte do membro superior','Ortopedia e imobilização',seed,'https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/',
 'Suporte provisório do membro superior para conforto e limitação de movimento em lesões selecionadas.',
 'Uso quando indicado após avaliação da lesão e da necessidade de imobilização complementar.',
 'Não substituir imobilização definitiva quando ela for necessária; reconsiderar diante de alteração neurovascular.',
 'Inspecionar suporte, pontos de pressão, integridade cutânea, edema e alinhamento tolerado.',
 ['Registrar perfusão, motricidade e sensibilidade antes da aplicação','Selecionar tamanho e ajustar suporte sem comprimir','Inspecionar pontos de pressão e conforto','Reavaliar perfusão e orientar sinais de alarme'],
 'Pressão sobre pescoço, compressão do punho, ausência de reavaliação distal.'),
('PT-M13-04','Tala tipo U para úmero','Ortopedia e imobilização',seed,'https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/',
 'Imobilização temporária do braço em situações selecionadas, com proteção de proeminências ósseas.',
 'Indicação após avaliação da lesão, neurovascular e da necessidade de redução ou tratamento específico.',
 'Evitar compressão circunferencial excessiva, especialmente na presença de edema progressivo.',
 'Avaliar braço, cotovelo, pele, artéria braquial e função nervosa distal antes e depois.',
 ['Conferir avaliação neurovascular basal','Preparar materiais e acolchoamento em manequim','Demonstrar proteção de proeminências e ajuste seguro','Reexaminar perfusão, sensibilidade e movimento distal'],
 'Apertar sobre edema, não avaliar função radial, ignorar dor progressiva.'),
('PT-M13-07','Imobilização do polegar: thumb spica','Ortopedia e imobilização',seed,'https://www.aafp.org/pubs/afp/issues/2009/0901/p491.html',
 'Tala de imobilização seletiva do polegar e do punho em lesões ou suspeitas que exigem proteção.',
 'Lesões do polegar e suspeita de algumas fraturas do escafoide, condicionadas ao exame e à imagem.',
 'Imobilização não substitui avaliação de lesão instável, aberta ou comprometimento neurovascular.',
 'Avaliar tabaqueira anatômica, polegar, punho, pele e função distal.',
 ['Registrar achados clínicos e necessidade de imagem','Selecionar tamanho e acolchoamento em simulação','Proteger proeminências sem apertar o polegar','Reavaliar perfusão, sensibilidade e mobilidade das partes livres'],
 'Cobertura compressiva, ausência de retorno para lesão oculta ou dor persistente.'),
('PT-M13-08','Imobilização de dedos e buddy taping','Ortopedia e imobilização',seed,'https://orthoinfo.aaos.org/en/recovery/care-of-casts-and-splints/',
 'Estabilização de lesões selecionadas de dedos com proteção de pele e alinhamento anatômico.',
 'Lesões estáveis conforme avaliação e exclusão de deformidade que exija outra conduta.',
 'Não aplicar sem avaliação de rotação, estabilidade, lesão tendínea ou déficit neurovascular.',
 'Inspecionar articulações, leito ungueal, alinhamento rotacional, pele entre os dedos.',
 ['Documentar alinhamento, integridade cutânea e exame distal','Selecionar proteção entre dedos em treinamento','Demonstrar estabilização sem compressão','Checar circulação e orientar revisão da pele'],
 'Prender dedos em desalinhamento, lesão por maceração, tensão excessiva.'),
('PT-M13-09','Colar cervical: indicações e limitações','Ortopedia e imobilização',seed,'https://www.facs.org/quality-programs/trauma/education/advanced-trauma-life-support/',
 'Recurso de restrição de movimento cervical em pacientes selecionados, integrado à avaliação do trauma.',
 'Situações de suspeita de lesão cervical conforme critérios clínicos e protocolos de trauma.',
 'Não usar indiscriminadamente nem atrasar manejo da via aérea e outras prioridades de ressuscitação.',
 'Manter referência do alinhamento cervical, avaliar integridade da pele e sinais neurológicos.',
 ['Identificar quando restrição de movimento é necessária','Demonstrar medidas de estabilização em manequim','Verificar adequação e riscos de pressão do dispositivo','Reavaliar via aérea, pele e exame neurológico'],
 'Aplicar tamanho inadequado, prejudicar via aérea, confiar apenas no colar como imobilização.'),
('PT-M06-05','Desbridamento: avaliação e indicação','Feridas e lesões',wound,'https://www.merckmanuals.com/professional/injuries-poisoning/how-to-care-for-wounds-and-lacerations/how-to-cleanse-irrigate-debride-and-dress-wounds',
 'Avaliar tecido desvitalizado e modalidades de remoção de tecido, em ambiente e competência apropriados.',
 'Feridas selecionadas com tecido desvitalizado após avaliação de perfusão, infecção e objetivos terapêuticos.',
 'Não realizar desbridamento instrumental sem habilidade, condições de segurança ou avaliação de isquemia.',
 'Considerar profundidade, estruturas profundas, perfusão, sangramento, dor e limites do tecido viável.',
 ['Identificar características de tecido desvitalizado em imagens educativas','Registrar perfusão, infecção e riscos','Diferenciar opções de tratamento e necessidade de encaminhamento','Descrever plano de monitoramento e reavaliação'],
 'Remover tecido viável, causar hemorragia, negligenciar isquemia ou infecção profunda.'),
]
for pid,title,scope,template,url,definition,indication,contra,anatomy,seq,errors in entries:
 if pid in existing:continue
 n=copy.deepcopy(template);n['id']=pid;n['topicIds']=[pid];n['title']=title;n['scope']=scope;n['materialLinks']=[];n['additionalSupplies']=['Modelos didáticos, elementos de identificação do dispositivo e materiais de segurança conforme protocolo de simulação'];n['criticalErrors']=[errors,'Omitir identificação do paciente, consentimento ou avaliação de segurança'];n['references']=[{'id':'MB03-L3-REF-'+pid,'title':'Referência institucional de apoio — verificar aplicabilidade local','url':url,'checkedOn':'2026-10-14'}];n['editorial']['version']='0.2';n['fields']['definition']=[definition];n['fields']['indications']=[indication];n['fields']['contraindications']=[contra];n['fields']['anatomy']=[anatomy];n['fields']['materials']=['Conferir identificação, integridade e compatibilidade dos materiais; somente dispositivos padronizados e permitidos no serviço.'];n['fields']['environment']=['Ambiente com equipamentos de simulação, medidas de segurança e supervisão habilitada.'];n['fields']['patient']=['Confirmar identificação, consentimento, avaliação da lesão, alergias e condições que modificam a conduta.'];n['fields']['analgesia']=['Planejar analgesia, conforto ou anestesia quando indicada, conforme prescrição e protocolo individualizado.'];n['fields']['sequence']=seq;n['fields']['confirmation']=['Confirmar objetivos clínicos e exame de segurança; registrar achados e necessidade de avaliação especializada.'];n['fields']['complications']=['Reconhecer riscos específicos: '+errors+' Encaminhar para reavaliação quando houver piora ou achados de alarme.'];n['fields']['aftercare']=['Orientar acompanhamento, cuidado com dispositivo quando aplicável, sinais de alarme e retorno individualizado.'];n['fields']['skills-checklist']=[q.replace('Demonstrar','Demonstra') for q in seq];n['fields']['media-references']=['Ficha original em revisão clínica — não substitui demonstração supervisionada.','Vídeo externo poderá ser cadastrado com licença e crédito no MB06.','Fonte de apoio e data de conferência identificadas ao final.'];n['media']=[]
 obj['procedures'].append(n)
raw=raw[:st]+json.dumps(obj,ensure_ascii=False,indent=2)+raw[end:];p.write_text(raw)
q=root/'qa_mb03.js';s=q.read_text();s=s.replace('38 fichas com IDs únicos', '46 fichas com IDs únicos').replace('pack.procedures.length===38','pack.procedures.length===46').replace('38 tópicos em revisão técnica','46 tópicos em revisão técnica').replace("length===38", "length===46").replace('38 cards no índice','46 cards no índice').replace('length===38','length===46').replace('38 rotas diretas','46 rotas diretas');q.write_text(s)
# Version and release file
pkg=root/'package.json';a=json.loads(pkg.read_text());a['version']='1.4.2-mb03.3';pkg.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
(root/'MB03_LOTE3_RELATORIO.md').write_text('''# Nexo Cirúrgico — MB03 Lote 3 (v1.4.2)\n\nEntregues 8 fichas originais adicionais, atingindo 46 fichas: tipos de fios, agulhas cirúrgicas, tipóia, tala tipo U, thumb spica, buddy taping, precauções em restrição de movimento cervical e avaliação de desbridamento. Não são protocolos clínicos; não incluem instruções de execução invasiva não supervisionada.\n\nTodas as novas fichas permanecem em revisão clínica. Esta entrega não altera o banco histórico de aulas, questões, casos e flashcards. O Atlas de materiais não foi ampliado neste lote: identificações individuais e fichas de novos dispositivos continuam pendentes.\n\nPróximo: revisão clínica, itens faltantes de acesso vascular, ampliação do Atlas, testes visuais e MB04.\n''')
print('fichas:',len(obj['procedures']))
