# Nexo Cirúrgico — auditoria do banco de avaliação 1.0

**Data:** 13 de outubro de 2026  
**Escopo:** 150 questões, 20 casos e 18 competências  
**Resultado:** auditoria estrutural aprovada; revisão humana independente e piloto pendentes

> **Nota de versão:** este relatório preserva a auditoria histórica do núcleo 1.0. O banco atual foi ampliado para 210 questões, 30 casos e 28 competências no blueprint 1.2; consulte `BLUEPRINT_AVALIACAO.md` e execute `node qa_assessment.js` para a situação estrutural atual.

---

## 1. O que foi auditado automaticamente

- unicidade de IDs;
- existência de quatro alternativas;
- ausência de alternativas idênticas no mesmo item;
- validade do índice do gabarito;
- existência da competência;
- existência das fontes vinculadas;
- presença de justificativa;
- presença dos campos essenciais dos casos;
- duplicidade exata de enunciados após normalização;
- quantidade de questões por competência;
- distribuição de dificuldade;
- distribuição da posição dos gabaritos.

O teste pode ser repetido com:

```bash
node qa_assessment.js
```

---

## 2. Resultado estrutural

| Indicador | Resultado |
|---|---:|
| Questões | 150 |
| Casos | 20 |
| Competências | 18 |
| Fontes catalogadas | 34 |
| IDs duplicados | 0 |
| Enunciados exatamente duplicados | 0 |
| Itens sem fonte | 0 |
| Alternativas duplicadas no mesmo item | 0 |
| Gabaritos inválidos | 0 |
| Competências fora da meta | 0 |

### Dificuldade

| Nível | Itens |
|---|---:|
| Básico | 38 |
| Aplicação | 82 |
| Análise | 30 |

### Posição dos gabaritos após correção

| Tipo | A | B | C | D |
|---|---:|---:|---:|---:|
| Questões | 38 | 38 | 37 | 37 |
| Casos | 5 | 5 | 5 | 5 |

---

## 3. Correção importante realizada

A primeira auditoria detectou forte viés de posição:

- questões: **A 7, B 122, C 19, D 2**;
- casos: **A 0, B 20, C 0, D 0**.

As alternativas foram reordenadas sem alterar o conteúdo da resposta correta, da justificativa ou das fontes. A nova distribuição é balanceada em 38/38/37/37 nas questões e 5/5/5/5 nos casos.

Essa correção reduz uma pista sistemática, mas não substitui a análise de pistas textuais, tamanho das alternativas e plausibilidade dos distratores.

---

## 4. Sinais enviados à revisão humana

O teste também sinaliza, sem reprovar automaticamente:

- enunciados curtos, para confirmar se o contexto é suficiente;
- uso de “sempre”, “nunca”, “somente” ou “apenas” no enunciado ou nas alternativas;
- justificativas curtas.

Termos absolutos podem ser intencionais em distratores. Por isso, devem ser avaliados por revisor e não removidos automaticamente.

---

## 5. O que a automação não valida

A auditoria estrutural não determina:

- precisão clínica;
- atualização da recomendação;
- adequação a todos os protocolos institucionais;
- existência de uma única melhor resposta em todos os contextos;
- realismo dos distratores;
- nível cognitivo observado;
- adequação do escopo profissional;
- clareza para o público-alvo;
- dificuldade empírica;
- capacidade de discriminação do item;
- ausência de viés cultural, linguístico ou de acessibilidade.

Esses pontos permanecem condicionados à revisão independente e ao piloto.

---

## 6. Pacote de revisão

O arquivo `PACOTE_REVISAO_INDEPENDENTE.xlsx` contém:

1. instruções e escala de decisão;
2. resumo do banco;
3. planilha das 150 questões;
4. planilha dos 20 casos;
5. matriz de competências;
6. catálogo de fontes;
7. atribuição de revisores;
8. modelo pseudonimizado para o piloto;
9. dicionário de campos.

As células de decisão começam como **Pendente**. O arquivo não deve ser tratado como prova de validação enquanto não houver revisor identificado, qualificação, decisão, data e registro das correções.

---

## 7. Sequência recomendada

### Etapa A — revisão independente

1. nomear revisores e declarar conflitos de interesse;
2. revisar precisão e atualização;
3. confirmar uma única melhor resposta;
4. revisar distratores e pistas;
5. confirmar limites profissionais;
6. registrar decisão: aprovar, corrigir ou arquivar;
7. realizar segunda checagem nos itens corrigidos.

### Etapa B — entrevistas cognitivas

Observar como participantes interpretam:

- termos técnicos;
- informação clínica relevante;
- diferença entre alternativas;
- motivo da escolha;
- confiança na resposta;
- percepção de ambiguidade.

### Etapa C — piloto fechado

Registrar somente os dados necessários, com código pseudônimo e regras prévias de acesso e retenção:

- versão do banco;
- item;
- alternativa;
- acerto;
- tempo;
- confiança;
- comentário de ambiguidade.

### Etapa D — análise

Calcular, quando houver amostra adequada:

- dificuldade observada;
- distribuição por alternativa;
- funcionamento dos distratores;
- relação do item com o desempenho total;
- tempo de resposta;
- desempenho por competência;
- comentários qualitativos.

Limiares estatísticos de aprovação devem ser definidos previamente por profissional de avaliação, considerando finalidade, tamanho da amostra e risco do uso. Itens não devem ser excluídos somente por um número sem revisão do conteúdo.

---

## 8. Gate para congelar a versão revisada

A versão seguinte só deve receber o estado **revisada** quando:

- 100% dos itens tiverem decisão registrada;
- itens marcados para correção tiverem segunda checagem;
- itens arquivados forem removidos do sorteio;
- o blueprint for recalculado;
- fontes e versões permanecerem rastreáveis;
- o relatório do piloto estiver aprovado;
- limitações e população do piloto estiverem documentadas.
