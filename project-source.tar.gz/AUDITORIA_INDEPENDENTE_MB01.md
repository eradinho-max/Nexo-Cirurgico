# NEXO CIRÚRGICO — PARECER DE AUDITORIA INDEPENDENTE DO MB01

**Data da revisão:** 14/10/2026  
**Pacote auditado:** `nexo-cirurgico-prototipo (2).zip` (321.794 bytes)  
**Linha de base de comparação:** `nexo-cirurgico-prototipo.zip` (pacote anterior)  
**Resultado:** **APROVADO COM RESSALVAS — MB02 LIBERADO**  
**Escopo:** integridade de dados, código, arquitetura didática, links curriculares, testes estruturais e ensaios funcionais locais de interface. **Não equivale a validação médica independente, acreditação ou teste de produção.**

## 1. Evidências reproduzíveis

- Integridade ZIP verificada sem entrada corrompida (`ZipFile.testzip()` retornou `None`).
- `node qa_content.js`: aprovado, zero erros; 33 trilhas, 115 aulas, 28 módulos técnicos, 227 tópicos, 94 aulas distintas mapeadas.
- `node qa_assessment.js`: aprovado estruturalmente, zero erros; preservadas 210 questões e 30 casos, com 92 alertas de revisão editorial previamente conhecidos.
- Comparação profunda da base JS anterior e da base MB01: os objetos `modules`, `flashcards`, `quiz`, `checklist`, `videos`, `evidence`, `mediaSources`, `references`, `competencies`, `assessmentBlueprint`, `cases`, `studyPlans` e `remediationMap` são idênticos; mudou o `roadmap` e foi adicionado o `technicalCurriculum`.
- Interface testada em Chromium com injeção dos arquivos originais em contexto local (sem rede): rota principal exibiu 28 cartões; `PICC` encontrou M05; filtro “Lacuna prioritária” retornou 8; `M07` exibiu 11 tópicos e 5 aulas relacionadas; busca global por “sutura simples” retornou M07. Sem exceções JavaScript durante esses testes.
- Teste em viewport de 390 px: largura de documento observada em 390 px, sem transbordamento horizontal nesse estado. Este ensaio não substitui testes completos de navegadores, acessibilidade ou dispositivo físico.

## 2. Mapa curricular verificado

| Item | Quantidade | Interpretação |
|---|---:|---|
| Macroáreas | 6 | Organização editorial |
| Módulos técnicos M01–M28 | 28 | Cobertura planejada por temas |
| Tópicos com IDs | 227 | Todos os IDs distintos |
| Títulos únicos | 224 | Três títulos repetidos em diferentes especialidades |
| Módulos base existente | 6 | Não equivale a conteúdo clínico validado |
| Módulos cobertura parcial | 14 | Exigem expansão |
| Módulos lacuna prioritária | 8 | Exigem desenvolvimento próprio |
| Vínculos entre matriz e aulas anteriores | 254 | Podem repetir uma mesma aula |
| Aulas distintas vinculadas | 94 | 21 aulas anteriores ainda sem vínculo |
| Modelo de ficha procedimental | 14 campos | Definição do padrão, não 227 fichas preenchidas |

## 3. Não conformidades do MB01 e correções

**MB01-01 — [ALTA] Busca médica sem normalização e sinônimos.**  
**Evidência:** busca global por `ECG` não retornou o tópico cadastrado como “Eletrocardiograma”; `puncao` não retornou “Punção”. Busca por `PICC` funcionou.  
**Ação:** criar função única de normalização de texto (acentos e pontuação) e aliases por tópico, incluindo abreviações e vocabulário técnico em PT/ES quando aplicável; usar a mesma função na busca global e na matriz.  
**Aceite:** testes automatizados para `ECG/eletrocardiograma`, `punção/puncao`, `cateter periférico/acesso venoso`, `PICC` e `sutura simples`; resultado deve indicar tópico correto e módulo.

**MB01-02 — [ALTA] Sem prioridade individual por tópico; filtro de prioridade interpreta faixas como categorias distintas.**  
**Evidência:** filtro `P0` retornou apenas os 9 módulos cuja prioridade literal é `P0`, excluindo módulos que contêm P0 em `P0–P1` ou `P0–P2`.  
**Ação:** usar `priorityLevels: ["P0",...]` ou prioridade específica em cada tópico; a interface deve incluir todos os itens cujo conjunto contém o nível filtrado.  
**Aceite:** `P0` retorna tópicos/módulos contendo P0, independentemente de faixa; preferencialmente mostrar quantidade de tópicos, não somente de módulos.

**MB01-03 — [MÉDIA] Mapeamento transversal não distingue cobertura direta de contexto.**  
**Evidência:** 254 vínculos de aula para somente 94 aulas distintas; algumas aulas aparecem vinculadas a até nove módulos.  
**Ação:** substituir lista plana de vínculos por entidades com `relationType` = `cobertura-direta` | `fundamento` | `pre-requisito` e eventual tópico-alvo. Preservar os vínculos antigos na migração.  
**Aceite:** módulo exibe tipos de vínculo; percentuais de conteúdo pronto contam apenas cobertura direta de tópicos com ficha aprovada.

**MB01-04 — [MÉDIA] Status de cobertura existe por módulo, não por tópico.**  
**Evidência:** títulos catalogados possuem apenas `id` e `title`; estado editorial e progresso de entrega não são rastreados individualmente.  
**Ação:** acrescentar `status` e revisão a cada tópico, com estados `catalogado` → `em-desenvolvimento` → `revisao-tecnica` → `validado` → `publicado`. Não derivar status somente de existência de aula correlata.  
**Aceite:** cada tópico pode ser atualizado independentemente e gera contagem rastreável por macrobloco.

**MB01-05 — [MÉDIA] Três títulos técnicos duplicados em especialidades.**  
**Evidência:** “Cardioversão sincronizada” (M12/M20); “Irrigação vesical” (M14/M22); “Punção capilar” (M18/M27). Os IDs são únicos; isso não é colisão técnica.  
**Ação:** definir um `canonicalProcedureId` e contextos/especialidades vinculados para evitar produzir instruções clínicas discordantes.  
**Aceite:** cada procedimento canônico tem uma ficha principal versionada e páginas contextuais explicitamente relacionadas.

**MB01-06 — [BAIXA] Descrição HTML desatualizada.**  
**Evidência:** `index.html` ainda anuncia “estudos de Centro Cirúrgico”, embora o produto agora tenha escopo mais amplo.  
**Ação:** atualizar metadados e texto editorial para “procedimentos técnicos e assistência perioperatória”, mantendo o nome de marca provisório.

**MB01-07 — [MÉDIA] Validador estrutural não avalia critérios de funcionamento e progressão.**  
**Evidência:** `qa_content.js` aceita qualquer catálogo com pelo menos 200 tópicos e não valida aliases, contexto, status por tópico, relevância dos vínculos, rota, pesquisa nem semântica do filtro.  
**Ação:** ampliar testes com integridade referencial, schema por tópico, cobertura, prioridade, aliases e navegação automatizada; documentar cobertura dos testes.  
**Aceite:** testes negativos (IDs inválidos, vínculos inexistentes, prioridade inconsistente) falham; smoke tests de UI incluem buscas e filtros críticos.

**MB01-08 — [EVOLUÇÃO PLANEJADA] Os 14 campos e os metadados são somente um contrato editorial.**  
**Evidência:** cada tópico contém `id` e `title`, ainda sem objeto procedimental completo.  
**Ação:** disponibilizar modelo de dados de ficha individual no MB03, integrando materiais do MB02.  
**Aceite:** conteúdo só recebe `validado` quando campos aplicáveis, referências, riscos e revisão estão preenchidos e aprovados. NÃO exigir 227 fichas prontas como critério retroativo do MB01.

**Observação:** as 21 aulas não mapeadas continuam preservadas. São principalmente anatomia, segurança institucional, CME, energia cirúrgica e procedimentos vasculares. Seu mapeamento é desejável, mas não há necessidade de forçar vínculo artificial.

## 4. Critérios objetivos de aceite do MB02 — Atlas de Materiais

### Estrutura obrigatória

1. Entidade `materialId` estável, com nome preferencial, nomes alternativos, categoria, descrição curta, indicações gerais, riscos, alternativas e precauções.
2. Tipologia de escala definida por classe (`G`, `Fr`, `mm`, numeração USP, número de lâmina e outras), sem misturar unidades. O cadastro **não** deve converter ou associar cores sem considerar o fabricante e a categoria do dispositivo.
3. Estrutura `variants` para diferentes tamanhos, comprimentos, materiais constitutivos, conectores e informações condicionais de compatibilidade.
4. Relação muitos-para-muitos material ↔ procedimento/tópico (`PT-Mxx-yy`), com papel do material (obrigatório, alternativa, opção dependente de indicação).
5. Proveniência e revisão de cada informação técnica: fonte/edição/URL ou fabricante/modelo, data consultada, estado de revisão, autor responsável.
6. Recursos visuais próprios ou com licença verificável; guardar autor, link original, licença, créditos e texto alternativo. Itens sem autorização não devem ser copiados para o projeto.
7. Atenção aos materiais de risco: validade, uso único, esterilidade, compatibilidades e contraindicações devem ser contextualizados; não indicar uso fora de escopo.
8. Busca por sigla, sinônimo, marca genérica/nome comum e dimensão; também funcionar sem acentos. Filtros por categoria, aplicação e escala.
9. Cartões e páginas detalhadas com links de volta à matriz e às fichas procedimentais correspondentes, sem quebrar o acervo pré-existente.
10. Testes estruturais, de interface e de regressão; relatório de fontes e itens pendentes.

### Cobertura inicial recomendada

**Camada A — dispositivos vasculares:** cateter periférico e Gauge, cateteres centrais e PICC, conectores, extensores, equipos, scalp e agulhas.  
**Camada B — seringas e acesso medicamentoso:** volumes, agulhas, seringas, sistemas sem agulha, equipamentos de infusão.  
**Camada C — sondas e via aérea:** sondas urinárias e escala French, sondas enterais, tubos endotraqueais e acessórios de ventilação/oxigenação.  
**Camada D — fechamento e instrumentos:** fios e escalas USP, agulhas cirúrgicas, cabos/lâminas, pinças, tesouras, afastadores, porta-agulhas e hemostasia.

Não é necessário cadastrar todos os instrumentos do mundo no primeiro lote. É necessário que o **modelo de dados funcione e seja ampliável**, e que os materiais do lote inicial tenham fichas úteis, fontes e validações.

### Testes de demonstração para o agente

- Buscar `jelco`, `cateter intravenoso`, `IV`, `24G`, `sonda Foley`, `14 Fr`, `nylon 4-0`, `lâmina 15`, com equivalências e sem resultados enganadores.
- Abrir um material e confirmar variantes, escala, aplicação, precauções, atribuição visual, fonte e acesso ao procedimento relacionado.
- Conferir que a cor de um cateter é apresentada como dependente de padrão/tipo/fabricante quando necessário.
- Garantir que uma ficha sem imagem licenciada use visual neutro/placeholder próprio, sem copiar miniaturas de terceiros.
- Verificar todas as 33 trilhas/115 aulas e o estado de progresso após atualização, assim como a matriz de 28 módulos e a contagem de 227 tópicos.
- Rodar QA + interação desktop/mobile + teste negativo de dados incompletos.

## 5. Decisão de aceite

**MB01 APROVADO COM RESSALVAS.** É legítimo avançar ao MB02 porque o núcleo de arquitetura, IDs, navegação e preservação foi entregue. As correções MB01-01 e MB01-02 devem ser tratadas cedo, preferencialmente antes ou junto com o começo do MB02, pois busca e prioridades serão reutilizadas no Atlas. MB01-03 a MB01-05 devem integrar o modelo de relacionamento do Atlas/Procedimentos para evitar dívida técnica. MB01-06 e MB01-07 podem ser concluídos até a integração MB08, desde que não haja novas regressões.

**Não alterar a marca agora.** “Nexo Cirúrgico” permanece nome provisório; eventual decisão comercial será avaliada depois dos oito macroblocos.

## 6. Procedimento para auditorias seguintes

Para cada MB entregue, comparar ZIP anterior com o novo; conferir arquivos novos/alterados; testes estruturais; testes reais de navegação/pesquisa/ações; integridade dos vínculos; adequação didática e risco médico; registrar falhas com severidade e critérios verificáveis. Não chamar um procedimento de “validado clinicamente” sem avaliação especializada documentada. Não promover MVP demonstrativo como certificação de habilidade prática.
