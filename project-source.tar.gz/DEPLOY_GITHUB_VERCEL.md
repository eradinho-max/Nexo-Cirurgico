# Nexo Cirúrgico — publicação GitHub + Vercel (piloto, 14/10/2026)

## 1. O que este pacote entrega

- Aplicação estática HTML/CSS/JS, hash router (`#/dashboard`, `#/procedimentos`, `#/atlas`), sem banco e sem chaves de API.
- Build com `npm run build`, que gera **somente 13 arquivos públicos**, em `dist/`.
- `vercel.json` configura `buildCommand`/`outputDirectory` e headers de proteção.
- `.github/workflows/quality.yml` testa regressões e conteúdo a cada push/PR.
- `robots.txt`, meta robots e cabeçalho `X-Robots-Tag` configurados para **noindex** enquanto faltar revisão clínica.
- 38 fichas procedimentais formativas, nenhuma com status de revisão clínica concluída.

## 2. Preparar GitHub (grátis)

1. Criar um **repositório GitHub novo** (preferencialmente privado enquanto a revisão de direitos e conteúdo está pendente), por exemplo `nexo-cirurgico`.
2. Descompactar `NEXO_CIRURGICO_MB03_LOTE2_GITHUB_VERCEL.zip`. Os arquivos `index.html`, `package.json`, `vercel.json`, `assets/` e `.github/` devem ficar **na raiz do repositório**, não dentro de uma pasta extra.
3. Enviar os arquivos com Git ou pela interface de upload do GitHub. Se usar Git:

```bash
git init
git add .
git commit -m "MB03 lote 2: fichas técnicas e deploy estático"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/nexo-cirurgico.git
git push -u origin main
```

4. Verificar em **Actions** o fluxo `Quality gate (Nexo Cirúrgico)`. Ele não exige configuração de segredos.

## 3. Importar na Vercel

1. Em Vercel → **Add New → Project**, importar o repositório GitHub (conectar conta se necessário).
2. **Root Directory:** `./` (raiz).
3. **Framework Preset:** `Other`.
4. As configurações de `vercel.json` já informam: **Build Command:** `npm run build`; **Output Directory:** `dist`; **Install Command:** `echo 'Build estático: nenhuma dependência de produção'`.
5. Clicar em **Deploy**, aguardar o build e abrir a URL fornecida pela Vercel.
6. Testar as rotas `/#/dashboard`, `/#/procedimentos`, `/#/procedimento/PT-M05-03`, `/#/atlas` e a versão móvel.

A Vercel costuma gerar implantações automaticamente após commits no branch integrado. A disponibilidade e os limites do plano gratuito seguem os termos vigentes da Vercel.

## 4. Teste local antes do envio

Requer Node.js 20+; recomendado Node 22.

```bash
npm run qa
npm run build
npm run qa:deploy
npm run preview -- --dist
```

Abra `http://127.0.0.1:4173`. Para rodar o QA legado de interface via jsdom: `npm install && npm run qa:ui` em ambiente com acesso ao npm. Os testes principais de QA e build não dependem de instalação.

## 5. Segurança, publicação e limitações

- Não publicar dados reais de pacientes, chaves de API, senhas, planilhas restritas ou dados pessoais no repositório.
- A aplicação **não** fornece autenticação. Repositório privado ≠ site privado: a URL Vercel pode ser pública. Para acesso restrito, configurar mecanismo de proteção adequado antes de divulgar o link.
- O conteúdo médico não está aprovado para conduta clínica. O gate editorial impede a classificação como validado, mas **não bloqueia sua leitura no piloto**.
- As quatro imagens JPG antigas não entram no `dist/` e foram substituídas por SVGs originais no app. Confirmar a procedência antes de publicar/adicionar novos ativos.
- Os dados de progresso ficam no armazenamento local do navegador e podem ser perdidos ao limpar os dados.
- `noindex` protege a indexação, **não é medida de controle de acesso**. Remover `robots.txt` restritivo e meta/header robots somente após os gates clínico/editorial e a decisão de indexar.
- O cabeçalho CSP permite `style-src 'unsafe-inline'` por causa do estilo dinâmico existente; endurecer quando esse código for refatorado.
- A aplicação é estática: não inclui banco de dados, sincronização de progresso, API de vídeos ou login.

## 6. Se o deploy falhar

- **Página 404:** conferir Root Directory `./`, saída `dist` e build finalizado.
- **CSS/JS ausentes:** conferir arquivos publicados e caminho relativo na aba Network do navegador.
- **Rota direta:** usar `/#/procedimentos`, não `/procedimentos`, pois o app usa rota por `#`.
- **Tela em branco:** inspecionar Console e se scripts carregaram na ordem `data.js` → `procedimentos_mb03.js` → `app.js`.
- **Deploy de commit não atualiza:** confirmar integração Git e branch de produção.

## 7. Fontes técnicas

- Vercel — Configuring a Build: https://vercel.com/docs/builds/configure-a-build
- Vercel — Builds and Git-based deployment: https://vercel.com/docs/builds
- Vercel — Project configuration: https://vercel.com/docs/project-configuration/vercel-json
