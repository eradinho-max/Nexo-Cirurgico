/* QA autônomo do MB03, sem dependências externas. Executar node qa_mb03.js */
'use strict';
const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const root=__dirname, errors=[], results=[];
const ctx={window:{},console,localStorage:{getItem:()=>null,setItem(){}},location:{hash:'#/dashboard'},setTimeout:()=>0,clearTimeout:()=>{},requestAnimationFrame:()=>{},document:null};
const events={};
function element(){return {innerHTML:'',textContent:'',value:'',style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelectorAll:()=>[],querySelector:()=>null,focus(){},parentElement:{addEventListener(){},contains(){return false},classList:{add(){},remove(){}}}}}
const els={};
ctx.document={title:'',querySelectorAll:()=>[],addEventListener(){},getElementById(id){return els[id]||(els[id]=element())}};
ctx.window.window=ctx.window;ctx.window.document=ctx.document;ctx.window.scrollTo=()=>{};ctx.window.addEventListener=(name,fn)=>events[name]=fn;ctx.window.innerWidth=1366;
ctx.window.setTimeout=ctx.setTimeout;ctx.window.location=ctx.location;ctx.window.localStorage=ctx.localStorage;
vm.createContext(ctx);
for(const filename of ['data.js','procedimentos_mb03.js','app.js'])vm.runInContext(fs.readFileSync(path.join(root,filename),'utf8'),ctx,{filename});
const data=ctx.window.NEXO_DATA, pack=ctx.window.NEXO_PROCEDURES;
function check(name,cond){results.push({name,passed:!!cond});if(!cond)errors.push(name)}
const oldCounts={modules:33,lessons:115,quiz:210,cases:30,flashcards:137};
for(const [k,v] of Object.entries(oldCounts))check('acervo '+k,k==='lessons'?data.modules.reduce((n,m)=>n+m.lessons.length,0)===v:data[k].length===v);
check('46 fichas com IDs únicos',pack.procedures.length===46&&new Set(pack.procedures.map(p=>p.id)).size===46);
check('227 tópicos preservados',data.technicalCurriculum.modules.reduce((n,m)=>n+m.topics.length,0)===227);
check('46 tópicos em revisão técnica',data.technicalCurriculum.modules.flatMap(m=>m.topics).filter(x=>x.status==='revisao-tecnica').length===46);
check('2 macroblocos completos, MB03 em execução',data.technicalCurriculum.macroblocks.filter(m=>m.status==='Entregue').length===2&&data.technicalCurriculum.macroblocks.find(m=>m.id==='MB03')?.status==='Em desenvolvimento');
const fieldIds=data.technicalCurriculum.lessonSchema.map(x=>x.id);
for(const p of pack.procedures){
 check('14 campos '+p.id,fieldIds.length===14&&fieldIds.every(f=>Array.isArray(p.fields[f])&&p.fields[f].length));
 check('referências '+p.id,p.references.length>=1&&p.references.every(x=>/^https:\/\//.test(x.url)));
 check('metadados/revisão '+p.id,p.editorial.clinicalReviewer===null&&p.editorial.status==='revisao-tecnica'&&p.supervision&&p.population&&p.professionalScope);
 check('material Atlas '+p.id,p.materialLinks.every(id=>data.materialAtlas.materials.some(m=>m.id===id)));
 check('tópico válido '+p.id,p.topicIds.every(id=>data.technicalCurriculum.modules.some(m=>m.topics.some(t=>t.id===id))));
 check('erros críticos '+p.id,p.criticalErrors.length>=2);
}
const render=(route)=>{ctx.location.hash='#/'+route;events.hashchange();return els.app.innerHTML;};
check('dashboard renderiza',render('dashboard').includes('Nexo Cirúrgico'));
check('46 cards no índice', (render('procedimentos').match(/class="procedure-card"/g)||[]).length===46);
check('46 rotas diretas',pack.procedures.every(p=>render('procedimento/'+p.id).includes('class="procedure-header"')));
let html=render('procedimento/PT-M05-01');
check('14 sections no acesso vascular',(html.match(/class="panel procedure-field"/g)||[]).length===14);
check('materiais de acesso links reversíveis',html.includes('#/atlas/MAT-VAS-001'));
check('hemocultura com referência CDC',render('procedimento/PT-M05-03').includes('Collect adult blood culture sets'));
check('tala sugar-tong com fonte',render('procedimento/PT-M13-03').includes('Sugar-tong arm splint'));
check('sutura contínua com referências',render('procedimento/PT-M07-04').includes('Laceration repair'));
check('mensagem didática sem bloqueio clínico',html.includes('Guia educacional')&&!html.includes('Não validado clinicamente'));
check('kit de simulação contextual',html.includes('Conferência da bandeja / kit')&&html.includes('proc-kit-check'));
check('ficha matriz contextual',render('matriz-tecnica/M05/PT-M05-01').includes('#/procedimento/PT-M05-01'));
check('atlas direciona para procedimento',render('atlas/MAT-VAS-001').includes('#/procedimento/PT-M05-01'));
check('aula antiga continua acessível',render('aula/'+data.modules[0].lessons[0].id).includes('aula'));
check('biblioteca antiga continua acessível',render('biblioteca').includes('Trilhas de aprendizagem'));
check('rota inválida protegida',render('procedimento/PT-INVALIDO').includes('Página não encontrada')||els.pageTitle.textContent==='Página não encontrada');
const index=fs.readFileSync(path.join(root,'index.html'),'utf8');
check('arquivos MB03 carregados em ordem', index.indexOf('data.js') < index.indexOf('procedimentos_mb03.js')&&index.indexOf('procedimentos_mb03.js')<index.indexOf('app.js'));
check('rodapé com crédito InMed', index.includes('Product by')&&index.includes('InMed'));
console.log(JSON.stringify({status:errors.length?'FALHOU':'APROVADO',passed:results.filter(x=>x.passed).length,total:results.length,errors},null,2));
if(errors.length)process.exit(1);
