from pathlib import Path
p=Path(__file__).parent
f=p/'app.js'; s=f.read_text()
changes={
 '${procedures.length} fichas técnicas em revisão':'${procedures.length} fichas de estudo disponíveis',
 'Abrir ficha técnica em revisão':'Abrir ficha técnica',
 'Somente uma ficha aprovada poderá avançar nos estados editoriais; relação transversal não altera esse status.':'O preenchimento das fichas evolui por etapas editoriais; relações transversais não equivalem a procedimentos completos.',
 'Antes da publicação':'Dados da ficha',
 'Preenchimento e revisão obrigatórios':'Dados editoriais em atualização',
 'Conteúdo em revisão técnica — não publicado como protocolo clínico':'Guia de estudo e simulação',
 'Preparação para simulação e treinamento supervisionado. Aplicação no paciente depende de habilitação e protocolos locais.':'Material didático disponível para estudo. Em atendimento real, seguir formação, supervisão e protocolos do serviço.',
 'Lote textual para simulação. As ilustrações anatômicas específicas ainda serão desenvolvidas e validadas.':'Sequência didática para simulação. Ilustrações específicas serão acrescentadas progressivamente.',
 'Não validado clinicamente':'Guia educacional',
 'Revisor clínico: não atribuído. Não usar como protocolo assistencial independente.':'Estudo independente disponível. A execução no paciente exige treinamento e supervisão adequados.',
 '${esc(proc.editorial.status.replaceAll(\'-\',\' \'))}':'Conteúdo de estudo',
 'Versão ${esc(selected.review.version)}. Sem revisor clínico atribuído; não classificada como validada.':'Versão didática ${esc(selected.review.version)}. Compare as especificações com as instruções do fabricante.',
 '<span class="eyebrow">REVISÃO</span><h2>${esc(selected.review.status)}</h2>':'<span class="eyebrow">EDIÇÃO</span><h2>Ficha de estudo</h2>',
 'As fichas são educacionais e permanecem em revisão editorial.':'O Atlas é didático e está disponível para consulta.',
 'Bibliografia específica em revisão editorial.':'Bibliografia específica em preparação.',
 'Os itens ainda precisam de revisão técnica independente e análise após aplicação piloto.':'Itens de treino que podem ser aprimorados com uso, referências e correções documentadas.',
 '<span class="eyebrow">STATUS DO GATE</span><h2>Auditoria estrutural aprovada; validação pendente</h2><p>O banco alcançou a distribuição quantitativa planejada e os gabaritos foram balanceados. O próximo gate exige revisão independente, piloto e análise dos itens.</p>':'<span class="eyebrow">BANCO DIDÁTICO</span><h2>Questões disponíveis para estudo</h2><p>Questões e gabaritos podem receber correções editoriais ao longo do desenvolvimento, sem impedir o acesso à plataforma.</p>',
 'Cada item precisa de revisão clínica antes de ser indicado como técnica compatível com protocolos brasileiros.':'A adequação ao uso assistencial depende das recomendações atuais e dos protocolos locais; o estudo permanece acessível.',
 'Material audiovisual ilustra uma prática, mas não substitui a instrução validada, a supervisão nem as instruções de uso do fabricante.':'Material audiovisual ilustra uma prática, mas não substitui supervisão nem instruções de uso do fabricante.',
 'Do protótipo à plataforma validada':'Do protótipo à biblioteca de procedimentos',
 '<span class="eyebrow">DEFINIÇÃO DE PRONTO</span><h2>Uma trilha só atravessa o gate clínico quando...</h2>':'<span class="eyebrow">QUALIDADE EDITORIAL</span><h2>Critérios para melhorar cada trilha</h2>',
 'Revisão técnica assinada':'Correções técnicas documentadas',
 'Questões revisadas e justificadas':'Questões explicadas e corrigíveis',
 'Mídia e licença documentadas':'Mídia e licença identificadas',
 'Acessibilidade e errata verificadas':'Acessibilidade e errata acessíveis',
 'Ficha técnica MB03 • ${proc.id} • revisão pendente':'Ficha técnica MB03 • ${proc.id} • estudo disponível',
 'Não substitui formação profissional, treinamento supervisionado, avaliação clínica ou protocolos institucionais.':'Não substitui treinamento supervisionado, avaliação clínica ou protocolos institucionais.',
}
for a,b in changes.items():
 if a not in s: print('NOT FOUND:',a[:100]);continue
 s=s.replace(a,b)
f.write_text(s)
# update profile/footer and no warning screen
f=p/'index.html';s=f.read_text().replace('Selecionar idioma da interface','Selecionar idioma do conteúdo e da interface').replace('<option value="es">ES · beta</option>','<option value="es">Español</option>').replace('<option value="pt">PT</option>','<option value="pt">Português</option>').replace('      <div id="localePending" class="locale-pending" hidden role="status"></div>\n','')
f.write_text(s)
f=p/'procedimentos_mb03.js';s=f.read_text().replace('/* MB03: fichas educacionais originais em revisão clínica; não são protocolos. */','/* Fichas de estudo prático. Fontes e versões registradas; não constituem autorização profissional. */')
f.write_text(s)
