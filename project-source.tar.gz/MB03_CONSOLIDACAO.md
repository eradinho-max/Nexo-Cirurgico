# Consolidação MB03 — 14/10/2026

- Correção auditada: ZIP da entrega anunciada como Lote 3 continha **38**, não 46 fichas. Foram aplicadas as 8 fichas do script, agora **46 de fato**.
- Tipografia: `html` e corpo 16 px (aprox. 12 pt), declarações CSS abaixo de 14 px elevadas a 14 px (aprox. 10,5 pt), linha de leitura 1,55–1,7.
- Atlas: 30 → 41 materiais; 133 → 158 variantes; nova categoria de imobilização. Fichas novas de fios, fitas, grampeador, removedor de grampos, malha, acolchoamento, gesso, fibra de vidro e atadura.
- Desenhos esquemáticos próprios (não anatômicos, sem escala) diferenciados por família de material, com aviso de desenho didático.
- Novos materiais relacionados bidirecionalmente a procedimentos; status permanecem em `revisao-editorial` e `revisao-tecnica`.
- Validações e testes integrados revisados para nova contagem.
- A aplicação é **educacional** e não substitui prática supervisionada, IFU, protocolos institucionais ou revisão clínica especializada.
- Fontes gerais: FDA (surgical sutures), AAOS OrthoInfo (care of casts and splints) e IFU do fabricante. Sem validação independente de modelo, lote, dispositivo ou conduta clínica.
- A publicação na Vercel não prova acessibilidade, correção clínica ou direitos de todos os ativos presentes na fonte interna; apenas `dist` deve ser publicado.

## Próximo passo

Auditoria clínica independente por módulos, avaliação de contraste e acessibilidade (WCAG), normalização definitiva do código GitHub em arquivos versionáveis e depois MB04 — Cirurgia e Anestesia.
