/* Nexo Cirúrgico — MB04 Lote 2; extensão modular do currículo existente. */
(function(){
  'use strict';
  const d=window.NEXO_DATA,p=window.NEXO_PROCEDURES;
  if(!d?.materialAtlas||!p?.procedures)throw new Error('MB04 L2: base não inicializada');
  const topics=d.technicalCurriculum.modules.flatMap(m=>m.topics);
  const index=new Map(topics.map(t=>[t.id,t]));
  const additions=[
  {
    "id": "PT-M08-01",
    "topicIds": [
      "PT-M08-01"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-001"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Verificar alergia, lesões extensas, idade, superfície exposta e absorção sistêmica; nem toda formulação serve para mucosas.",
      "Irritação, reação alérgica ou toxicidade sistêmica por aplicação excessiva.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Aplicação de agente anestésico sobre pele ou mucosa íntegra, sem punção, dentro da indicação e apresentação autorizadas."
      ],
      "indications": [
        "Preparo para procedimentos superficiais ou redução de desconforto em situações apropriadas."
      ],
      "contraindications": [
        "Verificar alergia, lesões extensas, idade, superfície exposta e absorção sistêmica; nem toda formulação serve para mucosas."
      ],
      "anatomy": [
        "Diferenciar pele íntegra, mucosa e ferida: a barreira altera absorção e risco."
      ],
      "materials": [
        "Formulação tópica identificada; aplicador descartável; luvas; temporizador e folha de checagem."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Sem dose universal: observar formulação, peso, área, tempo e instruções do fabricante."
      ],
      "sequence": [
        "Conferir identidade, indicação e local de aplicação no manequim.",
        "Verificar nome, concentração, validade, integridade e indicação da formulação.",
        "Delimitar no modelo a superfície permitida e calcular exposição total de acordo com referência do produto.",
        "Demonstrar aplicação sem contaminação do aplicador, seguindo instruções do fabricante.",
        "Conferir janela de ação, reavaliar conforto e vigiar sinais de toxicidade."
      ],
      "confirmation": [
        "Registrar local, horário, formulação e resposta; verificar integridade da pele."
      ],
      "complications": [
        "Irritação, reação alérgica ou toxicidade sistêmica por aplicação excessiva."
      ],
      "aftercare": [
        "Remover resíduo quando indicado e documentar efeitos/queixas."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASRA-LAST-2020",
        "title": "ASRA — LAST checklist: recognition and response",
        "url": "https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-02",
    "topicIds": [
      "PT-M08-02"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-MED-001",
      "MAT-MED-002",
      "MAT-ANE-001",
      "MAT-ANE-002"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Reavaliar em suspeita de infecção no trajeto, alergia relevante e necessidade de dose que exceda limite individual.",
      "Punção vascular, hematoma, lesão nervosa, reação alérgica e toxicidade sistêmica.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Bloqueio da sensibilidade mediante infiltração de anestésico local em tecido selecionado."
      ],
      "indications": [
        "Procedimentos superficiais ou pequenos reparos após avaliação de anatomia, dor e alternativa anestésica."
      ],
      "contraindications": [
        "Reavaliar em suspeita de infecção no trajeto, alergia relevante e necessidade de dose que exceda limite individual."
      ],
      "anatomy": [
        "Planos cutâneos, vasos e nervos superficiais; identificar estruturas que não devem ser atravessadas."
      ],
      "materials": [
        "Seringa e agulha apropriadas, antisséptico, luvas, anestésico rotulado e kit de resposta a emergências."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Nunca transferir uma dose máxima entre formulações ou pacientes; adotar referência farmacológica atual."
      ],
      "sequence": [
        "Identificar área, documentar alergias e calcular previamente dose total considerando peso e formulação.",
        "Preparar assepsia, rotular seringa e separar descarte imediato de perfurocortantes.",
        "No simulador, demonstrar plano de infiltração de modo progressivo, reconhecendo estruturas e mantendo comunicação.",
        "Verificar sinais de injeção intravascular ou desconforto inesperado e interromper diante de suspeita.",
        "Aguardar efeito e testar sensibilidade antes de iniciar a simulação do procedimento principal."
      ],
      "confirmation": [
        "Área planejada apresenta resposta sensitiva esperada e ausência de sinais de toxicidade."
      ],
      "complications": [
        "Punção vascular, hematoma, lesão nervosa, reação alérgica e toxicidade sistêmica."
      ],
      "aftercare": [
        "Documentar medicamento, concentração, quantidade total, local e intercorrências."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASRA-LAST-2020",
        "title": "ASRA — LAST checklist: recognition and response",
        "url": "https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-03",
    "topicIds": [
      "PT-M08-03"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-MED-001",
      "MAT-MED-002",
      "MAT-ANE-002",
      "MAT-ANE-003",
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Avaliar coagulopatia, infecção, alergia, alterações neurológicas prévias e possibilidade de síndrome compartimental mascarada.",
      "Injeção intravascular, lesão de nervo, hematoma, infecção e toxicidade sistêmica.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Anestesia regional em nervos periféricos com técnica e monitorização específicas."
      ],
      "indications": [
        "Analgesia/anestesia de território definido quando benefício, experiência e anatomia permitem."
      ],
      "contraindications": [
        "Avaliar coagulopatia, infecção, alergia, alterações neurológicas prévias e possibilidade de síndrome compartimental mascarada."
      ],
      "anatomy": [
        "Territórios nervosos, vasos adjacentes e princípios de ultrassonografia; sem usar posições anatômicas como receita universal."
      ],
      "materials": [
        "Ultrassom quando disponível, transdutor protegido, agulha apropriada, monitorização e kit de emergência."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Execução clínica depende de treinamento em bloqueio específico, não da leitura desta ficha."
      ],
      "sequence": [
        "Confirmar indicação, lateralidade, exame neurológico basal e consentimento.",
        "Revisar riscos do bloqueio, anticoagulantes, fármacos e dose cumulativa de anestésico local.",
        "No modelo, identificar nervos e vasos por anatomia/ultrassom e planejar caminho que evite estruturas vulneráveis.",
        "Simular comunicação com paciente, aspiração/monitorização conforme técnica e pausa diante de parestesia ou dor intensa.",
        "Conferir distribuição sensitiva e documentar limites e instruções de proteção do membro."
      ],
      "confirmation": [
        "Território esperado documentado e monitorização adequada durante e depois."
      ],
      "complications": [
        "Injeção intravascular, lesão de nervo, hematoma, infecção e toxicidade sistêmica."
      ],
      "aftercare": [
        "Vigiar recuperação motora/sensitiva; proteção de membro insensível e instruções de retorno."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASRA-LAST-2020",
        "title": "ASRA — LAST checklist: recognition and response",
        "url": "https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-04",
    "topicIds": [
      "PT-M08-04"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-AIR-002",
      "MAT-AIR-001",
      "MAT-MED-003",
      "MAT-ANE-004",
      "MAT-ANE-005"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não realizar sem equipe e materiais para ventilação de resgate, monitorização e observação pós-procedimento.",
      "Apneia, aspiração, hipotensão, dessaturação e sedação mais profunda que a pretendida.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Sedação farmacológica durante procedimentos, com risco de evolução inadvertida para planos mais profundos."
      ],
      "indications": [
        "Procedimento doloroso ou ansiogênico quando a equipe dispõe de capacidade de resgate da via aérea."
      ],
      "contraindications": [
        "Não realizar sem equipe e materiais para ventilação de resgate, monitorização e observação pós-procedimento."
      ],
      "anatomy": [
        "Reconhecimento de graus de sedação, reflexos de via aérea e sinais de ventilação inadequada."
      ],
      "materials": [
        "Monitor multiparamétrico, oximetria, capnografia conforme indicação, oxigênio, sucção e bolsa-válvula-máscara."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Disponibilidade de reversores quando pertinentes não substitui competência de resgate respiratório."
      ],
      "sequence": [
        "Definir necessidade de sedação, avaliação de via aérea, jejum pertinente e consentimento.",
        "Atribuir funções separadas a quem executa o procedimento e a quem monitora o paciente.",
        "Realizar checklist simulado de equipamento, oxigenação, capnografia e dispositivos de resgate.",
        "Treinar titulação e monitorização com cenário de simulação; não usar doses genéricas nem esquema único.",
        "Simular reconhecimento de hipoventilação/obstrução, chamada de ajuda e transição para observação."
      ],
      "confirmation": [
        "Ventilação, oxigenação, hemodinâmica, nível de consciência e plano de resgate verificados."
      ],
      "complications": [
        "Apneia, aspiração, hipotensão, dessaturação e sedação mais profunda que a pretendida."
      ],
      "aftercare": [
        "Critérios de recuperação e acompanhante/alta individualizados; documentar eventos."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASA-FAST-2023",
        "title": "ASA — Preoperative fasting practice guidelines 2023",
        "url": "https://doi.org/10.1097/ALN.0000000000004381",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-05",
    "topicIds": [
      "PT-M08-05"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-MED-001",
      "MAT-ANE-002",
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Avaliar recusa, infecção no local, alteração de coagulação/anticoagulação e situações de instabilidade.",
      "Hipotensão, bloqueio alto, cefaleia pós-punção, hematoma, infecção e eventos neurológicos.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Anestesia neuroaxial com deposição de anestésico no espaço subaracnóideo por profissional habilitado."
      ],
      "indications": [
        "Cirurgias adequadas ao bloqueio espinhal após escolha individualizada."
      ],
      "contraindications": [
        "Avaliar recusa, infecção no local, alteração de coagulação/anticoagulação e situações de instabilidade."
      ],
      "anatomy": [
        "Coluna lombar, meninges, líquido cefalorraquidiano e níveis sensitivos; anatomia deve ser verificada individualmente."
      ],
      "materials": [
        "Kit estéril neuroaxial, agulha espinhal, antisséptico compatível, monitor e suporte hemodinâmico."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Tempos para anticoagulantes e recomendações neuroaxiais requerem diretrizes vigentes específicas."
      ],
      "sequence": [
        "Simular avaliação de indicação, contraindicadores, medicamentos e consentimento.",
        "Conferir time-out, monitorização, acesso venoso, assepsia e materiais estéreis.",
        "Reconhecer em modelo anatômico os espaços e planos relevantes; técnica de punção exclusivamente em treinamento especializado.",
        "Treinar comunicação contínua e identificação precoce de bloqueio alto ou hipotensão.",
        "Mapear nível sensitivo, documentar dados e simular transferência para vigilância."
      ],
      "confirmation": [
        "Nível e extensão do bloqueio avaliados por profissional treinado, com estabilidade do paciente."
      ],
      "complications": [
        "Hipotensão, bloqueio alto, cefaleia pós-punção, hematoma, infecção e eventos neurológicos."
      ],
      "aftercare": [
        "Monitorar regressão, função motora, retenção urinária e sintomas de alarme."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "ASRA-LAST-2020",
        "title": "ASRA — LAST checklist: recognition and response",
        "url": "https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-06",
    "topicIds": [
      "PT-M08-06"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-MED-001",
      "MAT-ANE-002",
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Reavaliar coagulopatias, anticoagulantes, infecção, instabilidade ou contraindicação individual.",
      "Punção dural acidental, hipotensão, infecção, hematoma, injeção intravascular ou intratecal.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Técnica neuroaxial no espaço epidural, eventualmente com cateter para administração contínua."
      ],
      "indications": [
        "Analgesia/anestesia regional apropriada sob avaliação de anestesiologia."
      ],
      "contraindications": [
        "Reavaliar coagulopatias, anticoagulantes, infecção, instabilidade ou contraindicação individual."
      ],
      "anatomy": [
        "Espaço epidural, vértebras, meninges, estruturas vasculonervosas e localização do cateter."
      ],
      "materials": [
        "Kit epidural, cateter e filtro quando indicados, campos estéreis, monitorização e materiais de resgate."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Não misturar conectores de sistemas diferentes; confirmar dispositivos e compatibilidades por fabricante."
      ],
      "sequence": [
        "Confirmar consentimento, indicação, anticoagulação e risco infeccioso.",
        "Conferir materiais, rotulagem, monitorização e checklist de assepsia no simulador.",
        "Reconhecer modelos anatômicos do espaço epidural e conexões exclusivas apropriadas.",
        "Treinar verificação de cateter, comunicação de parestesias e vigilância de efeitos adversos.",
        "Simular registro do cateter, medicamentos autorizados e plano de retirada segura."
      ],
      "confirmation": [
        "Identificação do dispositivo, plano de vigilância e documentação dos déficits basais."
      ],
      "complications": [
        "Punção dural acidental, hipotensão, infecção, hematoma, injeção intravascular ou intratecal."
      ],
      "aftercare": [
        "Monitorização sensitivo-motora e medidas de segurança durante a permanência do cateter."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "ASRA-LAST-2020",
        "title": "ASRA — LAST checklist: recognition and response",
        "url": "https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-07",
    "topicIds": [
      "PT-M08-07"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-AIR-001",
      "MAT-AIR-002",
      "MAT-MED-003",
      "MAT-ANE-004",
      "MAT-ANE-005",
      "MAT-ANE-006"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Sem equipe, monitorização, máquina testada e plano de via aérea de resgate não se inicia anestesia geral.",
      "Aspiração, hipoxemia, instabilidade cardiovascular, eventos de via aérea e despertar inadequado.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Estado anestésico controlado que pode incluir inconsciência, analgesia, relaxamento e suporte à ventilação."
      ],
      "indications": [
        "Intervenções em que anestesia geral é a modalidade apropriada após avaliação."
      ],
      "contraindications": [
        "Sem equipe, monitorização, máquina testada e plano de via aérea de resgate não se inicia anestesia geral."
      ],
      "anatomy": [
        "Proteção da via aérea, ventilação e perfusão durante indução, manutenção e emergência."
      ],
      "materials": [
        "Máquina e circuito de anestesia, monitor, dispositivo de via aérea, aspiração e sistema de medicamentos rotulados."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Esta ficha não substitui plano individualizado do anestesiologista nem treinamento em via aérea."
      ],
      "sequence": [
        "Revisar avaliação anestésica, jejum, risco de aspiração, alergias e via aérea difícil.",
        "Realizar checklist da sala e da máquina com teste de alarme, ventilação e oxigênio.",
        "Simular divisão de funções e fases de anestesia, incluindo comunicação de indução e incisão.",
        "Treinar resposta a hipotensão, dessaturação, falha de ventilação e situações críticas em manequim.",
        "Conferir despertar, proteção da via aérea e transferência estruturada para recuperação."
      ],
      "confirmation": [
        "Monitorização contínua documentada, troca gasosa e estabilidade conforme plano anestésico."
      ],
      "complications": [
        "Aspiração, hipoxemia, instabilidade cardiovascular, eventos de via aérea e despertar inadequado."
      ],
      "aftercare": [
        "Handoff para SRPA com dados de via aérea, medicamentos, dor, náusea e intercorrências."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASA-FAST-2023",
        "title": "ASA — Preoperative fasting practice guidelines 2023",
        "url": "https://doi.org/10.1097/ALN.0000000000004381",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-08",
    "topicIds": [
      "PT-M08-08"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-004",
      "MAT-ANE-005",
      "MAT-ANE-006",
      "MAT-AIR-002"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não usar circuito com vazamento, conexões inadequadas, filtros incompatíveis ou alarmes inoperantes.",
      "Hipóxia por falha de gases, vazamento, desconexão, reinspiração de CO2 e alarme desativado.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Verificação funcional de máquina, circuito respiratório, alarmes, fonte de gases e monitorização."
      ],
      "indications": [
        "Antes de iniciar anestesia e após alterações do sistema que exijam nova checagem."
      ],
      "contraindications": [
        "Não usar circuito com vazamento, conexões inadequadas, filtros incompatíveis ou alarmes inoperantes."
      ],
      "anatomy": [
        "Fluxo de gases, absorvedor, vaporização, válvulas, mangueiras, capnografia e ventilação."
      ],
      "materials": [
        "Estação de anestesia, circuito e reservatório, fonte de O2, analisador de gases, capnógrafo e sucção."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Os passos específicos do autoteste dependem do modelo e manual do fabricante."
      ],
      "sequence": [
        "Conferir alimentação elétrica, oxigênio e fontes de reserva conforme checklist do equipamento.",
        "Verificar integridade e compatibilidade do circuito, conexões, filtro e sistema de exaustão.",
        "Executar teste automatizado/manual recomendado pelo fabricante e conferir vazamentos.",
        "Treinar alarmes de pressão, volume, apneia, desconexão e falha de suprimento.",
        "Registrar liberação do equipamento e simular plano alternativo diante de falha."
      ],
      "confirmation": [
        "Teste documentado e alarmes funcionais, circuito íntegro e dispositivo de ventilação de resgate pronto."
      ],
      "complications": [
        "Hipóxia por falha de gases, vazamento, desconexão, reinspiração de CO2 e alarme desativado."
      ],
      "aftercare": [
        "Repetir verificação após substituição ou desconexão relevante do circuito."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-09",
    "topicIds": [
      "PT-M08-09"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-AIR-002",
      "MAT-ANE-004",
      "MAT-ANE-005"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não confundir com reação vagal, sedação excessiva ou anafilaxia; avaliar contexto e sinais.",
      "Convulsão, arritmia grave, parada cardiorrespiratória e recorrência tardia.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Reconhecimento e resposta à toxicidade sistêmica por anestésicos locais (LAST), evento raro e potencialmente fatal."
      ],
      "indications": [
        "Treinamento de segurança obrigatório para quem utiliza anestésicos locais, especialmente em bloqueios."
      ],
      "contraindications": [
        "Não confundir com reação vagal, sedação excessiva ou anafilaxia; avaliar contexto e sinais."
      ],
      "anatomy": [
        "Sinais neurológicos/cardiovasculares precoces e colapso, após exposição a anestésico local."
      ],
      "materials": [
        "Monitor e suporte ventilatório, kit de emergência e emulsão lipídica protocolizada disponível."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Não aplicar doses de emulsão lipídica memorizadas de maneira genérica: utilizar algoritmo ASRA oficial vigente."
      ],
      "sequence": [
        "Em simulação, identificar sinais de alarme após aplicação de anestésico local.",
        "Interromper imediatamente a administração simulada e solicitar equipe de emergência.",
        "Priorizar oxigenação, ventilação e suporte circulatório por equipe habilitada.",
        "Localizar checklist ASRA e kit de emulsão lipídica, seguindo doses e algoritmos da fonte atual em serviço.",
        "Simular monitorização prolongada, registro e comunicação pós-evento."
      ],
      "confirmation": [
        "Reconhecimento oportuno, acionamento de ajuda e protocolo de resgate prontamente disponível."
      ],
      "complications": [
        "Convulsão, arritmia grave, parada cardiorrespiratória e recorrência tardia."
      ],
      "aftercare": [
        "Observação em ambiente apropriado após evento, documentação da dose total e investigação."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASRA-LAST-2020",
        "title": "ASRA — LAST checklist: recognition and response",
        "url": "https://asra.com/the-asra-family/special-interest-groups/cancer-pain-and-supportive-care-sig/cancer-pain-sig-article/guidelines/2020/11/01/checklist-for-treatment-of-local-anesthetic-systemic-toxicity",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M08-10",
    "topicIds": [
      "PT-M08-10"
    ],
    "title": null,
    "priority": "P0–P2",
    "level": "Treinamento supervisionado; varia por técnica",
    "scope": "Anestesia e analgesia",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-004",
      "MAT-ANE-005",
      "MAT-AIR-003"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Alta sem recuperação respiratória/hemodinâmica, controle de dor ou critérios institucionais documentados.",
      "Hipoventilação, obstrução, instabilidade, sangramento e sedação residual.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Vigilância da transição entre anestesia e recuperação até critérios apropriados de transferência ou alta."
      ],
      "indications": [
        "Após procedimentos anestésicos, inclusive sedação e anestesia regional conforme caso."
      ],
      "contraindications": [
        "Alta sem recuperação respiratória/hemodinâmica, controle de dor ou critérios institucionais documentados."
      ],
      "anatomy": [
        "Via aérea, consciência, circulação, temperatura, dor, náusea, sangramento e regressão de bloqueios."
      ],
      "materials": [
        "Oxímetro, pressão arterial, oxigênio, aspiração e materiais de emergência da SRPA."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Uma escala de recuperação isolada não substitui avaliação clínica contextual."
      ],
      "sequence": [
        "Receber passagem estruturada do anestesista com via aérea, comorbidades, medicamentos e intercorrências.",
        "Instalar monitorização e checar oxigenação, ventilação e estado de consciência.",
        "Avaliar dor, náusea, sangramento, hipotermia e déficits residuais.",
        "Reavaliar periodicamente sinais e tratar intercorrências conforme plano assistencial.",
        "Conferir critérios de transferência/alta institucional e registrar responsáveis e orientações."
      ],
      "confirmation": [
        "Critérios documentados, sinais de alerta ausentes ou tratados, plano de continuidade claro."
      ],
      "complications": [
        "Hipoventilação, obstrução, instabilidade, sangramento e sedação residual."
      ],
      "aftercare": [
        "Handoff detalhado e orientações sobre analgesia, cuidados e retorno."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-01",
    "topicIds": [
      "PT-M09-01"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não usar classificação ASA ou questionário isolado como substituto de história e exame.",
      "Omissão de anticoagulantes, alergias, apneia obstrutiva, doença cardíaca ou risco de aspiração.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Avaliação dirigida de risco clínico e anestésico que sustenta a preparação e decisão compartilhada."
      ],
      "indications": [
        "Antes de procedimento cirúrgico ou anestésico, proporcional à urgência e complexidade."
      ],
      "contraindications": [
        "Não usar classificação ASA ou questionário isolado como substituto de história e exame."
      ],
      "anatomy": [
        "Vias aéreas, cardiopulmonar, capacidade funcional, fragilidade, estado nutricional e exames pertinentes."
      ],
      "materials": [
        "Ficha clínica, lista de medicamentos, alergias e ferramenta institucional de estratificação."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Avaliação pré-anestésica definitiva cabe à equipe anestésica, com decisão contextual."
      ],
      "sequence": [
        "Confirmar cirurgia, urgência, identidade e responsável pela informação.",
        "Revisar antecedentes, procedimentos prévios, complicações anestésicas, alergias e medicamentos.",
        "Avaliar via aérea, sinais vitais, sintomas cardiopulmonares e risco de eventos relevantes.",
        "Identificar aspectos modificáveis e encaminhamentos sem pedir exames desnecessários.",
        "Compartilhar plano de risco e registrar pendências antes da cirurgia."
      ],
      "confirmation": [
        "Riscos relevantes identificados, plano comunicável e pendências resolvidas ou justificadas."
      ],
      "complications": [
        "Omissão de anticoagulantes, alergias, apneia obstrutiva, doença cardíaca ou risco de aspiração."
      ],
      "aftercare": [
        "Atualizar avaliação se condição clínica ou plano cirúrgico mudar."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG45",
        "title": "NICE NG45 — Routine preoperative tests",
        "url": "https://www.nice.org.uk/guidance/ng45/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-02",
    "topicIds": [
      "PT-M09-02"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não aplicar jejum de paciente saudável a gestantes, emergências, gastroparesia ou outros perfis de risco aumentado.",
      "Aspiração por jejum inadequado e eventos por restrição excessiva de líquidos.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Planejamento de ingestão de alimentos/líquidos para reduzir risco de aspiração sem prolongar jejum desnecessário."
      ],
      "indications": [
        "Em procedimentos eletivos com anestesia geral, regional ou sedação conforme risco e protocolo."
      ],
      "contraindications": [
        "Não aplicar jejum de paciente saudável a gestantes, emergências, gastroparesia ou outros perfis de risco aumentado."
      ],
      "anatomy": [
        "Fisiologia do esvaziamento gástrico, risco de regurgitação e aspiração."
      ],
      "materials": [
        "Quadro de horários, prescrição e instruções escritas ao paciente."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Exemplo 2 h é específico para líquidos claros e grupos definidos; não equivale a jejum de sólidos."
      ],
      "sequence": [
        "Confirmar cirurgia, anestesia prevista e fatores de risco para aspiração.",
        "Registrar última ingestão por categoria, horário e quantidade estimada.",
        "Verificar regras adequadas à população e técnica segundo protocolo de anestesia.",
        "Em adultos saudáveis eletivos, explicar que líquidos claros podem ser permitidos até 2 h antes conforme ASA/NICE; não extrapolar.",
        "Documentar descumprimento, comunicar equipe e reorganizar plano quando necessário."
      ],
      "confirmation": [
        "História de jejum validada e conduta individual documentada."
      ],
      "complications": [
        "Aspiração por jejum inadequado e eventos por restrição excessiva de líquidos."
      ],
      "aftercare": [
        "Reintrodução de ingestão oral após segurança de deglutição e decisão assistencial."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "ASA-FAST-2023",
        "title": "ASA — Preoperative fasting practice guidelines 2023",
        "url": "https://doi.org/10.1097/ALN.0000000000004381",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-03",
    "topicIds": [
      "PT-M09-03"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não pedir hemograma, coagulograma, ECG, radiografia ou função renal indiscriminadamente.",
      "Falso positivo, atraso desnecessário e exame útil omitido.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Seleção criteriosa de exames com base no risco da cirurgia, história e condições do paciente."
      ],
      "indications": [
        "Avaliação pré-operatória eletiva e reavaliações quando mudanças clínicas o justificarem."
      ],
      "contraindications": [
        "Não pedir hemograma, coagulograma, ECG, radiografia ou função renal indiscriminadamente."
      ],
      "anatomy": [
        "Correspondência exame → pergunta clínica → decisão que pode ser modificada."
      ],
      "materials": [
        "Critérios NICE NG45, resultados anteriores e solicitação clínica."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "NICE NG45 se refere a pessoas >16 anos em cirurgia eletiva; não é tabela universal para emergências."
      ],
      "sequence": [
        "Classificar complexidade do procedimento e condição clínica individual.",
        "Revisar exames recentes válidos e resultados anormais conhecidos.",
        "Relacionar comorbidades e medicações aos testes potencialmente úteis.",
        "Solicitar somente testes capazes de orientar conduta, conforme diretriz e contexto.",
        "Registrar justificativa, interpretação e plano diante de achados."
      ],
      "confirmation": [
        "Cada exame possui finalidade clínica identificável e resultado acompanhado."
      ],
      "complications": [
        "Falso positivo, atraso desnecessário e exame útil omitido."
      ],
      "aftercare": [
        "Comunicar alterações relevantes e planejar eventual reavaliação."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG45",
        "title": "NICE NG45 — Routine preoperative tests",
        "url": "https://www.nice.org.uk/guidance/ng45/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-04",
    "topicIds": [
      "PT-M09-04"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-007"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Consentimento não é apenas assinatura nem substitui explicação compreensível e decisão voluntária.",
      "Cirurgia em paciente/local errado, compreensão inadequada e consentimento inválido.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Consentimento informado e conferência correta de identidade, procedimento e lateralidade."
      ],
      "indications": [
        "Antes de procedimento; inclui verificação de mudanças de plano e capacidade de consentir."
      ],
      "contraindications": [
        "Consentimento não é apenas assinatura nem substitui explicação compreensível e decisão voluntária."
      ],
      "anatomy": [
        "Identificação inequívoca e localização de estruturas/lado quando aplicável."
      ],
      "materials": [
        "Documento de consentimento, prontuário e lista cirúrgica."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Regras legais sobre consentimento e responsáveis variam com país e contexto assistencial."
      ],
      "sequence": [
        "Confirmar identidade por pelo menos dois identificadores e procedimento planejado.",
        "Explicar finalidade, riscos relevantes, alternativas e expectativas em linguagem compreensível.",
        "Verificar capacidade, voluntariedade e dúvidas; documentar decisão válida.",
        "Conciliar consentimento com solicitação, imagem, marcação e checklist da sala.",
        "Interromper fluxo se houver discrepância de lado, paciente ou procedimento."
      ],
      "confirmation": [
        "Procedimento/lado coerentes entre registros, pessoa e equipe; autorização documentada."
      ],
      "complications": [
        "Cirurgia em paciente/local errado, compreensão inadequada e consentimento inválido."
      ],
      "aftercare": [
        "Registrar alterações de plano e comunicação quando surgirem."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-05",
    "topicIds": [
      "PT-M09-05"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-MED-001",
      "MAT-VAS-001",
      "MAT-MED-003"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não administrar profilaxia rotineiramente em cirurgia limpa não protética sem indicação; não confundir com terapia de infecção estabelecida.",
      "Alergia grave, antibiótico inadequado, tempo fora da janela e prolongamento indevido.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Decisão de profilaxia antimicrobiana preventiva conforme procedimento, risco, microbiota e formulários locais."
      ],
      "indications": [
        "Principalmente cirurgia limpa com prótese, limpa-contaminada ou contaminada, conforme diretriz."
      ],
      "contraindications": [
        "Não administrar profilaxia rotineiramente em cirurgia limpa não protética sem indicação; não confundir com terapia de infecção estabelecida."
      ],
      "anatomy": [
        "Categoria de ferida, tecido envolvido, microbiota esperada e tempo até incisão."
      ],
      "materials": [
        "Prescrição, histórico de alergias, checklist temporal e acesso IV quando indicado."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Não há antibiótico ou dose universal: indicar categoria, agente e ajuste a partir do protocolo vigente."
      ],
      "sequence": [
        "Classificar cirurgia/ferida e revisar política antimicrobiana institucional.",
        "Verificar alergias, peso, função renal e necessidades especiais para seleção pela equipe prescritoria.",
        "Documentar fármaco e tempo planejado em relação à incisão conforme farmacocinética.",
        "Simular conferência de administração durante checklist anestésico-cirúrgico.",
        "Identificar duração prolongada ou perda sanguínea que exija reavaliação do esquema prescrito."
      ],
      "confirmation": [
        "Indicação, fármaco e tempo estão documentados e alinhados ao plano de cirurgia."
      ],
      "complications": [
        "Alergia grave, antibiótico inadequado, tempo fora da janela e prolongamento indevido."
      ],
      "aftercare": [
        "Registrar administração e reavaliar necessidade de continuação segundo protocolo."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG125",
        "title": "NICE NG125 — Surgical site infections",
        "url": "https://www.nice.org.uk/guidance/ng125/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-06",
    "topicIds": [
      "PT-M09-06"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-008",
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Profilaxia medicamentosa exige ponderar hemorragia, anticoagulantes e procedimentos neuroaxiais.",
      "Profilaxia omitida, sangramento por anticoagulação inadequada, compressão mal ajustada.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Prevenção de tromboembolismo venoso a partir de risco trombótico e risco de sangramento."
      ],
      "indications": [
        "Cirurgias e períodos de imobilidade nos quais avaliação individual indica prevenção."
      ],
      "contraindications": [
        "Profilaxia medicamentosa exige ponderar hemorragia, anticoagulantes e procedimentos neuroaxiais."
      ],
      "anatomy": [
        "Estase venosa, risco relacionado à cirurgia e dispositivos compressivos."
      ],
      "materials": [
        "Ferramenta institucional de risco, dispositivo de compressão compatível e plano farmacológico quando indicado."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Decisões sobre intervalo de anticoagulantes em anestesia neuroaxial exigem referência específica."
      ],
      "sequence": [
        "Avaliar risco de TEV, sangramento, mobilidade, câncer, história de TEV e cirurgia prevista.",
        "Escolher estratégia não farmacológica, mecânica ou farmacológica pelo protocolo.",
        "Conferir tamanho, ajuste e contraindicações de compressão mecânica em simulação.",
        "Planejar mobilização precoce quando viável e comunicação sobre anticoagulantes.",
        "Registrar reavaliação periódica com mudança clínica e transição de cuidados."
      ],
      "confirmation": [
        "Estratégia e contraindicações documentadas; dispositivo e segurança conferidos."
      ],
      "complications": [
        "Profilaxia omitida, sangramento por anticoagulação inadequada, compressão mal ajustada."
      ],
      "aftercare": [
        "Reavaliar risco durante internação e orientar mobilização e alertas após alta."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-07",
    "topicIds": [
      "PT-M09-07"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-009"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não raspar rotineiramente a pele com lâmina: aumenta lesões cutâneas e risco de infecção.",
      "Microlesões por lâmina, irritação e falha de comunicação sobre infecção local.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Cuidados de higiene pré-operatória e manejo de pelos quando interferem no campo."
      ],
      "indications": [
        "Preparação para cirurgia com protocolo de banho e necessidade específica de remoção de pelos."
      ],
      "contraindications": [
        "Não raspar rotineiramente a pele com lâmina: aumenta lesões cutâneas e risco de infecção."
      ],
      "anatomy": [
        "Integridade da barreira cutânea e diferenças entre limpeza e antissepsia."
      ],
      "materials": [
        "Produto de banho indicado e aparador elétrico apropriado se remoção for necessária."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "NICE NG125 não recomenda remoção rotineira de pelos."
      ],
      "sequence": [
        "Orientar banho pré-operatório e confirmar condições cutâneas/lesões.",
        "Avaliar se há necessidade real de remover pelos do local cirúrgico.",
        "Quando indicado, demonstrar uso de aparador elétrico com cabeça apropriada no dia do procedimento.",
        "Reexaminar a pele após preparo e comunicar cortes ou irritação.",
        "Documentar preparo e contraindicações individuais dos produtos."
      ],
      "confirmation": [
        "Pele limpa, íntegra e sem lesões causadas por remoção desnecessária."
      ],
      "complications": [
        "Microlesões por lâmina, irritação e falha de comunicação sobre infecção local."
      ],
      "aftercare": [
        "Proteger área e comunicar alterações encontradas antes da cirurgia."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG125",
        "title": "NICE NG125 — Surgical site infections",
        "url": "https://www.nice.org.uk/guidance/ng125/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-08",
    "topicIds": [
      "PT-M09-08"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-010"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Evitar formulação incompatível com mucosa, neonatalidade, alergias ou risco de incêndio; observar tempo de secagem.",
      "Infecção, queimadura química, dermatite e incêndio por solução alcoólica úmida.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Uso correto de antisséptico apropriado para reduzir carga microbiana no sítio operatório."
      ],
      "indications": [
        "Imediatamente antes da incisão, de acordo com local, pele e necessidades do procedimento."
      ],
      "contraindications": [
        "Evitar formulação incompatível com mucosa, neonatalidade, alergias ou risco de incêndio; observar tempo de secagem."
      ],
      "anatomy": [
        "Pele, mucosas, dobras e zonas onde pode ocorrer acúmulo de solução."
      ],
      "materials": [
        "Antisséptico adequado e aplicador de uso único, campos estéreis e proteção de áreas sensíveis."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Produtos com clorexidina requerem atenção especial em neonatos e em áreas próximas de mucosa."
      ],
      "sequence": [
        "Confirmar sítio, alergias, integridade cutânea e contraindicações do produto.",
        "Selecionar antisséptico apropriado conforme local e diretriz; conferir rótulo.",
        "Simular aplicação do centro ao entorno quando indicada pela técnica, evitando recontaminação.",
        "Prevenir acúmulo sob o paciente, e aguardar secagem completa de produtos alcoólicos antes da energia cirúrgica.",
        "Conferir cobertura do campo, documentação de produto e hora."
      ],
      "confirmation": [
        "Sítio preparado sem área omitida e sem solução acumulada antes da incisão."
      ],
      "complications": [
        "Infecção, queimadura química, dermatite e incêndio por solução alcoólica úmida."
      ],
      "aftercare": [
        "Registrar produto, intercorrências e pele após retirada dos campos."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "NICE-NG125",
        "title": "NICE NG125 — Surgical site infections",
        "url": "https://www.nice.org.uk/guidance/ng125/chapter/recommendations",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-09",
    "topicIds": [
      "PT-M09-09"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-007"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Não confiar apenas em agenda, pulseira, memória ou marcação sem participação da equipe.",
      "Confusão de lateralidade, nível ou procedimento por marca oculta/incorreta.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Marcação inequívoca do sítio e lateralidade para impedir procedimento no local errado."
      ],
      "indications": [
        "Procedimentos nos quais sítio, lado ou nível possam ser confundidos."
      ],
      "contraindications": [
        "Não confiar apenas em agenda, pulseira, memória ou marcação sem participação da equipe."
      ],
      "anatomy": [
        "Marcos anatômicos, lateridade e níveis quando aplicável."
      ],
      "materials": [
        "Marcador apropriado, consentimento, imagens e formulário de checklist."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Emergências e intervenções em múltiplos sítios exigem política institucional específica."
      ],
      "sequence": [
        "Conferir nome, procedimento, sítio e lateralidade no prontuário e com paciente quando possível.",
        "Comparar marca planejada com consentimento, exames e plano cirúrgico.",
        "Realizar simulação de marcação por profissional responsável conforme regra local.",
        "Conferir visibilidade da marca após preparo e cobertura do campo.",
        "Executar conferência cruzada no time-out antes de incisão."
      ],
      "confirmation": [
        "Sítio/lado verificáveis por paciente, registro, marcação e equipe."
      ],
      "complications": [
        "Confusão de lateralidade, nível ou procedimento por marca oculta/incorreta."
      ],
      "aftercare": [
        "Registrar discrepâncias e interrupções de fluxo."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-10",
    "topicIds": [
      "PT-M09-10"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-011",
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Nunca fixar posição sem verificar pontos de pressão, perfusão, vulnerabilidade neurológica e equipamentos.",
      "Lesão nervosa, pressão cutânea, isquemia, desconexão de tubo e queda.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Posicionamento cirúrgico com proteção de nervos, vasos, pele, respiração e acessos."
      ],
      "indications": [
        "Toda cirurgia; ajustar às exigências de exposição, anestesia e condição clínica."
      ],
      "contraindications": [
        "Nunca fixar posição sem verificar pontos de pressão, perfusão, vulnerabilidade neurológica e equipamentos."
      ],
      "anatomy": [
        "Nervos periféricos, proeminências ósseas e implicações hemodinâmicas e ventilatórias da postura."
      ],
      "materials": [
        "Apoios acolchoados, cintas apropriadas, mesa e dispositivos de proteção."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Posições especiais requerem treinamento próprio e contraindicações individuais."
      ],
      "sequence": [
        "Confirmar posição planejada com cirurgia e anestesia, lesões prévias e mobilidade.",
        "Conferir superfícies de apoio, pontos de pressão, tubos e cabos antes da mudança.",
        "No manequim, realizar mudança coordenada protegendo cabeça, membros, coluna e dispositivos.",
        "Avaliar alinhamento, perfusão, circulação e acesso à via aérea na posição final.",
        "Reavaliar periodicamente após ajustes da mesa e comunicar qualquer mudança."
      ],
      "confirmation": [
        "Alinhamento mantido, pressões distribuídas e dispositivos funcionantes."
      ],
      "complications": [
        "Lesão nervosa, pressão cutânea, isquemia, desconexão de tubo e queda."
      ],
      "aftercare": [
        "Registrar posição, acolchoamento, duração e achados pós-operatórios."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG180",
        "title": "NICE NG180 — Perioperative care in adults",
        "url": "https://www.nice.org.uk/guidance/ng180/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  },
  {
    "id": "PT-M09-11",
    "topicIds": [
      "PT-M09-11"
    ],
    "title": null,
    "priority": "P0",
    "level": "Fundamental / intermediário",
    "scope": "Preparo cirúrgico",
    "population": "Adultos no contexto eletivo; adaptar a pediatria, gestação, urgência e condições de risco",
    "environment": "Laboratório de simulação; execução clínica somente em serviço com equipe e recursos apropriados",
    "supervision": "Treino em simulação orientada; prática invasiva por profissionais habilitados sob supervisão adequada",
    "professionalScope": "Equipe conforme habilitação legal, competência, recursos e protocolo da instituição",
    "prerequisites": [
      "Higiene das mãos e segurança do paciente",
      "Anatomia, comunicação e identificação correta",
      "Reconhecimento de emergência e plano de resgate"
    ],
    "editorial": {
      "status": "em-desenvolvimento",
      "version": "0.2-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null,
      "publishedOn": null
    },
    "materialLinks": [
      "MAT-ANE-007",
      "MAT-ANE-004"
    ],
    "additionalSupplies": [
      "EPI, prontuário ou ficha de simulação, materiais descartáveis e opções de contingência de acordo com o procedimento",
      "Consultar procedimento institucional e instruções do fabricante para características específicas"
    ],
    "criticalErrors": [
      "Checklist não deve ser preenchido retrospectivamente nem substituído por campo automático.",
      "Paciente/sítio errado, corpo estranho retido, erro de comunicação e eventos evitáveis.",
      "Prosseguir sem identificação correta, monitorização indicada ou plano de resposta a intercorrências"
    ],
    "fields": {
      "definition": [
        "Verificação em equipe dos momentos críticos de segurança perioperatória."
      ],
      "indications": [
        "Toda cirurgia, adaptada ao serviço com a lista OMS de 19 itens como referência."
      ],
      "contraindications": [
        "Checklist não deve ser preenchido retrospectivamente nem substituído por campo automático."
      ],
      "anatomy": [
        "Momentos antes da indução, antes da incisão e antes de o paciente sair da sala."
      ],
      "materials": [
        "Lista OMS de 19 itens, registros, identificação do paciente e contagem de instrumentais."
      ],
      "environment": [
        "Confirmar organização do campo, funcionalidade dos equipamentos, EPI, plano de contingência e ambiente apto à técnica."
      ],
      "patient": [
        "Conferir dois identificadores, comunicação, consentimento quando cabível, alergias e riscos individuais."
      ],
      "analgesia": [
        "Usar a lista OMS na língua disponível e adaptar localmente sem omitir itens críticos."
      ],
      "sequence": [
        "Simular Sign In antes da indução: identidade, consentimento, sítio e riscos anestésicos.",
        "Simular Time Out com toda equipe antes da incisão: apresentações, local/lado, eventos críticos e profilaxia.",
        "Confirmar materiais, imagens, esterilidade e plano de contingência em cenário.",
        "Simular Sign Out antes da saída: procedimento realizado, contagens, amostras e problemas de equipamento.",
        "Realizar passagem segura de cuidados e discutir oportunidade de melhoria."
      ],
      "confirmation": [
        "Três momentos realizados com participação da equipe e divergências resolvidas."
      ],
      "complications": [
        "Paciente/sítio errado, corpo estranho retido, erro de comunicação e eventos evitáveis."
      ],
      "aftercare": [
        "Registrar checklist, desvios e medidas corretivas; planejar handoff."
      ],
      "skills-checklist": [
        "Confere identidade, indicação e contraindicações antes de iniciar",
        "Seleciona os materiais e confirma compatibilidade/fabricante",
        "Executa a sequência operacional na simulação sem omitir pausas de segurança",
        "Reconhece sinais de alerta e sabe quando interromper/chamar ajuda",
        "Documenta resultado, comunicação e cuidados posteriores"
      ],
      "media-references": [
        "Roteiro autoral de estudo orientado por fontes identificadas; confira atualização e população aplicável.",
        "Os cinco livros fornecidos são base de planejamento curricular, sem reprodução de suas imagens ou trechos.",
        "Vídeos externos por ficha serão cadastrados no MB06 com créditos."
      ]
    },
    "references": [
      {
        "id": "WHO-SAFE-2009",
        "title": "OMS — WHO Surgical Safety Checklist e materiais",
        "url": "https://www.who.int/teams/integrated-health-services/quality-of-care-and-patient-safety/patient-safety-guidance-and-tools/safe-surgery/tool-and-resources",
        "checkedOn": "2026-10-16"
      },
      {
        "id": "NICE-NG125",
        "title": "NICE NG125 — Surgical site infections",
        "url": "https://www.nice.org.uk/guidance/ng125/chapter/recommendations",
        "checkedOn": "2026-10-16"
      }
    ],
    "media": [],
    "illustration": {
      "type": "original-schematic",
      "caption": "Roteiro de simulação e conferência; sem reutilização de ilustrações de terceiros",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto"
    }
  }
];
  const newMaterials=[
  {
    "id": "MAT-ANE-001",
    "preferredName": "Anestésico local — apresentação rotulada",
    "aliases": [
      "lidocaína",
      "bupivacaína",
      "anestésico infiltrativo"
    ],
    "categoryId": "medicacao",
    "description": "Família didática: anestésico local — apresentação rotulada. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-001-1",
        "label": "Formulação tópica autorizada",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-001-2",
        "label": "Solução injetável conforme prescrição",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M08-01",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-02",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-002",
    "preferredName": "Kit estéril de anestesia regional",
    "aliases": [
      "agulha neuroaxial",
      "agulha para bloqueio",
      "kit de bloqueio"
    ],
    "categoryId": "medicacao",
    "description": "Família didática: kit estéril de anestesia regional. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-002-1",
        "label": "Bloqueio periférico",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-002-2",
        "label": "Neuroaxial específico",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M08-02",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-03",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-05",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-06",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-003",
    "preferredName": "Ultrassom e transdutor para procedimentos",
    "aliases": [
      "ultrassonografia",
      "POCUS",
      "transdutor protegido"
    ],
    "categoryId": "instrumentais",
    "description": "Família didática: ultrassom e transdutor para procedimentos. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-003-1",
        "label": "Transdutor linear",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-003-2",
        "label": "Transdutor curvilíneo",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M08-03",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-004",
    "preferredName": "Monitor multiparamétrico perioperatório",
    "aliases": [
      "ECG",
      "pressão não invasiva",
      "oxímetro de pulso"
    ],
    "categoryId": "instrumentais",
    "description": "Família didática: monitor multiparamétrico perioperatório. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-004-1",
        "label": "ECG/PA/SpO₂",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-004-2",
        "label": "Monitoração modular",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M08-04",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-05",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-06",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-07",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-08",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-09",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-10",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-01",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-02",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-03",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-06",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-10",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-11",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-005",
    "preferredName": "Capnografia clínica",
    "aliases": [
      "capnógrafo",
      "ETCO2",
      "capnografia"
    ],
    "categoryId": "via-aerea",
    "description": "Família didática: capnografia clínica. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-005-1",
        "label": "Linha de amostra",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-005-2",
        "label": "Sensor mainstream",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M08-04",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-07",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-08",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-09",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-10",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-006",
    "preferredName": "Estação e circuito de anestesia",
    "aliases": [
      "máquina de anestesia",
      "ventilador anestesia",
      "circuito"
    ],
    "categoryId": "via-aerea",
    "description": "Família didática: estação e circuito de anestesia. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-006-1",
        "label": "Estação anestésica",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-006-2",
        "label": "Circuito respiratório",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M08-07",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M08-08",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-007",
    "preferredName": "Checklist e identificação do sítio cirúrgico",
    "aliases": [
      "lista cirúrgica",
      "marcador cirúrgico",
      "time out"
    ],
    "categoryId": "instrumentais",
    "description": "Família didática: checklist e identificação do sítio cirúrgico. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-007-1",
        "label": "Formulário de checklist",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-007-2",
        "label": "Marcador apropriado",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M09-04",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-09",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      },
      {
        "topicId": "PT-M09-11",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-008",
    "preferredName": "Dispositivo de compressão pneumática",
    "aliases": [
      "profilaxia mecânica TEV",
      "compressão intermitente"
    ],
    "categoryId": "imobilizacao",
    "description": "Família didática: dispositivo de compressão pneumática. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-008-1",
        "label": "Membro inferior — conforme ajuste",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-008-2",
        "label": "Sistema pneumático",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M09-06",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-009",
    "preferredName": "Aparador elétrico para preparo de pelos",
    "aliases": [
      "tricotomizador",
      "clipper",
      "aparador pelos"
    ],
    "categoryId": "instrumentais",
    "description": "Família didática: aparador elétrico para preparo de pelos. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-009-1",
        "label": "Cabeça descartável",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-009-2",
        "label": "Cabeça segundo fabricante",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M09-07",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-010",
    "preferredName": "Antisséptico cutâneo cirúrgico",
    "aliases": [
      "clorexidina",
      "povidona-iodo",
      "preparo pele"
    ],
    "categoryId": "medicacao",
    "description": "Família didática: antisséptico cutâneo cirúrgico. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-010-1",
        "label": "Clorexidina conforme sítio",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-010-2",
        "label": "Povidona-iodo conforme indicação",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M09-08",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  },
  {
    "id": "MAT-ANE-011",
    "preferredName": "Apoio e proteção de posicionamento",
    "aliases": [
      "acolchoamento mesa",
      "apoio membros",
      "coxim cirúrgico"
    ],
    "categoryId": "imobilizacao",
    "description": "Família didática: apoio e proteção de posicionamento. Confirmar apresentação, registro e instruções do fabricante.",
    "generalIndications": [
      "Material complementar dos roteiros anestésicos e perioperatórios, condicionado à indicação e à avaliação da equipe."
    ],
    "risks": [
      "Erro de seleção, incompatibilidade, falha do equipamento ou preparo inadequado."
    ],
    "alternatives": [
      "Alternativa com equivalência documentada pelo serviço e fabricante, se houver."
    ],
    "precautions": [
      "Verificar identidade, rótulo, modelo, integridade, manutenção/validade e adequação clínica antes de utilizar."
    ],
    "scaleSystem": null,
    "variants": [
      {
        "id": "VAR-ANE-011-1",
        "label": "Protetor de pressão",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      },
      {
        "id": "VAR-ANE-011-2",
        "label": "Apoio de posicionamento",
        "scaleType": null,
        "scaleValue": null,
        "manufacturerVerificationRequired": true
      }
    ],
    "procedureLinks": [
      {
        "topicId": "PT-M09-10",
        "role": "dependente-indicacao",
        "note": "Indicação depende do procedimento e avaliação clínica; ficha de equipamento em revisão editorial."
      }
    ],
    "compatibility": [],
    "provenance": [
      {
        "sourceId": "SRC-MAT-IFU",
        "claimScope": "Modelo, integridade, requisitos e compatibilidade dependem das instruções do fabricante.",
        "reviewedOn": null,
        "status": "pendente-fabricante"
      }
    ],
    "visual": {
      "kind": "original-schematic",
      "assetId": "atlas-inline-svg",
      "author": "Nexo Cirúrgico",
      "license": "Original do projeto",
      "sourceUrl": null,
      "alt": "Esquema vetorial genérico da categoria; identificação morfológica individual pendente"
    },
    "review": {
      "status": "revisao-editorial",
      "version": "0.1-MB04-L2",
      "clinicalReviewer": null,
      "reviewedOn": null
    }
  }
];
  const materialSet=new Set(d.materialAtlas.materials.map(m=>m.id));
  for(const m of newMaterials){if(materialSet.has(m.id))throw new Error('MB04 L2: material duplicado '+m.id);d.materialAtlas.materials.push(m);materialSet.add(m.id)}
  const existingIds=new Set(p.procedures.map(x=>x.id));
  for(const x of additions){
    const t=index.get(x.id);if(!t||existingIds.has(x.id))throw new Error('MB04 L2: procedimento inválido/duplicado: '+x.id);
    x.title=t.title; p.procedures.push(x);existingIds.add(x.id);
    t.status='em-desenvolvimento';t.revision={...t.revision,version:'0.2-MB04-L2',state:'em-desenvolvimento'};
    for(const mid of x.materialLinks){
      const m=d.materialAtlas.materials.find(z=>z.id===mid);if(!m)throw new Error('MB04 L2: sem material '+mid);
      if(!m.procedureLinks.some(z=>z.topicId===x.id))m.procedureLinks.push({topicId:x.id,role:'dependente-indicacao',note:'Material selecionado de acordo com avaliação, técnica e fabricante.'});
    }
  }
  p.version='0.4-MB04-L2';
  const mb04=d.technicalCurriculum.macroblocks.find(m=>m.id==='MB04');
  if(mb04){mb04.status='Em desenvolvimento';mb04.description='MB04 Lote 2: oito fichas de Cirurgia Geral + 21 fichas de anestesia e preparo perioperatório; treinamento e ampliação continuam.';}
})();
