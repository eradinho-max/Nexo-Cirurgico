# Nexo Cirúrgico — remediação formativa por plano e competência

**Data:** 13 de outubro de 2026  
**Estado:** implementada na rota `#/remediacao`  
**Escopo:** resultados locais dos últimos dez simulados

## 1. Objetivo

Transformar o relatório do simulado em ação didática. Em vez de apresentar apenas uma porcentagem, a plataforma agora associa o desempenho a:

- competência avaliada;
- etapa do plano de estudos;
- foco de revisão;
- três aulas recomendadas;
- temas das questões erradas, quando disponíveis;
- trilha principal da competência.

O resultado é formativo e não certifica habilidade prática ou domínio clínico.

## 2. Cobertura

| Elemento | Cobertura |
|---|---:|
| Competências com remediação | 28 de 28 |
| Aulas vinculadas ao mapa | 84 vínculos |
| Planos de estudo | 3 |
| Tentativas agregadas | até 10 |
| Questões por tentativa | 20 |

Cada competência possui duas aulas de sua trilha principal e uma aula complementar quando isso amplia a compreensão do processo, dos dispositivos ou das barreiras de segurança.

## 3. Regra de prioridade

| Desempenho agregado | Estado | Ação sugerida |
|---:|---|---|
| abaixo de 60% | Prioridade alta | revisar as aulas antes de nova tentativa |
| 60% a 79% | Reforçar | consolidar pontos frágeis e praticar novamente |
| 80% ou mais | Consolidar | revisar de modo espaçado e manter prática |
| sem itens respondidos | Não avaliada | não inferir desempenho |

A porcentagem é calculada com os itens efetivamente sorteados nas tentativas salvas. Competências com poucos itens permanecem acompanhadas de alerta sobre amostra insuficiente.

## 4. Organização por plano

As recomendações são agrupadas em:

1. **Fundamentos seguros — C01–C12**;
2. **Prática perioperatória ampliada — C13–C18**;
3. **Especialidades cirúrgicas P2 — C19–C28**.

Filtros permitem visualizar todas as etapas ou apenas uma. A rota direta `#/remediacao/Cxx` abre o reforço de uma competência específica.

## 5. Integração com o simulado

Ao concluir uma tentativa, a plataforma salva localmente:

- data;
- número de acertos e total;
- percentual;
- desempenho por competência;
- IDs das 20 questões sorteadas;
- IDs das questões erradas.

Os IDs das questões erradas permitem recuperar os temas que precisam de reforço. Tentativas antigas, sem esse detalhamento, continuam válidas para o cálculo agregado por competência.

O relatório final do simulado agora oferece:

- botão **Plano de reforço**;
- acesso direto ao reforço de cada competência;
- manutenção do link para o histórico de progresso.

## 6. Interface

A rota `#/remediacao` contém:

- estado vazio antes do primeiro simulado;
- indicadores de tentativas, competências amostradas, acerto agregado e respostas a reforçar;
- filtros pelos três planos;
- prioridade visual por competência;
- categorias das questões erradas;
- aulas recomendadas com duração, módulo e estado de conclusão;
- link para a trilha principal;
- explicação transparente do método.

Todo o histórico permanece somente no navegador por `localStorage`.

## 7. Limites

- O algoritmo não realiza diagnóstico de competência.
- Uma amostra de 20 questões não cobre todas as 28 competências.
- Percentuais com poucos itens não devem orientar decisões de certificação.
- O mapa ainda não usa parâmetros psicométricos, pois o piloto não foi realizado.
- Questões e recomendações ainda aguardam revisão clínica independente.
- Aulas recomendadas não autorizam execução autônoma de procedimentos invasivos.

## 8. Validação estrutural

Foram verificados:

- uma entrada de remediação para cada competência;
- inexistência de competências duplicadas;
- existência de todas as 84 aulas vinculadas;
- integração com as três etapas curriculares;
- persistência dos IDs de questões e erros;
- geração do plano após simulado;
- rota direta por competência;
- navegação para as aulas recomendadas.

Resultado: **zero erros estruturais**.

## 9. Próximo gate

1. testar acessibilidade e responsividade da remediação;
2. ampliar anatomia visual somente com ativos licenciados;
3. após conclusão editorial, executar revisão clínica e piloto;
4. somente depois do piloto, considerar dificuldade observada, discriminação e blocos equivalentes.
