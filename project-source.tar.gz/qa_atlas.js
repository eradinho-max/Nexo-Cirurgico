/* QA estrutural e testes negativos do MB02 — execute com: node qa_atlas.js */
const path=require('path');
global.window={};
require(path.join(__dirname,'data.js'));
const source=window.NEXO_DATA;
const clone=value=>JSON.parse(JSON.stringify(value));
const normalize=value=>String(value??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
const matches=(value,term)=>{const h=normalize(value),n=normalize(term);return n.length<=2?h.split(' ').includes(n):h.includes(n)};
const duplicates=values=>[...new Set(values.filter((value,index)=>values.indexOf(value)!==index))];

function validate(data){
  const errors=[];
  const technical=data.technicalCurriculum;
  const atlas=data.materialAtlas;
  if(!technical||!atlas)return ['Objetos technicalCurriculum/materialAtlas obrigatórios.'];
  const topics=technical.modules.flatMap(module=>module.topics.map(topic=>({...topic,moduleId:module.id})));
  const topicIds=new Set(topics.map(topic=>topic.id));
  const canonicalIds=new Set(technical.canonicalProcedures.map(item=>item.id));
  const workflow=new Set(technical.topicStatusWorkflow.map(item=>item.id));
  const lessonIds=new Set(data.modules.flatMap(module=>module.lessons.map(lesson=>lesson.id)));
  const materialIds=atlas.materials.map(item=>item.id);
  const allVariantIds=atlas.materials.flatMap(item=>(item.variants||[]).map(variant=>variant.id));
  if(duplicates(allVariantIds).length)errors.push("variantId duplicado.");
  const categoryIds=new Set(atlas.categories.map(item=>item.id));
  const scaleIds=new Set(atlas.scaleSystems.map(item=>item.id));
  const sourceIds=new Set(atlas.sources.map(item=>item.id));
  if(duplicates(materialIds).length)errors.push('materialId duplicado.');
  for(const module of technical.modules){
    const expected=(module.priority.match(/P[0-2]/g)||[]).map(value=>Number(value[1]));
    const levels=expected.length?Array.from({length:Math.max(...expected)-Math.min(...expected)+1},(_,i)=>`P${Math.min(...expected)+i}`):[];
    if(levels.join(',')!==(module.priorityLevels||[]).join(','))errors.push(`${module.id}: prioridade inclusiva inconsistente.`);
    if((module.lessonRelations||[]).length!==(module.existingLessonIds||[]).length)errors.push(`${module.id}: relações não preservam vínculos.`);
    for(const relation of module.lessonRelations||[]){
      if(!lessonIds.has(relation.lessonId))errors.push(`${relation.id}: aula inexistente.`);
      if(!['cobertura-direta','fundamento','pre-requisito'].includes(relation.relationType))errors.push(`${relation.id}: relationType inválido.`);
      if(relation.relationType==='cobertura-direta'&&!relation.targetTopicIds.length)errors.push(`${relation.id}: relação direta sem alvo.`);
      for(const id of relation.targetTopicIds)if(!module.topics.some(topic=>topic.id===id))errors.push(`${relation.id}: alvo fora do módulo.`);
    }
    for(const topic of module.topics){
      if(!workflow.has(topic.status))errors.push(`${topic.id}: status inválido.`);
      if(!canonicalIds.has(topic.canonicalProcedureId))errors.push(`${topic.id}: canonicalProcedureId inexistente.`);
      if(!Array.isArray(topic.aliases)||!topic.revision?.version)errors.push(`${topic.id}: aliases/revisão ausentes.`);
    }
  }
  for(const material of atlas.materials){
    if(!material.id||!material.preferredName||!material.aliases?.length)errors.push(`${material.id||'material'}: identificação incompleta.`);
    if(!categoryIds.has(material.categoryId))errors.push(`${material.id}: categoria inválida.`);
    if(material.scaleSystem&&!scaleIds.has(material.scaleSystem))errors.push(`${material.id}: escala inválida.`);
    if(!material.variants?.length||!material.procedureLinks?.length||!material.provenance?.length)errors.push(`${material.id}: estrutura incompleta.`);
    if(!material.visual?.author||!material.visual?.license||!material.visual?.alt)errors.push(`${material.id}: licença visual incompleta.`);
    for(const variant of material.variants||[]){
      if(!variant.manufacturerVerificationRequired)errors.push(`${variant.id}: confirmação de fabricante ausente.`);
      if(material.scaleSystem && variant.scaleType && variant.scaleType!==material.scaleSystem)errors.push(`${variant.id}: escala de variante não coincide com o material.`);
      for(const [key,value] of Object.entries(variant.dimensions||{}))if(typeof value==='number' && (!Number.isFinite(value)||value<=0))errors.push(`${variant.id}: dimensão ${key} deve ser positiva.`);
    }
    if(['validado','publicado'].includes(material.review?.status) && (!material.review.clinicalReviewer || !material.review.reviewedOn))errors.push(`${material.id}: status validado sem revisor clínico e data.`);
    for(const link of material.procedureLinks||[]){if(!topicIds.has(link.topicId))errors.push(`${material.id}: tópico inexistente.`);if(!['obrigatorio','alternativa','dependente-indicacao'].includes(link.role))errors.push(`${material.id}: papel inválido.`)}
    for(const relation of material.compatibility||[])if(!materialIds.includes(relation.withMaterialId)||!relation.condition)errors.push(`${material.id}: compatibilidade inválida.`);
    for(const provenance of material.provenance||[])if(!sourceIds.has(provenance.sourceId))errors.push(`${material.id}: proveniência inválida.`);
  }
  for(const source of atlas.sources)if(!source.url&&!source.manufacturerRequirement)errors.push(`${source.id}: fonte não rastreável.`);
  return errors;
}

const baseline=validate(source);
const topicIndex=source.technicalCurriculum.modules.flatMap(module=>module.topics.map(topic=>({...topic,module})));
const materialIndex=source.materialAtlas.materials;
const searchMaterials=term=>materialIndex.filter(item=>matches(`${item.id} ${item.preferredName} ${item.aliases.join(' ')} ${item.variants.map(v=>`${v.label} ${v.scaleValue||''}`).join(' ')}`,term)).map(item=>item.id);
const searchTopics=term=>topicIndex.filter(item=>matches(`${item.id} ${item.title} ${item.aliases.join(' ')}`,term)).map(item=>item.id);
const demonstrations={
  jelco:searchMaterials('jelco'),
  cateterIntravenoso:searchMaterials('cateter intravenoso'),
  IV:searchMaterials('IV'),
  '24G':searchMaterials('24G'),
  foley:searchMaterials('sonda Foley'),
  '14Fr':searchMaterials('14 Fr'),
  nylon40:searchMaterials('nylon 4-0'),
  lamina15:searchMaterials('lamina 15'),
  ECG:searchTopics('ECG'),
  puncao:searchTopics('puncao')
};
const expected={jelco:'MAT-VAS-001',cateterIntravenoso:'MAT-VAS-001',IV:'MAT-VAS-001','24G':'MAT-VAS-001',foley:'MAT-SON-001','14Fr':'MAT-SON-001',nylon40:'MAT-SUT-001',lamina15:'MAT-INS-002',ECG:'PT-M20-01',puncao:'PT-M18-02'};
for(const [test,id] of Object.entries(expected))if(!demonstrations[test].includes(id))baseline.push(`Busca ${test} não encontrou ${id}.`);
const p0Modules=source.technicalCurriculum.modules.filter(module=>module.priorityLevels.includes('P0')).map(module=>module.id);
if(!p0Modules.includes('M05')||!p0Modules.includes('M10')||!p0Modules.includes('M27'))baseline.push('Filtro P0 não inclui faixas P0–P1/P0–P2.');
for(const title of ['Cardioversão sincronizada','Irrigação vesical','Punção capilar']){
  const group=topicIndex.filter(topic=>topic.title===title);
  if(group.length!==2||new Set(group.map(topic=>topic.canonicalProcedureId)).size!==1)baseline.push(`${title}: contextos não compartilham ficha canônica.`);
}

const negativeTests=[];
function negative(name,mutate){const data=clone(source);mutate(data);const caught=validate(data).length>0;negativeTests.push({name,caught});if(!caught)baseline.push(`Teste negativo não detectado: ${name}.`)}
negative('variantId duplicado',data=>data.materialAtlas.materials[1].variants[0].id=data.materialAtlas.materials[0].variants[0].id);
negative('diâmetro negativo',data=>data.materialAtlas.materials[0].variants[0].dimensions.nominalOuterDiameterMm=-7);
negative('escala da variante inconsistente',data=>data.materialAtlas.materials[0].variants[0].scaleType='Fr');
negative('validado sem revisor clínico',data=>data.materialAtlas.materials[0].review.status='validado');
negative('materialId duplicado',data=>data.materialAtlas.materials[1].id=data.materialAtlas.materials[0].id);
negative('tópico relacionado inexistente',data=>data.materialAtlas.materials[0].procedureLinks[0].topicId='PT-INVALIDO');
negative('escala inexistente',data=>data.materialAtlas.materials[0].scaleSystem='ESCALA-X');
negative('proveniência inexistente',data=>data.materialAtlas.materials[0].provenance[0].sourceId='SRC-X');
negative('variante sem confirmação de fabricante',data=>data.materialAtlas.materials[0].variants[0].manufacturerVerificationRequired=false);
negative('compatibilidade com material inexistente',data=>data.materialAtlas.materials[8].compatibility[0].withMaterialId='MAT-X');
negative('status editorial inválido',data=>data.technicalCurriculum.modules[0].topics[0].status='pronto');
negative('prioridade inclusiva inconsistente',data=>data.technicalCurriculum.modules[4].priorityLevels=['P0']);

const result={status:baseline.length?'FALHOU':'APROVADO — MB01 CORRIGIDO E MB02 ESTRUTURAL',materials:materialIndex.length,variants:materialIndex.reduce((sum,item)=>sum+item.variants.length,0),topics:topicIndex.length,canonicalProcedures:source.technicalCurriculum.canonicalProcedures.length,lessonRelations:source.technicalCurriculum.modules.reduce((sum,item)=>sum+item.lessonRelations.length,0),priorityP0Modules:p0Modules.length,searchDemonstrations:demonstrations,negativeTests,errors:baseline};
console.log(JSON.stringify(result,null,2));
if(baseline.length)process.exit(1);
