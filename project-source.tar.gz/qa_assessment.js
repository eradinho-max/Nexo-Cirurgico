/* Auditoria estrutural reproduzível do banco Nexo Cirúrgico.
   Execute com: node qa_assessment.js */
const path = require("path");
global.window = {};
require(path.join(__dirname, "data.js"));
const data = window.NEXO_DATA;
const errors = [];
const reviewFlags = [];
const normalized = value => String(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
const duplicateValues = values => [...new Set(values.filter((value, index) => values.indexOf(value) !== index))];
const sourceIds = new Set(data.evidence.map(source => source.id));
const competenceIds = new Set(data.competencies.map(competence => competence.id));
const moduleIds = new Set(data.modules.map(module => module.id));
const competenciesById = new Map(data.competencies.map(competence => [competence.id, competence]));
const evidenceById = new Map(data.evidence.map(source => [source.id, source]));

for (const [label, ids] of [
  ["questão", data.quiz.map(item => item.id)],
  ["caso", data.cases.map(item => item.id)],
  ["competência", data.competencies.map(item => item.id)],
  ["fonte", data.evidence.map(item => item.id)]
]) {
  const duplicates = duplicateValues(ids);
  if (duplicates.length) errors.push(`${label}: IDs duplicados: ${duplicates.join(", ")}`);
}

for (const question of data.quiz) {
  if (!Array.isArray(question.options) || question.options.length !== 4) errors.push(`Questão ${question.id}: deve ter quatro alternativas.`);
  else if (new Set(question.options.map(normalized)).size !== 4) errors.push(`Questão ${question.id}: alternativas duplicadas.`);
  if (!Number.isInteger(question.answer) || question.answer < 0 || question.answer > 3) errors.push(`Questão ${question.id}: gabarito inválido.`);
  if (!competenceIds.has(question.competencyId)) errors.push(`Questão ${question.id}: competência inexistente.`);
  if (!["Básico", "Aplicação", "Análise"].includes(question.difficulty)) errors.push(`Questão ${question.id}: dificuldade inválida.`);
  if (!question.sourceIds?.length) errors.push(`Questão ${question.id}: sem fonte.`);
  for (const sourceId of question.sourceIds || []) if (!sourceIds.has(sourceId)) errors.push(`Questão ${question.id}: fonte inexistente ${sourceId}.`);
  if (!question.explanation || question.explanation.trim().length < 35) reviewFlags.push(`Questão ${question.id}: revisar extensão da justificativa.`);
  if (question.question.trim().length < 35) reviewFlags.push(`Questão ${question.id}: enunciado curto; confirmar suficiência.`);
  if (/\b(sempre|nunca|somente|apenas)\b/i.test(`${question.question} ${question.options.join(" ")}`)) reviewFlags.push(`Questão ${question.id}: confirmar uso intencional de termo absoluto.`);
}

for (const item of data.cases) {
  if (!Array.isArray(item.options) || item.options.length !== 4) errors.push(`Caso ${item.id}: deve ter quatro alternativas.`);
  else if (new Set(item.options.map(normalized)).size !== 4) errors.push(`Caso ${item.id}: alternativas duplicadas.`);
  if (!Number.isInteger(item.answer) || item.answer < 0 || item.answer > 3) errors.push(`Caso ${item.id}: gabarito inválido.`);
  if (!competenceIds.has(item.competencyId)) errors.push(`Caso ${item.id}: competência inexistente.`);
  if (!moduleIds.has(item.moduleId)) errors.push(`Caso ${item.id}: módulo inexistente.`);
  if (competenciesById.get(item.competencyId)?.moduleId !== item.moduleId) errors.push(`Caso ${item.id}: módulo incompatível com a competência.`);
  if (!item.sourceIds?.length) errors.push(`Caso ${item.id}: sem fonte.`);
  for (const sourceId of item.sourceIds || []) if (!sourceIds.has(sourceId)) errors.push(`Caso ${item.id}: fonte inexistente ${sourceId}.`);
  for (const field of ["context", "prompt", "rationale", "consequence"]) if (!item[field]?.trim()) errors.push(`Caso ${item.id}: campo ${field} vazio.`);
}

const normalizedStems = new Map();
for (const question of data.quiz) {
  const key = normalized(question.question);
  if (!normalizedStems.has(key)) normalizedStems.set(key, []);
  normalizedStems.get(key).push(question.id);
}
for (const ids of normalizedStems.values()) if (ids.length > 1) errors.push(`Enunciado duplicado nas questões ${ids.join(", ")}.`);

for (const competence of data.competencies) {
  const count = data.quiz.filter(question => question.competencyId === competence.id).length;
  if (count !== competence.targetQuestions) errors.push(`${competence.id}: ${count} questões; meta ${competence.targetQuestions}.`);
  if (!moduleIds.has(competence.moduleId)) errors.push(`${competence.id}: módulo inexistente ${competence.moduleId}.`);
  if (!competence.sourceIds?.length) errors.push(`${competence.id}: sem fonte central.`);
  for (const sourceId of competence.sourceIds || []) if (!sourceIds.has(sourceId)) errors.push(`${competence.id}: fonte inexistente ${sourceId}.`);
}

const blueprint = data.assessmentBlueprint;
if (data.competencies.length !== blueprint.targetCompetencies) errors.push(`Total de competências ${data.competencies.length}; meta ${blueprint.targetCompetencies}.`);
if (data.quiz.length !== blueprint.targetQuestions) errors.push(`Total de questões ${data.quiz.length}; meta ${blueprint.targetQuestions}.`);
if (data.cases.length !== blueprint.targetCases) errors.push(`Total de casos ${data.cases.length}; meta ${blueprint.targetCases}.`);

for (const question of data.quiz.filter(item => item.id >= 151)) {
  const hasVerifiedSource = (question.sourceIds || []).some(sourceId => evidenceById.get(sourceId)?.verifiedOn && evidenceById.get(sourceId)?.referenceStatus);
  if (!hasVerifiedSource) errors.push(`Questão P2 ${question.id}: nenhuma fonte com verificação documental.`);
}
for (const item of data.cases.filter(item => Number(item.number) >= 21)) {
  const hasVerifiedSource = (item.sourceIds || []).some(sourceId => evidenceById.get(sourceId)?.verifiedOn && evidenceById.get(sourceId)?.referenceStatus);
  if (!hasVerifiedSource) errors.push(`Caso P2 ${item.id}: nenhuma fonte com verificação documental.`);
}
for (const competence of data.competencies.filter(item => Number(item.id.slice(1)) >= 19)) {
  const caseCount = data.cases.filter(item => item.competencyId === competence.id).length;
  if (caseCount !== 1) errors.push(`${competence.id}: ${caseCount} casos P2; meta 1.`);
}

const answerDistribution = [0, 1, 2, 3].map(answer => data.quiz.filter(question => question.answer === answer).length);
const caseAnswerDistribution = [0, 1, 2, 3].map(answer => data.cases.filter(item => item.answer === answer).length);
if (Math.max(...answerDistribution) - Math.min(...answerDistribution) > 1) errors.push(`Gabaritos das questões desequilibrados: ${answerDistribution.join("/")}.`);
if (Math.max(...caseAnswerDistribution) - Math.min(...caseAnswerDistribution) > 1) errors.push(`Gabaritos dos casos desequilibrados: ${caseAnswerDistribution.join("/")}.`);

const difficultyDistribution = Object.fromEntries(["Básico", "Aplicação", "Análise"].map(level => [level, data.quiz.filter(question => question.difficulty === level).length]));
for (const rule of blueprint.cognitiveDistribution) {
  const actual = 100 * (difficultyDistribution[rule.level] || 0) / data.quiz.length;
  if (Math.abs(actual - rule.target) > 1) errors.push(`${rule.level}: ${actual.toFixed(1)}%; meta aproximada ${rule.target}%.`);
}
const summary = {
  status: errors.length ? "FALHOU" : "APROVADO NA AUDITORIA ESTRUTURAL",
  questions: data.quiz.length,
  cases: data.cases.length,
  competencies: data.competencies.length,
  sources: data.evidence.length,
  targets: {questions: blueprint.targetQuestions, cases: blueprint.targetCases, competencies: blueprint.targetCompetencies},
  targetQuestionsFromCompetencies: data.competencies.reduce((sum, competence) => sum + competence.targetQuestions, 0),
  difficultyDistribution,
  answerDistribution: {A:answerDistribution[0], B:answerDistribution[1], C:answerDistribution[2], D:answerDistribution[3]},
  caseAnswerDistribution: {A:caseAnswerDistribution[0], B:caseAnswerDistribution[1], C:caseAnswerDistribution[2], D:caseAnswerDistribution[3]},
  errors,
  reviewFlagsCount: reviewFlags.length,
  reviewFlags
};
console.log(JSON.stringify(summary, null, 2));
if (errors.length) process.exit(1);
