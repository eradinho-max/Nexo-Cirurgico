# Nexo Cirúrgico — registro de referências atualizadas

**Data de verificação:** 13 de outubro de 2026  
**Escopo:** núcleo perioperatório, especialidades P2, procedimentos e acessos  
**Total no catálogo da plataforma:** 72 referências  
**Com situação documental registrada:** 41 referências, incluindo 7 novas fontes de acessos, dispositivos e antissepsia

---

## 1. Política de atualidade

A plataforma usa a seguinte ordem de prioridade:

1. legislação, resolução e nota técnica brasileira vigente;
2. diretriz oficial de sociedade profissional na edição mais recente identificada;
3. revisão sistemática ou consenso recente;
4. documento oficial anterior que ainda permaneça listado como referência corrente;
5. material educacional institucional apenas como complemento.

“Atual” não significa “publicado no mesmo ano”. Um documento mais antigo pode continuar sendo a diretriz oficial disponível. Nesses casos, o catálogo registra a data da verificação e informa que atualizações devem ser monitoradas.

Conteúdo protegido por direitos autorais, como diretrizes AORN e SOBECC, é usado para orientar sínteses originais. Tabelas, algoritmos e texto integral não são copiados.

---

## 2. Atualizações brasileiras prioritárias

| Documento | Ano | Uso na plataforma | Situação em 13/10/2026 |
|---|---:|---|---|
| Anvisa — Nota Técnica nº 01/2026 | 2026 | Vigilância de IRAS e ISC | Prioritária para vigilância em 2026 |
| Anvisa — Nota Técnica nº 03/2026 | 2026 | Critérios diagnósticos de IRAS e ISC | Substitui a versão 03/2025 para os critérios abordados |
| Anvisa — Avaliação Nacional das Práticas de Segurança do Paciente | 2026 | Cirurgia segura, ISC e aplicação da lista | Edição anual corrente identificada |
| Anvisa — Protocolo de prevenção de ISC | 2025 | Barreiras preventivas | Mantido como protocolo-base recente |
| Anvisa — Nota Técnica nº 11/2025 | 2025 | Implementação institucional de protocolos de IRAS | Complemento para governança |
| NR-32 | atualização oficial consultada | Segurança ocupacional | Confirmar sempre a versão consolidada no portal oficial |
| Resolução CFM nº 2.471/2026 | 2026 | Sedação ambulatorial | Publicada, mas ainda no período de 180 dias anterior à vigência na data desta verificação |

### Regra editorial

Critério diagnóstico de ISC, prazo de vigilância e formulário anual não devem ser copiados de uma edição anterior quando existir nota técnica nova. A plataforma deve citar o documento de 2026 e manter documentos anteriores apenas para histórico ou prevenção quando não substituídos.

---

## 3. Referências atuais por especialidade

### Cirurgia geral e digestiva

- ERAS Society — *Guidelines for perioperative care in elective colorectal surgery*, atualização 2025;
- ESPEN — *Guideline on clinical nutrition in surgery*, atualização 2025;
- EAES/SAGES — recomendações para cuidado perioperatório de adultos idosos, 2026;
- Anvisa — prevenção e vigilância de ISC, 2025–2026.

**Uso didático:** organização da jornada, integração da equipe, redução de variabilidade, handoff e barreiras de infecção. A plataforma não transforma recomendações clínicas em prescrição individual.

### Ortopedia e trauma

- AAOS — prevenção de ISC após trauma maior de extremidades, 2022, ainda disponível no catálogo corrente;
- AAOS — catálogo de diretrizes e OrthoGuidelines consultado em 2026;
- FDA — guia final para guias personalizados de implantes ortopédicos, maio de 2026;
- Anvisa — critérios de ISC 2026, incluindo procedimentos ortopédicos monitorados.

**Uso didático:** lateralidade, implantes, lote, interface com imagem, amostras, torniquete e compatibilidade com instruções de uso.

### Ginecologia e obstetrícia

- ERAS Society — oncologia ginecológica, atualização 2026;
- ERAS Society — cuidado antenatal e pré-operatório na cesariana, atualização 2025;
- Anvisa — vigilância de ISC associada a cesariana, 2026;
- AORN — edição perioperatória 2026.

**Uso didático:** vias de acesso, posição, espécimes, segurança materno-neonatal, recuperação e resposta organizada à hemorragia sem apresentar esquema terapêutico.

### Urologia

- AUA — *Surgical Management of Kidney and Ureteral Stones*, diretriz 2026;
- EAU — diretrizes online correntes de urolitíase e infecções urológicas, verificadas em 2026;
- NR-32 — exposição ocupacional e interface com radiação.

**Uso didático:** endourologia, irrigação, cultura, dispositivos, energia, posição e rastreabilidade.

### Cirurgia vascular

- ESVS — infecção de enxerto e endoprótese vascular, nova edição 2026;
- ESVS — trauma vascular, 2025;
- ESVS — doença arterial periférica, 2024;
- ACC/AHA e sociedades parceiras — manejo cardiovascular perioperatório de cirurgia não cardíaca, 2026.

**Uso didático:** sala híbrida, controle vascular, tempos, enxertos, contraste, radiação e transição de cuidados.

### Neurocirurgia e coluna

- Congress of Neurological Surgeons — risco pré-operatório em cirurgia de coluna, diretriz oficial de 2021 ainda publicada e verificada em 2026;
- CNS — manejo de adenomas hipofisários funcionantes com tópicos perioperatórios, 2025;
- ACC/AHA — risco cardiovascular perioperatório, edição 2026;
- Anvisa — prevenção de ISC 2025 e critérios 2026.

**Uso didático:** nível correto, imagem, posição, navegação, tecnologia, implantes e espécimes. Recomendações antigas são marcadas para monitoramento, não apresentadas como novidade.

### Cabeça e pescoço

- ERAS Society — consenso para cirurgia oncológica maior com reconstrução, 2017;
- revisão de vias de recuperação com transferência livre de tecido, 2024;
- ASA — diretriz de analgesia local e regional, 2026;
- Anvisa — prevenção de ISC.

**Uso didático:** via aérea compartilhada, risco de incêndio, espécimes complexos, reconstrução e handoff. O consenso de 2017 é usado como base histórica ainda citada, complementada por revisão recente.

### Torácica e cardíaca

- ERAS Cardiac Society / ERAS International / STS — consenso cardíaco, 2024;
- ERAS Society / ESTS — diretriz de recuperação após cirurgia pulmonar, 2019, ainda listada oficialmente;
- ASA — analgesia perioperatória, 2026;
- ACC/AHA — diretriz perioperatória, 2026.

**Uso didático:** posição lateral, isolamento pulmonar como comunicação, drenos, circulação extracorpórea, implantes e transferência para terapia intensiva.

### Pediatria e neonatal

- ERAS Society — recomendações de cuidado perioperatório neonatal, 2024;
- consenso ERAS de manejo não farmacológico da dor neonatal, 2025;
- APSA Pediatric Surgery NaT — recurso institucional sobre ERAS;
- Anvisa — critérios de IRAS 2026 para adultos, crianças e recém-nascidos.

**Uso didático:** termorregulação, tamanho, identificação, integração NICU–centro cirúrgico e participação familiar.

### Minimamente invasiva e robótica

- AORN — edição de diretrizes perioperatórias 2026;
- AORN Journal — cuidado em cirurgia robótica, 2026;
- FDA — rascunho de setembro de 2026 sobre dispositivos cirúrgicos roboticamente assistidos;
- AORN — energia cirúrgica e instruções de uso;
- NR-32 — segurança ocupacional.

**Atenção:** o documento da FDA é **rascunho não vinculante e ainda aberto a comentários** em 13/10/2026. Ele serve para tendências de segurança, terminologia e fatores humanos, mas não pode ser apresentado como regra final.

---

## 4. Procedimentos, acessos e antissepsia

| Documento | Ano | Uso na plataforma | Situação em 13/10/2026 |
|---|---:|---|---|
| OMS — cateteres intravasculares, parte 1 | 2024 | Acesso periférico, inserção, manutenção e remoção | Diretriz oficial atual na consulta |
| OMS — cateteres intravasculares, parte 2 | 2026 | Acesso venoso central e prevenção de infecção | Diretriz oficial publicada em 28/05/2026 |
| INS — *Infusion Therapy Standards of Practice*, 9ª ed. | 2024 | Terapia infusional e dispositivos vasculares | Edição corrente identificada; integral licenciado |
| ASA — acesso venoso central | 2020 | Preparo, assistência, barreiras e complicações | Ainda listada pela ASA; complementada pela OMS 2026 |
| ASA — via aérea difícil | 2022 | Estratégia, equipamento, resgate e handoff | Diretriz oficial vigente na consulta |
| CDC — prevenção de ITU associada a cateter | 2025 | Indicação, sistema fechado e retirada oportuna | Página oficial corrente; remete à diretriz-base |
| AORN — antissepsia pré-operatória da pele | 2026 | Pele, pelos, seleção, aplicação, secagem e fogo | Resumo público corrente; diretriz integral licenciada |

**Uso didático:** as novas aulas cobrem preparação, assistência, barreiras, vigilância, rastreabilidade e escalonamento. Punção, inserção, intubação e outros procedimentos invasivos não são ensinados como autorização para execução autônoma.

---

## 5. Mudanças que afetaram o conteúdo

1. Os critérios de IRAS passaram a apontar para a Nota Técnica Anvisa nº 03/2026, que revisa a edição de 2025.
2. A vigilância anual usa a Nota Técnica Anvisa nº 01/2026.
3. O bloco colorretal usa a atualização ERAS 2025, não a versão de 2018.
4. O bloco ginecológico usa a atualização ERAS 2026.
5. O bloco urológico usa a diretriz AUA de cálculos de 2026.
6. O bloco vascular usa a nova diretriz ESVS de infecção de enxertos de 2026.
7. O risco cardiovascular perioperatório aponta para a publicação ACC/AHA reafirmada em 2026, que formalmente substitui a publicação de 2024 sem alterar suas recomendações.
8. Cirurgia robótica distingue explicitamente diretriz vigente de rascunho regulatório.
9. Diretrizes mais antigas continuam acompanhadas de documento recente ou indicação de monitoramento.
10. Acesso periférico usa a diretriz global OMS 2024 e os padrões INS 2024.
11. Acesso central prioriza a diretriz OMS 2026, complementada pela ASA 2020 para a interface procedimental.
12. Via aérea difícil usa a atualização ASA 2022.
13. Antissepsia da pele distingue resumo público corrente de conteúdo AORN integral licenciado.

---

## 6. Controle de atualização

### Revisão programada

- busca trimestral em Anvisa, CFM, Cofen, Ministério da Saúde, AORN, ERAS, AUA, EAU, AAOS, ESVS, CNS, ASA, ACC/AHA e FDA;
- revisão extraordinária quando houver resolução, alerta de segurança, recall ou atualização de diretriz;
- registro de data, URL, documento substituído e impacto nas aulas;
- conservação da versão anterior apenas para histórico editorial.

### Regra para a plataforma

Uma fonte deve receber um destes estados:

- **Atual na consulta**;
- **Edição corrente identificada**;
- **Documento anterior ainda listado oficialmente**;
- **Complemento recente**;
- **Rascunho — não vinculante**;
- **Substituída — não usar para recomendação atual**.

A data de verificação informa quando a equipe conferiu a fonte; ela não garante que o documento continuará vigente depois dessa data.
