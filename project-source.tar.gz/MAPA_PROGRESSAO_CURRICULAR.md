# Nexo Cirúrgico — mapa de progressão curricular

**Data:** 13 de outubro de 2026  
**Escopo:** organização das 115 aulas em uma sequência recomendada  
**Estado:** implementado na rota `#/planos`

## 1. Objetivo

A ampliação para 33 trilhas resolveu lacunas de conteúdo, mas tornou necessária uma sequência explícita. O mapa organiza todas as trilhas e aulas uma única vez, evitando que o estudante entre em especialidades antes de dominar barreiras, dispositivos e comunicação.

A sequência é recomendada, não bloqueada. Instituições e preceptores podem adaptar a ordem ao perfil da turma, desde que preservem pré-requisitos clínicos e prática supervisionada.

## 2. Visão global

| Etapa | Trilhas | Aulas | Minutos | Competências vinculadas |
|---|---:|---:|---:|---|
| 01 — Fundamentos seguros | 14 | 40 | 689 | C01–C12 |
| 02 — Prática perioperatória ampliada | 9 | 35 | 658 | C13–C18 |
| 03 — Especialidades cirúrgicas P2 | 10 | 40 | 721 | C19–C28 |
| **Total** | **33** | **115** | **2.068** | **C01–C28** |

## 3. Etapa 01 — Fundamentos seguros

### Trilhas

1. Instrumentais cirúrgicos;
2. Fios e suturas;
3. Posicionamento cirúrgico;
4. Assepsia e segurança;
5. Anatomia aplicada;
6. Fluxo de procedimentos;
7. Ambiente e equipe cirúrgica;
8. Cirurgia segura;
9. Prevenção de infecção cirúrgica;
10. Contagens e itens retidos;
11. Espécimes e implantes;
12. CME e processamento;
13. Assepsia, antissepsia e preparo da pele;
14. Procedimentos perioperatórios essenciais.

### Resultados esperados

- reconhecer barreiras essenciais de segurança;
- organizar ambiente, materiais e equipe;
- aplicar assepsia, contagens e rastreabilidade;
- executar o estudo dentro dos limites profissionais.

### Gate recomendado

Concluir as aulas e conseguir explicar as barreiras sem consultar antes de iniciar a prática ampliada.

## 4. Etapa 02 — Prática perioperatória ampliada

### Trilhas

1. Energia, fogo e fumaça;
2. Medicamentos e rotulagem;
3. Anestesia e SRPA;
4. Segurança ocupacional;
5. Documentação, ética e privacidade;
6. Eventos críticos e emergências;
7. Procedimentos e vias de acesso cirúrgico;
8. Acessos vasculares e terapia infusional;
9. Via aérea, sondas e drenos.

### Resultados esperados

- apoiar procedimentos e acessos sem extrapolar habilitação;
- reconhecer falhas, complicações e critérios de escalonamento;
- estruturar transferências e registros de dispositivos;
- integrar segurança ocupacional, energia, medicamentos e anestesia.

### Gate recomendado

Concluir os módulos e demonstrar, em cenários simulados, raciocínio de pausa, comunicação, rastreabilidade e escalonamento.

## 5. Etapa 03 — Especialidades cirúrgicas P2

### Trilhas

1. Cirurgia geral e digestiva;
2. Ortopedia e trauma;
3. Ginecologia e obstetrícia;
4. Urologia;
5. Cirurgia vascular;
6. Neurocirurgia e coluna;
7. Cabeça e pescoço;
8. Cirurgia torácica e cardíaca;
9. Cirurgia pediátrica e neonatal;
10. Cirurgia minimamente invasiva e robótica.

### Resultados esperados

- adaptar barreiras ao contexto da especialidade;
- preparar equipamentos, implantes, espécimes e dispositivos;
- reconhecer transições e planos de conversão;
- realizar handoff especializado e rastreável.

### Gate recomendado

Concluir as trilhas e revisar o desempenho formativo por competência. A prática real continua dependente de treinamento e supervisão.

## 6. Relação entre conteúdo e avaliação

As competências avaliativas C01–C28 foram distribuídas entre as três etapas. Os cinco módulos novos de procedimentos e acessos aprofundam competências existentes e não receberam um novo bloco de questões neste lote. Essa decisão preserva o equilíbrio solicitado pelo projeto:

- **115 aulas**;
- **210 questões**;
- **1,83 questão por aula**;
- simulado com apenas 20 itens sorteados por tentativa.

Os resultados continuam formativos até revisão clínica e piloto.

## 7. Implementação na interface

A rota `#/planos` apresenta:

- três etapas em sequência;
- trilhas, aulas e minutos por etapa;
- progresso calculado a partir das aulas concluídas;
- resultados esperados e gate recomendado;
- pré-requisito sugerido;
- botão para começar ou continuar a próxima aula;
- aviso de que conteúdo e avaliação têm funções diferentes.

A navegação anterior e seguinte das aulas também segue agora a ordem curricular, e não apenas a numeração de criação dos módulos.

## 8. Próximo gate

Após esta organização, permanecem como próximos passos editoriais:

1. remediação direcionada por plano e competência — entregue em `REMEDIACAO_FORMATIVA.md`;
2. arquitetura dos 28 módulos técnicos — corrigida após auditoria independente;
3. Atlas de materiais — entregue em `ATLAS_MATERIAIS_MB02.md`;
4. fichas canônicas de procedimentos fundamentais — próximo macrobloco;
5. teste contínuo de acessibilidade e responsividade;
6. revisão clínica independente e piloto ao final da produção.
